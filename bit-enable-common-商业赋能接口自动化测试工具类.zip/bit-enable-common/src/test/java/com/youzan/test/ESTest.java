package com.youzan.test;

import com.youzan.test.quickstart.utils.ESUtil;
import com.youzan.test.quickstart.utils.HttpUtil;
import com.youzan.test.quickstart.utils.LoginUtil;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;


/**
 * @author: huangyt.
 * @create: 2019-05-22 19:24
 **/
public class ESTest extends BaseTest {

    @Test
    public void test(){
        ESUtil.getById("234324","ws_team","team");

        List<Long> longs = new ArrayList<>();
        longs.add(324L);
        longs.add(46123L);
        ESUtil.getResources("crm_resource",longs);
    }

    @Test
    public void test1(){
//        LoginUtil.getKtdSessionId(1774L,"huangyuting","qd_user");
    }
}
