package com.youzan.test;

import com.youzan.test.quickstart.BaseApplication;
import org.mybatis.spring.annotation.MapperScan;


@MapperScan({"com.youzan.test.quickstart.mapper"})
public class QuickstartApplication extends BaseApplication {



}
