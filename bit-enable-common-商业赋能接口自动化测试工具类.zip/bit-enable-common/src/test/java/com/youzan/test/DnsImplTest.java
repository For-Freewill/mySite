package com.youzan.test;


import com.youzan.test.quickstart.javahost.JavaHost;
import com.youzan.test.quickstart.javahost.impl.DnsImpl;
import com.youzan.test.quickstart.javahost.model.Host;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import java.util.List;


public class DnsImplTest {

	private DnsImpl dns = new DnsImpl();

	@Test
    @Ignore
	public void update() {

		dns.update("qudao.youzan.com", "192.168.66.239");
		Assert.assertEquals("192.168.66.239", JavaHost.queryIp("qudao.youzan.com"));
		dns.remove("qudao.youzan.com");
		Assert.assertNull(JavaHost.queryIp("qudao.youzan.com"));
		Assert.assertNull(JavaHost.getIp("qudao.youzan.com"));
	}

	@Test
	public void query() {

		{
			JavaHost.queryIp("leopard.io");
			this.dns.query("leopard.io");
		}
		{
			JavaHost.queryIp("baidu.com");
			this.dns.query("baidu.com");
		}
		{
			dns.update("javahost.leopard.io", "127.0.0.1");
			JavaHost.queryIp("javahost.leopard.io");
			this.dns.query("javahost.leopard.io");
		}
		{
			JavaHost.queryIp("leopard2e.leopard.io");
			this.dns.query("leopard2e.leopard.io");
		}
	}

	@Test
	public void list() {
		dns.update("javahost.leopard.io", new String[] { "127.0.0.1", "127.0.0.2" });
		List<Host> list = dns.list("javahost.leopard.io");
		System.out.println("######虚拟DNS记录#######");
		for (Host host : list) {
			System.out.println(host);
		}
		System.out.println("######ping#######");
		for (int i = 0; i < 20; i++) {
			String ip = JavaHost.queryIp("javahost.leopard.io");
			String ip2 = JavaHost.getIp("javahost.leopard.io");
			System.out.println("ping host:javahost.leopard.io" + " 返回的ip:" + ip + " ip2:" + ip2);
		}
	}

	@Test
	public void test() {
	}

}