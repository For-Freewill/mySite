package com.youzan.test;

import com.alibaba.fastjson.JSONObject;
import com.youzan.test.quickstart.BaseApplication;
import com.youzan.test.quickstart.entity.Resource;
import com.youzan.test.quickstart.invoker.AnnotationListener;
import com.youzan.test.quickstart.utils.LoginUtil;
import com.youzan.test.quickstart.utils.PropertyUtil;
import com.youzan.test.quickstart.utils.SCUtil;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;

import java.util.Properties;


/**
 * @Author qibu
 * @create 2019/5/7 8:12 PM
 */
@SpringBootTest(classes = QuickstartApplication.class)
@Listeners(AnnotationListener.class)
public class BaseTest extends AbstractTestNGSpringContextTests {


    @BeforeTest
    public void beforeBaseTest() throws Exception {
        Properties properties = PropertyUtil.getProperties();
        String scName = properties.getProperty("env.sc");
        SCUtil.init(scName);
    }
}
