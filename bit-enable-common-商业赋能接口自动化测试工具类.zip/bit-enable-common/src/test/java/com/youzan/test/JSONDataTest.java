package com.youzan.test;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.ListResult;
import com.youzan.bitcomparecommon.aop.CompareConfig;
import com.youzan.crm.workflow.api.model.dto.pool.PoolDTO;
import com.youzan.crm.workflow.api.pool.PoolQueryService;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.test.quickstart.compare.config.CollectionCompareConfig;
import com.youzan.test.quickstart.compare.service.CompareServiceImp;
import com.youzan.test.quickstart.entity.Resource;
import com.youzan.test.quickstart.mapper.ResourcesMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * @Author qibu
 * @create 2020/9/24 9:08 PM
 */
public class JSONDataTest extends BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(JSONDataTest.class);

    @JSONData("data/resource.json")
    private Resource resource;

    @JSONData(value = "data/resourceAll.json", key = "expectResult")
    private Resource resourceExpectResult;

    @Dubbo
    PoolQueryService poolQueryService;

    @Autowired
    private CompareServiceImp compareServiceImp;

    @Autowired
    private ResourcesMapper resourcesMapper;


    @Test
    public void test() {
        logger.info("resource:{}", JSON.toJSONString(resource));
        //对比
        CollectionCompareConfig compareConfig = new CollectionCompareConfig();
        //对比前排序
        compareConfig.setJsonArrayPath("$.data");
        compareConfig.setSortKey("name");
        //忽略字段
        compareConfig.getIgnoredPaths().add("/data/id");
        CompareConfig compareConfig1 = new CompareConfig();
        compareConfig1.getIgnoredPaths().add("/data/id");
        //接口调用时会触发SC环境与稳定环境调用结果对比
        ListResult<PoolDTO> result = compareServiceImp.invoke(() -> poolQueryService.queryAssociatedUserPoolByDeptPoolId(
                81836L), compareConfig1);
        logger.info("result:{}", JSON.toJSONString(result));
        //数据库结果对比
        Resource resourceActualResult = resourcesMapper.selectById(42066);
        CompareConfig dbCompareConfig = new CompareConfig();
        dbCompareConfig.getIgnoredPaths().add("/city");
        resourceExpectResult.setStatusDesc("已激活");
        compareServiceImp.compare(resourceActualResult, resourceExpectResult, dbCompareConfig);
    }
}
