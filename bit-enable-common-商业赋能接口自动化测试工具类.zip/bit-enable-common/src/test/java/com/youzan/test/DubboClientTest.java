package com.youzan.test;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.youzan.api.common.response.ListResult;
import com.youzan.crm.workflow.api.model.dto.pool.PoolDTO;
import com.youzan.crm.workflow.api.pool.PoolQueryService;
import com.youzan.crm.workflow.api.test.ResourceFlowRemoteTestService;
import com.youzan.test.quickstart.annotation.DB;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.compare.config.CollectionCompareConfig;
import com.youzan.test.quickstart.compare.service.CompareServiceImp;
import com.youzan.test.quickstart.mapper.ResourcesMapper;
import com.youzan.test.quickstart.utils.DBUtil;
import com.youzan.test.quickstart.utils.HttpUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;


/**
 * @Author qibu
 * @create 2019/4/23 3:31 PM
 */
public class DubboClientTest extends BaseTest {

    private static final Logger logger = LoggerFactory.getLogger(DubboClientTest.class);


    @Autowired
    private ResourcesMapper resourcesMapper;


    @Http("cw")
    private HttpUtil httpUtil;

    @Http("kefu")
    private HttpUtil kefuHttpUtil;

    @DB("cw")
    private DBUtil dbUtil;

    @Dubbo
    PoolQueryService poolQueryService;

    @Dubbo
    ResourceFlowRemoteTestService resourceFlowRemoteTestService;
    @Autowired
    private CompareServiceImp compareServiceImp;



//    @Test
    public void doInvoke2() throws Exception {
        Map map = Maps.newHashMap();
        map.put("ss","null");
        map.put("sss",null);
        map.put("page",1);
        map.put("pageSize",10);

        String a= kefuHttpUtil.doGetReturnResponse("/hotline/serviceRecord/list/v2",map);
        System.out.println(a);
//        String b= kefuHttpUtil.doGetReturnResponse("/hotline/serviceRecord/list/v2","keywordType&page=1&pageSize=10");
//        System.out.println(b);
    }

//    @Test
    public void doInvoke() throws Exception {
        Map header = Maps.newHashMap();
        String kdtsessionid = "YZ780420011042914304YZODyOdV74";
        header.put("Cookie", "KDTSESSIONID="+kdtsessionid);
        String b= httpUtil.doGetReturnResponse("/ycm/v1/activity/goodsDiscount/activity","page=1&pageSize=10",header);
        System.out.println(b);
    }

    @Test
    public void doInvoke1() throws Exception {
//        //数据库
//        dbUtil.undeleteById("resource",37218L);
//        logger.info("resultMap2:{}",JSON.toJSONString(resourcesMapper.selectById(37218L)));
//
//        Map<String, Object> resultMap = dbUtil.queryForMap("SELECT * FROM pool_bound_party WHERE `pool_id` = ? LIMIT 0, 1000;", 81836L);
//        logger.info("resultMap:{}",JSON.toJSONString(resultMap));
//
        CollectionCompareConfig config = new CollectionCompareConfig();
        config.setJsonArrayPath("$.data");
        config.setSortKey("name");
        ListResult<PoolDTO> result = compareServiceImp.invoke(()->poolQueryService.queryAssociatedUserPoolByDeptPoolId(81836L),config);
        logger.info("result:{}",JSON.toJSONString(result));
//
//        PlainResult<Boolean> result2 = resourceFlowRemoteTestService.triggerRealtimeTransfer(33432L);
//        Assert.assertTrue(result2.getData());
//        Resource resource = resourcesMapper.selectById(42066);
//        logger.info("resource:{}",JSON.toJSONString(resource));
    }


}
