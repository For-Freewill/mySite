package com.youzan.test;


import com.alibaba.fastjson.JSON;
import com.youzan.test.quickstart.entity.ResourceStatusHistory;
import com.youzan.test.quickstart.mapper.ResourceStatusHistoryMapper;
import com.youzan.test.quickstart.mapper.ResourcesMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;


public class SampleTest extends BaseTest {

    @Autowired
    private ResourcesMapper resourcesMapper;

    @Autowired
    private ResourceStatusHistoryMapper resourceStatusHistoryMapper;

    @Test
    public void testSelect() throws Exception{
        ResourceStatusHistory rsh = resourceStatusHistoryMapper.selectById(6077L);
        System.out.println("ResourceStatusHistory："+JSON.toJSONString(rsh));
        rsh.setId(null);
        System.out.println(resourceStatusHistoryMapper.insert(rsh));

        System.out.println(("----- selectAll method test ------"));
       /* //update
        Resource resource1 = new Resource();
        resource1.setId(42066L);
        resource1.setCity("武汉");
        int r = resourcesMapper.updateById(resource1);

        //select
        Resource resource = resourcesMapper.selectById(42066);

        //delete
        //resourcesMapper.deleteById(37218);

        System.out.println("before ："+JSON.toJSONString(resource));
        resource1.setCity("武汉市");
        resourcesMapper.updateById(resource1);
        System.out.println("after："+JSON.toJSONString(resourcesMapper.selectById(42066)));*/
    }
}