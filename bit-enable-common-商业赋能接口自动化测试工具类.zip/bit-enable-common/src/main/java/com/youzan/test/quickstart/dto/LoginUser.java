package com.youzan.test.quickstart.dto;

import java.io.Serializable;

import lombok.Data;


/**
 * @author: huangyt.
 * @create: 2018-08-20 12:41
 **/
@Data
public class LoginUser implements Serializable {
    private Long id;
    private Long casId;
    private Long userId;
    private String sid;
    private String nickname;
    private String realname;
    private Integer sex;
    private Integer status;
    private String casUsername;
    private Long mobile;
    private String email;
    private String avatar;
    private Integer departmentId;
    private Long oaId;
    private String positionName;
    private Boolean isAdmin;
}
