package com.youzan.test.quickstart.invoker;

import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.test.quickstart.utils.*;

import java.lang.reflect.Field;

/**
 * @Author qibu
 * @create 2020/9/24 8:32 PM
 */
public class JSONInvoker {


    public static void jsonInvokeAnnotation(Field f, Object instance) {
        JSONData jsonDataAnnotation = f.getAnnotation(JSONData.class);
        f.setAccessible(true);
        try {
            if (f.get(instance) != null) {
                return;
            }
            Object oo = JsonUtil.getObjectFromFile(jsonDataAnnotation.value(),jsonDataAnnotation.key(),f);
            f.set(instance, oo);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
