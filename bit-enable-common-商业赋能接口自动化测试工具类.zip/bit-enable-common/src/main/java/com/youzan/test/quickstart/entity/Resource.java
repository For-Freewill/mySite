package com.youzan.test.quickstart.entity;

import lombok.Data;

import java.util.Date;

/**
 * 资源主表
 */
@Data
public class Resource extends SuperEntity{

    /**
     * 绑定当前资源池后的第一次拜访时间
     */
    private Date bindFirstVisitTime;
    /**
     * 绑定当前资源池后的最近一次拜访时间
     */
    private Date bindLastVisitTime;
    /**
     * 绑定当前资源池后的拜访次数
     */
    private Integer bindVisitCount;
    /**
     * 绑定时间
     */
    private Date boundTime;
    /**
     * 资源所属区域-市
     */
    private String city;
    /**
     * 市-码
     */
    private Long cityId;
    /**
     * 资源所属区域-区
     */
    private String county;
    /**
     * 区-码
     */
    private Long countyId;
    /**
     * 客户ID
     */
    private Long customerId;
    /**
     * 客户表和聚合表变更通知资源标志字段，给dts用的,毫秒级时间戳
     */
    private Long customerTouchSign;
    /**
     * 资源是否延期流出（永久有效）
     */
    private Integer deffered;
    /**
     * 首次激活时间
     */
    private Date firstActivationTime;
    /**
     * 第一次拜访时间
     */
    private Date firstVisitTime;
    /**
     * 资源在当前资源池中的关注等级
     */
    private Integer focusLevel;
    /**
     * 资源当前跟进阶段
     */
    private String followStage;
    /**
     * 最近一次激活时间
     */
    private Date lastActivationTime;
    /**
     * 最近拜访时间
     */
    private Date lastVisitTime;
    /**
     * 生命周期版本
     */
    private Integer lifecycleVersion;
    /**
     * 资源池ID
     */
    private Long poolId;
    /**
     * 资源池名
     */
    private String poolName;
    /**
     * 资源池类型
     */
    private Integer poolType;
    /**
     * 资源所属SOP阶段的前N个SOP阶段名列表(long) [111,222,333]
     */
    private String prevSopStageBindingDepts;
    /**
     * 资源所属SOP阶段的前N个SOP阶段名列表(string) [type1:user1, type2:user2]
     */
    private String prevSopStageBindingUsers;
    /**
     * 资源所属SOP阶段的前N个SOP阶段名列表 JSON数组(string) [name1, name2]
     */
    private String prevSopStageNames;
    /**
     * 资源类型-产品线
     */
    private Long prodLine;
    /**
     * 资源所属区域-省
     */
    private String province;
    /**
     * 省-码
     */
    private Long provinceId;
    /**
     * 释放时间
     */
    private Date releaseTime;
    /**
     * 资源类型-SOP阶段
     */
    private String sopStage;
    /**
     * sop阶段-版本
     */
    private Integer sopStageVersion;
    /**
     * 资源状态[1:沉睡,10:已转化,20:激活中]
     */
    private Integer status;
    /**
     * 资源状态描述
     */
    private String statusDesc;
    /**
     * 流转说明-流转原因标签
     */
    private String transferredReasonTag;
    /**
     * 流转说明-流转原因标签Id
     */
    private Long transferredReasonTagId;
    /**
     * 总拜访次数
     */
    private Integer visitCount;
}
