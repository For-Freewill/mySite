package com.youzan.test.quickstart.invoker;

import ch.qos.logback.core.util.StringCollectionUtil;
import com.alibaba.dubbo.config.model.ApplicationModel;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.utils.DubboUtil;
import com.youzan.test.quickstart.utils.PropertyUtil;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.lang.reflect.Field;
import java.util.Properties;


/**
 * @Author qibu
 * @create 2019/5/7 10:30 AM
 */
public class DubboInvoker {


    public static void dubboInvokeAnnotation(Field f,Object instance){
        Dubbo dubboAnnotation = f.getAnnotation(Dubbo.class);
        Class ft = f.getType();
        f.setAccessible(true);
        try {
            if (f.get(instance) != null) {
                return;
            }
            String urlPrimary = dubboAnnotation.url();
            if(StringUtils.isEmpty(urlPrimary)){
                urlPrimary = PropertyUtil.get("dubbo.url.primary");
            }
            Assert.assertTrue(StringUtils.isNotEmpty(urlPrimary),"dubbo.url.primary 不能为空！");
//            String key = "dubbo_"+urlPrimary+"_"+ ft.getName() ;
//
//            if (EntityCache.isExist(key)) {
//                f.set(instance, EntityCache.get(key));
//            }else{
//                Object oo = DubboUtil.getReference(ft, urlPrimary,dubboAnnotation.timeout());
//                f.set(instance, oo);
//                EntityCache.set(key, oo);
//            }
            Object oo = DubboUtil.getReference(ft, urlPrimary,dubboAnnotation.timeout());
            f.set(instance, oo);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
