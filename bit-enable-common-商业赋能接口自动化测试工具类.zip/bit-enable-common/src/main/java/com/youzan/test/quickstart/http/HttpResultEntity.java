package com.youzan.test.quickstart.http;

import org.apache.http.cookie.Cookie;

import java.util.List;


/**
 * @author qibu
 */
public class HttpResultEntity {
	
	private String responseString;
	
	private List<Cookie> cookies;

	public String getResponseString() {
		return responseString;
	}

	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	public List<Cookie> getCookies() {
		return cookies;
	}

	public void setCookies(List<Cookie> cookies) {
		this.cookies = cookies;
	}
}
