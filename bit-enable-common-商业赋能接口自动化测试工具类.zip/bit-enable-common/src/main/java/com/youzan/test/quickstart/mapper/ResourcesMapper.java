package com.youzan.test.quickstart.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.test.quickstart.entity.Resource;

@DS("cw")
public interface ResourcesMapper extends BaseMapper<Resource> {

}
