package com.youzan.test.quickstart.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.youzan.bigdata.essync.dto.DocMeta;
import com.youzan.bigdata.essync.dto.ESDoc;
import com.youzan.bigdata.essync.dto.ESResult;
import com.youzan.bigdata.essync.dto.GetResponse;
import com.youzan.bigdata.essync.dto.GetResult;
import com.youzan.bigdata.essync.service.GetService;
import com.youzan.bigdata.essync.service.SyncService;
import com.youzan.bigdata.search.dto.SearchResult;
import com.youzan.bigdata.search.service.SearchService;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;


/**
 * @author: huangyt.
 * @create: 2019-05-21 10:40
 * es操作的工具类
 **/
public  class  ESUtil {

    private static Logger logger = LoggerFactory.getLogger(ESUtil.class);

    static {
        ESUtil.init();
    }

    private static void init(){
        syncService = DubboUtil.getReference(SyncService.class);
        getService = DubboUtil.getReference(GetService.class);
        searchService = DubboUtil.getReference(SearchService.class);
    }

    private static SyncService syncService;

    private static GetService getService;

    private static SearchService searchService;

    /**
     *  根据id删除一个文档
     */
    public  static boolean deleteById(String id,String index,String type){
        ESDoc doc = new ESDoc();
        DocMeta meta = new DocMeta();
        meta.setIndex(index);
        meta.setType(type);
        meta.setId(id);
        doc.setMetaData(meta);
        ESResult result = syncService.deleteDoc(doc); // 调用delete方法，获取结果
        if (result.getCode() != 0) {
            logger.error("delete fail,id:{},index:{},type:{}",id,index,type); // 进行错误处理
            return false;
        }
        return true;
    }


    /**
     * 根据id获取一个文档
     * @param id 主键id
     * @param index 索引
     * @param type 文档
     * @return
     */
    public static GetResult getById(String id,String index,String type){
        GetResponse result = getService.getDoc(index, type, id, ""); // 调用get方法，获取结果
        if (result.getCode() != 0) {
            logger.error("delete fail,id:{},index:{},type:{}",id,index,type); // 进行错误处理
            return null;
        }
        return result.getResponse();
    }


    /**
     * 往某索引中插入一个文档
     * @param index
     * @param type
     * @param id
     * @param source
     * @return
     */
    public static  boolean  createTeamEs(String index,String type,String id,Map<String, Object> source){
        ESDoc doc = new ESDoc();
        DocMeta meta = new DocMeta();
        meta.setIndex(index);
        meta.setType(type);
        meta.setId(id);

        doc.setMetaData(meta);
        doc.setDoc(source);

        ESResult result = syncService.indexDoc(doc);
        if (result.getCode() != 0) {
            logger.error("failed"); // 进行错误处理
            return false;
        }
        return true;
    }

    public static boolean getResources(String index,List<Long> resourceIdList){
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

        BoolQueryBuilder builder = new BoolQueryBuilder();
        builder.must(QueryBuilders.termsQuery("resource_id",resourceIdList));

        searchSourceBuilder.query(builder);
        JSONObject jsonObject = JSON.parseObject(searchSourceBuilder.toString());

        SearchResult searchResult = searchService.search(index, jsonObject.toJSONString());
        if (searchResult.getHits().getHits() == null || searchResult.getHits().getTotalHits() != resourceIdList.size()){
            logger.info("es-searchFromWsTeam返回数据："+searchResult.getHits().getHits());
            return false;
        }
        return true;

    }

}
