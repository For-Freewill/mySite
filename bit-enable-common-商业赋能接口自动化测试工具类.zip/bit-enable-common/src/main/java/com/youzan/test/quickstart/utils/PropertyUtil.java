package com.youzan.test.quickstart.utils;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;

import java.util.Properties;


/**
 * @Author qibu
 * @create 2019/5/16 11:13 AM
 */
public class PropertyUtil {
    private static Properties properties;

    static {
        properties = getProperties("application.yml");
    }

    public static Properties getProperties() {
        return properties;
    }

    public static Properties getProperties(String fileName) {
        PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource(fileName));//class路径引入
        configurer.setProperties(yaml.getObject());
        return yaml.getObject();
    }

    public static String get(String key){
        return properties.getProperty(key);
    }

}
