package com.youzan.test.quickstart.compare.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.jayway.jsonpath.JsonPath;
import com.youzan.bitcomparecommon.aop.CompareConfig;
import com.youzan.bitcomparecommon.aop.CompareUtil;
import com.youzan.bitcomparecommon.aop.EnvironmentSetting;
import com.youzan.test.quickstart.compare.config.CollectionCompareConfig;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * @Author qibu
 * @create 2019/9/18 10:20 AM
 */
@Component
public class CompareServiceImp {

    @Resource
    private EnvironmentSetting environmentSetting;

    public <T> T invoke(Supplier<T> serviceMethod) {
        CompareConfig config = new CompareConfig();
        return compare(serviceMethod, config);
    }

    public <T> T invoke(Supplier<T> serviceMethod, CompareConfig compareConfig) {
        return compare(serviceMethod, compareConfig);
    }

    public void compare(Object actualResult,Object expectResult){
        compare(actualResult,expectResult,new CompareConfig());
    }

    public void compare(Object actualResult,Object expectResult,CompareConfig compareConfig){
        if(null == compareConfig){
            compareConfig = new CompareConfig();
        }
        CompareUtil.projectRequestCompare(actualResult, expectResult, compareConfig);
    }

    private <T> T compare(Supplier<T> serviceMethod, CompareConfig compareConfig) {
        //如果走基础环境，则直接返回结果，默认不校验
        if (environmentSetting.isBasicRequest()) {
            return serviceMethod.get();
        }
        if (null == compareConfig) {
            compareConfig = new CompareConfig();
        }
        try {
            //走基础环境
            environmentSetting.handelBasicRequest();
            T baseResult1 = serviceMethod.get();
            environmentSetting.handelBasicRequest();
            T baseResult2 = serviceMethod.get();
            //走项目环境
            environmentSetting.handelProjectRequest();
            T projectResult = serviceMethod.get();
            if (compareConfig instanceof CollectionCompareConfig) {
                compareWithJSONArray(projectResult,baseResult1,baseResult2, (CollectionCompareConfig) compareConfig);
            }else {
                //将基础环境中值不同的字段自动加入忽略
                CompareUtil.BaseRequestCompare(baseResult1, baseResult2, compareConfig);
                CompareUtil.projectRequestCompare(projectResult, baseResult2, compareConfig);
            }
            return projectResult;
        } finally {//保证方法执行完后环境能切换到项目环境
            environmentSetting.handelProjectRequest();
        }
    }

    public Object sortJSONArray(Object result,String jsonPath,String sortKey){
        try {
            String resultStr = JSON.toJSONString(result);
            JSONArray jsonArray = JSON.parseArray(JSON.toJSONString(JsonPath.read(resultStr, jsonPath)));
            if (CollectionUtils.isNotEmpty(jsonArray)) {
                jsonArray = sort(jsonArray, sortKey, false);
                resultStr = JsonPath.parse(resultStr).set(jsonPath, jsonArray).jsonString();
                return JSON.parseObject(resultStr, result.getClass());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private void compareWithJSONArray(Object projectResult, Object baseResult1, Object baseResult2, CollectionCompareConfig compareConfig) {
        String jsonPath = compareConfig.getJsonArrayPath();
        String sortKey = compareConfig.getSortKey();
        if(StringUtils.isNotEmpty(jsonPath)){
            projectResult = sortJSONArray(projectResult,jsonPath,sortKey);
            baseResult1 = sortJSONArray(baseResult1,jsonPath,sortKey);
            baseResult2 = sortJSONArray(baseResult2,jsonPath,sortKey);
        }
        CompareUtil.BaseRequestCompare(baseResult1, baseResult2, compareConfig);
        CompareUtil.projectRequestCompare(projectResult, baseResult2, compareConfig);
    }

    /**
     * 对json数组排序，
     *
     * @param jsonArr
     * @param sortKey 排序关键字
     * @param isDesc  is_desc-false升序列  is_desc-true降序 (排序字段为字符串)
     * @return
     */
    private JSONArray sort(JSONArray jsonArr, String sortKey, boolean isDesc) {
        //存放排序结果json数组
        JSONArray sortedJsonArray = new JSONArray();
        //用于排序的list
        List<JSONObject> jsonValues = new ArrayList<JSONObject>();
        //将参数json数组每一项取出，放入list

        if(StringUtils.isEmpty(sortKey)){//[1,5,7,3]这种类型JSONArray，不支持升序跟降序
            List<Object> jsonlist = jsonArr.toJavaList(Object.class).stream().sorted().collect(Collectors.toList());
            return JSONArray.parseArray(JSON.toJSONString(jsonlist));
        }else{
            jsonValues = JSONObject.parseArray(jsonArr.toJSONString(), JSONObject.class);
            Collections.sort(jsonValues, new Comparator<JSONObject>() {
                //排序字段
                private final String KEY_NAME = sortKey;
                //重写compare方法
                @Override
                public int compare(JSONObject a, JSONObject b) {
                    String valA = new String();
                    String valB = new String();
                    try {
                        valA = a.getString(KEY_NAME);
                        valB = b.getString(KEY_NAME);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    //是升序还是降序
                    if (isDesc) {
                        return -valA.compareTo(valB);
                    } else {
                        return -valB.compareTo(valA);
                    }

                }
            });
        }
        //快速排序，重写compare方法，完成按指定字段比较，完成排序
        //将排序后结果放入结果jsonArray
        for (int i = 0; i < jsonArr.size(); i++) {
            sortedJsonArray.add(jsonValues.get(i));
        }
        return sortedJsonArray;
    }

}
