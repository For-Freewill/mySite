package com.youzan.test.quickstart.utils;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ConsumerConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.model.ApplicationModel;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;

import com.youzan.test.quickstart.invoker.EntityCache;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.util.Properties;


/**
 * @Author qibu
 * @create 2019/5/16 3:23 PM
 */
public class DubboUtil {
    private static ApplicationConfig application = new ApplicationConfig();


    public static synchronized <T> T getReference(Class<T> service, String urlPrimary,int timeout) {
        String key = "dubbo_"+urlPrimary+"_"+ service.getName() ;
        if (EntityCache.isExist(key)) {
            return (T)EntityCache.get(key);
        }
        String appName = PropertyUtil.get("dubbo.application.name");
        appName = StringUtils.isEmpty(appName)?"bit-enable":appName;
        application.setName(appName);
        ReferenceConfig<T> reference = new ReferenceConfig<>();
        reference.setApplication(application);
        reference.setProtocol("dubbo");
        reference.setInterface(service);
        //设置url
        if(StringUtils.isEmpty(urlPrimary)){
            urlPrimary = PropertyUtil.get("dubbo.url.primary");
        }
        Assert.assertTrue(StringUtils.isNotEmpty(urlPrimary),"dubbo.url.primary 不能为空！");
        String url= PropertyUtil.get("dubbo.url."+urlPrimary);
        Assert.assertTrue(StringUtils.isNotEmpty(url),"dubbo.url."+urlPrimary+" 找不到对应的值！");
        reference.setUrl(url);
        reference.setTimeout(timeout);
        T ref = reference.get();
        EntityCache.set(key,ref);
        return ref;
    }

    public static synchronized <T> T getReference(Class<T> service) {
        String  urlPrimary = PropertyUtil.get("dubbo.url.primary");
        String key = "dubbo_"+urlPrimary+"_"+ service.getName() ;
        if (EntityCache.isExist(key)) {
            return (T)EntityCache.get(key);
        }
        String appName = PropertyUtil.get("dubbo.application.name");
        appName = StringUtils.isEmpty(appName)?"bit-enable":appName;
        application.setName(appName);
        ReferenceConfig<T> reference = new ReferenceConfig<>();
        reference.setApplication(application);
        reference.setProtocol("dubbo");
        reference.setInterface(service);
        //设置url
        Assert.assertTrue(StringUtils.isNotEmpty(urlPrimary),"dubbo.url.primary 不能为空！");
        String url= PropertyUtil.get("dubbo.url."+urlPrimary);
        Assert.assertTrue(StringUtils.isNotEmpty(url),"dubbo.url."+urlPrimary+" 找不到对应的值！");
        reference.setUrl(url);
        reference.setTimeout(3000);
        T ref = reference.get();
        EntityCache.set(key,ref);
        return ref;
    }

}
