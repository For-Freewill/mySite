package com.youzan.test.quickstart.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.test.quickstart.entity.Resource;
import com.youzan.test.quickstart.entity.ResourceStatusHistory;

@DS("cw")
public interface ResourceStatusHistoryMapper extends BaseMapper<ResourceStatusHistory> {

}
