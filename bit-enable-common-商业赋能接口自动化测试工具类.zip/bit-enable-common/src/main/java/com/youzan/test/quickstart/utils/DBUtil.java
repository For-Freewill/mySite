package com.youzan.test.quickstart.utils;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;


/**
 * DB Class
 *
 * @author qibu
 */
public class DBUtil {
    private QueryRunner queryRunner = new QueryRunner();
    private String driveClassName;
    private String url;
    private String username;
    private String password;
    private Connection conn;

    public DBUtil(String driveClassName, String url, String username, String password) {
        this.driveClassName = driveClassName;
        this.url = url;
        this.username = username;
        this.password = password;
        connection();
    }


    /**
     * 数据库连接
     *
     * @return
     */
    public void connection() {
        try {
            Class.forName(this.driveClassName).newInstance();
            conn = DriverManager.getConnection(this.url,
                    this.username, this.password);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("数据库连接失败！");
        }
    }

    /**
     * 关闭Connection
     */
    public void closeConnection() {
        try {
            if (conn != null && conn.isValid(0)) {
                conn.close();
                conn = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 通过id恢复逻辑删除数据
     * @param tableName
     * @param id
     * @return
     */
    public boolean undeleteById(String tableName, Long id) {
        Assert.assertTrue(StringUtils.isNotEmpty(tableName), "table name 不能为空！");
        Assert.assertNotNull(id, "id 不能为空！");
        String sql = "update " + tableName + " set deleted_at = '1970-01-01 08:00:00' where id = ?";
        return update(sql, id) != 0 ? true : false;
    }

    /**
     * 查询一行多列记录，将结果封装成一个Map，key为字段名，value为字段值
     *
     * @param sql
     * @param params
     * @return
     */
    public Map<String, Object> queryForMap(String sql, Object... params) {
        Map<String, Object> result = null;
        try {
            result = queryRunner.query(conn, sql, new MapHandler(), params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 查询多行多列记录，将结果列表中的每一行封装成一个Map，key为字段名，value为字段值
     *
     * @param sql
     * @param params
     * @return
     */
    public List<Map<String, Object>> queryForMapList(String sql, Object... params) {
        List<Map<String, Object>> result = null;
        try {
            result = queryRunner.query(conn, sql, new MapListHandler(), params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 查询多行一列数据
     *
     * @param <T>
     * @param sql
     * @param params
     * @return
     */
    public <T> List<T> queryForObjectList(String sql, Class<T> c, Object... params) {
        List<T> result = null;
        try {
            result = queryRunner.query(conn, sql, new ColumnListHandler<T>(), params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 查询单个值
     *
     * @param <T>
     * @param sql
     * @param params
     * @return
     */
    public <T> T queryForObject(String sql, Class<T> c, Object... params) {
        T result = null;
        try {
            result = queryRunner.query(conn, sql, new ScalarHandler<T>(), params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 插入
     *
     * @param sql
     * @param params
     * @return
     */
    public void insert(String sql, Object... params) {
        try {
            queryRunner.update(conn, sql, params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 插入(返回主键)
     *
     * @param sql
     * @param params
     * @return
     */
    public Object insertReturnPK(String sql, Object... params) {
        try {
            return queryRunner.insert(conn, sql, new ScalarHandler<Object>(), params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 批量插入
     *
     * @param sql
     * @param params
     * @return
     */
    public Object insertBatch(String sql, Object[][] params) {
        try {
            return queryRunner.batch(conn, sql, params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 更新
     *
     * @param sql
     * @param params
     * @return
     */
    public int update(String sql, Object... params) {
        try {
            return queryRunner.update(conn, sql, params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 批量更新
     *
     * @param sql
     * @param params
     * @return
     */
    public void updateBatch(String sql, Object[][] params) {
        try {
            queryRunner.batch(conn, sql, params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     * 关闭PreparedStatement
     */
    public void closePreparedStatement(PreparedStatement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
                stmt = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 关闭Connection 和 Statement
     *
     * @param stmt
     */
    public void close(PreparedStatement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
                stmt = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
                conn = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public PreparedStatement prepareStatement(String sql) {
        try {
            return conn.prepareStatement(sql);
        } catch (SQLException e) {
            return null;
        }
    }

    private ThreadLocal<PreparedStatement> threadLocal = null;
    private ThreadLocal<Short> threadLocal_cnt = null;

    /**
     * 批量操作准备
     *
     * @param sql
     */
    public void batchPrepare(final String sql) {
        if (threadLocal == null) {
            threadLocal = new ThreadLocal<PreparedStatement>() {
                @Override
                protected PreparedStatement initialValue() {
                    try {
                        return conn != null ? conn.prepareStatement(sql) : null;
                    } catch (SQLException e) {
                        return null;
                    }
                }
            };
        }
    }

    /**
     * 设置参数
     *
     * @param params
     */
    public void batchAdd(Object... params) {
        try {
            if (threadLocal != null) {
                PreparedStatement stmt = threadLocal.get();
                for (int i = 0; i < params.length; i++) {
                    if (params[i] != null) {
                        stmt.setObject(i + 1, params[i]);
                    } else {
                        stmt.setNull(i + 1, Types.VARCHAR);
                    }
                }
                stmt.addBatch();

                Short cnt = threadLocal_cnt.get();
                threadLocal_cnt.set(++cnt);
                if (cnt % 100 == 0) {
                    stmt.executeBatch();
                    stmt.clearBatch();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 批量执行并且关闭连接
     */
    public void batchExecuteAndClose() {
        try {
            if (threadLocal != null) {
                PreparedStatement stmt = threadLocal.get();
                stmt.executeBatch();
                stmt.clearBatch();
                stmt.closeOnCompletion();
                stmt = null;
                threadLocal.remove();
                threadLocal = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
