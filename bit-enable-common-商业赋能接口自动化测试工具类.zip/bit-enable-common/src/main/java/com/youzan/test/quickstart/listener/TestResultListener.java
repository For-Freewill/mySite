package com.youzan.test.quickstart.listener;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IResultMap;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import java.util.Set;

/**
 * @Author qibu
 * @create 2020/10/28 12:36 PM
 */
public class TestResultListener extends TestListenerAdapter {

    private static Logger logger = LoggerFactory.getLogger(TestResultListener.class);

    @Override
    public void onTestSuccess(ITestResult tr) {
        super.onTestSuccess(tr);
        logger.info(tr.getName() + " Success");
    }

    @Override
    public void onTestFailure(ITestResult tr) {
        super.onTestFailure(tr);
        logger.info(tr.getName() + " Failure");
    }

    @Override
    public void onTestSkipped(ITestResult tr) {
        super.onTestSkipped(tr);
        logger.info(tr.getName() + " Skipped");
    }

    /**
     *重试执行的用例，如果失败会记录到跳过（skipped）里面,需要去掉
     * @param testContext
     */
    @Override
    public void onFinish(ITestContext testContext) {
        super.onFinish(testContext);
        IResultMap failTests = testContext.getFailedTests();
        IResultMap passTests = testContext.getPassedTests();
        Set<ITestResult> skipTests = testContext.getSkippedTests().getAllResults();
        // Eliminate the repeat methods
        skipTests.removeIf(e-> CollectionUtils.isNotEmpty(failTests.getResults(e.getMethod()))
                ||CollectionUtils.isNotEmpty(passTests.getResults(e.getMethod())));
    }

}
