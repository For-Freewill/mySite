package com.youzan.test.quickstart.invoker;

import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import com.youzan.test.quickstart.utils.LoginUtil;
import com.youzan.test.quickstart.utils.PropertyUtil;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.lang.reflect.Field;
import java.util.Properties;


/**
 * @Author qibu
 * @create 2019/5/28 7:20 PM
 */
public class HttpInvoker {
    private final static String qudaoStorekey ="qd_user";
    private final static String youzanStorekey ="yz_user";

    public static void httpInvokeAnnotation(Field f, Object instance) {
        Http httpAnnotation = f.getAnnotation(Http.class);
        Properties properties = PropertyUtil.getProperties();
        String primary = StringUtils.isNotEmpty(httpAnnotation.value()) ? httpAnnotation.value() : properties.getProperty("http.primary");
        Assert.assertTrue(StringUtils.isNotEmpty(primary), "没有指定要连接的站点！");
        String domain = properties.getProperty("http.site." + primary + ".domain");
        String casid = properties.getProperty("http.site." + primary + ".casid");
        String username = properties.getProperty("http.site." + primary + ".username");
        String storekey = properties.getProperty("http.site." + primary + ".storekey");
        String departmentId = properties.getProperty("http.site." + primary + ".departmentId");
        String email = properties.getProperty("http.site." + primary + ".email");
        Assert.assertTrue( StringUtils.isNotEmpty(domain), "无法找到站点 " + primary + " 的连接信息！");
        Assert.assertTrue( domain.startsWith("http"), "测试站点 " + primary + " 的domain必须以http开头！");
        Class ft = f.getType();
        f.setAccessible(true);
        try {
            if (f.get(instance) != null) {
                return;
            }
            String key = "http_"+primary+"_"+ ft.getName() ;
            if (EntityCache.isExist(key)) {
                f.set(instance, EntityCache.get(key));
            }else{
                if(StringUtils.isNotEmpty(casid)&&StringUtils.isNotEmpty(username)){
                    String ktdSessionId = "";
                    String sessionId = "";
                    if(StringUtils.isNotEmpty(storekey)&&storekey.equals(qudaoStorekey)){
                        sessionId = LoginUtil.getKtdSessionId(casid,username,youzanStorekey,departmentId,email,"");
                    }
                    ktdSessionId = LoginUtil.getKtdSessionId(casid,username,storekey,departmentId,email,sessionId);
                    Assert.assertNotNull(ktdSessionId,"无法获取 ktdSessionId！");
                    Object oo = new HttpUtil(domain,ktdSessionId,sessionId);
                    f.set(instance, oo);
                    EntityCache.set(key,oo);
                }else{
                    Object oo = new HttpUtil(domain);
                    f.set(instance, oo);
                    EntityCache.set(key,oo);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
