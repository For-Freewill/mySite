package com.youzan.test.quickstart.invoker;

import com.youzan.test.quickstart.annotation.DB;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.Http;

import com.youzan.test.quickstart.annotation.JSONData;
import org.testng.IClassListener;
import org.testng.IMethodInstance;
import org.testng.ITestClass;
import org.testng.TestListenerAdapter;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * @Author qibu
 * @create 2019/5/7 11:02 AM
 */
public class AnnotationListener extends TestListenerAdapter implements IClassListener {


    @Override
    public void onBeforeClass(ITestClass iTestClass, IMethodInstance iMethodInstance) {
        initService(iMethodInstance);
    }

    @Override
    public void onAfterClass(ITestClass iTestClass, IMethodInstance iMethodInstance) {

    }

    public void initService(IMethodInstance iMethodInstance) {
        Object instance = iMethodInstance.getMethod().getInstance();
        Class instanceClass = instance.getClass();
        Field[] fs = getAllField(instanceClass);
        for (Field f : fs) {
            if (f.isAnnotationPresent(Dubbo.class)) {
                DubboInvoker.dubboInvokeAnnotation(f,instance);
            } else if (f.isAnnotationPresent(DB.class)) {
                DBInvoker.dbInvokeAnnotation(f,instance);
            }else if (f.isAnnotationPresent(Http.class)) {
                HttpInvoker.httpInvokeAnnotation(f,instance);
            }else if (f.isAnnotationPresent(JSONData.class)){
                JSONInvoker.jsonInvokeAnnotation(f,instance);
            }

        }
    }

    private Field[] getAllField(Class instanceClass){
        List<Field> fieldList = new ArrayList<>();
        while (instanceClass != null){
            fieldList.addAll(new ArrayList<>(Arrays.asList(instanceClass.getDeclaredFields())));
            instanceClass = instanceClass.getSuperclass();
        }
        Field[] fields = new Field[fieldList.size()];
        fieldList.toArray(fields);
        return fields;
    }
}
