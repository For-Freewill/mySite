package com.youzan.test.quickstart.utils;

import com.youzan.platform.service_chain.Constants;
import com.youzan.platform.service_chain.ServiceChainContainer;
import com.youzan.platform.service_chain.context.ServiceChainContext;
import com.youzan.platform.service_chain.interceptor.ServiceChainInterceptorUtil;
import com.youzan.test.quickstart.http.HttpConstant;

import javassist.ClassClassPath;
import javassist.ClassPool;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ReflectionUtils;
import org.testng.Assert;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


/**
 * @Author qibu
 * @create 2019/5/16 4:07 PM
 */
public class SCUtil {

    public static void init(String sc) {
        setHttpServiceChain(sc);
//        setNsqServiceChain(sc);
        setDubboServiceChain(sc);
    }

    public static void setDubboServiceChain(String sc) {
        Assert.assertTrue(StringUtils.isNotEmpty(sc), "sc 不能为空！");
        Map serviceChain = new HashMap<String, Object>();
        serviceChain.put(Constants.SERVICE_CHAIN_NAME, sc);
        ServiceChainContext.setInvocationServiceChainContext(serviceChain);
    }

    @SneakyThrows
    public static void setNsqServiceChain(String sc) {
        ClassPool pool = ClassPool.getDefault();
        pool.insertClassPath(new ClassClassPath(ServiceChainInterceptorUtil.class));
        Method interceptNsqClientMethod = Arrays.stream(ReflectionUtils.getAllDeclaredMethods(ServiceChainInterceptorUtil.class))
                .filter(it -> "interceptNsqClient".equals(it.getName()))
                .findFirst()
                .orElse(null);

        if (interceptNsqClientMethod != null) {
            interceptNsqClientMethod.setAccessible(true);
            interceptNsqClientMethod.invoke(ServiceChainInterceptorUtil.class, pool);
        }
    }

    public static void setHttpServiceChain(String sc){
        if(StringUtils.isNotEmpty(sc)){
            HttpConstant.SC_HEADER_VALUE= "{\"name\":\""+sc+"\"}";
        }
    }
}
