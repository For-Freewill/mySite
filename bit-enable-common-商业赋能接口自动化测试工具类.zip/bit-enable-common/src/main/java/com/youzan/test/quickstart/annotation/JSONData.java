package com.youzan.test.quickstart.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @Author qibu
 * @create 2020/9/24 7:47 PM
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface JSONData {
    String key() default "";

    /**
     * json文件在resource目录下的路径path
     * @return
     */
    String value();
}
