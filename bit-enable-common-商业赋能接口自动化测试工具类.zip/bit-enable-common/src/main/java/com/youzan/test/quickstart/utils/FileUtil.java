package com.youzan.test.quickstart.utils;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;

/**
 * @Author qibu
 * @create 2020/9/25 10:44 AM
 */
public class FileUtil {

    public static String getStr(String filePath) {
        try {
            //filePath:resource目录的相对路径
            Resource resource = new ClassPathResource(filePath);
            Reader reader = new InputStreamReader(new FileInputStream(resource.getFile()));
            StringBuffer stringBuffer = new StringBuffer();
            int position = 0;
            while ((position = reader.read()) != -1) {
                stringBuffer.append((char) position);
            }
            reader.close();
            return stringBuffer.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

}
