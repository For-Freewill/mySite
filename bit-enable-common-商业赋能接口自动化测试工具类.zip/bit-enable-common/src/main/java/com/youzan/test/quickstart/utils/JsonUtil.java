package com.youzan.test.quickstart.utils;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.invoker.EntityCache;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * @Author qibu
 * @create 2020/9/24 8:32 PM
 */
public class JsonUtil {

    /**
     * 不支持 PlainResult<T> 结构的对象
     * @param filePath resource目录的相对路径
     * @param tClass
     * @param <T>
     * @return
     */
    public static <T> T getObjectFromFile(String filePath,Class<T> tClass) {
        if(StringUtils.isEmpty(filePath)){
            return null;
        }
        String jsonStr = "";
        String key = "json_"+ filePath;
        if (EntityCache.isExist(key)) {
            jsonStr = (String) EntityCache.get(key);
        }else{
            jsonStr =FileUtil.getStr(filePath);
            if(StringUtils.isEmpty(jsonStr)){
                return null;
            }
            EntityCache.set(key, jsonStr);
        }
        T result = null;
        try{
            JSONObject.parseObject(jsonStr, tClass);
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }

    public static <T> T getObjectFromFile(String filePath, String key, Field f) {
        if(StringUtils.isEmpty(filePath)){
            return null;
        }
        String jsonStr = "";
        String entityKey = "json_"+ filePath;
        if (EntityCache.isExist(entityKey)) {
            jsonStr = (String) EntityCache.get(entityKey);
        }else{
            jsonStr =FileUtil.getStr(filePath);
            EntityCache.set(entityKey, jsonStr);
        }
        if(StringUtils.isEmpty(jsonStr)){
            return null;
        }
        if(StringUtils.isNotEmpty(key)){
            jsonStr = JSONObject.parseObject(jsonStr).getString(key);
        }
        //对PlainResult<T>结构进行特殊处理
        if(f.getType().equals(PlainResult.class)){
            Type type = f.getGenericType();
            Type genericType = ((ParameterizedType) type).getActualTypeArguments()[0];
            Class<?> clazz = null;
            try {
                clazz = Class.forName(genericType.getTypeName());
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            return (T)JSONObject.parseObject(jsonStr, new TypeReference<PlainResult<T>>(clazz) {});
        }
        return JSONObject.parseObject(jsonStr, f.getGenericType());
    }
}
