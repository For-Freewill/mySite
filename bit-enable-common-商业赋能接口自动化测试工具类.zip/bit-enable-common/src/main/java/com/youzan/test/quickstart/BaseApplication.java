package com.youzan.test.quickstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.youzan.test.quickstart.compare"})
public class BaseApplication {

    public static void main(String[] args) {
        System.setProperty("apollo.env", "qa");
        System.setProperty("youzan.apollo.enable", "false");
        SpringApplication.run(BaseApplication.class, args);
    }

}
