package com.youzan.test.quickstart.utils;

import com.alibaba.fastjson.JSONObject;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.dto.LoginUser;
import com.youzan.uic.session.api.model.SessionGetResultModel;
import com.youzan.uic.session.api.model.SessionIdModel;
import com.youzan.uic.session.api.model.SessionSetResultModel;
import com.youzan.uic.session.api.param.SessionGetParam;
import com.youzan.uic.session.api.param.SessionSetObjParam;
import com.youzan.uic.session.api.service.UicSessionService;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;


/**
 * @author: huangyt.
 * @create: 2019-05-23 14:22
 **/
public class LoginUtil {

    public static final String SESSION_STORE_KEY = "loginUser";


    static {
        LoginUtil.init();
    }

    private static void init(){
        uicSessionService = DubboUtil.getReference(UicSessionService.class,"",200000);
    }

    private static UicSessionService uicSessionService;

    public static String getKtdSessionId(String casId,String userName,String storeKey,String departmentId,String email,String baseSessionId){
        if(StringUtils.isEmpty(baseSessionId)){
            PlainResult<SessionIdModel> idResult = uicSessionService.createSessionId();
            if (isValidIdResult(idResult)){
                baseSessionId = idResult.getData().getSessionId();
            }
        }
        if (StringUtils.isNotEmpty(baseSessionId)){
            LoginUser user = new LoginUser();
            if(StringUtils.isNotEmpty(casId)){
                user.setCasId(Long.parseLong(casId));
                user.setUserId(Long.parseLong(casId));
            }
            user.setCasUsername(userName);
            user.setIsAdmin(false);
            user.setSid(baseSessionId);
            user.setNickname(userName);
            user.setRealname(userName);
            if(StringUtils.isNotEmpty(departmentId)){
                user.setDepartmentId(Integer.parseInt(departmentId));
            }
            user.setEmail(email);
            SessionSetObjParam setParam = new SessionSetObjParam();
            if (StringUtils.isNotBlank(storeKey)){
                setParam.setKey(storeKey);
            }else{
                setParam.setKey(SESSION_STORE_KEY);
            }
            setParam.setValue(user);
            setParam.setSessionId(baseSessionId);
            PlainResult<SessionSetResultModel> setUserResult = uicSessionService.setObj(setParam);
            Assert.assertNotNull(setUserResult);
            Assert.assertTrue(setUserResult.isSuccess());
            return baseSessionId;
        }
        return null;
    }

    private static boolean isValidIdResult(PlainResult<SessionIdModel> result) {
        return result.isSuccess() && result.getData() != null && result.getData().getSessionId() != null;
    }


}
