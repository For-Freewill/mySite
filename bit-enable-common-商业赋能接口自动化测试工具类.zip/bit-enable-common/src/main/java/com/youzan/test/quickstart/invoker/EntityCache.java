package com.youzan.test.quickstart.invoker;

import java.util.Hashtable;
import java.util.Map;

/**
 */
public class EntityCache {
	
	private static Map<String,Object> currentCache=new Hashtable<String,Object>();
	
	public static boolean isExist(String key){
		synchronized (currentCache) {
			return currentCache.containsKey(key);
		}
	}
	
	public static void set(String key,Object value){
		synchronized (currentCache) {
			if(value!=null){
				currentCache.put(key, value);
			}
		}
	}
	
	public static Object get(String key){
		synchronized (currentCache) {
			return currentCache.get(key);
		}
	}
}
