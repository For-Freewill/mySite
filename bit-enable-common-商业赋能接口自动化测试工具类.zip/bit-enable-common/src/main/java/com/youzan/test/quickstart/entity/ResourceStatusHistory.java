package com.youzan.test.quickstart.entity;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
* 资源生命周期流转记录
*/
@Data
public class ResourceStatusHistory extends SuperEntity{

	/**
	 * from 状态
	 */
	private Integer fromStatus;
	/**
	 * from 状态描述
	 */
	private String fromStatusDesc;
	/**
	 * 生命周期版本
	 */
	private Integer lifecycleVersion;
	/**
	 * 资源类型-产品线
	 */
	private Long prodLine;
	/**
	 * 资源ID
	 */
	private Long resourceId;
	/**
	 * 资源类型-SOP阶段
	 */
	private String sopStage;
	/**
	 * sop阶段-版本
	 */
	private Integer sopStageVersion;
	/**
	 * to 状态
	 */
	private Integer toStatus;
	/**
	 * to 状态描述
	 */
	private String toStatusDesc;
	/**
	 * 状态变更时间
	 */
	private Date transferredTime;
	/**
	 * 触发资源状态变更的记录
	 */
	private String triggerReason;
}