package com.youzan.test.quickstart.compare.config;

import com.youzan.bitcomparecommon.aop.CompareConfig;
import lombok.Data;


@Data
public class CollectionCompareConfig extends CompareConfig {

    /**
     * jsonArray路径 $.data.orderItems
     */
    private String jsonArrayPath;

    /**
     * 排序的字段值
     */
    private String sortKey;

}
