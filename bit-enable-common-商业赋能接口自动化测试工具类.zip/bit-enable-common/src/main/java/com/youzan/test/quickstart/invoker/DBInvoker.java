package com.youzan.test.quickstart.invoker;

import com.youzan.test.quickstart.annotation.DB;
import com.youzan.test.quickstart.utils.DBUtil;
import com.youzan.test.quickstart.utils.PropertyUtil;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.lang.reflect.Field;
import java.util.Properties;


/**
 * @Author qibu
 * @create 2019/5/16 3:14 PM
 */
public class DBInvoker {


    public static void dbInvokeAnnotation(Field f, Object instance){
        DB dbAnnotation = f.getAnnotation(DB.class);
        Properties properties = PropertyUtil.getProperties();
        String primaryDB = StringUtils.isNotEmpty(dbAnnotation.value()) ? dbAnnotation.value() : properties.getProperty("spring.datasource.dynamic.primary");
        Assert.assertTrue(StringUtils.isNotEmpty(primaryDB), "没有指定要连接的数据库！");
        String driveClassName = properties.getProperty("spring.datasource.dynamic.datasource." + primaryDB + ".driver-class-name");
        String url = properties.getProperty("spring.datasource.dynamic.datasource." + primaryDB + ".url");
        String username = properties.getProperty("spring.datasource.dynamic.datasource." + primaryDB + ".username");
        String password = properties.getProperty("spring.datasource.dynamic.datasource." + primaryDB + ".password");
        Assert.assertTrue(StringUtils.isNotEmpty(driveClassName)&&StringUtils.isNotEmpty(url)&&
                StringUtils.isNotEmpty(username)&&StringUtils.isNotEmpty(password),"无法找到数据源 "+primaryDB+" 的连接信息！");
        Class ft = f.getType();
        f.setAccessible(true);
        try {
            if (f.get(instance) != null) {
                return;
            }
            String key = "db_"+primaryDB+"_"+ ft.getName() ;
            if (EntityCache.isExist(key)) {
                f.set(instance, EntityCache.get(key));
            }else{
                Object oo = new DBUtil(driveClassName,url,username,password);
                f.set(instance, oo);
                EntityCache.set(key,oo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
