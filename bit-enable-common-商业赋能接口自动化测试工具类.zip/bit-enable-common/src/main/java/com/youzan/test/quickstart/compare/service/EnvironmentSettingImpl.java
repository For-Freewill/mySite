package com.youzan.test.quickstart.compare.service;

import com.youzan.bitcomparecommon.aop.EnvironmentSetting;
import com.youzan.test.quickstart.compare.utils.CompareSCUtil;
import org.springframework.stereotype.Component;

/**
 * @Author qibu
 * @create 2019/9/10 7:19 PM
 */
@Component
public class EnvironmentSettingImpl implements EnvironmentSetting {
    @Override
    public boolean isBasicRequest() {
        return false;
    }

    @Override
    public void handelProjectRequest() {
        CompareSCUtil.resetSC();
    }

    @Override
    public void handelBasicRequest() {
        CompareSCUtil.removeSC();
    }

}
