package com.youzan.test.quickstart.listener;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.testng.IMethodSelector;
import org.testng.IMethodSelectorContext;
import org.testng.ITestNGMethod;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 通过外部动态指定要执行的用例
 * 参数格式JSONArray：["className.methodName"]
 * ["com.youzan.test.basecase.period_count.MultiStoreTest.test_ReNewBuyMultiStoreNumWithAdd_3"]
 */
@Slf4j
@Deprecated
public class RunMethodSelector implements IMethodSelector {
    private static List<String> runMethods = Lists.newArrayList();

    private static boolean isInit = false;

    private static List<Class<?>> runMethodClazzes;

    static {
        boolean isOnJenkins = System.getenv().get("JENKINS_HOME") != null;
        String failedMethodStr ="";
        if (isOnJenkins) {
            //获取失败case
            failedMethodStr = System.getenv().get("runMethod");
        } else {
            failedMethodStr = "[\"com.youzan.test.JSONDataTest.*\"]";
        }
        if(StringUtils.isNotEmpty(failedMethodStr)){
            try{
                runMethods = JSONObject.parseArray(failedMethodStr,String.class);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public boolean includeMethod(IMethodSelectorContext iMethodSelectorContext, ITestNGMethod iTestNGMethod, boolean isTestMethod) {
        iMethodSelectorContext.setStopped(true);
        if (!isInit) {
            initWith(runMethods);
        }
        String methodStr =iTestNGMethod.getRealClass().getName()+"."+iTestNGMethod.getMethodName();
        if(CollectionUtils.isEmpty(runMethods)){//if no method to be run
            return false;
        }
        if(isTestMethod){
            if(runMethods.contains(methodStr)||runMethods.contains(iTestNGMethod.getRealClass().getName()+".*")){
                log.info("run method：" + methodStr);
                return true;
            } else {
                return false;
            }
        }else {
            boolean isNeed = runMethodClazzes.stream().anyMatch(methodClazz->iTestNGMethod.getMethod().getDeclaringClass().isAssignableFrom(methodClazz));
            if(isNeed){
                log.info("run config method：" + methodStr);
            }
            return isNeed;
        }
    }

    private synchronized  void initWith(List<String> runMethods) {
        if (isInit == true){
            return;
        }
        List<String> runMethodsClazz = getClassFromMethods(runMethods);
        List<Class<?>> clazzes = runMethodsClazz.stream()
                .map(clazz-> loadClassByName(clazz))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        this.runMethodClazzes = clazzes;
        isInit = true;
    }

    private Class<?> loadClassByName(String clazz) {
        ClassLoader cl = this.getClass().getClassLoader();
        try {
            return cl.loadClass(clazz);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    private List<String> getClassFromMethods(List<String> runMethods) {
        return runMethods.stream()
                .map(runMethod->{
                        String clazz = runMethod.substring(0,runMethod.lastIndexOf("."));
                    return clazz;
                })
                .collect(Collectors.toList());
    }

    @Override
    public void setTestMethods(List<ITestNGMethod> list) {
    }

}
