package com.youzan.test.quickstart.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.youzan.test.quickstart.http.HttpConstant;
import com.youzan.test.quickstart.http.HttpRequest;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;


import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;


public class HttpUtil {
	private static final HttpUtil httpUtil = new HttpUtil();

	private String domain;

	private String kdtsessionid;

	private String yzSessionid;

	public HttpUtil(String domain) {
		this.domain=domain;
	}
	public HttpUtil(String domain,String kdtSessionid,String yzSessionid) {
		this.domain=domain;
		this.kdtsessionid=kdtSessionid;
		this.yzSessionid=yzSessionid;
	}

	private HttpUtil() {}

	public static HttpUtil getInstance() {
		return httpUtil;
	}

	/**
	 * 通过Post请求返回Json格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @return
	 */
	public JSONObject doPostReturnResponseJson(String url) {
		return doPostReturnResponseJson(url, null, null, HttpConstant.UTF8);
	}

	/**
	 * 通过Post请求返回Json格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @param params
	 *            请求参数
	 * @return
	 */
	public JSONObject doPostReturnResponseJson(String url, Map<String, Object> params) {
		return doPostReturnResponseJson(url, params, null, HttpConstant.UTF8);
	}

	/**
	 * 通过raw body方式发送参数
	 *
	 * @param url
	 *            请求URL地址
	 * @param params
	 *            请求参数
	 * @return
	 */
	public JSONObject doPostReturnResponseJson(String url, String params) {
		return doPostReturnResponseJson(url, params, null, null, null);
	}

	/**
	 * 通过Post请求返回Json格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @param params
	 *            请求参数
	 * @param header
	 *            请求头
	 * @return
	 */
	public JSONObject doPostReturnResponseJson(String url, Map<String, Object> params, Map<String, String> header) {
		return doPostReturnResponseJson(url, params, header, HttpConstant.UTF8);
	}

	/**
	 * 通过Post请求返回Json格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @param params
	 *            请求参数
	 * @param header
	 *            请求头
	 * @param charset
	 *            字符编码
	 * @return
	 */
	public JSONObject doPostReturnResponseJson(String url, Map<String, Object> params, Map<String, String> header,
			String charset) {
		return doPostReturnResponseJson(url, params, header, null, null);
	}

	// TODO
	public JSONObject doPostReturnResponseJson(String url, Map<String, Object> params, Map<String, String> header,
			String filePath, String pwd) {

		url = this.domain+url;
		header = resetHeader(header);
		return HttpRequest.doPostReturnResponseJson(url, params, header, filePath, pwd);
	}

	// TODO
	public JSONObject doPostReturnResponseJson(String url, String params, Map<String, String> header, String filePath,
			String pwd) {

		url = this.domain+url;
		header = resetHeader(header);
		return HttpRequest.doPostReturnResponseJson(url, params, header,  filePath, pwd);
	}

	/**
	 * 通过POST发送请求
	 *
	 * @param url
	 *            请求的URL地址
	 * @return
	 */
	public String doPostReturnResponse(String url) {
		return doPostReturnResponse(url, null, null);
	}

	/**
	 * 通过POST发送请求
	 *
	 * @param url
	 *            请求的URL地址
	 * @param params
	 *            请求的查询参数,可以为null
	 * @return
	 */
	public String doPostReturnResponse(String url, Map<String, Object> params) {
		return doPostReturnResponse(url, params, null);
	}

	/**
	 * 通过POST发送请求
	 *
	 * @param url
	 *            请求的URL地址
	 * @param params
	 *            请求的查询参数,可以为null
	 * @return 返回请求响应的HTML
	 */
	public String doPostReturnResponse(String url, Map<String, Object> params, Map<String, String> header) {
		return doPostReturnResponse(url, params, header, null, null);
	}

	/**
	 * @Description: 通过POST发送请求 @param url @param params @param header @param
	 *               filePath @param pwd @param charset @return String @throws
	 */
	public String doPostReturnResponse(String url, Map<String, Object> params, Map<String, String> header,
			String filePath, String pwd) {
		JSONObject jsonObject = doPostReturnResponseJson(url, params, header, filePath, pwd);
		return jsonObject.toJSONString();
	}
	/**
	 * 通过Post请求返回Json格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @param params
	 *            请求参数
	 * @return
	 */
	public JSONObject doPutReturnResponseJson(String url, String params) {
		url = this.domain+url;
		Map<String,String> header = new HashMap<>();
		header = resetHeader(header);
		return HttpRequest.doPutReturnResponseJson(url, params, header, null,null);
	}

	public JSONObject doPutReturnResponseJson(String url, Map<String, Object> params, Map<String, String> header) {
		url = this.domain+url;
		header = resetHeader(header);
		return HttpRequest.doPutReturnResponseJson(url, JSON.toJSONString(params), header, null, null);
	}

	public JSONObject doPutReturnResponseJson(String url, String params, Map<String, String> header) {
		url = this.domain+url;
		header = resetHeader(header);
		return HttpRequest.doPutReturnResponseJson(url, params, header, null, null);
	}

	public JSONObject doDeleteReturnResponseJson(String url, Map<String, Object> params, Map<String, String> header) {
		url = this.domain+url;
		header = resetHeader(header);
		return HttpRequest.doDeleteReturnResponseJson(url, JSON.toJSONString(params), header, null, null,null);
	}

	/**
	 * 通过Get请求返回Josn格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @return
	 */
	public JSONObject doGetReturnResponseJson(String url) {
		return doGetReturnResponseJson(url, null);
	}

	/**
	 * 通过Get请求返回Josn格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @param queryString
	 *            请求参数
	 * @return
	 */
	public JSONObject doGetReturnResponseJson(String url, String queryString) {
		return doGetReturnResponseJson(url, queryString, null);
	}

	/**
	 * 通过Get请求返回Josn格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @param queryString
	 *            请求参数
	 * @param header
	 *            请求头
	 * @return
	 */
	public JSONObject doGetReturnResponseJson(String url, String queryString, Map<String, String> header) {
		return doGetReturnResponseJson(url, queryString, header, null, null);
	}

	/**
	 * 通过Get请求返回Josn格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @param queryString
	 *            请求参数
	 * @param header
	 *            请求头
	 * @return
	 */
	public JSONObject doGetReturnResponseJson(String url, String queryString, Map<String, String> header, String file,
			String pwd) {
		url = this.domain+url;
		header = resetHeader(header);
		return HttpRequest.doGetReturnResponseJson(url, queryString, header, file, pwd);
	}

	/**
	 * 执行一个HTTP GET请求，返回请求响应的HTML
	 *
	 * @param url
	 *            请求的URL地址
	 * @return 返回请求响应的HTML
	 */
	public String doGetReturnResponse(String url) {
		return doGetReturnResponse(url, "", null);
	}

	/**
	 * 执行一个HTTP GET请求，返回请求响应的HTML
	 *
	 * @param url
	 *            请求的URL地址
	 * @return 返回请求响应的HTML
	 */
	public String doGetReturnResponse(String url,Map<String,Object> params) {
		url = appendUrlParams(url,params);
		return doGetReturnResponse(url, "", null);
	}

	/**
	 * 执行一个HTTP GET请求，返回请求响应的HTML
	 *
	 * @param url
	 *            请求的URL地址
	 * @param queryString
	 *            请求的查询参数,可以为null
	 * @return 返回请求响应的HTML
	 */
	public String doGetReturnResponse(String url, String queryString) {
		return doGetReturnResponse(url, queryString, null);
	}

	/**
	 * 执行一个HTTP GET请求，返回请求响应的HTML
	 *
	 * @param url
	 *            请求的URL地址
	 * @param queryString
	 *            请求的查询参数,可以为null
	 * @param header
	 *            header信息
	 * @return 返回请求响应的HTML
	 */
	public String doGetReturnResponse(String url, String queryString, Map<String, String> header) {
		return doGetReturnResponse(url, queryString, header, null, null);
	}

	/**
	 * 执行一个HTTP GET请求，返回请求响应的HTML
	 *
	 * @param url
	 *            请求的URL地址
	 * @param queryString
	 *            请求的查询参数,可以为null
	 * @param header
	 *            header信息
	 * @param filePath
	 *            https的key文件路径
	 * @param pwd
	 *            秘钥key
	 * @return 返回请求响应的HTML
	 */
	public String doGetReturnResponse(String url, String queryString, Map<String, String> header, String filePath,
			String pwd) {
		JSONObject jsonObject = doGetReturnResponseJson(url, queryString, header, filePath, pwd);
		return jsonObject.toString();
	}

	/**
	 * 通过Post请求返回Json格式对象
	 *
	 * @param url
	 *            请求URL地址
	 * @return
	 */
	public JSONObject doDeleteReturnResponseJson(String url,String paras) {
		url = this.domain+url;
		Map<String,String> header = new HashMap<>();
		header = resetHeader(header);
		return HttpRequest.doDeleteReturnResponseJson(url, paras,header, null, null,null);
	}

	private Map<String,String> resetHeader(Map<String,String> header){
		if (null == header) {
			header = new HashMap<String, String>();
		}
		header.put("Content-Type","application/json;charset=UTF-8");
		if(StringUtils.isNotEmpty(HttpConstant.SC_HEADER_VALUE)){
			header.put(HttpConstant.SC_HEADER_KEY, HttpConstant.SC_HEADER_VALUE);
		}
		if(StringUtils.isNotEmpty(kdtsessionid)){
			header.put("Cookie", "KDTSESSIONID="+kdtsessionid+";QD_SESSIONID="+kdtsessionid+";sid="+yzSessionid);
		}
		return header;
	}

	protected String appendUrlParams(String url, Map<String, Object> params) {
		if (MapUtils.isNotEmpty(params)) {
			if (!url.endsWith("?")) {
				url = url + "?";
			}
			url = url + params.entrySet().stream().map(entry -> entry.getKey() + "=" + (entry.getValue()==null?"":entry.getValue()))
					.collect(Collectors.joining("&"));
		}
		return url;
	}

}
