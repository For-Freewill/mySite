package ftnt.qa.autotest.ui.framework.constants;

public class PropertiesKeys {
	public static final String  BROWSER_TYPE="Browser.Type";
}
