package ftnt.qa.autotest.ui.framework.xml;
//https://dops-gerrit.fortinet-us.com/#/c/19842/1/phoenix/src/java/phoenix-web/src/main/java/com/ph/phoenix/ws/rest/system/SystemConfigsResource.java
//https://blog.csdn.net/new___smile/article/details/51922145
//https://www.cnblogs.com/jycboy/p/saxparxml.html
//https://blog.csdn.net/zp357252539/article/details/48084509
public class TestXML {

}
