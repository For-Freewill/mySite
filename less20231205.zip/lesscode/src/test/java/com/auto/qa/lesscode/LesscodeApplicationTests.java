package com.auto.qa.lesscode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LesscodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
