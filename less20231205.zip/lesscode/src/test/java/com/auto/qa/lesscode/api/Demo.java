package com.auto.qa.lesscode.api;

import com.auto.qa.lesscode.StartTest;
import com.auto.qa.lesscode.api.dataprovider.DataProviderFactory;
import com.auto.qa.lesscode.core.annotation.Case;
import com.auto.qa.lesscode.core.model.ScenarioSpec;
import lombok.extern.slf4j.Slf4j;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import java.util.HashMap;

@Slf4j
public class Demo extends StartTest {

    @Case(filePath = "json/demo.json")
    @Test(dataProviderClass = DataProviderFactory.class,dataProvider = "scenario")
    public void testScenario(ScenarioSpec scenarioSpec, ITestContext iTestContext) {
        runner.httpScenario(scenarioSpec,iTestContext);
    }

    @Case(filePath = "json/demo.json")
    @Test(dataProviderClass = DataProviderFactory.class,dataProvider = "step")
    public void testStep(ScenarioSpec scenarioSpec, ITestContext iTestContext) {
        String step_1 = "get_user_details";
        String resp1 = runner.httpStep(scenarioSpec,step_1,iTestContext);
    }

    @Case(filePath = "json/demo.json")
    @Test(dataProviderClass = DataProviderFactory.class,dataProvider = "map")
    public void testMap(HashMap map, ITestContext iTestContext) {
        runner.httpMap(map,iTestContext);
    }
}
