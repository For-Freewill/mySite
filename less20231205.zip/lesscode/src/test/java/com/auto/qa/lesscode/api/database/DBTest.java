package com.auto.qa.lesscode.api.database;

import com.auto.qa.lesscode.StartTest;
import com.auto.qa.lesscode.database.connector.MysqlConnector;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * @author: wulei
 * @date: 2023/11/29 下午8:27
 */
@Slf4j
public class DBTest extends StartTest {
    MysqlConnector mysqlConnector = new MysqlConnector("master_db");
    @Test
    public void testCreate(){
        String sql = "INSERT INTO `automation`.`user` (`name`, `age`, `sex`, `height`, `weight`, `birthdate`, `is_deleted`, `created_at`, `updated_at`) VALUES ('auto', 1, 'sex', 11, 11, '1990-01-01', 0, '2023-11-29 15:22:03', '2023-11-29 15:22:03')";
        boolean re = mysqlConnector.insert(sql);
        log.info("insert success?" +re);
    }
    @Test
    public void testRead(){
        List<Map<String,Object>> re = mysqlConnector.query("select * from user");
        log.info("read" +re.toString());
    }
    @Test
    public void testUpdate(){
        String sql = "UPDATE `automation`.`user` t SET t.`name` = '333' WHERE t.`id` = 3";
        int re = mysqlConnector.updateCount(sql);
        log.info("update success count = " +re);
    }

    @Test
    public void testDelete(){
        String sql = "DELETE FROM `automation`.`user` WHERE `id` = 6";
        boolean re = mysqlConnector.delete(sql);
        log.info("delete success?" +re);
    }
}
