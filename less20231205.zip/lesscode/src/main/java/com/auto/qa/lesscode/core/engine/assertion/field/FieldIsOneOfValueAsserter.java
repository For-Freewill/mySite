package com.auto.qa.lesscode.core.engine.assertion.field;

import com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher;
import com.auto.qa.lesscode.core.engine.assertion.JsonAsserter;

import java.util.Arrays;

import static org.apache.commons.lang3.StringUtils.substringBetween;

public class FieldIsOneOfValueAsserter implements JsonAsserter {
    final Object expected;
    private final String path;

    public FieldIsOneOfValueAsserter(String path, Object expected) {
        this.path = path;
        this.expected = expected;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public Object getExpected() {
        return expected;
    }

    @Override
    public FieldAssertionMatcher actualEqualsToExpected(Object actualResult) {
        boolean areEqual;

        if (expected != null) {
            String expectedString = substringBetween((String) expected, "[", "]");

            // Store collection as a java array
            String[] expectedArray = null;

            // Check if it's an empty json array
            if (!expectedString.isEmpty()) {
                // Split into an array
                expectedArray = expectedString.split(",");
            } else {
                expectedArray = new String[]{};
            }

            // Remove leading and trailing spaces
            for (int i = 0; i < expectedArray.length; i++) {
                // Checking that this is not a whitespace string (cannot use .isBlank() as we're
                // targeting java 1.8)
                if (!expectedArray[i].trim().isEmpty())
                    expectedArray[i] = expectedArray[i].trim();
            }

            if (actualResult != null) {
                // Search list for value
                areEqual = Arrays.asList(expectedArray).contains(actualResult);
            } else {
                areEqual = false;
            }
        } else {
            // Both null
            areEqual = actualResult == null;
        }

        return areEqual ? FieldAssertionMatcher.aMatchingMessage()
                : FieldAssertionMatcher.aNotMatchingMessage(path, "One Of:" + expected, actualResult);
    }

}