package com.auto.qa.lesscode.core.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @author: wulei
 * @date: 2023/11/23 下午2:37
 */
@Data
@Slf4j
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Parameterized {
    public List<String> csvSource;
    public List<Object> valueSource;
}
