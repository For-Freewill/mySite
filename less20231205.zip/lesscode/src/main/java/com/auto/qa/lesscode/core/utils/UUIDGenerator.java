package com.auto.qa.lesscode.core.utils;

import static java.util.UUID.randomUUID;

public class UUIDGenerator {

    @Override
    public String toString() {
        return randomUUID().toString();
    }


}
