package com.auto.qa.lesscode.api.utils;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

/**
 * @author: wulei
 * @date: 2023/11/27 上午10:44
 */
public class FileUtils {
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");
    public static final String[] LINE_EXCLUDE = {"//", "#"};

    public static String getFileContent(String filePath) {
        try {
            //filePath:resource目录的相对路径
            Resource resource = new ClassPathResource(filePath);
            Reader reader = new InputStreamReader(new FileInputStream(resource.getFile()));
            StringBuffer stringBuffer = new StringBuffer();
            int position = 0;
            while ((position = reader.read()) != -1) {
                stringBuffer.append((char) position);
            }
            reader.close();
            return stringBuffer.toString();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String readStringFromFile(File file) throws IOException {
        try {
            StringBuffer buffer = new StringBuffer();
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line);
                buffer.append(LINE_SEPARATOR);
            }
            reader.close();
            return buffer.toString();
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("file read fail");
        }
    }

    public static String readstringfromxml(File file) throws IOException {
        try {
            StringBuffer buffer = new StringBuffer();
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line);
                buffer.append(LINE_SEPARATOR);
            }
            reader.close();
            String content = buffer.toString();
            content = content.replaceAll("&", "&amp;");
            return content;
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("xml read fail");
        }
    }

    public static void getAllFile(File fileInput, List<File> allFileList) {
        //file列表
        File[] fileList = fileInput.listFiles();
        assert fileList != null;
        for (File file : fileList) {
            if (file.isDirectory()) {
                getAllFile(file, allFileList);
            } else {
                allFileList.add(file);
            }
        }
    }

    public static String getResourceFilePath(String filename) {
        //
        ClassLoader classLoader = FileUtils.class.getClassLoader();
        URL url = classLoader.getResource(filename);
        if (url == null) {
            File file = new File(filename);
            if (!file.exists()) {
                throw new NullPointerException("File=" + filename + " not exist in resource path!");
            }
            try {
                url = file.toURI().toURL();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
        try {
            return url.toURI().getPath();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void writeStringToFile(String data, File file, boolean append) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(file, append));
        writer.write(data);
        writer.close();
    }

    public static boolean copyFile(File fromFile, File toFile) {
        boolean rtn = false;
        try {
            org.apache.commons.io.FileUtils.copyFile(fromFile, toFile);
            rtn = true;
        } catch (IOException e) {
            e.printStackTrace();
            rtn = false;
        }
        return rtn;
    }

    public static void deleteFile(String filePath) {
        if ("" != filePath) {
            File file = new File(filePath);
            if (file.exists()) {
                file.delete();
            }
        }
    }
}
