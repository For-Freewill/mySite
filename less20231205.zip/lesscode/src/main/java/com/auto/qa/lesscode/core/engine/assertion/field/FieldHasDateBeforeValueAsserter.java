package com.auto.qa.lesscode.core.engine.assertion.field;


import com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher;
import com.auto.qa.lesscode.core.engine.assertion.JsonAsserter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import static com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher.aMatchingMessage;
import static com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher.aNotMatchingMessage;

public class FieldHasDateBeforeValueAsserter implements JsonAsserter {
    private final String path;
    private final LocalDateTime expected;

    public FieldHasDateBeforeValueAsserter(String path, LocalDateTime expected) {
        this.path = path;
        this.expected = expected;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public Object getExpected() {
        return expected;
    }

    @Override
    public FieldAssertionMatcher actualEqualsToExpected(Object result) {
        boolean areEqual;

        if (result == null && expected == null) {
            areEqual = true;
        } else if (result == null) {
            areEqual = false;
        } else {
            LocalDateTime resultDT = null;
            try {
                resultDT = LocalDateTime.parse((String) result,
                        DateTimeFormatter.ISO_DATE_TIME);
                areEqual = resultDT.isBefore(expected);
            } catch (DateTimeParseException ex) {
                areEqual = false;
            }
        }

        return areEqual ? aMatchingMessage()
                : aNotMatchingMessage(path, "Date Before:" + expected, result);
    }
}
