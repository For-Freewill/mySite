package com.auto.qa.lesscode.core.engine.preprocessor;

import com.auto.qa.lesscode.core.model.Step;

import java.util.List;

public interface ZeroCodeExternalFileProcessor {

    Step resolveExtJsonFile(Step thisStep);

    List<Step> createFromStepFile(Step thisStep, String stepId);
}
