package com.auto.qa.lesscode.core.engine.validators;

import com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher;
import com.auto.qa.lesscode.core.engine.assertion.JsonAsserter;
import com.auto.qa.lesscode.core.engine.preprocessor.ZeroCodeAssertionsProcessor;
import com.auto.qa.lesscode.core.model.Step;
import com.auto.qa.lesscode.core.model.Validator;
import com.google.inject.Inject;
import com.jayway.jsonpath.JsonPath;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

import static com.auto.qa.lesscode.core.utils.HelperJsonUtils.strictComparePayload;
import static org.slf4j.LoggerFactory.getLogger;

public class ZeroCodeValidatorImpl implements ZeroCodeValidator {
    private static final Logger LOGGER = getLogger(ZeroCodeValidatorImpl.class);

    private final ZeroCodeAssertionsProcessor zeroCodeAssertionsProcessor;

    @Inject
    public ZeroCodeValidatorImpl(ZeroCodeAssertionsProcessor zeroCodeAssertionsProcessor) {
        this.zeroCodeAssertionsProcessor = zeroCodeAssertionsProcessor;
    }

    @Override
    public List<FieldAssertionMatcher> validateFlat(Step thisStep, String actualResult, String resolvedScenarioState) {
        LOGGER.debug("Comparing results via flat validators");

        List<FieldAssertionMatcher> failureResults = new ArrayList<>();
        List<Validator> validators = thisStep.getValidators();

        for (Validator validator : validators) {
            String jsonPath = validator.getField();

            String transformed = zeroCodeAssertionsProcessor.resolveStringJson(jsonPath, resolvedScenarioState);

            String expectedValue = validator.getValue();

            Object actualValue = JsonPath.read(actualResult, transformed);

            List<JsonAsserter> asserters = zeroCodeAssertionsProcessor.createJsonAsserters(expectedValue);

            failureResults.addAll(zeroCodeAssertionsProcessor.assertAllAndReturnFailed(asserters, actualValue.toString()));
        }

        return failureResults;
    }

    @Override
    public List<FieldAssertionMatcher> validateStrict(String expectedResult, String actualResult) {
        LOGGER.debug("Comparing results via STRICT matchers");

        return strictComparePayload(expectedResult, actualResult);
    }

    @Override
    public List<FieldAssertionMatcher> validateLenient(String expectedResult, String actualResult) {
        LOGGER.debug("Comparing results via LENIENT matchers");

        List<JsonAsserter> asserters = zeroCodeAssertionsProcessor.createJsonAsserters(expectedResult);
        return zeroCodeAssertionsProcessor.assertAllAndReturnFailed(asserters, actualResult);
    }
}
