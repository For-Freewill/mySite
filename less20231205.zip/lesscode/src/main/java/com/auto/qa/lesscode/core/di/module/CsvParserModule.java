package com.auto.qa.lesscode.core.di.module;

import com.auto.qa.lesscode.core.di.provider.CsvParserProvider;
import com.google.inject.Binder;
import com.google.inject.Module;
import com.univocity.parsers.csv.CsvParser;

import javax.inject.Singleton;

public class CsvParserModule implements Module {

    @Override
    public void configure(Binder binder) {
        binder.bind(CsvParser.class).toProvider(CsvParserProvider.class).in(Singleton.class);
    }
}

