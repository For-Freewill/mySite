package com.auto.qa.lesscode.core.engine.preprocessor;

import org.apache.commons.lang.text.StrSubstitutor;

import java.util.HashMap;
import java.util.Map;

public class StepExecutionState {
    private static String requestResponseState = "\"${STEP.NAME}\": {\n" +
            "    \"request\":${STEP.REQUEST},\n" +
            "    \"response\": ${STEP.RESPONSE}\n" +
            "  }";
    Map<String, String> paramMap = new HashMap<>();

    public StepExecutionState() {
        //SmartUtils.readJsonAsString("engine/request_respone_template_scene.json");
    }

    public static String getRequestResponseState() {
        return requestResponseState;
    }

    public void setRequestResponseState(String requestResponseState) {
        StepExecutionState.requestResponseState = requestResponseState;
    }

    public void addStep(String stepName) {
        paramMap.put("STEP.NAME", stepName);
    }

    public void addRequest(String requestJson) {
        paramMap.put("STEP.REQUEST", requestJson);

    }

    public void addResponse(String responseJson) {
        paramMap.put("STEP.RESPONSE", responseJson);
    }

    public String getResolvedStep() {
        StrSubstitutor sub = new StrSubstitutor(paramMap);
        return sub.replace(requestResponseState);
    }
}
