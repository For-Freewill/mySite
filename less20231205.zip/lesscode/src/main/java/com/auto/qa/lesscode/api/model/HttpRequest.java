package com.auto.qa.lesscode.api.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * http request模型
 *
 * @author: wulei
 * @date: 2023/11/30 下午12:09
 */
@Slf4j
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class HttpRequest {
    public String url;
    public Map<String, Object> headers = new HashMap<>();
    public Map<String, Object> params = new HashMap<>();
    public String body="";

    public void setUrl(String url) {
        this.url = url;
    }

    public void setHeaders(Map<String, Object> headers) {
        this.headers = headers;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getUrl() {
        return url;
    }

    public Map<String, Object> getHeaders() {
        return headers;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public String getBody() {
        return body;
    }
}
