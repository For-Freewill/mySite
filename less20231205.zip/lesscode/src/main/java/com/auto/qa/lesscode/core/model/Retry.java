package com.auto.qa.lesscode.core.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

/**
 * @author: wulei
 * @date: 2023/11/23 下午2:41
 */
@Data
@Slf4j
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Retry {
    private Integer max;
    private Integer delay;
}
