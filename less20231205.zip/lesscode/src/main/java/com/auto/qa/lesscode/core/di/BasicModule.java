package com.auto.qa.lesscode.core.di;

import com.auto.qa.lesscode.core.di.module.CsvParserModule;
import com.auto.qa.lesscode.core.engine.executor.ApiServiceExecutor;
import com.auto.qa.lesscode.core.engine.executor.ApiServiceExecutorImpl;
import com.auto.qa.lesscode.core.engine.executor.httpapi.HttpApiExecutor;
import com.auto.qa.lesscode.core.engine.executor.httpapi.HttpApiExecutorImpl;
import com.auto.qa.lesscode.core.engine.executor.javaapi.JavaMethodExecutor;
import com.auto.qa.lesscode.core.engine.executor.javaapi.JavaMethodExecutorImpl;
import com.auto.qa.lesscode.core.engine.preprocessor.*;
import com.auto.qa.lesscode.core.engine.report.ZeroCodeReportGenerator;
import com.auto.qa.lesscode.core.engine.report.ZeroCodeReportGeneratorImpl;
import com.auto.qa.lesscode.core.engine.sorter.ZeroCodeSorter;
import com.auto.qa.lesscode.core.engine.sorter.ZeroCodeSorterImpl;
import com.auto.qa.lesscode.core.engine.validators.ZeroCodeValidator;
import com.auto.qa.lesscode.core.engine.validators.ZeroCodeValidatorImpl;
import com.auto.qa.lesscode.core.runner.ScenarioRunner;
import com.auto.qa.lesscode.core.runner.ScenarioRunnerImpl;
import com.google.inject.AbstractModule;

/**
 * @author: wulei
 * @date: 2023/11/23 下午3:49
 */
public class BasicModule extends AbstractModule {

    @Override
    protected void configure() {
        install(new CsvParserModule());

        /**
         * bind class impl to interface
         */
        bind(ScenarioRunner.class).to(ScenarioRunnerImpl.class);
        bind(ApiServiceExecutor.class).to(ApiServiceExecutorImpl.class);
        bind(HttpApiExecutor.class).to(HttpApiExecutorImpl.class);
        bind(JavaMethodExecutor.class).to(JavaMethodExecutorImpl.class);
        bind(ZeroCodeAssertionsProcessor.class).to(ZeroCodeAssertionsProcessorImpl.class);
        bind(ZeroCodeValidator.class).to(ZeroCodeValidatorImpl.class);
        bind(ZeroCodeReportGenerator.class).to(ZeroCodeReportGeneratorImpl.class);
        bind(ZeroCodeExternalFileProcessor.class).to(ZeroCodeExternalFileProcessorImpl.class);
        bind(ZeroCodeParameterizedProcessor.class).to(ZeroCodeParameterizedProcessorImpl.class);
        bind(ZeroCodeSorter.class).to(ZeroCodeSorterImpl.class);
    }
}
