package com.auto.qa.lesscode.api.dataprovider;

import com.auto.qa.lesscode.core.annotation.Case;
import lombok.extern.slf4j.Slf4j;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;

import java.lang.reflect.Method;

/**
 * @author: wulei
 * @date: 2023/11/23 下午4:00
 */
@Slf4j
public class DataProviderFactory {
    private DataProviderFactory() {
    }

    @DataProvider(name = "scenario")
    public static Object[][] jsonScenario(ITestContext iTestContext, Method method) {
        String caseFile = method.getAnnotation(Case.class).filePath();
        return new JsonProvider(caseFile, iTestContext).getJsonScenario();
    }

    @DataProvider(name = "step")
    public static Object[][] jsonStep(ITestContext iTestContext, Method method) {
        String caseFile = method.getAnnotation(Case.class).filePath();
        return new JsonProvider(caseFile, iTestContext).getJsonScenario();
    }

    @DataProvider(name = "map")
    public static Object[][] jsonMap(ITestContext iTestContext, Method method) {
        String caseFile = method.getAnnotation(Case.class).filePath();
        return new JsonProvider(caseFile, iTestContext).getJsonMap();
    }
}
