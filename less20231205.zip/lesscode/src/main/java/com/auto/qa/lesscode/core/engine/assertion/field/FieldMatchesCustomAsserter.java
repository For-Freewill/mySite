package com.auto.qa.lesscode.core.engine.assertion.field;

import com.auto.qa.lesscode.core.di.ObjectMapperProvider;
import com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher;
import com.auto.qa.lesscode.core.engine.assertion.JsonAsserter;
import com.auto.qa.lesscode.core.engine.executor.javaapi.JavaCustomExecutor;
import com.fasterxml.jackson.databind.ObjectMapper;

import static com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher.aMatchingMessage;
import static com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher.aNotMatchingMessage;

public class FieldMatchesCustomAsserter implements JsonAsserter {
    private final String path;
    private final String expected;
    ObjectMapper mapper = new ObjectMapperProvider().get();

    public FieldMatchesCustomAsserter(String path, String expected) {
        this.path = path;
        this.expected = expected;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public Object getExpected() {
        return expected;
    }

    @Override
    public FieldAssertionMatcher actualEqualsToExpected(Object actual) {
        boolean areEqual = JavaCustomExecutor.executeMethod(expected, actual);

        return areEqual ?
                aMatchingMessage() :
                aNotMatchingMessage(path, " custom assertion:" + expected, actual);
    }
}
