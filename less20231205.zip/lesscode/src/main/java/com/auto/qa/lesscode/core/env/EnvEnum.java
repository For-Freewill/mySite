package com.auto.qa.lesscode.core.env;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * @author: wulei
 * @date: 2023/11/29 下午7:14
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum EnvEnum {
    /**
     * Default dev
     */
    Default("dev"),
    /**
     * DEV env
     */
    DEV("dev"),
    /**
     * UAT env
     */
    UAT("uat");

    public String env;

    public static EnvEnum Env(String env) {
        if (StringUtils.isNotEmpty(env)) {
            EnvEnum[] envEnums = EnvEnum.values();
            for (EnvEnum e : envEnums) {
                if (env.equals(e.getEnv())) {
                    return e;
                }
            }
            return null;
        }
        return null;
    }
}
