package com.auto.qa.lesscode.api.utils;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;

/**
 * @author: wulei
 * @date: 2023/11/27 上午10:41
 */
public class JSONUtil {
    public static <T> T fileToFieldClass(String filePath, String key, Field filed) {
        if (StringUtils.isEmpty(filePath)) {
            return null;
        }
        //filePath:resource目录的相对路径
        String jsonStr = FileUtils.getFileContent(filePath);

        if (StringUtils.isEmpty(jsonStr)) {
            return null;
        }
        if (StringUtils.isNotEmpty(key)) {
            jsonStr = JSONObject.parseObject(jsonStr).getString(key);
        }
        // 对PlainResult < T > 结构进行特殊处理
//        if (filed.getType().equals(PlainResult.class)) {
//            Type type = filed.getGenericType();
//            Type genericType = ((ParameterizedType) type).getActualTypeArguments()[0];
//            Class<?> clazz = null;
//            try {
//                clazz = Class.forName(genericType.getTypeName());
//            } catch (ClassNotFoundException e) {
//                e.printStackTrace();
//                return (T) JSONObject.parseObject(jsonStr, new TypeReference<PlainResult<T>>(clazz) ());
//            }
//        }
        return JSONObject.parseObject(jsonStr, filed.getGenericType());
    }

    public static <T> T fileToClass(String filePath, String key, Class<T> T) {
        if (StringUtils.isEmpty(filePath)) {
            return null;
        }
        //filePath:resource目录的相对路径
        String jsonStr = FileUtils.getFileContent(filePath);

        if (StringUtils.isEmpty(jsonStr)) {
            return null;
        }
        if (StringUtils.isNotEmpty(key)) {
            jsonStr = JSONObject.parseObject(jsonStr).getString(key);
        }
        return JSONObject.parseObject(jsonStr, T);
    }
}