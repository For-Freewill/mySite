package com.auto.qa.lesscode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LesscodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LesscodeApplication.class, args);
	}

}
