package com.auto.qa.lesscode.core.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author: wulei
 * @date: 2023/11/23 下午3:13
 */
@Slf4j
@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum Priority {
    P0("P0", 1),
    P1("P1", 2),
    P2("P2", 3);
    private String priority;
    private int number;
}
