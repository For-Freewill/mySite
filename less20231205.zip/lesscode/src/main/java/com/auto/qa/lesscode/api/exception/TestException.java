package com.auto.qa.lesscode.api.exception;

/**
 * @author: wulei
 * @date: 2023/11/29 下午8:06
 */
public class TestException extends RuntimeException {
    public TestException() {
    }

    public TestException(String message) {
        super(message);
    }

    public TestException(String message, Throwable cause) {
        super(message, cause);
    }

    public TestException(Throwable cause) {
        super(cause);
    }

    public TestException(String message, Throwable cause, boolean en, boolean wri) {
        super(message, cause, en, wri);
    }
}
