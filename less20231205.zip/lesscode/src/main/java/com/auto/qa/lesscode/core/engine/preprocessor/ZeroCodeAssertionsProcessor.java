package com.auto.qa.lesscode.core.engine.preprocessor;

import com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher;
import com.auto.qa.lesscode.core.engine.assertion.JsonAsserter;

import java.util.List;

/**
 * @author wulei
 */
public interface ZeroCodeAssertionsProcessor {

    String resolveStringJson(String requestJsonAsString, String resolvedScenarioState);

    String resolveKnownTokensAndProperties(String requestJsonOrAnyString);

    String resolveJsonPaths(String resolvedFromTemplate, String jsonString);

    List<String> getAllJsonPathTokens(String requestJsonAsString);

    List<JsonAsserter> createJsonAsserters(String resolvedAssertionJson);

    List<FieldAssertionMatcher> assertAllAndReturnFailed(List<JsonAsserter> asserters, String executionResult);
}
