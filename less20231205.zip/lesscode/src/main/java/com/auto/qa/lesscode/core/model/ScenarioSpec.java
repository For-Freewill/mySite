package com.auto.qa.lesscode.core.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @author: wulei
 * @date: 2023/11/23 下午2:34
 */
@Data
@Slf4j
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ScenarioSpec {
    public String scenarioName;
    public List<Step> steps;
    public Parameterized parameterized;
    public Integer loop;
    public Boolean ignoreStepFailures;
}
