package com.auto.qa.lesscode.core.engine.sorter;

import com.auto.qa.lesscode.core.model.Step;

public interface ZeroCodeSorter {

    String sortArrayAndReplaceInResponse(Step thisStep, String results, String resolvedScenarioState);
}
