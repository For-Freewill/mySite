package com.auto.qa.lesscode;

import com.auto.qa.lesscode.api.listener.TestNGListener;
import com.auto.qa.lesscode.core.runner.Runner;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.Listeners;

/**
 * @author wulei
 */
@Slf4j
@SpringBootTest(classes = LesscodeApplication.class)
@Listeners({TestNGListener.class})
public class StartTest extends AbstractTestNGSpringContextTests {
    public Runner runner = new Runner();
}
