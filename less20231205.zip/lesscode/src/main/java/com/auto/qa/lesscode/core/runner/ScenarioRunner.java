package com.auto.qa.lesscode.core.runner;

import com.auto.qa.lesscode.core.model.ScenarioSpec;
import org.testng.ITestContext;

import java.util.HashMap;

/**
 * @author: wulei
 * @date: 2023/11/23 下午2:33
 */
public interface ScenarioRunner {
    /**
     * Run scenario (all steps will be run)
     *
     * @param scenarioSpec
     * @param iTestContext
     * @return NO return
     */
    boolean runScenario(ScenarioSpec scenarioSpec, ITestContext iTestContext);

    /**
     * Run specified.step (specific step will be run)
     *
     * @param stepName
     * @param scenarioSpec
     * @param iTestContext
     * @return Step call api resp
     */
    String runStep(ScenarioSpec scenarioSpec, String stepName, ITestContext iTestContext);

    /**
     * Run with hash map
     *
     * @param hashMap
     * @param iTestContext
     * @return Step call api resp
     */
    String runMap(HashMap hashMap, ITestContext iTestContext);
}
