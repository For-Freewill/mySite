package com.auto.qa.lesscode.core.engine.assertion.field;

import com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher;
import com.auto.qa.lesscode.core.engine.assertion.JsonAsserter;
import com.auto.qa.lesscode.core.engine.assertion.NumberComparator;


public class FieldHasEqualNumberValueAsserter implements JsonAsserter {
    private final String path;
    private final Number expected;

    public FieldHasEqualNumberValueAsserter(String path, Number expected) {
        this.path = path;
        this.expected = expected;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public Object getExpected() {
        return expected;
    }

    @Override
    public FieldAssertionMatcher actualEqualsToExpected(Object actualResult) {
        boolean areEqual;

        if (actualResult instanceof Number && expected instanceof Number) {
            NumberComparator comparator = new NumberComparator();
            areEqual = comparator.compare((Number) actualResult, expected) == 0;

        } else if (actualResult == null && expected == null) {
            areEqual = true;

        } else if (actualResult == null) {
            areEqual = false;

        } else {
            areEqual = false;

        }

        return defaultAssertionMessage(actualResult, areEqual);
    }
}

