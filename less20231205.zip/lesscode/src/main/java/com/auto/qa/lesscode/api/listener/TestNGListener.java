package com.auto.qa.lesscode.api.listener;

import org.testng.IClassListener;
import org.testng.IMethodInstance;
import org.testng.ITestClass;
import org.testng.TestListenerAdapter;

/**
 * @author: wulei
 * @date: 2023/11/23 下午5:20
 */
public class TestNGListener extends TestListenerAdapter implements IClassListener {

    @Override
    public void onBeforeClass(ITestClass iTestClass, IMethodInstance iMethodInstance) {

    }

    @Override
    public void onAfterClass(ITestClass iTestClass, IMethodInstance iMethodInstance) {

    }
}
