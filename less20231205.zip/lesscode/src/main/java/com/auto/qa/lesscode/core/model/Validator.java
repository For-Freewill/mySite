package com.auto.qa.lesscode.core.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * @author: wulei
 * @date: 2023/11/23 下午2:40
 */
@Data
@Slf4j
@Getter
@Setter
@NoArgsConstructor
public class Validator {
    public String filed;
    public String value;

    public Validator(String filed, String value) {
        this.filed = filed;
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public String getField() {
        return filed;
    }
}
