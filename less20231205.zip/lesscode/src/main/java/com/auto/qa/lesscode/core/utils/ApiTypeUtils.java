package com.auto.qa.lesscode.core.utils;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.isEmpty;

public class ApiTypeUtils {
    public static final String JAVA_API_PROTOCOL_MAPPINGS = "java.api.protocol.mappings";
    private static final Logger LOGGER = LoggerFactory.getLogger(ApiTypeUtils.class);
    @Inject(optional = true)
    @Named(JAVA_API_PROTOCOL_MAPPINGS)
    private String javaApiProtoMappings;

    public ApiTypeUtils() {
    }

    public ApiTypeUtils(String javaApiProtoMappings) {
        this.javaApiProtoMappings = javaApiProtoMappings;
    }

    public static ApiType apiType(String url, String methodName) {
        ApiType apiType;

        if (StringUtils.isEmpty(url) && isEmpty(methodName)) {
            apiType = ApiType.NONE;

        } else if (url.contains("://") && !url.startsWith("http")) {
            apiType = ApiType.JAVA_CALL;

        } else {
            apiType = ApiType.REST_CALL;
        }

        return apiType;
    }

    public String getQualifiedJavaApi(String url) {
        if (!url.contains("://")) {
            return url;
        }
        return findMapping(javaApiProtoMappings, url);
    }

    private String findMapping(String javaApiProtoMappings, String url) {
        LOGGER.debug("Locating protocol service mapping for - '{}'", url);

        if (isEmpty(javaApiProtoMappings)) {
            LOGGER.error("Protocol mapping was null or empty. Please create the mappings first and then rerun");
            throw new RuntimeException("\nProtocol mapping was null or empty.");
        }
        List<String> mappingList = Arrays.asList(javaApiProtoMappings.split(","));
        String foundMapping = mappingList.stream()
                .filter(thisMapping -> thisMapping.startsWith(url))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("\nurl '" + url + "' Not found"));

        String qualifiedClazz = foundMapping.split("\\|")[1];
        LOGGER.debug("Found protocol mapping for - '{} -> {}'", url, qualifiedClazz);

        return qualifiedClazz;
    }
}
