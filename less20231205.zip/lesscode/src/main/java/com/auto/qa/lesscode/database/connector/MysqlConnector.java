package com.auto.qa.lesscode.database.connector;

import com.auto.qa.lesscode.api.exception.TestException;
import com.auto.qa.lesscode.core.env.EnvUtil;
import org.apache.commons.lang3.StringUtils;

import java.sql.*;
import java.util.*;

/**
 * @author: wulei
 * @date: 2023/11/29 下午7:11
 */
public class MysqlConnector {
    private static String DB_DRIVER = ".driver-class-name";
    private static final String DB_URL = ".url";
    private static final String DB_USER = ".username";
    private static final String DB_PASSWORD = ".password";
    private Connection connection = null;

    public MysqlConnector(String profile) {
        try {
            DB_DRIVER = EnvUtil.getValue("spring.datasource.dynamic.datasource." + profile + DB_DRIVER);
            String url = EnvUtil.getValue("spring.datasource.dynamic.datasource." + profile + DB_URL);
            String user = EnvUtil.getValue("spring.datasource.dynamic.datasource." + profile + DB_USER);
            String password = EnvUtil.getValue("spring.datasource.dynamic.datasource." + profile + DB_PASSWORD);
            if (StringUtils.isEmpty(url) || StringUtils.isEmpty(user) || StringUtils.isEmpty(password)) {
                return;
            }
            conn(url, user, password);
        } catch (Exception e) {
            throw new NullPointerException("Mysql config is empty!!");
        }
    }

    /**
     * 初始化连接器
     */
    public void conn(String url, String user, String password) {
        try {
            Class.forName(DB_DRIVER);
            connection = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * CRUD:Create
     */
    public boolean insert(String sql){
        return execute(sql);
    }

    /**
     * CRUD:Read
     */
    public List<Map<String, Object>> query(String sql) {
        Statement statement = null;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            List<Map<String, Object>> resultList = setToList(resultSet);
            return resultList;
        } catch (Exception e) {
            throw new TestException("SQL 执行失败："+sql+",msg= "+e.getMessage());
        } finally {
            if(statement!=null){
                try{
                    statement.close();
                }catch (Exception e){
                    throw new TestException(e);
                }
            }
        }
    }
    /**
     * CRUD:Update
     */
    public boolean update(String sql){
        return execute(sql);
    }

    public int updateCount(String sql){
        return executeUpdate(sql);
    }
    /**
     * CRUD:Delete
     */
    public boolean delete(String sql){
        return execute(sql);
    }

    /**
     * common execute
     * @param sql
     * @return
     */
    public boolean execute(String sql) {
        Statement statement = null;
        try {
            statement = connection.createStatement();
            boolean result = statement.execute(sql);
            return result;
        } catch (Exception e) {
            throw new TestException("SQL 执行失败："+sql+",msg="+e.getLocalizedMessage());
        } finally {
            if(statement!=null){
                try{
                    statement.close();
                }catch (Exception e){
                    throw new TestException(e);
                }
            }
        }
    }
    /**
     * Update with cnt return
     * @param sql
     * @return
     */
    public int executeUpdate(String sql) {
        Statement statement = null;
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate(sql);
            return result;
        } catch (Exception e) {
            throw new TestException("SQL 执行失败："+sql+",msg="+e.getLocalizedMessage());
        } finally {
            if(statement!=null){
                try{
                    statement.close();
                }catch (Exception e){
                    throw new TestException(e);
                }
            }
        }
    }
    /**
     * set to List
     */
    public static List<Map<String, Object>> setToList(ResultSet resultSet) throws SQLException {
        if(resultSet==null){
            return Collections.emptyList();
        }else {
            ResultSetMetaData md = resultSet.getMetaData();
            int columnCnt = md.getColumnCount();
            ArrayList list = new ArrayList();
            new HashMap();
            while (resultSet.next()){
                HashMap rowData = new HashMap(columnCnt);
                for (int i = 1; i <=columnCnt ; ++i) {
                    rowData.put(md.getColumnLabel(i),resultSet.getObject(i));
                }
                list.add(rowData);
            }
            return list;
        }

    }
}
