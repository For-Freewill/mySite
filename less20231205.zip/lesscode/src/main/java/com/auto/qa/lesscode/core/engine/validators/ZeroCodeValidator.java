package com.auto.qa.lesscode.core.engine.validators;

import com.auto.qa.lesscode.core.engine.assertion.FieldAssertionMatcher;
import com.auto.qa.lesscode.core.model.Step;

import java.util.List;

public interface ZeroCodeValidator {

    List<FieldAssertionMatcher> validateFlat(Step thisStep, String actualResult, String resolvedScenarioState);

    List<FieldAssertionMatcher> validateStrict(String expectedResult, String actualResult);

    List<FieldAssertionMatcher> validateLenient(String expectedResult, String actualResult);

}
