package com.auto.qa.lesscode.core.runner;

import com.auto.qa.lesscode.core.di.BasicModule;
import com.auto.qa.lesscode.core.model.ScenarioSpec;
import com.auto.qa.lesscode.core.model.Step;
import com.google.inject.Guice;
import com.google.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.testng.ITestContext;

import java.util.HashMap;

/**
 * @author: wulei
 * @date: 2023/11/23 下午3:47
 */
@Slf4j
public class Runner {
    @Inject
    private final ScenarioRunner scenarioRunner;


    public Runner() {
        scenarioRunner = createScenarioRunner();
    }

    public void httpScenario(ScenarioSpec scenarioSpec, ITestContext iTestContext) {
        scenarioRunner.runScenario(scenarioSpec, iTestContext);

    }

    public String httpStep(ScenarioSpec scenarioSpec,String stepName, ITestContext iTestContext) {
        return scenarioRunner.runStep(scenarioSpec,stepName, iTestContext);
    }

    public String httpMap(HashMap map, ITestContext iTestContext) {
        return scenarioRunner.runMap(map, iTestContext);
    }

    private ScenarioRunner createScenarioRunner() {
        synchronized (this) {
            return Guice.createInjector(new BasicModule()).getInstance(ScenarioRunner.class);
        }
    }
}
