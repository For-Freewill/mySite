package com.auto.qa.lesscode.core.engine.preprocessor;


import com.auto.qa.lesscode.core.model.ScenarioSpec;

public interface ZeroCodeParameterizedProcessor {

    ScenarioSpec resolveParameterized(ScenarioSpec scenario, int iteration);
}
