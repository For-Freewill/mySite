package com.auto.qa.lesscode.api.utils;

import com.auto.qa.lesscode.api.annotation.GetJson;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;

/**
 * @author: wulei
 * @date: 2023/11/27 上午10:38
 */
public class JSONInvoker {
    public static void jsonInvoker(Field field, Object instance) {
        GetJson caseAnnotation = field.getAnnotation(GetJson.class);
        field.setAccessible(true);
        try {
            if (field.get(instance) != null) {
                return;
            }
            Object object = null;
            if (StringUtils.isNotEmpty(caseAnnotation.key())) {
                object = JSONUtil.fileToFieldClass(caseAnnotation.filePath(), caseAnnotation.key(), field);
            } else {
                object = JSONUtil.fileToFieldClass(caseAnnotation.filePath(), "", field);
            }
            field.set(instance, object);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
