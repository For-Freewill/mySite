package com.auto.qa.lesscode.api.utils;

import com.auto.qa.lesscode.api.model.HttpRequest;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.config.EncoderConfig.encoderConfig;

/**
 * HTTP请求工具：基于RestAssured
 *
 * @author: wulei
 * @date: 2023/11/30 下午12:00
 */
@Slf4j
public class RestUtil {
    /**
     * Get
     */
    public static Response get(String url, HttpRequest request) {
        Response response = RestAssured.given().relaxedHTTPSValidation().contentType("application/json;charset=UTF-8")
                .headers(request.headers)
                .queryParams(request.params)
                .when().get(url.trim());
        return response;
    }

    public static Response get(HttpRequest request) {
        return get(request.getUrl(), request);
    }

    /**
     * Get with proxy
     */
    public static Response get_proxy(String url, HttpRequest request, String host, int port) {
        Response response = RestAssured.given().relaxedHTTPSValidation().contentType("application/json;charset=UTF-8")
                .headers(request.headers)
                .queryParams(request.params)
                .proxy(host, port)
                .when().get(url.trim());
        return response;
    }


    /**
     * post
     */
    public static Response post(String url, HttpRequest request) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().contentType("application/json;charset=UTF-8").spec(requestSpecification)
                .headers(request.headers)
                .queryParams(request.params)
                .body(request.body)
                .when().post(url.trim());
        return response;
    }

    public static Response post(HttpRequest request) {
        return post(request.getUrl(), request);
    }

    /**
     * post_proxy
     */
    public static Response post_proxy(String url, HttpRequest request, String host, int port) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().spec(requestSpecification)
                .headers(request.headers)
                .queryParams(request.params)
                .proxy(host, port)
                .body(request.body)
                .when().post(url.trim());
        return response;
    }

    /**
     * put
     */
    public static Response put(String url, HttpRequest request) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().spec(requestSpecification)
                .headers(request.headers)
                .queryParams(request.params)
                .body(request.body)
                .when().put(url.trim());
        return response;
    }

    public static Response put(HttpRequest request) {
        return put(request.getUrl(), request);
    }

    /**
     * put with proxy
     */
    public static Response put_proxy(String url, HttpRequest request, String host, int port) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().spec(requestSpecification)
                .headers(request.headers)
                .queryParams(request.params)
                .proxy(host, port)
                .body(request.body)
                .when().put(url.trim());
        return response;
    }


    /**
     * patch
     */
    public static Response patch(String url, HttpRequest request) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().spec(requestSpecification)
                .headers(request.headers)
                .queryParams(request.params)
                .body(request.body)
                .when().patch(url.trim());
        return response;
    }

    public static Response patch(HttpRequest request) {
        return patch(request.getUrl(), request);
    }

    /**
     * patch with proxy
     */
    public static Response patch_proxy(String url, HttpRequest request, String host, int port) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().spec(requestSpecification)
                .headers(request.headers)
                .queryParams(request.params)
                .proxy(host, port)
                .body(request.body)
                .when().patch(url.trim());
        return response;
    }

    /**
     * delete
     */
    public static Response delete(String url, HttpRequest request) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().spec(requestSpecification)
                .headers(request.headers)
                .queryParams(request.params)
                .body(request.body)
                .when().delete(url.trim());
        return response;
    }

    public static Response delete(HttpRequest request) {
        return delete(request.getUrl(), request);
    }

    /**
     * delete with proxy
     */
    public static Response delete_proxy(String url, HttpRequest request, String host, int port) {
        //去除默认字符集：ISO-8859-1
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setConfig(RestAssuredConfig.newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
        RequestSpecification requestSpecification = requestSpecBuilder.build();

        Response response = RestAssured.given().relaxedHTTPSValidation().spec(requestSpecification)
                .headers(request.getHeaders())
                .queryParams(request.getParams())
                .proxy(host, port)
                .body(request.body)
                .when().delete(url.trim());
        return response;
    }

    public static void main(String[] args) {
        //sampler：https://reqres.in/
        Map<String, Object> params = new HashMap<>();
        params.put("age",2);
        HttpRequest request = HttpRequest.builder().url("https://reqres.in/api/users").headers(new HashMap<>()).params(params).build();
        Response response = RestUtil.get(request);
        log.info("resp="+response.getBody().prettyPrint());
        //post
        String body="{\"email\":\"eve.holt@reqres.in\",\"password\":\"pistol\"}";
        HttpRequest request2 = HttpRequest.builder().url("https://reqres.in/api/register").headers(new HashMap<>()).params(new HashMap<>()).body(body).build();
        Response response2 = RestUtil.post(request2);
        log.info("resp post="+response2.getBody().prettyPrint());
    }
}
