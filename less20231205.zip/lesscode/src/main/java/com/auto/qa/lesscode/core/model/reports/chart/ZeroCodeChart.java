package com.auto.qa.lesscode.core.model.reports.chart;

public class ZeroCodeChart {
}
