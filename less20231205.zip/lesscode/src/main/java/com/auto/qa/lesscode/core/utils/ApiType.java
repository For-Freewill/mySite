package com.auto.qa.lesscode.core.utils;

public enum ApiType {
    REST_CALL,
    KAFKA_CALL,
    JAVA_CALL,
    NONE
}
