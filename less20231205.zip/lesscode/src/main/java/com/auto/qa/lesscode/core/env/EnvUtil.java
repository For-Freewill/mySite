package com.auto.qa.lesscode.core.env;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.Properties;

/**
 * @author: wulei
 * @date: 2023/11/29 下午7:21
 */
@Slf4j
public class EnvUtil {
    @Autowired
    public static Environment environment;

    public static final String suffix = ".yml";
    public static final Properties properties = new Properties();
    public static  String env;

    /**
     * 处理动态env环境变量参数
     */
    static {
        env=System.getProperty("env");
        if(StringUtils.isBlank(env)){
            env = EnvEnum.Default.getEnv();
        }
        try{
            properties.load(EnvUtil.class.getClassLoader().getResourceAsStream("application-"+env+suffix));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    /**
     * 读取application-env.yml配置文件的指定kv
     */
    public static String getValue(String key){
        YamlPropertiesFactoryBean yamlPropertiesFactoryBean = new YamlPropertiesFactoryBean();
        yamlPropertiesFactoryBean.setResources(new ClassPathResource("application-"+env+suffix),new ClassPathResource("application.yml"));
        Properties properties = yamlPropertiesFactoryBean.getObject();
        String value = properties.getProperty(key);
        if(StringUtils.isNotBlank(value)){
            return value;
        }
        return "";
    }
    /**
     * 返回完整配置文件信息
     */
    public static Properties getProperties(){
        return properties;
    }
    /**
     * 读取任意配置信息
     */
    public static String getProp(String key){
        String value = properties.get(key).toString();
        if(StringUtils.isNotBlank(value)){
            return value;
        }
        return "";
    }

}
