package com.auto.qa.lesscode.core.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;

import java.util.List;

/**
 * @author: wulei
 * @date: 2023/11/23 下午2:37
 */
@Data
@Slf4j
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Step {
    private boolean enable;
    private String id;
    private String operation;
    private boolean ignoreStep;
    private String name;
    private String author;
    private List<String> groups;
    private Priority priority;
    private String method;
    private String url;
    private String request;
    private String assertions;
    private String verifyMode;
    private Integer loop;
    private Retry retry;
    /**
     *     low priority
     */
    private List<Validator> validators;
    private String sort;
    private String verify;
    private List<Object> parameterized;
    private List<String> parameterizedCsv;
    private String customLog;

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public boolean isIgnoreStep() {
        return ignoreStep;
    }

    public void setIgnoreStep(boolean ignoreStep) {
        this.ignoreStep = ignoreStep;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public List<String> getGroups() {
        return groups;
    }

    public void setGroups(List<String> groups) {
        this.groups = groups;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public String getAssertions() {
        return assertions;
    }

    public void setAssertions(String assertions) {
        this.assertions = assertions;
    }

    public String getVerifyMode() {
        return verifyMode;
    }

    public void setVerifyMode(String verifyMode) {
        this.verifyMode = verifyMode;
    }

    public Integer getLoop() {
        return loop;
    }

    public void setLoop(Integer loop) {
        this.loop = loop;
    }

    public Retry getRetry() {
        return retry;
    }

    public void setRetry(Retry retry) {
        this.retry = retry;
    }

    public List<Validator> getValidators() {
        return validators;
    }

    public void setValidators(List<Validator> validators) {
        this.validators = validators;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getVerify() {
        return verify;
    }

    public void setVerify(String verify) {
        this.verify = verify;
    }

    public List<Object> getParameterized() {
        return parameterized;
    }

    public void setParameterized(List<Object> parameterized) {
        this.parameterized = parameterized;
    }

    public List<String> getParameterizedCsv() {
        return parameterizedCsv;
    }

    public void setParameterizedCsv(List<String> parameterizedCsv) {
        this.parameterizedCsv = parameterizedCsv;
    }

    public String getCustomLog() {
        return customLog;
    }

    public void setCustomLog(String customLog) {
        this.customLog = customLog;
    }


    public boolean getIgnoreStep() {
        return ignoreStep;
    }
}
