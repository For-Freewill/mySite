package com.auto.qa.lesscode.api.dataprovider;

import com.auto.qa.lesscode.api.utils.JSONUtil;
import com.auto.qa.lesscode.core.model.ScenarioSpec;
import com.auto.qa.lesscode.core.model.Step;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.testng.ITestContext;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author: wulei
 * @date: 2023/11/23 下午4:02
 */
@Slf4j
public class JsonProvider {

    public String caseFile;
    public ITestContext iTestContext;
    public String caseFilePath;

    public JsonProvider(String caseFile, ITestContext iTestContext) {
        super();
        this.caseFile = caseFile;
        this.iTestContext = iTestContext;
    }

    /**
     * 解析为Scenario
     *
     * @return
     */
    public Object[][] getJsonScenario() {
        ScenarioSpec scenarioSpec = JSONUtil.fileToClass(caseFile, "", ScenarioSpec.class);
        return new Object[][]{
                {scenarioSpec}
        };
    }

    /**
     * 解析为Scenario.Step
     *
     * @return
     */
    public Object[][] getJsonStep(String stepName) {
        if (StringUtils.isEmpty(stepName)) {
            throw new NullPointerException("Step name is Empty!");
        }
        ScenarioSpec scenarioSpec = JSONUtil.fileToClass(caseFile, "", ScenarioSpec.class);
        List<Step> result = new ArrayList<>();
        if (scenarioSpec.getSteps() != null) {
            for (int i = 0; i < scenarioSpec.getSteps().size(); i++) {
                if(scenarioSpec.getSteps().get(i).getName().equals(stepName)) {
                    result.add(scenarioSpec.getSteps().get(i));
                }
            }
            if(result.size()==0){
                throw new NullPointerException("Step is not found!");
            }
            if(result.size()!=1){
                throw new IllegalArgumentException("Step name is not unique!");
            }
            return new Object[][]{
                    {result.get(0)}
            };
        }else {
            throw new NullPointerException("Step is Empty!");
        }

    }

    /**
     * 解析为HaspMap
     *
     * @return
     */
    public Object[][] getJsonMap() {
        HashMap hashMap = JSONUtil.fileToClass(caseFile, "", HashMap.class);
        return new Object[][]{
                {hashMap}
        };
    }

    public String getPath() throws IOException {
        String filePath = null;
        File directory = new File(".");
        caseFilePath = directory.getCanonicalPath() + "/src/test/resources/json";
        File sourceFile = new File(caseFilePath);
        List<File> allFileList = new ArrayList<>();
        com.auto.qa.lesscode.api.utils.FileUtils.getAllFile(sourceFile, allFileList);
        for (File file : allFileList) {
            if (file.getPath().contains(caseFile)) {
                filePath = file.getPath();
                break;
            }
        }
        if (filePath == null) {
            String tempFileName = caseFile.replaceAll("\\\\", "/");
            for (File file : allFileList) {
                if (file.getPath().contains(tempFileName)) {
                    filePath = file.getPath();
                    break;
                }
            }
        }
        return filePath;
    }
}
