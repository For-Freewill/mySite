package com.auto.qa.lesscode.api.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author: wulei
 * @date: 2023/11/27 下午4:33
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface GetJson {
    String filePath() default "";

    String key() default "";
}
