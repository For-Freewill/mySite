package com.auto.qa.lesscode.core.engine.executor.httpapi;

/**
 * @author wulei
 */
public interface HttpApiExecutor {
    /**
     * 执行http请求
     * @param url
     * @param method
     * @param requestJson
     * @return
     * @throws Exception
     */
    String execute(String url, String method, String requestJson) throws Exception;
}
