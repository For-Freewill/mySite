import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
// 引入自定义的flex.css
import "./assets/css/flex.css";
//引入element组件库
import ElementUI from "element-ui";
//引入element样式文件
import "element-ui/lib/theme-chalk/index.css";
//使用element
Vue.use(ElementUI);

Vue.config.productionTip = false;
// 引入Fragment解决收缩菜单时文字的隐藏问题
import Fragment from "vue-fragment";
Vue.use(Fragment.Plugin);
router.beforeEach((to, from, next) => {
  // to 进入的路由
  // from 将要离开的路由
  // next 让路由继续

  // 获取当前打开的选项卡
  store.commit("getTabs");
  // 设置当前激活的选项卡
  store.commit("setActiveTabs", to.name);
  //如果store中的菜单数据menu_data被刷新了，那么从新加载
  let menuData = sessionStorage.getItem("menuList");
  if (to.path === "/login") {
    if (menuData) {
      next({ path: "/home" });
    } else {
      next();
    }
  } else {
    if (!menuData && to.name !== "login") {
      next({ path: "/login" });
    } else {
      if (store.state.MenuStore.menu_data.length == 0) {
        store.commit("getMenuList", router);
        next({ path: to.path });
      } else {
        next();
      }
    }
  }
});

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
