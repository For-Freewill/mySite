<template>
  <div>
    <h3>div默认是垂直方向排列的</h3>
    <div style="background: #000079;height: 250px;">
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>div变成盒子模型,默认是水平方向</h3>
    <div style="background: #000079;height: 250px;display: flex;">
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>flex-direction:row</h3>
    <div
      style="background: #000079;height: 250px;display: flex;flex-direction:row;"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>flex-direction:row-reverse</h3>
    <div
      style="background: #000079;height: 250px;display: flex;flex-direction:row-reverse;"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>flex-direction:column</h3>
    <div
      style="background: #000079;height: 250px;display: flex;flex-direction:column;"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>flex-direction:column-reverse</h3>
    <div
      style="background: #000079;height: 250px;display: flex;flex-direction:column-reverse;"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>justify-content:center居中对齐</h3>
    <div
      style="background: #000079;height: 250px;display: flex;justify-content:center"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>justify-content:flex-start</h3>
    <div
      style="background: #000079;height: 250px;display: flex;justify-content:flex-start"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>
    <h3>justify-content:space-between</h3>
    <div
      style="background: #000079;height: 250px;display: flex;justify-content:space-between"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>justify-content:space-around</h3>
    <div
      style="background: #000079;height: 250px;display: flex;justify-content:space-around"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>align-items: flex-start;</h3>
    <div
      style="background: #000079;height: 250px;display: flex;align-items: flex-start;"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>align-items: center;</h3>
    <div
      style="background: #000079;height: 250px;display: flex;align-items: center;"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>align-items: flex-end;</h3>
    <div
      style="background: #000079;height: 250px;display: flex;align-items: flex-end;"
    >
      <div style="background: #d9006c;height: 50px; width:50px;">1</div>
      <div style="background: #FFBB77;height: 50px;width:50px;">2</div>
      <div style="background: #ccffcc;height: 50px;width:50px;">3</div>
      <div style="background: #747477;height: 50px;width:50px;">4</div>
    </div>

    <h3>flex-grow:1;</h3>
    <div style="background: #000079;height: 250px;display: flex;">
      <div style="background: #d9006c;height: 50px; width:50px;flex-grow:1">
        1
      </div>
      <div style="background: #FFBB77;height: 50px;width:50px;flex-grow:2">
        2
      </div>
      <div style="background: #ccffcc;height: 50px;width:50px;flex-grow:1">
        3
      </div>
      <div style="background: #747477;height: 50px;width:50px;flex-grow:1">
        4
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
