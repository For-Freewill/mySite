<template>
  <el-container class="home">
    <!--头部-->
    <el-header class="ub main-justify cross-center header">
      <div class="header-left-text">
        Spring Boot开发小而完整的Web前后端分离项目实战
      </div>
      <div class="ub main-center cross-center">
        <el-dropdown placement="bottom-start">
          <img class="user-img" src="../assets/images/avatar.jpg" alt />
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>个人中心</el-dropdown-item>
            <el-dropdown-item>退出</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <div class="user-role">
          <div class="welcome">欢迎您，管理员</div>
          <div class="header-time">213</div>
        </div>
      </div>
    </el-header>

    <el-container>
      <!--菜单栏-->
      <el-aside width="auto">
        <menu-bar></menu-bar>
      </el-aside>
      <!--右边main区域，tabs选项卡显示区域-->
      <el-container>
        <el-main style="padding:0;">
          <!--菜单收缩按钮-->
          <i
            class="arrowIcon"
            :class="[isCollapse ? 'el-icon-s-unfold' : ' el-icon-s-fold']"
            @click="iconClick"
          ></i>
          <tabs></tabs>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </el-container>
</template>

<script>
// @ is an alias to /src
import MenuBar from "../components/MenuBar.vue";
import tabs from "../components/tabs.vue";
import { mapState } from "vuex";
export default {
  name: "Home",
  components: { MenuBar, tabs },
  computed: {
    ...mapState({
      isCollapse: state => state.MenuStore.isCollapse
    })
  },
  methods: {
    iconClick() {
      //console.log("clicked");
      this.$store.commit("setOpenorClose");
    },
  },
};
</script>

<style lang="css" scope>
.el-tabs__header {
  position: static!important;
}
.arrowIcon {
  font-size: 24px;
  border: 1px solid transparent;
  float: left;
  height: 39px;
  width: 50px;
  background: #eaedf1;
  text-align: center;
  line-height: 39px !important;
}
.home {
  height: 100%;
  width: 100%;
}
.header {
  background-color: #167bd8;
  color: #fff;
}
.header-left-text {
  font-size: 20px;
}
.user-img {
  height: 45px;
  width: 45px;
  border-radius: 50%;
  cursor: pointer;
}
.user-role {
  margin-left: 10px;
}
.welcome {
  font-size: 15px;
  font-weight: bolder;
}
.header-time {
  font-size: 14px;
}
.menu-bar:not(.el-menu--collapse) {
  width: 200px;
  min-height: 400px;
}
.el-menu {
  border-right: none;
}
.el-aside {
  border-right: 1px solid #e6e6e6;
}
</style>
