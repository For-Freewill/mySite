<template>
  <div class="about">
    <el-row>
      <el-button plain>朴素按钮</el-button>
    </el-row>
  </div>
</template>
