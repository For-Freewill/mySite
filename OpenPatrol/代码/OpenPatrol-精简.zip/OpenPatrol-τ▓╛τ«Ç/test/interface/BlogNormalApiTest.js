const {describe,it,before,after,afterEach}=require('mocha');
const Base=require('../Base');
const loginCookie = require('../../src/cookie/HandleCookie');
const request = require("supertest");
const {expect,assert}=require('chai');

describe('博客园cookie',function () {
    before(Base.before);
    // after(Base.after);
    afterEach(Base.afterEach);
    this.timeout(1000000);
    it('Case1-接口访问', async function () {
        const userInfo="https://www.cnblogs.com/";
        await loginCookie.loginBlogCheck(userInfo,null,null);
        // 访问userinfo接口-get
        await request('https://account.cnblogs.com/user/userinfo')
            .get('')
            .set('Accept','application/json, text/javascript')
            .set('Cookie',global.cookieStr)
            .expect([200,201,204])
            .then((response) => {
                console.log('res' + JSON.stringify(response));
                console.log('res.body=' + JSON.stringify(response.body));
                assert.equal(response.body.displayName, 'UI自动化');
                assert.equal(response.body.spaceUserId, '2910916');
            })
            .catch((err) => {
                assert.fail(err);
            });
        //postIds接口-post接口
        await request('https://www.cnblogs.com/aggsite/MyDigged/postIds')
            .post('')
            .set('Accept','application/json, text/javascript')
            .set('Cookie',global.cookieStr)
            .expect(200)
            .then((response) => {
                console.log('res' + JSON.stringify(response));
                console.log('res.body=' + JSON.stringify(response.body));
                assert.equal(JSON.stringify(response.body.records), '[]');
            })
            .catch((err) => {
                assert.fail(err);
            });
    })
})