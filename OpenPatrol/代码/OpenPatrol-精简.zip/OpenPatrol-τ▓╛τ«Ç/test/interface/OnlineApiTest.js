const {describe, it, before} = require('mocha');
const Base = require('../Base');
const request = require("supertest");
const {expect, assert} = require('chai');

describe('OnlineAPI测试', function () {
    before(Base.before);
    this.timeout(20000);
    it('1-GET方法', async function () {
        const get_url = "https://jsonplaceholder.typicode.com";
        await request(get_url)
            .get('/posts/2')
            .set('Accept', 'application/json')
            .expect(200)
            .expect('Content-Type', 'application/json; charset=utf-8')
            .then((response) => {
                console.log('res' + JSON.stringify(response));
                console.log('res.body=' + JSON.stringify(response.body));
                assert.equal(response.body.userId, 1);
                assert.equal(response.body.id, 2);
                assert.equal(response.body.title, 'qui est esse');
                expect(response.body).to.have.property('title');
            })
            .catch((err) => {
                assert.fail(err);
            });
        ;
    })
    it('2-POST方法', async function () {
        const req_body = "{\"title\":\"foo\",\"body\":\"bar\",\"userId\":1}";
        const post_url = "https://jsonplaceholder.typicode.com";

        await request(post_url)
            .post('/posts')
            .send(req_body)
            .set('Accept', 'application/json')
            .expect([200,201])
            .expect('Content-Type', 'application/json; charset=utf-8')
            .then((response) => {
                console.log('res' + JSON.stringify(response));
                console.log('res.body=' + JSON.stringify(response.body));
                assert.equal(response.body.id, 101);
            })
            .catch((err) => {
                assert.fail(err);
            });
        ;
    })
    it('3-PUT方法', async function () {
        const put_url = "https://jsonplaceholder.typicode.com";
        const body = "{\"title\":\"foo\",\"body\":\"bar\",\"userId\":1}";
        await request(put_url)
            .put('/posts/1')
            .send(body)
            .set('Accept', 'application/json')
            .expect(200)
            .expect('Content-Type', 'application/json; charset=utf-8')
            .then((response) => {
                console.log('res' + JSON.stringify(response));
                console.log('res.body=' + JSON.stringify(response.body));
                assert.equal(response.body.id, 1);
            })
            .catch((err) => {
                assert.fail(err);
            });
        ;
    })
    it('4-DELETE方法', async function () {
        const delete_url = "https://jsonplaceholder.typicode.com";
        await request(delete_url)
            .del('/posts/1')
            .set('Accept', 'application/json')
            .expect(200)
            .expect('Content-Type', 'application/json; charset=utf-8')
            .then((response) => {
                console.log('res' + JSON.stringify(response));
                console.log('res.body=' + JSON.stringify(response.body));
                assert.equal(JSON.stringify(response.body), '{}');
            })
            .catch((err) => {
                assert.fail(err);
            });
        ;
    })
})