const {describe,it,before,after,afterEach}=require('mocha');
const Base=require('../Base');
const loginCookie = require('../../src/cookie/HandleCookie');
const {assert}=require('chai');
const Api=require('../../src/utils/Api')

describe('博客园cookie',function () {
    before(Base.before);
    // after(Base.after);
    afterEach(Base.afterEach);
    this.timeout(1000000);
    it('Case1-API测试', async function () {
        const userInfo="https://www.cnblogs.com/";
        await loginCookie.loginBlogCheck(userInfo,null,null);
        // 访问userinfo接口-get
        let spaceUserId;//参数提取
        await Api.get('https://account.cnblogs.com/user/userinfo')
            .then((response) => {
                spaceUserId=response.body.spaceUserId;
                assert.equal(response.status, 200);
            });
        console.log('spaceUserId='+spaceUserId);

        //postIds接口-post接口
        await Api.post('https://www.cnblogs.com/aggsite/MyDigged/postIds','')
            .then((response) => {
                assert.equal(response.status, 200);
            });
    })
})