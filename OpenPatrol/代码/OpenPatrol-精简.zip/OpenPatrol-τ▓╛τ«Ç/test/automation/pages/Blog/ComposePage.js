const Element = require('../Element');
const newPuppeteer = require('../../../../src/utils/NewPuppeteer');
const ComposePage = {
    //url
    'compose_url': "https://msg.cnblogs.com/compose",

    //元素封装
    'input_receiver': Element('#txtIncept', '收件人'),
    'input_title': Element('#txtTitle', '标题'),
    'input_content': Element('#txtContent', '内容'),
    'button_send': Element('#btnSend', '收件人'),
    'text_success': Element('#span_msg > div > span', '发送成功'),
    'button_inbox': Element('#span_msg > div > a[href=\'/inbox\']', '返回收信箱'),
    //api
    'api_md': "https://msg.cnblogs.com/api/common/md",
    'api_getMgsCount': "https://msg.cnblogs.com/api/message",

    //常见方法
    /**
     * 撰写短消息
     */
    composeMsg: async function (receiver,title) {
        //输入信息并跳转
        await newPuppeteer.focusAndType(this.input_receiver,receiver);
        await newPuppeteer.focusAndType(this.input_title,title);
        await newPuppeteer.focusAndType(this.input_content,'content'+Date.now());
        await newPuppeteer.click(this.button_send);

        //等待响应返回200
        await page.waitForResponse(response => response.status() === 200);
        await page.waitForTimeout(2000);
    }

};
module.exports=ComposePage;