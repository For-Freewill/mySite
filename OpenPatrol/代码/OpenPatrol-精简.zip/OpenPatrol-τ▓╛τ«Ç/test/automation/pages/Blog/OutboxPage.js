const Element = require('../Element');
const newPuppeteer = require('../../../../src/utils/NewPuppeteer');
const OutboxPage = {
    //url
    'outbox_url': "https://msg.cnblogs.com/outbox",
    //元素封装
    'checkbox_all': Element('#chkSelAll', '选择所有'),
    'button_delete': Element('#btnBatDel', '删除选中'),
    'dialog_box': Element('body > div.alertify > div > div', '确定要删除吗？'),
    'dialog_ok': Element('body > div.alertify > div > div > nav > button.ok', '确定'),
    'text_delete': Element('#opt_tips', '删除成功'),
    //api
    'api_batchDelete': " https://msg.cnblogs.com/api/message/batchdelete?ids=3711531",

    //常见方法
    /**
     * 删除所有消息
     */
    deleteAllMsg: async function () {
        //1. 点击选中全部
        await newPuppeteer.click(this.checkbox_all);
        //2. 点击确认删除
        await newPuppeteer.click(this.button_delete);
        //3. 如果弹出框，点击确认删除
        if(await newPuppeteer.isExist(this.dialog_box)){
            await newPuppeteer.click(this.dialog_ok);
        }
    }

};
module.exports=OutboxPage;