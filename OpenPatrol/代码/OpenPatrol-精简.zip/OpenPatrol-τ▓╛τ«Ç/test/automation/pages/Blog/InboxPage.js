const Element = require('../Element');
const newPuppeteer = require('../../../../src/utils/NewPuppeteer');
const InboxPage = {
    //url
    'inbox_url': "https://msg.cnblogs.com/inbox",
    //元素封装
    'button_compose': Element('#right_sidebar > div > ul > li:nth-child(1) > a[href=\'/compose\']', '撰写短消息'),
    //api
    'api_current': "https://msg.cnblogs.com/api/user/current",
    'api_getMgsCount': "https://msg.cnblogs.com/api/message/GetNewMsgCount",

    //常见方法
    /**
     * 跳转撰写短消息
     */
    gotoComposeMsg: async function () {
        //1. 点击撰写短消息
        await newPuppeteer.click(this.button_compose);

        //等待响应返回200
        await page.waitForResponse(response => response.status() === 200);
        await page.waitForTimeout(2000);
    }

};
module.exports=InboxPage;