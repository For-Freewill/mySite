const Element = require('../Element');
const LoginBlogPage = {
    'login_url': "https://account.cnblogs.com/signin",
    //元素封装
    'password_login': Element('#mat-tab-label-0-0 > div', '密码登录'),
    'name': Element('#mat-input-0', '登陆用户名/邮箱'),
    'password': Element('#mat-input-1', '密码'),
    'remember': Element('#mat-checkbox-1 > label > span.mat-checkbox-inner-container', '记住我'),
    'login_btn': Element('body > app-root > app-sign-in-layout > div > div > app-sign-in > app-content-container > div > div > div > form > div > button', '登录'),
    //常见方法
    /**
     * 密码登陆
     */
    passwordLogin: async function (login_name,login_pwd) {
        //1. 登陆：博客园
        await page.goto(LoginBlogPage.login_url);
        //2. 点击：密码登陆
        await page.waitForSelector(LoginBlogPage.password_login.selector, {timeout: 2 * 1000}).then(ele => {
            ele.click()
        }).catch(e => {
            console.log(e)
        })
        //3. 输入：用户名
        await page.focus(LoginBlogPage.name.selector);
        await page.type(LoginBlogPage.name.selector, login_name);
        //4. 输入：密码
        await page.focus(LoginBlogPage.password.selector);
        await page.type(LoginBlogPage.password.selector, login_pwd);
        //5. 勾选：记住我（可选）
        // await page.click(LoginBlogPage.remember.selector);
        //6. 点击：登陆
        await page.waitForSelector(LoginBlogPage.login_btn.selector, {timeout: 2 * 1000}).then(ele => {
            ele.click()
        }).catch(e => {
            console.log(e)
        })
        //等待响应返回200
        await page.waitForResponse(response => response.status() === 200);
        await page.waitForTimeout(2000);
    }

};
module.exports=LoginBlogPage;