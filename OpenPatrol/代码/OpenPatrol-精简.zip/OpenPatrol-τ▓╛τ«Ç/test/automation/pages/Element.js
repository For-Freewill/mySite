const Element = (selector, content, msg) => ({selector, content, msg});
module.exports = Element;