const {describe,it,before,after,afterEach}=require('mocha');
const Base=require('../../../Base');
const newPuppeteer=require('../../../../src/utils/NewPuppeteer');
const Element = require('../../../../test/automation/pages/Element');

describe('LoginBase',function () {
    before(Base.before);
    // after(Base.after);
    // afterEach(Base.afterEach);
    const wangye=Element('#sbox > tbody > tr > td.search > table > tbody > tr > td.help > a','帮助');
    this.timeout(20000);
    it('Case1-打开百度', async function () {
        await page.goto('https://www.baidu.com/');
    })
    it('Case2-搜索', async function () {
        await page.goto('http://news.baidu.com/');
        await page.waitForTimeout(2000)
        const el =await newPuppeteer.find(wangye,2000);
        console.log(el.screenshot())
    })
})