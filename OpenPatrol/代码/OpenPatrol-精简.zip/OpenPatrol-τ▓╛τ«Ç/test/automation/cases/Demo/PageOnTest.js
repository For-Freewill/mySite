const {describe,it,before,after,afterEach}=require('mocha');
const Base=require('../../../Base');
const {assert}=require('chai');

describe('Page事件监听',function () {
    before(Base.before);
    // after(Base.after);
    afterEach(Base.afterEach);
    this.timeout(40000);
    it('1-Load事件', async function () {
        //load事件
        await page.on('load',async load=>{
            console.log('load event');
        });
        console.log('开始登陆')
        //1.博客园
        await page.goto("https://account.cnblogs.com/signin");
        //3. 输入：用户名
        await page.focus('#mat-input-0');
        await page.type('#mat-input-0','UI自动化');
        //4. 输入：密码
        await page.focus('#mat-input-1');
        await page.type('#mat-input-1','520bokeyuan');
    })

    it('2-console事件', async function () {
        //console
        await page.on('console',async console_msg=>{
            console.log("console output：type="+console_msg.type()+",msg="+console_msg.text())
        });
        console.log('开始登陆')
        //1.博客园
        await page.goto("https://account.cnblogs.com/signin");
        //3. 输入：用户名
        await page.focus('#mat-input-0');
        await page.type('#mat-input-0','UI自动化');
        //4. 输入：密码
        await page.focus('#mat-input-1');
        await page.type('#mat-input-1','520bokeyuan');
    })

    it('3-pageerror事件', async function () {
        //pageerror
        await page.on('pageerror',async error=>{
            console.log("page error"+error);
        });
        console.log('开始登陆')
        //1.博客园
        await page.goto("https://account.cnblogs.com/signin");
        //3. 输入：用户名
        await page.focus('#mat-input-0');
        await page.type('#mat-input-0','UI自动化');
        //4. 输入：密码
        await page.focus('#mat-input-1');
        await page.type('#mat-input-1','520bokeyuan');
    })
    it('4-requestfinished事件', async function () {
        //requestfinished
        await page.on('requestfinished',async request => {
            const res = request.response();
            if (request.resourceType() == "xhr" && res.status()!==200) {
                console.log("接口="+request.url()+"，请求数据="+request.postData()+"，返回状态="+res.status());
                res.text().then(text => {
                    console.log("返回体="+text);
                });
            }
        });
        //1.博客园
        await page.goto("https://account.cnblogs.com/signin");
    })
    it('5-response事件', async function () {
        //1. 登陆：博客园
        await page.goto("https://account.cnblogs.com/signin");
        //2. 点击：密码登陆
        await page.waitForSelector('#mat-tab-label-0-0 > div',{timeout:2*1000}).then(ele=>{ele.click()}).catch(e=>{console.log(e)})
        //3. 输入：用户名
        await page.focus('#mat-input-0');
        await page.type('#mat-input-0','UI自动化');
        //4. 输入：密码
        await page.focus('#mat-input-1');
        await page.type('#mat-input-1','520bokeyuan');
        //5. 勾选：记住我（可选）
        // await page.click('#mat-checkbox-1 > label > span.mat-checkbox-inner-container');
        //6. 点击：登陆
        await page.waitForSelector('body > app-root > app-sign-in-layout > div > div > app-sign-in > app-content-container > div > div > div > form > div > button',{timeout:2*1000}).then(ele=>{ele.click()}).catch(e=>{console.log(e)})
        //response
        await page.on('response',async res => {
            if(res.url().indexOf("https://www.cnblogs.com/aggsite/allsitecategories")!==-1 &&res.status() === 200){
                res.text().then(text => {
                    console.log("返回体="+text);
                });
            }
        });
        //等待响应返回200
        await page.waitForResponse(response => response.status() === 200);
        await page.waitForTimeout(2000);
        await page.goto("https://home.cnblogs.com/u/2910916");
    })
    it('6-request事件-请求拦截', async function () {
        //1. 登陆：博客园
        await page.goto("https://account.cnblogs.com/signin");
        //2. 点击：密码登陆
        await page.waitForSelector('#mat-tab-label-0-0 > div',{timeout:2*1000}).then(ele=>{ele.click()}).catch(e=>{console.log(e)})
        //3. 输入：用户名
        await page.focus('#mat-input-0');
        await page.type('#mat-input-0','UI自动化');
        //4. 输入：密码
        await page.focus('#mat-input-1');
        await page.type('#mat-input-1','520bokeyuan');
        //5. 勾选：记住我（可选）
        // await page.click('#mat-checkbox-1 > label > span.mat-checkbox-inner-container');
        //6. 点击：登陆
        await page.waitForSelector('body > app-root > app-sign-in-layout > div > div > app-sign-in > app-content-container > div > div > div > form > div > button',{timeout:2*1000}).then(ele=>{ele.click()}).catch(e=>{console.log(e)})
        //request：拦截图片请求
        await page.setRequestInterception(true);//开启请求拦截
        await page.on('request',async request => {
            if(request.resourceType()==='image'){
                return request.abort();//图片请求，直接丢弃
            }else{
                return request.continue();//其他请求，继续
            }
        });
        //等待响应返回200
        await page.waitForResponse(response => response.status() === 200);
        await page.waitForTimeout(2000);
        await page.goto("https://home.cnblogs.com/u/2910916");
    })
    it('6-request事件-Mock', async function () {
        //1. 登陆：博客园
        await page.goto("https://account.cnblogs.com/signin");
        //2. 点击：密码登陆
        await page.waitForSelector('#mat-tab-label-0-0 > div',{timeout:2*1000}).then(ele=>{ele.click()}).catch(e=>{console.log(e)})
        //3. 输入：用户名
        await page.focus('#mat-input-0');
        await page.type('#mat-input-0','UI自动化');
        //4. 输入：密码
        await page.focus('#mat-input-1');
        await page.type('#mat-input-1','520bokeyuan');
        //5. 勾选：记住我（可选）
        // await page.click('#mat-checkbox-1 > label > span.mat-checkbox-inner-container');
        //6. 点击：登陆
        await page.waitForSelector('body > app-root > app-sign-in-layout > div > div > app-sign-in > app-content-container > div > div > div > form > div > button',{timeout:2*1000}).then(ele=>{ele.click()}).catch(e=>{console.log(e)})
        //request
        await page.setRequestInterception(true);//开启请求拦截
        await page.on('request',async request => {
            if(request.url()==="https://www.cnblogs.com/aggsite/allsitecategories"){
                await request.respond({//自定义返回
                    status: 200,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                    },
                    contentType: 'application/json; charset=utf-8',
                    body: JSON.stringify({"code":0,"msg":""})}
                    );
            }else{
                return request.continue();//其他请求，继续
            }
        });
        //等待响应返回200
        await page.waitForResponse(response => response.status() === 200);
        await page.waitForTimeout(2000);
    })
})