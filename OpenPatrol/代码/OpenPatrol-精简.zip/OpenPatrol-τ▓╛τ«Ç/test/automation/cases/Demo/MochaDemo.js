const puppeteer = require('puppeteer');
const {describe,it,before,beforeEach,after,afterEach}=require('mocha');
const newPuppeteer = require('../../../../src/utils/NewPuppeteer');

describe('MochaTestSuite',function () {
    before(() => {console.log("before running")});
    beforeEach(() => {console.log("beforeEach running")});
    after(() => {console.log("after running")});
    afterEach(() => {console.log("afterEach running")});
    this.timeout(100000);
    it('用例1：打开百度', async function () {
        const browser = await puppeteer.launch({    //启动浏览器
            headless: false,   //代码运行时打开浏览器方便观察
        });
        const page = await browser.newPage();  //打开浏览器的一个tab 页
        await page.goto('https://www.baidu.com/');  //访问网址 https://www.baidu.com/
        console.log("用例1：打开百度 运行中")
        await browser.close();  //关闭浏览器
    })
    it('用例2：输入puppeteer', async function () {
        const browser = await puppeteer.launch({    //启动浏览器
            headless: false,   //代码运行时打开浏览器方便观察
        });
        const page = await browser.newPage();  //打开浏览器的一个tab 页
        await page.goto('https://www.baidu.com/');  //访问网址 https://www.baidu.com/
        await page.waitForSelector('#kw');//等待输入框出现
        console.log("用例2：输入puppeteer 运行中")
        await page.type('#kw', "puppeteer");//输入：puppeteer
        await page.screenshot({path: 'test/report/screenshot/mocha.png',type:'png'});  //截图
        await browser.close();  //关闭浏览器
    })
    it('用例3：百度新闻滚动全屏截图', async function () {
        const browser = await puppeteer.launch({    //启动浏览器
            headless: false,   //代码运行时打开浏览器方便观察
        });
        const page = await browser.newPage();  //打开浏览器的一个tab 页
        await page.goto('http://news.baidu.com/');  //访问网址 http://news.baidu.com/
        //滚动全屏截图
        await newPuppeteer.fullScreen(page);
    })
})