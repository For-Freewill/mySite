const puppeteer = require('puppeteer'); //引入puppeteer库

(async () => {
    const browser = await puppeteer.launch({    //启动浏览器
        headless: false,   //代码运行时打开浏览器方便观察
        // devtools:true   //打开f12界面
    });
    const page = await browser.newPage();  //打开浏览器的一个tab 页
    await page.goto('http://news.baidu.com/');  //goto访问网址
    // await page.pdf({path:'../../../test/report/screenshot/baidu.pdf'});
    await page.evaluate(() => {
        return new Promise((resolve, reject) => {
            //滚动的总高度
            var totalHeight = 0;
            //每次向下滚动的高度 100 px
            var distance = 500;
            var timer = setInterval(() => {
                //页面的高度 包含滚动高度
                var scrollHeight = document.body.scrollHeight;
                //滚动条向下滚动 distance
                window.scrollBy(0, distance);
                totalHeight += distance;
                //当滚动的总高度 大于 页面高度 说明滚到底了。也就是说到滚动条滚到底时，以上还会继续累加，直到超过页面高度
                if (totalHeight >= scrollHeight) {
                    clearInterval(timer);
                    resolve();
                }
            }, 2000);
        })
    });

    await page.screenshot({
        path: '../../../../test/report/screenshot/baidu.png',
        fullPage:true
    });
    console.log("截图成功，等待5s后关闭浏览器");
    await page.waitForTimeout(5 * 1000); //睡眠5s'
    // await browser.close();  //关闭浏览器
})();