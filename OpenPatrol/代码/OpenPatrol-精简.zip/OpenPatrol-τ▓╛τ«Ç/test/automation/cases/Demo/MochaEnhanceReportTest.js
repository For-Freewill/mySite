const axios = require('axios');
const utilFormat = require('../../../../src/utils/ReportFormat');
const addContext = require('mochawesome/addContext');
const {describe,beforeEach,afterEach,it}=require('mocha');

describe('自定义报告TestSuite',function () {
    this.timeout(10000);
    let obj;//1-定义全局obj变量
    beforeEach(function () {
        obj = null;//2-beforeEach初始化
    })
    afterEach(function () {
        addContext(this, utilFormat.add(obj));//4-afterEach执行addContext方法传入格式化的数据
    });

    it('场景1：自定义报告', async function () {
        await axios.get("https://www.baidu.com/", {
        }).then(function (res) {
            obj = res;//3-response对象赋值给obj
        }).catch(function (error) {
            console.log(error);
        })
    })
})