const {describe,it}=require('mocha');
const {expect,assert}=require('chai');

describe('MochaChai',function () {
    this.timeout(10000);
    it('1-BDD：expect例子', async function () {
        expect('foo').to.be.a('string');
        expect(12).to.be.a('number');
        expect(1).to.equal(1);
        expect('foo').to.equal('foo');
        expect('foobar').to.have.string('bar');
        expect([1, 2, 3]).to.include(2);
        expect('foobar').to.match(/^foo/);
        expect({a: 1}).to.have.property('a');
        expect({a: 1, b: 2}).to.have.all.keys('a', 'b');
        expect({a: 1, b: 2}).to.have.any.keys('a');
    })
    it('2-TDD：assert例子', async function () {
        const teaServed = true;
        assert.isTrue(teaServed, 'the tea has been served');

        assert.deepEqual({ tea: 'green' }, { tea: 'green' });
        assert.isAtLeast(5, 2, '5 is greater or equal to 2');
        assert.isAtMost(3, 6, '3 is less than or equal to 6');
        assert.hasAnyKeys({foo: 1, bar: 2, baz: 3}, ['foo', 'iDontExist', 'baz']);
        assert.hasAllKeys({foo: 1, bar: 2, baz: 3}, {foo: 30, bar: 99, baz: 1337});
        assert.containsAllKeys({foo: 1, bar: 2, baz: 3}, ['foo', 'baz']);
        assert.lengthOf('foobar', 6, 'string has length of 6');
    })
})