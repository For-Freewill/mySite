const {describe,it,before,after,afterEach}=require('mocha');
const Base=require('../../../Base');
const loginCookie = require('../../../../src/cookie/HandleCookie');
const {assert}=require('chai');
const inboxPage = require('../../pages/Blog/InboxPage');
const composePage = require('../../pages/Blog/ComposePage');
const outboxPage = require('../../pages/Blog/OutboxPage');
const newPuppeteer = require('../../../../src/utils/NewPuppeteer');
const Api=require('../../../../src/utils/Api')

describe('博客园-短消息',function () {
    before(Base.before);
    // after(Base.after);
    afterEach(Base.afterEach);
    this.timeout(1000000);
    it('Case1-消息发送与删除', async function () {
        //页面1：收件箱
        await loginCookie.loginBlogCheck(inboxPage.inbox_url,null,null);
        //收件箱页面API测试
        await Api.get(inboxPage.api_current)
            .then((response) => {
                console.log('resp='+JSON.stringify(response));
                assert.equal(response.body.alias, "2910916");
                assert.equal(response.body.displayName, "UI自动化");
                assert.equal(response.status, 200);
            });

        await Api.get(inboxPage.api_getMgsCount)
            .then((response) => {
                console.log('resp='+JSON.stringify(response));
                assert.equal(response.body, 0);
                assert.equal(response.status, 200);
            });

        //页面2：撰写短消息
        await inboxPage.gotoComposeMsg();
        //撰写短消息
        await composePage.composeMsg('2',"title2");
        //判断文字存在：发送成功
        await newPuppeteer.isExist(composePage.text_success);
        //判断元素：返回收信箱存在
        await newPuppeteer.isExist(composePage.button_inbox);
        //页面3：发件箱
        await page.goto(outboxPage.outbox_url);
        //删除所有消息
        await outboxPage.deleteAllMsg();
        //判断删除成功出现
        await newPuppeteer.isExist(outboxPage.text_delete);
    })
})