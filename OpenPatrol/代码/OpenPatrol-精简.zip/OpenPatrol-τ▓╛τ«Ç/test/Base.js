const assert = require('assert');
const init = require('../src/system/init');

class Base{
    static async before() {//before初始化页面
        try {
            console.log(this.currentTest.fullTitle()+" before running");
            // this.currentTest.retries(3);//全局设置失败重试次数=3
            if (global.browser != null || global.browser != undefined) {
                global.cookies = undefined;//开始前如果有未关闭的浏览器，先cookie置为空
                await global.browser.close();
            }
            global.browser = await init.createBrowser();
            await init.createPage(browser);
        } catch (e) {
            console.log(this.currentTest.fullTitle()+" before running failed,msg="+e);
            assert.ok(false);
        }

    }
    static async after() {///after关闭页面
        try {
            console.log(this.currentTest.fullTitle()+" after running");
            global.cookies = undefined;//最后cookie置为空
            await global.browser.close();
        } catch (e) {
            console.log(this.currentTest.fullTitle()+" after running failed:浏览器关闭异常,msg="+e);
            assert.ok(false);
        }
    }

    static async afterEach() {//失败截图
        try {
            console.log(this.currentTest.fullTitle()+" afterEach running");
            if (this.currentTest.state == 'failed') {
                console.log("开始截图")
                let currentTime = new Date().getTime();
                await page.screenshot({
                    path: './test/report/screenShot/'+this.currentTest.title+currentTime+'.png',
                    type: 'png',
                    fullPage: true
                });
            }
        } catch (e) {
            console.log("截图失败,msg="+e);
        }
    }
}

module.exports=Base;