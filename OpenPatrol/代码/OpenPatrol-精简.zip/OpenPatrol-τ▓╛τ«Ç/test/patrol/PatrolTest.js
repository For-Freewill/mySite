const {describe,it,before,after,afterEach}=require('mocha');
const Base=require('../Base');
const loginCookie = require('../../src/cookie/HandleCookie');
const patrol = require('../../src/utils/Patrol');

describe('博客园cookie',function () {
    before(Base.before);
    // after(Base.after);
    afterEach(Base.afterEach);
    this.timeout(1000000);
    it('Case1-userInfo巡检', async function () {
        const userInfo="https://home.cnblogs.com/u/2910916";
        await loginCookie.loginBlogCheck(userInfo,null,null);
        //巡检
        await patrol.patrolNormalHref(page,userInfo);
        await patrol.patrolSpecialHref(page,userInfo);
    })
    it('Case2-博客申请巡检', async function () {
        const myBlog="https://account.cnblogs.com/blog-apply";
        await loginCookie.loginBlogCheck(myBlog,null,null);
        //巡检
        await patrol.patrolNormalHref(page,myBlog);
        await patrol.patrolSpecialHref(page,myBlog);
    })
    it('Case3-个人资料巡检', async function () {
        const profile="https://home.cnblogs.com/set/profile/";
        await loginCookie.loginBlogCheck(profile,null,null);
        //巡检
        await patrol.patrolNormalHref(page,profile);
        await patrol.patrolSpecialHref(page,profile);
    })
    it('Case4-屏蔽管理巡检', async function () {
        const blocks="https://account.cnblogs.com/settings/blocks";
        await loginCookie.loginBlogCheck(blocks,null,null);
        //巡检
        await patrol.patrolNormalHref(page,blocks);
        await patrol.patrolSpecialHref(page,blocks);
    })
    it('Case5-账户设置巡检', async function () {
        const account="https://account.cnblogs.com/settings/account";
        await loginCookie.loginBlogCheck(account,null,null);
        //巡检
        await patrol.patrolNormalHref(page,account);
        await patrol.patrolSpecialHref(page,account);
    })
})