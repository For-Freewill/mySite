var config = {
    'headless': false,
    'executePath': "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    'slowMo': 50,
    'phone7': {
        'name':'iPhone 7 Plus',
        'viewPoint':{
            'width': 414,
            'height': 600,
            'deviceScaleFactor': 2,
            'isMobile': true,
            'hasTouch': true,
            'isLandscape': true
        },
        'ua':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_1_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/7.0 Mobile/12B466'
    },
    'retry':1,
    'timeout': 50000,
    'remote': false,
    'login_name':'UI自动化',
    'login_pwd':'520bokeyuan',
    'cookies': './src/cookie/nowCookies.js',
    'cookies_Baidu': './src/cookie/cookiesBaidu.js',
};
module.exports=config;