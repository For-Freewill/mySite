const puppeteer = require('puppeteer');
const defaultConfig = require('../../src/config/config')

module.exports = {
    setConfig: function () {//全局配置
        if (global.config != null || global.config != undefined) {
            return;
        }
        global.config = {
            ...defaultConfig,
        }
    },
    createBrowser: async function() {//生成浏览器
        // 加载全局配置
        this.setConfig();
        let args = ['--disable-dev-shm-usage','--disable-setuid-sandbox','--material-hybrid', '--no-sandbox']

        if (global.config.remote == false) {//默认情况下
            const browser = await puppeteer.launch({
                headless: global.config.headless, // 默认为无界面模式
                slowMo: global.config.slowMo, // 调试用，比较慢的模式
                isMobile: true,
                hasTouch: true,
                ignoreHTTPSErrors:true,
                args,
                executablePath: global.config.executePath

            });
            return browser;
        }else {
            const browser = await puppeteer.connect({
                defaultViewport: null,
                headless: true, // 默认为无界面模式
                slowMo: global.config.slowMo, // 调试用
                isMobile: true,
                hasTouch: true,
                ignoreHTTPSErrors:true,
                args,
                executablePath: global.config.executePath,
            });
            return browser;
        }
    },
    createPage: async function(browser) {//创建页面
        if (global.config.remote == false) {//默认情况，本地
            const page = await browser.newPage();
            await page.setViewport({
                'width': 1280,
                'height': 800
            });
            page.setDefaultNavigationTimeout(global.config.timeout);
            let targets = await browser.targets();
            const targetPages = await targets.filter(target => target.type() === 'page');
            //如果打开了多个页面，那么就要切换到最后一个页面
            if (targetPages.length > 2) {
                await targetPages[targetPages.length - 1].page();
            }
            global.page = page;
            //监听load事件
            // page.on('load',  async load => {
            //     console.log("load stared");
            // });
            //监听console事件:可以按照类型进行过滤
            page.on('console',  async console_msg => {
                if(console_msg.type()==='error'){
                    console.log("console error output msg="+console_msg.text());
                }
            });
            //监听page error事件
            // page.on('pageerror',  async error_msg => {
            //     console.log("page error="+error_msg);
            // });
            //监听request finished事件，对事件进行输出
            page.on('requestfinished',  async request => {
                const res = request.response();
                if (request.resourceType() == "xhr" && res.status()!==200) {
                    console.log("接口="+request.url()+"，请求数据="+request.postData()+"，返回状态="+res.status());
                    res.text().then(text => {
                        console.log("返回体="+text);
                    });
                }
            });
            return page;
        } else {
            const pages = await browser.pages();
            const page = pages[0];
            page.setViewport({
                'width': 1280,
                'height': 800
            });
            page.setDefaultNavigationTimeout(global.config.timeout);
            let targets = await browser.targets();
            const targetPages = await targets.filter(target => target.type() === 'page');
            //如果打开了多个页面，那么就要切换到最后一个页面
            if (targetPages.length > 2) {
                await targetPages[targetPages.length - 1].page();
            }
            global.page = page;
            //监听load事件
            // page.on('load',  async load => {
            //     console.log("load stared");
            // });
            //监听console事件:可以按照类型进行过滤
            page.on('console',  async console_msg => {
                if(console_msg.type()==='error'){
                    console.log("console error output msg="+console_msg.text());
                }
            });
            //监听page error事件
            // page.on('pageerror',  async error_msg => {
            //     console.log("page error="+error_msg);
            // });
            //监听request finished事件，对事件进行输出
            page.on('requestfinished',  async request => {
                const res = request.response();
                if (request.resourceType() == "xhr" && res.status()!==200) {
                    console.log("接口="+request.url()+"，请求数据="+request.postData()+"，返回状态="+res.status());
                    res.text().then(text => {
                        console.log("返回体="+text);
                    });
                }
            });
            return page;
        }
    }
}