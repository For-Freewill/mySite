const request = require("supertest");
const {assert}=require('chai');

/**
 * 封装常见的API
 */
const Api = {
    get: async function (url) {
        return request(url).get('')
            .set('Accept', 'application/json, text/javascript')
            .set('Cookie', global.cookieStr)
            .catch((err) => {
                assert.fail(err);
            });
    },
    post: async function (url, body) {
        return request(url).post('')
            .set('Accept','application/json, text/javascript')
            .set('Cookie',global.cookieStr)
            .send(body)
            .catch((err) => {
                assert.fail(err);
            });
    },
    put: async function (url, body) {
        return request(url).put('')
            .set('Accept','application/json, text/javascript')
            .set('Cookie',global.cookieStr)
            .send(body)
            .catch((err) => {
                assert.fail(err);
            });
    },
    delete: async function (url) {
        return request(url).del('')
            .set('Accept','application/json, text/javascript')
            .set('Cookie',global.cookieStr)
            .catch((err) => {
                assert.fail(err);
            });
    }
};
module.exports = Api;