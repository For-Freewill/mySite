module.exports = {
    //接口响应巡检
    patrolResp:async function(response, apis) {
        const url_list = apis instanceof Array ? apis : [apis];
        if (url_list.indexOf(response.url()) !== -1 && response.status() !== 200) {
            response.text().then(text => {
                console.log(response.request().resourceType() + '=' + response.url() + ",返回值=" + text);
            });
        }
    },
    //数组去重
    distinct:function (arr) {
        const newArr = [...new Set(arr)];
        return newArr;
    },
    //页面普通链接巡检
    patrolNormalHref:async function(page,url) {
        //指定访问页面
        await page.goto(url);
        //页面-普通超链接
        const urls = await page.evaluate(
            () => Array.from(document.body.querySelectorAll('a[href*=\'//\']'), ({ href }) => href)
        );
        //排重
        const distinct_urls =this.distinct(urls);
        console.log('子链接统计:'+url);
        console.log('普通子链接:'+distinct_urls.length);
        // 巡检页面超链接
        for (const url in distinct_urls){
            await page.goto(distinct_urls[url],{timeout:10000,waitUntil: 'domcontentloaded'}).catch(async error => {
                console.log('巡检异常URL='+distinct_urls[url]);
                console.log('异常信息='+error);
            });
            // page.on('pageerror', pageerror=> {
            //     console.log('page_error='+pageerror);
            // });
        }
        //巡检特殊子链接
        await  patrolSpecialHref(page,url);
    },
    //页面特殊链接巡检
    patrolSpecialHref:async function(page,url) {
        //指定访问页面
        await page.goto(url);
        //特殊子链接
        const special_urls = await page.$$('a[href=\'javascript:void(0)\']');
        console.log('子链接统计:'+url);
        console.log('特殊子链接:'+special_urls.length);
        for (let element of special_urls) {
            try {
                await element.tap();
                await page.waitForNavigation({
                    timeout: 5000, //
                    waitUntil: 'load'
                });
                //如果点击后，页面跳转了，需要返回
                if(url!==page.url()){
                    console.log('特殊子链接跳转到新页面'+page.url());
                    await page.goBack({ waitUntil: "networkidle0" }); // 返回到原先的检测页面
                }
            } catch (e) {
                console.log(e);
                break;
            }
        }
    }
}