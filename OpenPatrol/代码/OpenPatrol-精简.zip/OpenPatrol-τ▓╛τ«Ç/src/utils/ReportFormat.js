exports.add = function (obj) {
    let options ;
    if (obj !== null) {
        options = {
            title: '请求与响应信息',
            value: {
                请求URL: obj.config.method + " " + obj.config.baseURL + obj.config.url,
                请求Headers: obj.config.headers,
                请求体Body: obj.config.data,
                响应Headers: obj.headers,
                响应体Body: obj.data,
            }
        }
    } else
        options = {title: '请求与响应信息',value: {}};
    return options
}