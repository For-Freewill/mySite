const fs = require('fs');
const loginBlogPage = require('../../test/automation/pages/Blog/LoginBlogPage');

const HandleCookie = {
    /**
     * 登陆流程，有cookie直接跳转；无cookie，登陆后写入cookie信息后跳转
     */
    loginBlogCheck: async function (url,loginName,loginPwd,cookie_File) {
        let login_name = (loginName == undefined ? global.config.login_name : loginName);
        let login_pwd = (loginPwd == undefined ? global.config.login_pwd : loginPwd);
        let cookieFile = (cookie_File === undefined ? global.config.cookies : cookie_File);

        //1-有正确cookie，直接跳转targetURL
        const goodCookies = await this.checkCookie(login_name, cookieFile, url);
        //2-无正确cookie，先登陆，写入cookie信息，后跳转targetURL
        if (!goodCookies) {
            console.log("cookies校验错误，开始登陆并写入cookie");
            if (global.cookies === undefined) {
                //PO模式登陆
                await loginBlogPage.passwordLogin(login_name, login_pwd);
                //登陆后获取浏览器cookie
                global.cookies = await page.cookies();
                //写入cookie
                await this.writeCookie(login_name,cookieFile);
            }
            // 如果第一次进来的时候有cookie
            let newPageCookies = await page.cookies();
            // 设置global.cookieStr参数
            global.cookieStr=newPageCookies.map(item=>`${item.name}=${item.value}`).join(';')
            if (newPageCookies.length === 0) {
                // 这里需要加上"..."，是因为cookies是一个多值的数组
                console.log("没有cookie，加进来")
                await page.setCookie(...global.cookies);
            }
            // 选择店铺并跳转到目标页面
            console.log('指定URL', url);
            await page.goto(url,{timeout:20000})
        }
    },
    /**
     * 检查cookie信息是否符合要求
     * 如果存在正确的cookie信息，直接登陆到指定URL
     */
    checkCookie: async function (login_name,cookieFile, gotoUrl) {
        const TodayTimeStamp = (new Date(new Date().setHours(0, 0, 0, 0)) / 1000 * 1000).toString();//当天0点的时间戳
        try {
            var data = fs.readFileSync(cookieFile);
        } catch (error) {
            console.log(error);
            return false;
        }
        const cookies = JSON.parse(data);
        const check = cookies.pop();//读取cookie文件，POP自定义的信息进行校验
        if (check.time > TodayTimeStamp) {
            if (check.login_name == login_name) {
                await this.readCookie(cookieFile);
                console.log('cookie校验通过，直接登陆并跳转到指定URL='+gotoUrl)
                await page.goto(gotoUrl);
                return true;
            }
        }
    },
    /**
     * 从正确的cookie文件中读取cookies塞到浏览器中
     * @param cookieFile 需要输入的cookies存储路径，config文件中有默认
     * @returns {Promise.<void>};
     */
    readCookie: async function (cookieFile) {
        var data = fs.readFileSync(cookieFile);
        console.log("同步读取cookies文件成功");
        var cookies = JSON.parse(data);
        const check = cookies.pop();//读取cookie文;件，POP自定义的信息进行校验
        global.cookieStr=check.cookie_str;//设置全局的参数
        await page.setCookie(...cookies);
        global.cookies = await page.cookies();
    },

    /**
     * 写入cookie：浏览器cookies+自定义的cookie信息一起存在文件里持久化
     * 自定义cookie信息主要是记录了时间
     */
    writeCookie: async function (login_name,cookieFile) {
        if (cookieFile == null) {
            return console.error(cookieFile);
        }
        //读取浏览器cookies信息
        let cookie = await page.cookies();
        //自定义cookie检查内容
        let check = {name: "modTime"};
        check.time = new Date().getTime().toString();
        check.login_name = login_name;
        check.cookie_str =cookie.map(item=>`${item.name}=${item.value}`).join(';');//写入格式化后的cookie
        //将自定义的cookie信息加入到浏览器读取的内容中
        cookie.push(check);
        const cookieJson = JSON.stringify(cookie);
        //浏览器+自定义的cookieJson写入cookieFile（文件）中
        fs.writeFile(cookieFile, cookieJson, function (err) {
            if (err) {
                return;
            }
            console.log("异步cookies文件写入成功");
            fs.readFile(cookieFile, function (err) {
                if (err) {
                    return console.error(err);
                }
                console.log("异步读取cookies文件成功 ");
            });
        });

    },

};

module.exports=HandleCookie;
