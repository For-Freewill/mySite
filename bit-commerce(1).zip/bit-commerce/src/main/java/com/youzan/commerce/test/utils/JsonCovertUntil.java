package com.youzan.commerce.test.utils;

import com.alibaba.fastjson.JSONObject;

import java.io.*;

/**
 * created by leifeiyun on 2019/8/1
 **/
public class JsonCovertUntil {

    public static <T> T getObjectFromjson(String filePath, Class<T> tClass) {
        try {
            //filePath:相对路径
            File file = new File(filePath);
            Reader reader = new InputStreamReader(new FileInputStream(file));
            StringBuffer stringBuffer = new StringBuffer();
            int position = 0;
            while ((position = reader.read()) != -1) {
                stringBuffer.append((char) position);
            }
            reader.close();
//            T requestResult = new Gson().fromJson(stringBuffer.toString(), tClass);
            T requestResult = JSONObject.parseObject(stringBuffer.toString(), tClass);
            return requestResult;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

    }
}
