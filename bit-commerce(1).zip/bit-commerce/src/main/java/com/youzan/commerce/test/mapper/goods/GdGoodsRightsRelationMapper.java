package com.youzan.commerce.test.mapper.goods;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.goods.GdGoodsRightsRelationEntity;
import com.youzan.commerce.test.entity.dataobject.goods.GdSkuContentEntity;

/**
 * @author: wulei
 * @Date: 7/19/21 5:33 PM
 */
@DS("ycm")
public interface GdGoodsRightsRelationMapper extends BaseMapper<GdGoodsRightsRelationEntity> {
}
