package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.OrderStatus;

/**
 * created by leifeiyun on 2019/7/31
 **/
@DS("open")
public interface OpenApplicationOrderStatusMapper extends BaseMapper<OrderStatus> {
}
