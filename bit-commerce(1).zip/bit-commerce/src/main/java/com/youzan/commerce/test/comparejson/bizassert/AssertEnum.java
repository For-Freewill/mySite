package com.youzan.commerce.test.comparejson.bizassert;

/**
 * @author tianning
 * @date 2020/8/22 1:46 下午
 */
public enum AssertEnum {

    EQUAL(1, "判断相等");

    private int category;

    private String desc;

    AssertEnum(int category, String desc) {
        this.category = category;
        this.desc = desc;
    }
}
