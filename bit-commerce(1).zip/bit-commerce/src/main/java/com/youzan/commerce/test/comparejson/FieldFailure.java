package com.youzan.commerce.test.comparejson;

import lombok.Data;

/**
 * @author tianning
 * @date 2020/8/20 8:36 上午
 */
@Data
public class FieldFailure {

    /**
     * 字段名
     */
    private String field;

    /**
     * 实际值
     */
    private Object actual;

    /**
     * 期望值
     */
    private Object expect;

    public FieldFailure(String field, Object actual, Object expect) {
        this.field = field;
        this.actual = actual;
        this.expect = expect;
    }
}
