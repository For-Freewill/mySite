package com.youzan.commerce.test.utils;

import com.youzan.platform.service_chain.context.ServiceChainContext;
import com.youzan.test.quickstart.http.HttpConstant;
import com.youzan.test.quickstart.utils.PropertyUtil;
import com.youzan.test.quickstart.utils.SCUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * @Author qibu
 * @create 2019/9/11 6:38 PM
 */
public class CompareSCUtil {
    private static String sc;

    private static void initSC() {
        if (StringUtils.isEmpty(sc)) {
            String tempSC = PropertyUtil.get("env.sc");
            boolean isOnJenkins = System.getenv().get("JENKINS_HOME") != null;
            if (isOnJenkins) {
                tempSC = System.getenv().get("sc");
                if (StringUtils.isEmpty(tempSC)) {
                    tempSC = System.getProperty("sc");
                }
            }
            sc = tempSC;
        }
    }

    public static void resetSC() {
        initSC();
        setSC(sc);
    }

    public static void removeSC() {
        ServiceChainContext.removeServiceChainContext();
        HttpConstant.SC_HEADER_VALUE = "";
    }

    public static String getSC() {
        return sc;
    }

    private static void setSC(String sc) {
        if (sc != null) {
            SCUtil.setDubboServiceChain(sc);
            SCUtil.setHttpServiceChain(sc);
        } else {
            sc = "";
        }

    }
}
