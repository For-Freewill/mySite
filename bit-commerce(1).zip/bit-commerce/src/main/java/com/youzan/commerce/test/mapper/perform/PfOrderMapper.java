package com.youzan.commerce.test.mapper.perform;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;

/**
 * created by leifeiyun on 2019/12/27
 **/
@DS("ycm")
public interface PfOrderMapper extends BaseMapper<PfOrder> {
}
