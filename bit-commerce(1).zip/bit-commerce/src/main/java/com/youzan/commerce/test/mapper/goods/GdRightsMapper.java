package com.youzan.commerce.test.mapper.goods;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.goods.GdCombineItem;
import com.youzan.commerce.test.entity.dataobject.goods.GdRightsEntity;

/**
 * @author wulei
 * @date 2021/8/31 19:28
 */
@DS("ycm")
public interface GdRightsMapper extends BaseMapper<GdRightsEntity> {
}
