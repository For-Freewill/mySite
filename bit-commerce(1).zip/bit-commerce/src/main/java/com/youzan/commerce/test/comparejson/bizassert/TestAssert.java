package com.youzan.commerce.test.comparejson.bizassert;

import lombok.Data;

/**
 * @author tianning
 * @date 2020/8/22 1:43 下午
 */
@Data
public class TestAssert {

    /**
     * 描述
     */
    private String desc;

    /**
     * 期望结果
     */
    private Object expect;

    /**
     * 实际结果
     */
    private Object actual;

    /**
     * 操作符
     */
    private AssertEnum assertEnum;

    /**
     * 结果
     */
    private ResultEnum resultEnum;

    public static TestAssert getTestAssert(Object actual, Object expect, AssertEnum assertEnum, String checkPoint) {
        TestAssert testAssert = new TestAssert();
        testAssert.setActual(actual);
        testAssert.setExpect(expect);
        testAssert.setAssertEnum(assertEnum);
        testAssert.setDesc(checkPoint);
        return testAssert;
    }


    @Override
    public String toString() {
        return String.format("%s，期望值：%s, 实际值：%s", desc, expect, actual);
    }
}
