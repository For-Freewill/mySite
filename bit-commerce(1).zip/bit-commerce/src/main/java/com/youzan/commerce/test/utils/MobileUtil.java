package com.youzan.commerce.test.utils;

import java.util.Random;


/**
 * @author: huangyt.
 * @create: 2019-03-19 17:20
 **/
public class MobileUtil {

    /**
     * 随机生成手机号
     *
     * @return
     */
    public static String geneMobile() {
        Random rand = new Random();
        Integer num = rand.nextInt(1000000000);
        long time = System.currentTimeMillis() / 100L + num + 1000000000L;
        String mobile = String.valueOf(time);
        return mobile;
    }

}
