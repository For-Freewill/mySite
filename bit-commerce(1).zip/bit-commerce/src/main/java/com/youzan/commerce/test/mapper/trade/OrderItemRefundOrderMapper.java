package com.youzan.commerce.test.mapper.trade;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.OrderItemRefundOrder;

/**
 * Created by baoyan on 2020-07-30.
 */
@DS("ycm")
public interface OrderItemRefundOrderMapper extends BaseMapper<OrderItemRefundOrder> {
}
