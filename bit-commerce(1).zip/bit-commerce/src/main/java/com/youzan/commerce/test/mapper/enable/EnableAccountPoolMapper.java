package com.youzan.commerce.test.mapper.enable;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.enable.EnableAccountPoolEntity;

/**
 * @author wuwu
 * @date 2021/2/6 6:46 PM
 */
@DS("ycmqa")
public interface EnableAccountPoolMapper extends BaseMapper<EnableAccountPoolEntity> {
}
