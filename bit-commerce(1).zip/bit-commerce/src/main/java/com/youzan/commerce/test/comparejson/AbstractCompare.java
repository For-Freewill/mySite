package com.youzan.commerce.test.comparejson;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.youzan.commerce.test.comparejson.bizassert.EasyTestAssert;
import org.apache.commons.lang3.StringUtils;
import org.skyscreamer.jsonassert.FieldComparisonFailure;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.testng.collections.Lists;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author tianning
 * @date 2020/8/19 11:59 下午
 */
public abstract class AbstractCompare {
    protected JSONObject actualObject;
    protected JSONObject exceptObject;
    protected List<FieldComparisonFailure> fieldFailures = Lists.newArrayList();
    protected List<FieldComparisonFailure> fieldMissing = Lists.newArrayList();
    protected List<FieldComparisonFailure> fieldUnexpected = Lists.newArrayList();
    protected List<String> message = Lists.newArrayList();
    private List<String> ignorePath = Lists.newArrayList();
    private List<String> ignoreValue = Lists.newArrayList();
    private Pattern indexPattern = Pattern.compile("\\[\\d+\\]\\.");
    private Pattern keyPattern = Pattern.compile("\\.\\d+\\.");
    private Pattern lengthErrorPatern = Pattern.compile("(.*)\\[\\]: Excepted (\\d+) values but got (\\d+)");
    private boolean isAssert = true;

    public AbstractCompare(List<String> ignorePath, List<String> ignoreValue, boolean isAssert) {
        this.ignorePath = ignorePath;
        this.ignoreValue = ignoreValue;
        this.isAssert = isAssert;
        updateEnvIgnore();
    }

    public AbstractCompare() {
        this(Lists.newArrayList(), Lists.newArrayList(), true);
    }

    public AbstractCompare(boolean isAssert) {
        this(Lists.newArrayList(), Lists.newArrayList(), isAssert);
    }

    public AbstractCompare(List<String> ignorePath, List<String> ignoreValue) {
        this(ignorePath, ignoreValue, true);
    }

    public abstract void beforeCompareHandler();

    public abstract void afterCompareHandler();

    public CompareResult compareJSON(String actual, String expect) {
        return compare(actual, expect, null, true, null);
    }

    public CompareResult compareJSON(String actual, String expect, List<String> ignoreAbsolutePath) {
        return compare(actual, expect, ignoreAbsolutePath, true, null);
    }


    public CompareResult compareJSON(String actual, String expect, String comparePath) {
        return compare(actual, expect, null, true, comparePath);
    }

    public CompareResult compareJSONStructure(String actual, String expect) {
        return compare(actual, expect, null, false, null);
    }

    public CompareResult compareJSONStructure(String actual, String expect, List<String> ignoreAbsolutePath) {
        return compare(actual, expect, ignoreAbsolutePath, false, null);
    }

    public CompareResult compareJSONStructure(String actual, String expect, String comparePath) {
        return compare(actual, expect, null, false, comparePath);
    }

    private CompareResult compare(String actual, String expect, List<String> ignoreAbsolutePath, boolean compareValue, String comparePath) {
        try {
            actualObject = JSON.parseObject(actual);
            exceptObject = JSON.parseObject(expect);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        //对比之前，对实际结果和期望结果做处理
        beforeCompareHandler();
        JSONCompareResult result = null;
        //返回对比失败的结果
        CompareResult compareResult = new CompareResult();
        try {
            result = JSONCompare.compareJSON(JSON.toJSONString(exceptObject), JSON.toJSONString(actualObject), JSONCompareMode.STRICT);
        } catch (org.json.JSONException e) {
            e.printStackTrace();
        }
        //字段值对比错误
        fieldFailures = result.getFieldFailures();
        //实际结果有缺失字段
        fieldMissing = result.getFieldMissing();
        //实际结果有额外字段
        fieldUnexpected = result.getFieldUnexpected();
        //错误信息汇总
        message = Arrays.asList(result.getMessage().split(";"));
        //对比之后，对对比的结果做处理
        afterCompareHandler();

        if (compareValue) {
            //处理字段对比失败的结果
            for (FieldComparisonFailure item : fieldFailures) {
                if (ignoreHandler(item.getField(), item.getActual(), ignoreAbsolutePath, comparePath)) {
                    if (isAssert) {
                        EasyTestAssert.assetEquals(item.getActual(), item.getExpected(), item.getField() + "字段错误");
                    }
                    compareResult.getFieldFailures().add(new FieldFailure(item.getField(), item.getActual(), item.getExpected()));
                }
            }
            //处理list长度不一致的结果
            for (String item : message) {
                Matcher matcher = lengthErrorPatern.matcher(item.trim());
                if (matcher.find()) {
                    String listField = matcher.group(2);
                    if (ignoreHandler(listField, null, null, comparePath)) {
                        String expectedLength = matcher.group(2);
                        String actualLength = matcher.group(3);
                        if (isAssert) {
                            EasyTestAssert.assetEquals(actualLength, expectedLength, listField + "个数错误");
                        }
                        compareResult.getListFieldFailures().add(new FieldFailure(listField, actualLength, expectedLength));
                    }
                }
            }
        }
        //处理字段缺失的结果
        for (FieldComparisonFailure item : fieldMissing) {
            String field = item.getField();
            if (StringUtils.isEmpty(field)) {
                field = item.getExpected().toString();
            } else {
                field = field + "." + item.getExpected().toString();
            }
            if (ignoreHandler(field, item.getActual(), null, comparePath)) {
                if (isAssert) {
                    EasyTestAssert.assetEquals(item.getActual(), item.getExpected(), item.getField() + "字段缺失");
                }
                compareResult.getFieldMissing().add(new FieldFailure(item.getField(), item.getActual(), item.getExpected()));
            }
        }
        //处理字段冗余的结果
        for (FieldComparisonFailure item : fieldUnexpected) {
            String field = item.getField();
            if (StringUtils.isEmpty(field)) {
                field = item.getActual().toString();
            } else {
                field = field + "." + item.getActual().toString();
            }
            if (ignoreHandler(field, item.getActual(), null, comparePath)) {
                if (isAssert) {
                    EasyTestAssert.assetEquals(item.getActual(), item.getExpected(), item.getField() + "字段冗余");
                }
                compareResult.getFieldUnexpected().add(new FieldFailure(item.getField(), item.getActual(), item.getExpected()));
            }
        }
        return compareResult;
    }

    private Boolean ignoreHandler(String field, Object actualValue, List<String> ignoreAbsolutePath, String comparePath) {
        //忽略绝对路径
        if (ignoreAbsolutePath != null) {
            for (String absolutePath : ignoreAbsolutePath) {
                if (field.startsWith(absolutePath)) {
                    return false;
                }
            }
        }
        //忽略相对路径
        Matcher matcherIndex = indexPattern.matcher(field);
        field = matcherIndex.replaceAll(".");
        Matcher matcherKey = keyPattern.matcher(field);
        field = matcherKey.replaceAll(".");
        for (String item : ignorePath) {
            if (field.startsWith(item)) {
                return false;
            }
        }
        //忽略值
        if (actualValue != null) {
            for (String item : ignoreValue) {
                if (actualValue.toString().contains(item)) {
                    return false;
                }
            }
        }
        //指定对比路径
        if (StringUtils.isNotEmpty(comparePath)) {
            if (!field.startsWith(comparePath)) {
                return false;
            }
        }
        return true;
    }

    private void updateEnvIgnore() {
        String globalIgnorePath = System.getenv().getOrDefault("COMPARE_IGNORE_PATH", "");
        if (!globalIgnorePath.isEmpty()) {
            this.ignorePath.addAll(Arrays.asList(globalIgnorePath.split(";")));
        }
        String globalIgnoreValue = System.getenv().getOrDefault("COMPARE_IGNORE_VALUE", "");
        if (!globalIgnoreValue.isEmpty()) {
            this.ignorePath.addAll(Arrays.asList(globalIgnoreValue.split(";")));
        }
    }

    public JSONObject getActualObject() {
        return actualObject;
    }

    public void setActualObject(JSONObject actualObject) {
        this.actualObject = actualObject;
    }

    public JSONObject getExceptObject() {
        return exceptObject;
    }

    public void setExceptObject(JSONObject exceptObject) {
        this.exceptObject = exceptObject;
    }

    public List<FieldComparisonFailure> getFieldFailures() {
        return fieldFailures;
    }

    public void setFieldFailures(List<FieldComparisonFailure> fieldFailures) {
        this.fieldFailures = fieldFailures;
    }

    public List<FieldComparisonFailure> getFieldMissing() {
        return fieldMissing;
    }

    public void setFieldMissing(List<FieldComparisonFailure> fieldMissing) {
        this.fieldMissing = fieldMissing;
    }

    public List<FieldComparisonFailure> getFieldUnexpected() {
        return fieldUnexpected;
    }

    public void setFieldUnexpected(List<FieldComparisonFailure> fieldUnexpected) {
        this.fieldUnexpected = fieldUnexpected;
    }

    public List<String> getMessage() {
        return message;
    }

    public void setMessage(List<String> message) {
        this.message = message;
    }

}
