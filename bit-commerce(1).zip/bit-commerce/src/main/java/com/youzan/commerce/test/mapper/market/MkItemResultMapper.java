package com.youzan.commerce.test.mapper.market;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.market.MkItemResult;

/**
 * @author leifeiyun
 * @date 2020/11/5
 **/
@DS("ycm")
public interface MkItemResultMapper extends BaseMapper<MkItemResult> {
}
