package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.CrmOrder;
import com.youzan.commerce.test.entity.dataobject.yop.Order;
import com.youzan.yop.api.enums.BuyType;

import java.util.Date;

/**
 * Created by baoyan on 2021-03-30.
 */
@DS("open")
public interface CrmOrderMapper extends BaseMapper<CrmOrder>{

}