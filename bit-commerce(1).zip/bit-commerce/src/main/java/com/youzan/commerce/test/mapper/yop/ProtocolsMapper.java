package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.Protocols;

/**
 * Created by baoyan on 2021-04-20.
 */
@DS("open")
public interface ProtocolsMapper extends BaseMapper<Protocols> {
}
