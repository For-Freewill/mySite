package com.youzan.commerce.test.mapper.sms;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.sms.SmsStockDetailEntity;

/**
 * @author leifeiyun
 * @date 2021/4/8
 **/
@DS("courier")
public interface SmsStockDetailMapper extends BaseMapper<SmsStockDetailEntity> {
}
