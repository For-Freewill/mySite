package com.youzan.commerce.test.mapper.ycmJob;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.ycmJob.JbcTask;

@DS("ycm")
public interface JbcTaskMapper extends BaseMapper<JbcTask> {
}

