package com.youzan.commerce.test.mapper.market;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.market.JoinQualification;

/**
 * @author wuwu
 * @date 2021/12/10 9:54 AM
 */
@DS("ycm")
public interface JoinQualificationMapper extends BaseMapper<JoinQualification> {
}
