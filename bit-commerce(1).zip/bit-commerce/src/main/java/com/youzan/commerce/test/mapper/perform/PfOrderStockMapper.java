package com.youzan.commerce.test.mapper.perform;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStock;

/**
 * Created by baoyan on 2020-07-30.
 */
@DS("ycm")
public interface PfOrderStockMapper extends BaseMapper<PfOrderStock> {
}
