package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.Preferential;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2020-11-18 17:26
 **/
@DS("open")
public interface OpenApplicationItemPreferentionMapper extends BaseMapper<Preferential> {
}
