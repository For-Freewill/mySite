package com.youzan.commerce.test.comparejson;

import java.util.List;

/**
 * @author tianning
 * @date 2020/8/20 8:35 上午
 */
public class Compare extends AbstractCompare {

    public Compare() {
        super();
    }

    public Compare(List<String> ignorePath, List<String> ignoreValue) {
        super(ignorePath, ignoreValue);
    }

    public Compare(boolean isAssert) {
        super(isAssert);
    }

    public Compare(List<String> ignorePath, List<String> ignoreValue, boolean isAssert) {
        super(ignorePath, ignoreValue, isAssert);
    }

    @Override
    public void beforeCompareHandler() {

    }

    @Override
    public void afterCompareHandler() {

    }
}
