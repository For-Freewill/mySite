package com.youzan.commerce.test;

import com.youzan.commerce.test.utils.CompareSCUtil;
import com.youzan.test.quickstart.invoker.AnnotationListener;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;

/**
 * @author tianning
 * @date 2020/8/9 11:12 下午
 * 服务启动类
 */

@SpringBootTest(classes = QuickstartApplication.class)
@Listeners(AnnotationListener.class)
public class StartTest extends AbstractTestNGSpringContextTests {

    @BeforeClass
    public void beforeBaseClass() {
        CompareSCUtil.resetSC();
        logger.info("当前线程："+Thread.currentThread().getId()+":"+Thread.currentThread().getName());
        logger.info("测试sc：" + CompareSCUtil.getSC());
    }
}
