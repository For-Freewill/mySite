package com.youzan.commerce.test.mapper.trade;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.market.MkBizRecord;

/**
 * @Author qibu
 * @create 2019/6/26 3:53 PM
 */
@DS("ycm")
public interface BizRecordMapper extends BaseMapper<MkBizRecord> {
}