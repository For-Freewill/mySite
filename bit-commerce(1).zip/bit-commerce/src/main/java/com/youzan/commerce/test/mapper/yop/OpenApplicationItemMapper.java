package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.OpenApplicationItemEntity;

/**
 * @author wulei
 * @date 2021/2/5 10:44
 */
@DS("open")
public interface OpenApplicationItemMapper extends BaseMapper<OpenApplicationItemEntity> {
}
