package com.youzan.commerce.test.mapper.perform;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.perform.PfRegulationExec;

/**
 * @author wuwu
 * @date 2020/12/26 4:33 PM
 */
@DS("ycm")
public interface PfRegulationExecMapper extends BaseMapper<PfRegulationExec> {
}
