package com.youzan.commerce.test.utils;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.*;

/**
 * @author tianning
 * @date 2020/10/29 11:46 下午
 */
@Slf4j
public class AsynUtil {

    private static AsynUtil asynUtil;

    private static ExecutorService executorService = new ThreadPoolExecutor(4, 10, 60, TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(1000));

    static {
        Runtime.getRuntime().addShutdownHook(new Thread(executorService::shutdown));
    }

    private AsynUtil() {

    }

    public static synchronized AsynUtil getInstance() {
        if (asynUtil == null) {
            return new AsynUtil();
        }
        return asynUtil;
    }

    /**
     * 根据返回结果来判断是否进行重试
     *
     * @param executor
     * @param count
     * @param sleepMillis
     * @return
     */
    public <R> R submitWithRetryWithHandleResult(HandleResultExecutor<R> executor, int count, long sleepMillis) {
        ResultHandleAsyncTask<R> asyncTask = new ResultHandleAsyncTask(executor, count, sleepMillis);
        Future future = executorService.submit(asyncTask);
        try {
            return (R) future.get();
        } catch (Exception e) {
            log.error("获取结果异常", e);
        }
        return null;
    }

    public interface HandleResultExecutor<R> {
        R doExecute();

        // 返回true，不需要继续重试
        boolean handleResult(R result);
    }

    /**
     * 需要根据结果来判断是否重试的task
     */
    static class ResultHandleAsyncTask<R> implements Callable<R> {
        /**
         * 线程池
         */
        private HandleResultExecutor<R> executor;
        /**
         * 重试次数
         */
        private int count;
        /**
         * 睡眠时间
         */
        private long sleepMillis;

        public ResultHandleAsyncTask(HandleResultExecutor<R> executor, int count, long sleepMillis) {
            this.executor = executor;
            this.count = count;
            this.sleepMillis = sleepMillis;
        }

        @Override
        public R call() {
            CompareSCUtil.resetSC();
            log.info("当前在" + CompareSCUtil.getSC() + "环境执行用例");
            R result = null;
            boolean needRetry = true;
            for (int i = 0; i < count && needRetry; i++) {
                log.info("当前重试第"+ i + "次");
                try {
                    result = executor.doExecute();
                    if (executor.handleResult(result)) {
                        needRetry = false;
                    }
                } catch (Exception ex) {
                    log.error("invoke biz error", ex);
                }
                try {
                    TimeUnit.MILLISECONDS.sleep(sleepMillis);
                } catch (Exception ex) {
                    log.error("retryByCountWhenException thread is interrupted ! error:{}", ex, ex);
                }
            }
            return result;
        }
    }

   /* public static void main(String[] args) {
        Boolean result = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<Boolean>() {

                    @Override
                    public Boolean doExecute() {
                        return test();
                    }

                    @Override
                    public boolean handleResult(Boolean result) {
                        return result;
                    }
                }, 5, 100);
    }

    private static Boolean test() {
        System.out.println("test");
        return false;
    }*/
}