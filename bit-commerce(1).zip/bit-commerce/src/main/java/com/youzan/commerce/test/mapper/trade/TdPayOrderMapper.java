package com.youzan.commerce.test.mapper.trade;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.trade.TdPayOrder;

/**
 * Created by baoyan on 2020-07-29.
 */
@DS("ycm")
public interface TdPayOrderMapper extends BaseMapper<TdPayOrder> {

}
