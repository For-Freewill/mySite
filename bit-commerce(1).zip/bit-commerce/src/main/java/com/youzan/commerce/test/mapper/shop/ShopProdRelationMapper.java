package com.youzan.commerce.test.mapper.shop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.shop.ShopProdRelation;

import java.util.Base64;

/**
 * @author wuwu
 * @date 2021/1/18 1:57 PM
 */
@DS("shop")
public interface ShopProdRelationMapper extends BaseMapper<ShopProdRelation> {
}
