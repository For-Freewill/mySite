package com.youzan.commerce.test.utils;

import org.apache.http.util.TextUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


/**
 * @author: huangyt.
 * @create: 2018-11-21 14:48
 **/
public class DateUtil {

    public static boolean isSameDay(Date date1, Date date2) {
        if (date1 != null && date2 != null) {
            Calendar cal1 = Calendar.getInstance();
            cal1.setTime(date1);
            Calendar cal2 = Calendar.getInstance();
            cal2.setTime(date2);
            return isSameDay(cal1, cal2);
        } else {
            throw new IllegalArgumentException("The date must not be null");
        }
    }

    public static boolean isSameDay(Calendar cal1, Calendar cal2) {
        if (cal1 != null && cal2 != null) {
            return cal1.get(0) == cal2.get(0) && cal1.get(1) == cal2.get(1) && cal1.get(6) == cal2.get(6);
        } else {
            throw new IllegalArgumentException("The date must not be null");
        }
    }

    public static boolean isInitialDate(Date date) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String data = dateFormat.format(date);
        return data.contains("1970-01-01");
    }

    public static String getDate(Date date) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateString = dateFormat.format(date);
        return dateString;
    }

    /**
     * 服务期比较
     *
     * @param date1
     * @param date2
     * @param calendarType
     * @param count
     */
    public static boolean compareDate(Date date1, Date date2, Integer calendarType, Integer count) {
        System.out.println("compareDate start:--" + new Date());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        calendar.add(calendarType, count);
       /* Assert.assertTrue( simpleDateFormat.format(calendar.getTime()).compareTo(simpleDateFormat.format(date2))==0,
                "date1:"+simpleDateFormat.format(calendar.getTime())+"   date2:"+simpleDateFormat.format(date2));*/
        if (simpleDateFormat.format(calendar.getTime()).compareTo(simpleDateFormat.format(date2)) == 0) {
            System.out.println("success:compareDate method end:--  " + new Date());
            return true;

        } else {
            System.out.println("error:compareDate method end:--  " + new Date());
            System.out.println("date1： " + calendar.getTime() + "\nsimpleDateFormat.format(date2): " + simpleDateFormat.format(date2));
            System.out.println("date1:" + simpleDateFormat.format(calendar.getTime()) + "   date2:" + simpleDateFormat.format(date2));
            return false;
        }
    }

    /**
     * 将Unix时间戳转换成指定格式日期字符串
     * @param timestamp 时间戳 如："14730482650000";
     * @param formats 要格式化的格式 默认："yyyy-MM-dd HH:mm:ss";
     */
    public static String TimeStamp2Date(Date timestamp, String formats) {
        if (TextUtils.isEmpty(formats))
            formats = "yyyy-MM-dd HH:mm:ss";
        String date = new SimpleDateFormat(formats, Locale.CHINA).format(timestamp);
        return date;
    }

    /**
     * 比较2个日期的天数差
     * @param from
     * @param to
     * @return
     */
    public static Long durationDays(Date from,Date to){
        Instant instant = from.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
        LocalDate localDateFrom = localDateTime.toLocalDate();

        Instant instant2 = to.toInstant();
        ZoneId zone2 = ZoneId.systemDefault();
        LocalDateTime localDateTime2 = LocalDateTime.ofInstant(instant2, zone2);
        LocalDate localDateTo = localDateTime2.toLocalDate();

        return ChronoUnit.DAYS.between(localDateFrom,localDateTo);
    }

    /**
     * 比较2个日期的差值，支持类型设置
     * @param from
     * @param to
     * @return
     */
    public static Long durations(Date from,Date to,ChronoUnit type){
        Instant instant = from.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
        LocalDate localDateFrom = localDateTime.toLocalDate();

        Instant instant2 = to.toInstant();
        ZoneId zone2 = ZoneId.systemDefault();
        LocalDateTime localDateTime2 = LocalDateTime.ofInstant(instant2, zone2);
        LocalDate localDateTo = localDateTime2.toLocalDate();

        return type.between(localDateFrom,localDateTo);
    }

    /**
     * 比较2个日期的年数差
     * @param from
     * @param to
     * @return
     */
    public static Long durationYears(Date from,Date to){
        Instant instant = from.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
        LocalDate localDateFrom = localDateTime.toLocalDate();

        Instant instant2 = to.toInstant();
        ZoneId zone2 = ZoneId.systemDefault();
        LocalDateTime localDateTime2 = LocalDateTime.ofInstant(instant2, zone2);
        LocalDate localDateTo = localDateTime2.toLocalDate();

        return ChronoUnit.YEARS.between(localDateFrom,localDateTo);
    }

}
