package com.youzan.commerce.test.mapper.goods;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.goods.GdAtomItemPropertyRelation;

/**
 * Created by baoyan on 2020-10-12.
 */
@DS("ycm")
public interface GdAtomItemPropertyRelationMapper extends BaseMapper<GdAtomItemPropertyRelation> {
}
