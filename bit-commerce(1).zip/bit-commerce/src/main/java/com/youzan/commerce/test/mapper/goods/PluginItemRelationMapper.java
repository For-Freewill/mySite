package com.youzan.commerce.test.mapper.goods;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.goods.GdSkuEntity;
import com.youzan.commerce.test.entity.dataobject.goods.PluginItemRelationEntity;

/**
 * @author: wulei
 * @Date: 7/19/21 5:33 PM
 */
@DS("open")
public interface PluginItemRelationMapper extends BaseMapper<PluginItemRelationEntity> {
}
