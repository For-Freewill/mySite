package com.youzan.commerce.test.mapper.market;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.market.MkJoinRecord;

/**
 * @Author qibu
 * @create 2019/6/26 3:53 PM
 */
@DS("ycm")
public interface JoinRecordMapper extends BaseMapper<MkJoinRecord> {
}
