package com.youzan.commerce.test.mapper.finance;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.finance.CaCommissionSettleOrderDO;

/**
 * Created by baoyan on 11/16/21.
 */
@DS("finance")
public interface CaCommissionSettleOrderMapper extends BaseMapper<CaCommissionSettleOrderDO> {
}
