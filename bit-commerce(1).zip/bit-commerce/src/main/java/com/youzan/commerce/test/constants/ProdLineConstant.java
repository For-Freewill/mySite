package com.youzan.commerce.test.constants;

/**
 * 产品线常量
 * @author ruirui@youzan.com
 * @date 2019/6/20
 */
public interface ProdLineConstant {
    /**
     * 微商城
     */
    String WSC = "WSC";

    /**
     * 零售单店
     */

    String RETAIL = "RETAIL";

    /**
     * 零售连锁
     */
    String CHAIN_RETAIL = "CHAIN_RETAIL";

    /**
     * 零售连锁
     */
    String CHAIN_WSC = "CHAIN_WSC";

    /**
     * 美业
     */
    String BEAUTY = "BEAUTY";

    /**
     * 教育
     */
    String EDU = "EDU";
    
    /**
     * 旺小店
     */
    String WANG_XIAO_DIAN = "WANG_XIAO_DIAN";

    /**
     * 企业微信助手
     */
    String ENTERPRISE_WECHAT_ASSISTANT = "ENTERPRISE_WECHAT_ASSISTANT";

    /**
     * 其他
     */
    String OTHER = "OTHER";
}
