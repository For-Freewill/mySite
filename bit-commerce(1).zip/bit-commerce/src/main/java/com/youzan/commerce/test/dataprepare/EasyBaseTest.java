/*
package com.youzan.commerce.test.dataprepare;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.youzan.commerce.test.BaseTest;
import com.youzan.commerce.test.dataprepare.driver.SimpleDriverService;
import com.youzan.commerce.test.dataprepare.util.DataUtil;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.BeforeMethod;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

*/
/**
 * @author tianning
 * @date 2020/8/10 11:06 下午
 *//*


@Slf4j
public class EasyBaseTest extends BaseTest {

    @BeforeMethod
    public void beforeMethod(Method method) {
        List<Map<String, Object>> allCaseData = DataUtil.loadDataSource(method);
        if(CollectionUtils.isNotEmpty(allCaseData)) {
            SimpleDriverService.param = allCaseData.get(0);
        }
    }
}
*/
