package com.youzan.commerce.test.comparejson.bizassert;

/**
 * @author tianning
 * @date 2020/8/22 1:53 下午
 */
public enum ResultEnum {

    /**
     * 成功
     */
    PASS,

    /**
     * 失败
     */
    FAIL
}
