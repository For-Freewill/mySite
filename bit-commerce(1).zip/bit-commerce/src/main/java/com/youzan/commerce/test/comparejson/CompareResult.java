package com.youzan.commerce.test.comparejson;

import lombok.Data;
import org.apache.commons.compress.utils.Lists;

import java.util.List;

/**
 * @author tianning
 * @date 2020/8/20 8:35 上午
 */
@Data
public class CompareResult {

    /**
     * 存放字段对比失败结果
     */
    private List<FieldFailure> fieldFailures = Lists.newArrayList();

    /**
     * 存放字段比对缺失结果
     */
    private List<FieldFailure> fieldMissing = Lists.newArrayList();

    /**
     * 存在字段比对冗余结果
     */
    private List<FieldFailure> fieldUnexpected = Lists.newArrayList();

    /**
     * 存放list长度不一致的字段结果
     */
    private List<FieldFailure> listFieldFailures = Lists.newArrayList();

    public CompareResult() {

    }

    public List<FieldFailure> getFieldFailures() {
        return fieldFailures;
    }

    public CompareResult setFieldFailures(List<FieldFailure> fieldFailures) {
        this.fieldFailures = fieldFailures;
        return this;
    }

    public List<FieldFailure> getFieldMissing() {
        return fieldMissing;
    }

    public CompareResult setFieldMissing(List<FieldFailure> fieldMissing) {
        this.fieldMissing = fieldMissing;
        return this;
    }


    public List<FieldFailure> getFieldUnexpected() {
        return fieldUnexpected;
    }

    public CompareResult setFieldUnexpected(List<FieldFailure> fieldUnexpected) {
        this.fieldUnexpected = fieldUnexpected;
        return this;
    }

    public List<FieldFailure> getListFieldFailures() {
        return listFieldFailures;
    }

    public CompareResult setListFieldFailures(List<FieldFailure> listFieldFailures) {
        this.listFieldFailures = listFieldFailures;
        return this;
    }

}
