package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.PromotionActivity;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2020-11-20 12:51
 **/
@DS("open")
public interface PromotionActivityMappingMapper extends BaseMapper<PromotionActivity> {
}
