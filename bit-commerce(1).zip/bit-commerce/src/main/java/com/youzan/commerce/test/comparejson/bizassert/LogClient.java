package com.youzan.commerce.test.comparejson.bizassert;

import lombok.extern.slf4j.Slf4j;

/**
 * @author tianning
 * @date 2020/8/22 1:55 下午
 */
@Slf4j
public class LogClient {

    public static void logAssert(TestAssert testAssert) {
        if (testAssert.getResultEnum() == ResultEnum.PASS) {
            log.info(testAssert.toString());
        } else {
            log.error(testAssert.toString());
        }
    }
}
