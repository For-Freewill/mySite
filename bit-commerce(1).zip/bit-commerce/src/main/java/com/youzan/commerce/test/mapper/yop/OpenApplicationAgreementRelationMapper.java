package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.OpenApplicationAgreementRelationEntity;

/**
 * wulei
 **/
@DS("open")
public interface OpenApplicationAgreementRelationMapper extends BaseMapper<OpenApplicationAgreementRelationEntity> {
}
