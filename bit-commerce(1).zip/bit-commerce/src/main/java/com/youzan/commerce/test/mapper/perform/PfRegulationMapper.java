package com.youzan.commerce.test.mapper.perform;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.perform.PfRegulation;

/**
 * @author wuwu
 * @date 2020/12/26 4:43 PM
 */
@DS("ycm")
public interface PfRegulationMapper extends BaseMapper<PfRegulation> {
}
