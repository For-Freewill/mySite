package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.protocol.ProtocolContext;
import com.youzan.commerce.test.entity.dataobject.yop.OpenApplicationAgreementEntity;

/**
 * wulei
 **/
@DS("open")
public interface ProtocolsContextMapper extends BaseMapper<ProtocolContext> {
}
