package com.youzan.commerce.test.constants;

/**
 * Created by baoyan on 2018/9/4.
 */
public enum HttpType {
    GET,
    POST,
    PUT,
    DELETE,
    POST_FORMDATA
}
