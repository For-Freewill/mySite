package com.youzan.commerce.test.mapper.perform;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderItemBiz;

/**
 * @author leifeiyun
 * @date 2020/8/26
 **/
@DS("ycm")
public interface PfOrderItemBizMapper extends BaseMapper<PfOrderItemBiz> {
}
