//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.youzan.commerce.test;

import com.youzan.test.quickstart.BaseApplication;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;

@MapperScan({"com.youzan.commerce.test.mapper"})
public class QuickstartApplication extends BaseApplication {
    public QuickstartApplication() {
    }

    public static void main(String[] args) {
        System.setProperty("dubbo.application.name", "bit-commerce");
        System.setProperty("apollo.env", "qa");
        System.setProperty("youzan.apollo.enable", "false");
        SpringApplication.run(QuickstartApplication.class, args);
    }
}
