package com.youzan.commerce.test.mapper.shop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.shop.ShopProdVersionRelation;

/**
 * @author wuwu
 * @date 2021/1/18 1:59 PM
 */
@DS("shop")
public interface ShopProdVersionRelationMapper extends BaseMapper<ShopProdVersionRelation> {
}
