package com.youzan.commerce.test.mapper.yop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.yop.Gift;

/**
 * created by leifeiyun on 2019/6/2
 **/
@DS("open")
public interface OpenApplicationGiftMapper extends BaseMapper<Gift> {
}
