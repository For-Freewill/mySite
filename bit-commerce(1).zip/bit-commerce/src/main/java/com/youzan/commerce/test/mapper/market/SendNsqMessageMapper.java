package com.youzan.commerce.test.mapper.market;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.market.SendNsqMessageDO;

@DS("open")
public interface SendNsqMessageMapper extends BaseMapper<SendNsqMessageDO> {
}