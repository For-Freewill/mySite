package com.youzan.commerce.test.utils;

import java.util.Date;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-04-14 11:05
 **/
public class TimeUtils {
    public static Date getNow() {
        return new Date();
    }

    public static Date getTimeWithOffset(Long timeMillis) {
        return new Date(System.currentTimeMillis() + timeMillis);
    }
}
