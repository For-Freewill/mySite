package com.youzan.commerce.test.mapper.market;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.youzan.commerce.test.entity.dataobject.trade.DeductionResultComposition;

/**
 * Created by baoyan on 2020-07-29.
 */
@DS("ycm")
public interface DeductionResultCompositionMapper extends BaseMapper<DeductionResultComposition> {
}
