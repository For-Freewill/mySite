package com.youzan.commerce.test.comparejson.bizassert;

import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;

/**
 * @author tianning
 * @date 2020/8/22 1:40 下午
 */
@Slf4j
public class EasyTestAssert {

    public static void assetEquals(Object actual, Object expected, String checkPoint) {
        TestAssert testAssert = TestAssert.getTestAssert(actual, expected, AssertEnum.EQUAL, checkPoint);
        try {
            Assert.assertEquals(actual, expected);
        } catch (Exception e) {
            testAssert.setResultEnum(ResultEnum.FAIL);
            throw new RuntimeException(e.toString());
        } finally {
            LogClient.logAssert(testAssert);
        }
    }
}
