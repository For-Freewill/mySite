package com.youzan.test.refund.basecase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.constant.refund.RefundModeConstants;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.request.RefundNonConsumeRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/5/19 3:05 PM
 */
public class DeductionOrderRefundTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(DeductionOrderRefundTest.class);
    public Long basicPromotion = 26966L;
    public Long proPromotion = 26967L;
    public Long ultiPromotion = 26968L;
    public Boolean isUsePromotion = false;

    public Long deductionRefundKdtId = newWscKdtId();

    public String deductionRefundKdtName = "CI-接口自动化-抵扣升级订单退款";
    /**
     * 抵扣升级1次的订单退款
     */
//    @BeforeClass
//    public void beforeClass() {
//        deductionRefundKdtId = newWscKdtId();
//    }
    @Test
    public void oneTimeDeductionOrderWithGiftRefund() {
        Long deductionRefundKdtId = newWscKdtId();

        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);
        isUsePromotion = Boolean.TRUE;


        setActivityValid(basicPromotion);
        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);
        setActivityInvalid(basicPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建升级订单
        setActivityValid(proPromotion);

        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);
        setActivityInvalid(proPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));
        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        Long refundCny =1260759L;
        Long refundYzb = 19200L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");


    }

    @Test
    public void oneTimeDeductionOrderWithGiftRefundAter24Hour(){
        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);
        isUsePromotion = Boolean.TRUE;

        setActivityValid(basicPromotion);
        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);

        setActivityInvalid(basicPromotion);
        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建升级订单
        setActivityValid(proPromotion);

        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);
        setActivityInvalid(proPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        movePerformStatusByAppId(deductionRefundKdtId,873L,-100);

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));

        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));


        Long refundCny =911891L;
        Long refundYzb = 0L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");
    }


    @Test
    public void oneTimeDeductionOrderWithoutGiftRefundIn24Hour(){
        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);

        isUsePromotion = Boolean.FALSE;
        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建升级订单

        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));
        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        Long refundCny =1260000L;
        Long refundYzb = 20000L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");

    }

    @Test
    public void oneTimeDeductionOrderWithoutGiftRefundAfter24Hour(){
        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);
        isUsePromotion = Boolean.FALSE;

        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建升级订单
        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        movePerformStatusByAppId(deductionRefundKdtId,873L,-100);

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));
        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        Long refundCny =911342L;
        Long refundYzb = 0L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");

    }


    /**
     * 抵扣升级2次的订单退款
     */
    @Test
    public void twoTimesDeductionOrderWithGiftRefund() {
        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);
        isUsePromotion = Boolean.TRUE;

        setActivityValid(basicPromotion);
        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);

        setActivityInvalid(basicPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建第一笔升级订单
        setActivityValid(proPromotion);

        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);
        setActivityInvalid(proPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));

        //创建第二笔升级订单
        setActivityValid(ultiPromotion);

        PlainResult<String> deductionResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,ultimateItemId_2021,1,yzb);
        logger.info("创建订单的结果：{}",deductionResult);
        setActivityInvalid(ultiPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(deductionResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(deductionResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", deductionResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));
        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        Long refundCny =2652219L;
        Long refundYzb = 27700L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");


    }

    @Test
    public void twoTimesDeductionOrderWithGiftRefundAfter24Hour(){
        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);
        isUsePromotion = Boolean.TRUE;


        setActivityValid(basicPromotion);
        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);

        setActivityInvalid(basicPromotion);
        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建升级订单
        setActivityValid(proPromotion);

        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);
        setActivityInvalid(proPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));


        //创建第二笔升级订单
        setActivityValid(ultiPromotion);

        PlainResult<String> deductionResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,ultimateItemId_2021,1,yzb);
        logger.info("创建订单的结果：{}",deductionResult);
        setActivityInvalid(ultiPromotion);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+deductionResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(deductionResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(deductionResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", deductionResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        movePerformStatusByAppId(deductionRefundKdtId,873L,-100);

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));

        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));


        Long refundCny =1918317L;
        Long refundYzb = 0L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");
    }


    @Test
    public void twoTimesDeductionOrderWithoutGiftRefundIn24Hour(){
        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);

        isUsePromotion = Boolean.FALSE;
        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建升级订单

        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));


        //创建第二笔升级订单
        PlainResult<String> deductionResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,ultimateItemId_2021,1,yzb);
        logger.info("创建订单的结果：{}",deductionResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+deductionResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(deductionResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(deductionResult.getData()));


        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", deductionResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));
        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        Long refundCny =2650000L;
        Long refundYzb = 30000L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");

    }

    @Test
    public void twoTimesDeductionOrderWithoutGiftRefundAfter24Hour(){
        initShopByKdtId(deductionRefundKdtId);
        rechargeYzcoin(deductionRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(deductionRefundKdtId), cny);

        isUsePromotion = Boolean.FALSE;
        PlainResult<String> result =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,basicWechatItemId,1,yzb);
        logger.info("创建订单的结果：{}",result);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(result.getData()));

        //创建升级订单
        PlainResult<String> renewResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,professionItemId,1,yzb);
        logger.info("创建订单的结果：{}",renewResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(renewResult.getData()));


        //创建第二笔升级订单
        PlainResult<String> deductionResult =createNormalOrder(deductionRefundKdtId,deductionRefundKdtName,ultimateItemId_2021,1,yzb);
        logger.info("创建订单的结果：{}",deductionResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+deductionResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(deductionResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, deductionRefundKdtId);
        }

        waitForPerform(deductionRefundKdtId,873L,Long.valueOf(deductionResult.getData()));


        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", deductionResult.getData()));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        movePerformStatusByAppId(deductionRefundKdtId,873L,-100);

        deductionOrderRefundCheck(pfOrder.getId().toString());
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(tdOrder.getId()));
        PfOrder pfOrderRefunded = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        Long refundCny =1916712L;
        Long refundYzb = 0L;

        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_cny_summary"),refundCny.toString(),"cny退款不正确");
        Assert.assertEquals(JSONObject.parseObject(pfOrderRefunded.getBizExt()).get("refund_yzb_summary"),refundYzb.toString(),"yzb退款不正确");

    }




    @Override
    public PlainResult<String> createNormalOrder(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);
        Byte type = 25;

        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();

        if(isUsePromotion == true) {
            PreferentialDescApi itemPromtion = new PreferentialDescApi();
            itemPromtion.setType(type);
            itemPromtion.setSelected(true);
            if (itemId == basicWechatItemId) {
                itemPromtion.setPromotionId(basicPromotion);
            } else if (itemId == professionItemId) {
                itemPromtion.setPromotionId(proPromotion);
            } else if (itemId == ultimateItemId_2021) {
                itemPromtion.setPromotionId(ultiPromotion);
            }

            itemPromotionList.add(itemPromtion);
            orderItemForm.setItemPromotionList(itemPromotionList);
        }
        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);
        logger.info("创建订单参数:{}", JSON.toJSONString(createOrderForm));
        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);

        return resultCreateNormalOrder;
    }


    public void deductionOrderRefundCheck(String orderId) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(new Date());

        RefundNonConsumeRequest refundNonConsumeRequest = new RefundNonConsumeRequest();
        refundNonConsumeRequest.setMemo("");
        refundNonConsumeRequest.setOperatorId("2135");
        refundNonConsumeRequest.setOrderId(orderId);
        refundNonConsumeRequest.setRefundCalculateTime(refundTime);
        refundNonConsumeRequest.setRefundMode(RefundModeConstants.VALUE);
        refundNonConsumeRequest.setRefundWay("ORIG");
        PlainResult<Boolean> refundResult = refundRemoteService.refundNonConsume(refundNonConsumeRequest);
        Assert.assertEquals(refundResult.getMessage(), "successful");
        Assert.assertEquals(refundResult.getCode(), 200);
        Assert.assertTrue(refundResult.getData());
    }

}
