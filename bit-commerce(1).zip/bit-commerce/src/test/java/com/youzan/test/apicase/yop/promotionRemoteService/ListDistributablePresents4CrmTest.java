package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.StartTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.request.ListAndMatchDistributablePresents4CrmRequest;
import com.youzan.yop.api.response.ListAndMatchDistributablePresentPromotions4CrmResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: bit-commerce
 * @description   获取可分配买赠信息列表
 * @author: tianning
 * @create: 2021-03-24 14:06
 **/
public class ListDistributablePresents4CrmTest extends StartTest {
    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void listDistributablePresents4CrmTest() {
        ListAndMatchDistributablePresents4CrmRequest listAndMatchDistributablePresents4CrmRequest = new ListAndMatchDistributablePresents4CrmRequest();
        List<Long> availableCouponIdList = new ArrayList<>();
        availableCouponIdList.add(1L);
        listAndMatchDistributablePresents4CrmRequest.setAvailableCouponIdList(availableCouponIdList);
        listAndMatchDistributablePresents4CrmRequest.setTargetKdtId(58711819L);
        PlainResult<ListAndMatchDistributablePresentPromotions4CrmResponse> listDistributablePresents4CrmResult = promotionRemoteService.listDistributablePresents4Crm(listAndMatchDistributablePresents4CrmRequest);
        Assert.assertEquals(listDistributablePresents4CrmResult.getCode(), 200);
    }

    /**
     * 异常用例
     */
    @Test
    public void listDistributablePresents4CrmTargetKdtIdNullTest() {
        ListAndMatchDistributablePresents4CrmRequest listAndMatchDistributablePresents4CrmRequest = new ListAndMatchDistributablePresents4CrmRequest();
        List<Long> availableCouponIdList = new ArrayList<>();
        availableCouponIdList.add(1L);
        listAndMatchDistributablePresents4CrmRequest.setAvailableCouponIdList(availableCouponIdList);
        listAndMatchDistributablePresents4CrmRequest.setTargetKdtId(null);
        PlainResult<ListAndMatchDistributablePresentPromotions4CrmResponse> listDistributablePresents4CrmResult = promotionRemoteService.listDistributablePresents4Crm(listAndMatchDistributablePresents4CrmRequest);
        Assert.assertEquals(listDistributablePresents4CrmResult.getCode(), 130501);
    }
}
