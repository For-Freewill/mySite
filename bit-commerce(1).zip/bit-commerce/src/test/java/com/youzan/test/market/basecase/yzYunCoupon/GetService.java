package com.youzan.test.market.basecase.yzYunCoupon;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import org.apache.commons.collections.MapUtils;
import org.testng.annotations.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @author wuwu
 * @date 2021/9/16 7:48 PM
 * desc 获取ops上服务方法调用链
 */
public class GetService extends DeductBaseTest {
    @Http("ops")
    public HttpUtil opsHttp;

    public void writeServiceIntoCsv() {
        String jsonString = "{\"data\":{\"metadata\":{\"dubbo_rpc_metadata\":[{\"interfaces\":[{\"generic\":false,\"group\":\"\",\"methods\":[\"batchCancelGiftAsset\",\"batchCommitGiftAsset\",\"batchRecycleTestShopGiftAsset\",\"calculateGiftAssetValue\",\"cancelGiftAsset\",\"cancelRestrictions\",\"commitGiftAsset\",\"createAndSendGiftFromWorkflow\",\"createGiftAsset\",\"createGiftAssetBatch\",\"createGiftAssetForSCRM\",\"createMakeUpGiftAsset\",\"createPresentGiftAsset\",\"createRedeemCodeRightsGiftAsset\",\"exportGiftAsset\",\"fetchGiftAsset\",\"findGiftAssetById\",\"getGiftAssetList\",\"giftAssetModifyOwner\",\"listGfAssetByBizInfo\",\"listGfAssetByBizInfos\",\"listGfAssetByOwner\",\"pageQueryGiftAsset\",\"pageQueryGiftAssetBackstage\",\"queryGiftDistributeNotice\",\"receiveGift\",\"receiveGiftAsset\",\"recycleByBackstage\",\"recycleGiftAsset\",\"sendDynamicGiftToSpecifiedDate\",\"validateGrantGiftGoodsLegal\"],\"name\":\"com.youzan.ycm.gift.api.GiftAssetRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"deleteTemplateById\",\"fetchGiftTemplate\",\"fetchGiftTemplateBatchByTemplateIds\",\"generateAsset\",\"getAllGiftTemplateList\",\"getFilterGiftGoods\",\"getFilterGiftGoodsSku\",\"getRedeemCodeRightsGiftTemplate\",\"pageQueryGiftTemplate\",\"queryRedeemCodeStock\",\"queryStockByRedeemCodeList\",\"saveCommonGiftTemplate\",\"saveGiftTemplate\",\"savePlusPurchaseGiftTemplate\",\"updateGiftTemplate\",\"updateGiftTemplateBasicInfo\"],\"name\":\"com.youzan.ycm.gift.api.GiftTemplateRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"queryCollocationJoinCount\"],\"name\":\"com.youzan.ycm.market.api.ActivityJoinCountRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"grant\",\"invalid\",\"judgeCanGrant\",\"queryJoinQualificationByActorList\",\"queryJoinQualificationByMarketList\"],\"name\":\"com.youzan.ycm.market.api.ActivityJoinQualificationRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"createActivity\",\"updateActivityBasicInfo\",\"updateActivityState\"],\"name\":\"com.youzan.ycm.market.api.ActivityManageRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"batchQueryActivityBaseInfoByIds\",\"fuzzyQueryActivity\",\"queryAvailableActivityPromotions\",\"updateActivityState\"],\"name\":\"com.youzan.ycm.market.api.ActivityRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"pageQueryCapitalAccountRecordList\"],\"name\":\"com.youzan.ycm.market.api.CapitalAccountRecordRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"cancelCapitalAccount\",\"commitCapitalAccount\",\"freezeCapitalAccount\",\"queryCapitalAccount\",\"refundToCapitalAccount\"],\"name\":\"com.youzan.ycm.market.api.CapitalAccountRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"getColloGoodsItemInfo\",\"getFilterColloGoods\",\"listAllCollocationActivities\",\"listCollocationByMainAppId\",\"pageQueryCollocationList\",\"queryById\",\"queryCollocationById\",\"queryCollocationStatistic\",\"save\",\"saveCollocation\",\"updateCollocationState\"],\"name\":\"com.youzan.ycm.market.api.CollocationActivityRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"batchQueryCouponAssetByKdtIds\",\"batchQueryCouponBaseInfoByAssetIds\",\"batchRecycleCouponAsset\",\"batchSendCouponAsset\",\"pageQueryCouponAssetHistoryByBelongTo\",\"pageQueryCouponAssetList\",\"queryAvailableCouponAsset\",\"queryCouponAssetById\",\"queryCouponAssetDistributeNotice\",\"queryCouponAssetListByKdtId\",\"queryCouponAssetOperableByBelongToForList\",\"receiveCouponAsset\",\"recycleCouponAsset\",\"saveCouponAsset\"],\"name\":\"com.youzan.ycm.market.api.CouponAssetRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"createCoupon\",\"updateCouponBasicInfo\",\"updateCouponState\"],\"name\":\"com.youzan.ycm.market.api.CouponManageRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"fuzzyQueryCoupon\",\"fuzzyQueryCouponByBatchType\",\"pageQueryCouponList\",\"queryCollectableCoupons\",\"queryCouponById\",\"queryCouponByIdList\",\"queryCouponCreateConfig\",\"refreshCouponToNewRule\",\"saveCoupon\",\"updateCouponBasicInfo\",\"updateCouponState\"],\"name\":\"com.youzan.ycm.market.api.CouponRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"checkSendCouponRecordAvailable\",\"invalidCouponSendRecord\",\"pageQueryCouponSendRecordList\",\"queryCouponSendRuleById\",\"queryCouponStatistic\",\"saveCouponSendRecord\",\"send\",\"sendCoupon\"],\"name\":\"com.youzan.ycm.market.api.CouponSendRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"pageQueryActivityList\",\"queryActivityById\",\"queryActivityStatistic\",\"saveActivity\",\"updateActivityState\",\"updateBasicActivityById\"],\"name\":\"com.youzan.ycm.market.api.GoodsDicountActivityuRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"getReceiveObjList\",\"receive\",\"tips\"],\"name\":\"com.youzan.ycm.market.api.MKReceiveRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"noticed\"],\"name\":\"com.youzan.ycm.market.api.NotifyRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"recovery\"],\"name\":\"com.youzan.ycm.market.api.NsqFailBackRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"pageQueryActivityList\",\"queryActivityById\",\"queryActivityStatistic\",\"saveActivity\",\"updateActivityState\",\"updateBasicFullReduceActivity\"],\"name\":\"com.youzan.ycm.market.api.OrderFullReduceActivityRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"checkGiftAsset\"],\"name\":\"com.youzan.ycm.market.api.PresentAssetCheckService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"distributeStockToKdt\",\"editItemPresentPromotionBasicInfo\",\"getAvailablePresentGift\",\"getPresentActivity4Crm\",\"getPresentActivityByPresentIdForCrm\",\"getPresentActivitys4Crm\",\"getPresentPromotion\",\"invalidPresentPromotion\",\"judgeOrderIsMeetCondition\",\"listAndMatchPresentCoupon\",\"queryTemporaryPresentPromotionResponse\",\"saveItemPresentPromotion\",\"searchPresentActivity\",\"searchPresentCoupon\",\"sendPresentCoupon\",\"sendPresentGift\"],\"name\":\"com.youzan.ycm.market.api.PresentRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"invalid\",\"matchRule\",\"pageQueryRecommendList\",\"queryRecommendByRuleId\",\"queryRecommendGoods\",\"save\",\"update\"],\"name\":\"com.youzan.ycm.market.api.RecommendRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"queryStockAccount\"],\"name\":\"com.youzan.ycm.market.api.StockAccountRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"apply\",\"applyV2\",\"batchCalculate\",\"calcAndApply\",\"calculate\",\"calculateV2\",\"cancel\",\"commit\",\"queryAvailableGoodsPromotions\",\"queryJoinedPromotion\",\"queryJoinedPromotionByBuyer\"],\"name\":\"com.youzan.ycm.market.api.TradeRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"saveActivity\"],\"name\":\"com.youzan.ycm.market.api.internal.GoodsFractionDiscountActivityRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"verifyActions\",\"verifyConditions\"],\"name\":\"com.youzan.ycm.market.api.internal.MetaDataVerifyRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"addRedeemCodeConf\",\"editRedeemCodeConf\",\"getRedeemCodeConfInfo\",\"getRedeemCodeData\",\"invalidRedeemCodeConf\",\"pageRedeemCodeConf\",\"pageRedeemCodeRecord\",\"recycle\",\"recycleRedeemObj\"],\"name\":\"com.youzan.ycm.market.api.redeemcode.RedeemCodeManagerService\",\"version\":\"\"},{\"generic\":false,\"group\":\"\",\"methods\":[\"acquire\",\"acquireForNewPersonGift\",\"pageQueryRedeemCode\",\"queryRedeemCodeRecord\",\"redeem\"],\"name\":\"com.youzan.ycm.market.api.redeemcode.RedeemCodeRemoteService\",\"version\":\"\"},{\"generic\":false,\"group\":\"ycm_market\",\"methods\":[\"calculate\"],\"name\":\"com.youzan.ycm.trade.api.spi.TradeOrderPayExpireTimeCalculateSPI\",\"version\":\"\"}],\"protocol\":\"dubbo\"}]},\"namespace\":\"pre\",\"service\":\"ycm-market\"},\"message\":\"OK\",\"status\":200}\n";
        JSONObject jsonObject = new JSONObject(JSON.parseObject(jsonString));
        //JSONObject.parseObject(jsonObject.get("data"));

        Object jsonData = JSON.parseObject(jsonString).get("data");
        String data = JSON.toJSONString(jsonData);
        Object jsonMeta = JSON.parseObject(data).get("metadata");
        String dubboRpcMetadata = JSON.toJSONString(jsonMeta);
        Object jsonDubboRpcMetadata = JSON.parseObject(dubboRpcMetadata).get("dubbo_rpc_metadata");

        String metaData = JSON.toJSONString(jsonDubboRpcMetadata);

        JSONObject obj0 = JSONArray.parseArray(metaData).getJSONObject(0);

        String interfacesData = JSON.toJSONString(obj0);

//
//        String stringObj1 = JSON.toJSONString(obj0);
//
//        JSONArray arr1 = JSONArray.parseArray(stringObj1);

//        String stringObj2 = JSONObject.toJSONString(arr1);

        JSONArray jsonInterFaces = JSON.parseObject(interfacesData).getJSONArray("interfaces");

        String stringObj3 = JSONObject.toJSONString(jsonInterFaces);

        JSONArray arr = JSONArray.parseArray(stringObj3);

        //第一步：先获取csv文件的路径，通过BufferedReader类去读该路径中的文件
        File csv = new File("methods1.csv");



        try{
            //第二步：通过BufferedReader类创建一个使用默认大小输出缓冲区的缓冲字符输出流
            BufferedWriter writeText = new BufferedWriter(new FileWriter(csv));
            String flag = "";

            //第三步：将文档的下一行数据赋值给lineData，并判断是否为空，若不为空则输出
            for(int i = 0;i<arr.size();i++) {
                String stringObj = JSONObject.toJSONString(arr.get(i));
                String nameObject = JSONObject.parseObject(stringObj).getString("name");
                //String stringName = JSONObject.toJSONString(nameObject);
                JSONArray methods = JSONObject.parseObject(stringObj).getJSONArray("methods");
                //System.out.println(stringName+","+methods);
                for(int j = 0;j<methods.size();j++){
                    List<String> appData = getServiceMethodFromAppData("ycm-market","1632939180071","1632982380071",methods.get(j).toString(),nameObject);
                    //String[] stringAppData = appData.toArray(new String[appData.size()]);
                    String stringAppData = appData.toString();
                    if(nameObject != flag){
                        writeText.newLine();    //换行
                        //调用write的方法将字符串写到流中
                        writeText.write(nameObject);
                        writeText.newLine();    //换行
                        writeText.write(""+","+methods.get(j)+","+stringAppData);
                    }else {
                        writeText.newLine();    //换行
                        //调用write的方法将字符串写到流中
                        writeText.write(""+","+methods.get(j)+","+stringAppData);
                    }
                    flag = nameObject;
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

            //使用缓冲区的刷新方法将数据刷到目的地中
            writeText.flush();
            //关闭缓冲区，缓冲区没有调用系统底层资源，真正调用底层资源的是FileWriter对象，缓冲区仅仅是一个提高效率的作用
            //因此，此处的close()方法关闭的是被缓存的流对象
            writeText.close();
        }catch (FileNotFoundException e){
            System.out.println("没有找到指定文件");
        }catch (IOException e){
            System.out.println("文件读写出错");
        }
    }



    public List<String> getServiceMethodFromAppData(String app, String startTime, String endTime, String method, String service) {

        Map header = new HashMap();
        header.put("Content-Type", "application/json;charset=UTF-8");
        String cookie = "UM_distinctid=1795a46259a23-00e1233277f1fb-113c6055-13c680-1795a46259bc0; yz_log_uuid=ea1f0ec3-014a-76cd-70bc-b64524c6ae8d; yz_log_ftime=1620724515851; _hjid=a343e209-23ce-49ce-a25e-308abd9fe54e; _ga=GA1.2.1390778405.1620892865; _rdt_uuid=1620892866260.73007d70-bdf8-4007-b48c-9d72dae4689b; _fbp=fb.1.1620892868798.1224794601; gr_user_id=3a62bd44-5b9c-4ccc-8755-f61c15e5af60; yz_log_uuid=fd020a39-ff05-5889-de57-e9f725016616; yz_log_ftime=1627200803129; XIAOLV_SESSION_ID_prod=sv1-Veu4mV4FsrlhaksQeUDQfSdjUPnz1mHB2mch; KDTSESSIONID=YZ892012978094239744YZipw6iXf8; cas_username=wuwu; access_user=5718_1; authority=user; is_admin=false; username=wuwu; buId=1; buName=youzan; loc_dfp=c3e3ebd7d73d9c87ae17f85198669033; dfp=af2dc85057f7876c8c383e60ca3661cf; cas=755ef207cf59a5d51f989bca4e71545358e967df3fa8a23d16af3e00396e8f84884; OPS_JWT_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJrZXkiOiJ3dXd1IiwicmVhbG5hbWUiOiLlkLTlsI_lubMiLCJpZCI6NTcxOCwidGltZXN0YW1wIjoxNjMyOTY5MDU2LCJtb2JpbGUiOiIxODUwNzU1NjA1MiIsImdlbmRlciI6dHJ1ZSwidXNlcl9pZCI6NTcxOCwiaXNfYWRtaW4iOmZhbHNlLCJlbWFpbCI6Ind1d3VAeW91emFuLmNvbSIsImV4cCI6MTYzMzk2OTA1NSwidXNlcm5hbWUiOiJ3dXd1IiwiYWxpYXNuYW1lIjoi5ZC05ZC0In0.4VIHTFpWtxJypcws2rUPDXTvrYxZmpUA_5qvoZquWmo; UnitWhiteList=java-demo,ump-manage,uic,ump-trade,sam,shop-prod,trade-rp,scrm-level,retail-scrm,shopcenter,scrm-behavior,retail-stock,retail-stock-scm,trade-invoice,ic,pay-gateway,scrm-api,retail-ump-calculation,shop-config,retail-pay,trade-plugin,retail-trade-cart,trade-dc,retail-shop,retail-ump,retail-trademanager,ump-asset,shop-center,scrm,yop,ump-deal,mall-trade-seller,marketing,retail-ofc-dispatcher,delivery,scrm-cmc,carmen-oauth,uic-user,yz-cardvoucher-biz,scrm-cmc-core,trade,scrm-credit,scrm-coc,trade-safeguard,trade-refund,retail-ofc,shop-configretail-scrm,price-center,cert,trade-detail,sc,retail-trade-core,trade-core,pay-gateway,pay-ucashier,ump-voucher-core,pay-assetcenter,pay-customer,bifrost-token-proxy,pay-gateway,pay-ucashier,pay-customer,pay-customercore,pay-merchant,pay-login,pay-assetcenter,pay-trading-core,pay-payment-core,pay-fund-channel,pay-acctrans,pay-microacctrans,pay-user,pay-usercore,pay-cashier,pay-cardvoucher,pay-cardvoucherop,pay-payment-recharge,bifrost-youzan-gateway,bifrost-youzan-oauth,paas-test-provider,paas-test-consumer,paas-test-node,yz7test-tool,bifrost-proxy; _pk_id.1.9bec=09fb41ccd43b149f.1627302993.89.1632972633.1632972633.; _pk_ses.1.9bec=*; yz_log_seqb=1632972634148; yz_log_seqn=6";
        header.put("Cookie",cookie);


        Map<String,Object> params = new HashMap<>();
        params.put("action","Soa.getServiceMethodFromAppData");
        params.put("app",app);
        params.put("startTime",startTime);
        params.put("endTime",endTime);
        params.put("method", method);
        params.put("service", service);
        params.put("env","prod");
        params.put("metric","qps");

        String url = "/api/v1.0/skynet/dispatch";

        String newUrl = appendUrlParams(url,params);

        String stringResult = opsHttp.doGetReturnResponse(newUrl,"",header);

        System.out.println(stringResult);
        JSONObject data = JSONObject.parseObject(stringResult);
        JSONObject appData = data.getJSONObject("data");
        String stringAppData = JSON.toJSONString(appData);
        Map maps = (Map)JSON.parse(stringAppData);
        List<String> appDataList = new ArrayList<>();
        if(maps == null) {
            return null;
        }
        for (Object map : maps.entrySet()){
//            System.out.println(((Map.Entry)map).getKey()+"     " + ((Map.Entry)map).getValue());
            System.out.println(((Map.Entry)map).getKey());
            appDataList.add(((Map.Entry)map).getKey().toString());

        }
        System.out.println(appDataList);
        return appDataList;
    }


    public String appendUrlParams(String url, Map<String, Object> params) {
        if (MapUtils.isNotEmpty(params)) {
            if (!url.endsWith("?")) {
                url = url + "?";
            }

            url = url + (String)params.entrySet().stream().map((entry) -> {
                return (String)entry.getKey() + "=" + (entry.getValue() == null ? "" : entry.getValue());
            }).collect(Collectors.joining("&"));
        }

        return url;
    }

//    public static void main(String[] args) {
//        String response = getServiceMethodFromAppData("ycm-market","1631954220748","1631954220748","updateCouponState","com.youzan.ycm.market.api.CouponRemoteService");
//        System.out.println(response);
//    }

    @Test(enabled = false)
    public void getStringResult() {
//        String response = getServiceMethodFromAppData("ycm-market","1632236280202","1632238080202","pageQueryGiftAsset","com.youzan.ycm.gift.api.GiftAssetRemoteService");
//        System.out.println(response);
//        JSONObject data = JSONObject.parseObject(response);
//        JSONObject appData = data.getJSONObject("data");
//        String stringAppData = JSON.toJSONString(appData);
//        Map maps = (Map)JSON.parse(stringAppData);
//        for (Object map : maps.entrySet()){
////            System.out.println(((Map.Entry)map).getKey()+"     " + ((Map.Entry)map).getValue());
//            System.out.println(((Map.Entry)map).getKey());
//
//        }
//        List<String> app = new ArrayList<>();
//        for(int i = 0; i<appData.size();i++) {
//                app.add(appData)
//        }

        //getServiceMethodFromAppData("ycm-market","1632236280202","1632238080202","pageQueryGiftAsset","com.youzan.ycm.gift.api.GiftAssetRemoteService");
        writeServiceIntoCsv();

    }



}
