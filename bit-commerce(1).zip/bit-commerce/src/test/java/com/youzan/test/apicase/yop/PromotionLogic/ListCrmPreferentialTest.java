/*
package com.youzan.test.apicase.yop.PromotionLogic;

import com.youzan.commerce.test.StartTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.entity.ListCrmPreferentialParam;
import com.youzan.yop.api.entity.OpenAppCrmPreferentialApi;
import com.youzan.yop.api.form.order.CalOrderPriceForm;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

*/
/**
 * @program: bit-commerce
 * @description 查询进行中的优惠
 * @author: tianning
 * @create: 2021-03-24 16:22
 **//*

public class ListCrmPreferentialTest extends StartTest {

    @Dubbo
    public PromotionLogic promotionLogic;

    @JSONData(value = "dataResource/apicase/yop/CalOrderPriceRequestData.json", key = "request")
    private CalOrderPriceForm calOrderPriceForm;

    */
/**
     * 正常用例
     *//*

    @Test
    public void listCrmPreferentialTest() {
        ListCrmPreferentialParam listCrmPreferentialParam = new ListCrmPreferentialParam();
        List<OpenAppCrmPreferentialApi> listCrmPreferentialResult = orderRemoteService.listCrmPreferential(listCrmPreferentialParam);
        Assert.assertEquals(calOrderPriceResult.getCode(), 200);
        Assert.assertEquals(calOrderPriceResult.getData().getItems().get(0).getItemId().longValue(), 8531);
    }
}
*/
