package com.youzan.test.checkDebugTest.CreateOrderRisk;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.form.order.RiskCheckForm;
import com.youzan.yop.api.response.ItemRiskResultApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/2/23 4:22 PM
 */
public class CheckRiskForItem extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(FuwuPackageOrderTest.class);


    public Long lsKdtId = 59200319L;
    public String lsKdtName = "CI-自动化测试-零售下单校验";

    /**
     * 新购专业版+服务包+店铺员工
     */
    @Test
    public void submitProWithFuwuPackageAndStaff() {
        closeWaitPayOrder(wscNoBuyKdtId);
        RiskCheckForm riskCheckForm = new RiskCheckForm();
        List<OrderItemForm> orderItemList = new ArrayList<>();
        List<Integer> itemIdList = Arrays.asList(professionItemId,fuwuPackageItemId,staffItemId);
        for(Integer itemId:itemIdList) {
            OrderItemForm orderItemForm = new OrderItemForm();
            orderItemForm.setItemId(itemId);
            orderItemForm.setDuration(1);
            orderItemForm.setQuantity(1);
            if (itemId == staffItemId) {
                orderItemForm.setBuyType((byte) 1);
            }
            orderItemList.add(orderItemForm);
        }

        riskCheckForm.setItemList(orderItemList);
        riskCheckForm.setKdtId(wscNoBuyKdtId);
        riskCheckForm.setAppId(873);
        riskCheckForm.setV2(true);
        logger.info("提交订单按钮风控参数：{}",JSON.toJSONString(riskCheckForm));
        /**
         * 基础环境正确返回{"code":200,"data":[],"message":"successful","success":true}
         */
        PlainResult<List<ItemRiskResultApi>> riskResult
                = compareServiceImp.invoke(()->orderRemoteService.checkRiskForItemList(riskCheckForm));

    }

    /**
     * 新购专业版+服务包
     */
    @Test
    public void submitProWithFuwuPackage() {
        closeWaitPayOrder(wscNoBuyKdtId);
        RiskCheckForm riskCheckForm = new RiskCheckForm();
        List<OrderItemForm> orderItemList = new ArrayList<>();
        List<Integer> itemIdList = Arrays.asList(professionItemId,fuwuPackageItemId);
        for(Integer itemId:itemIdList) {
            OrderItemForm orderItemForm = new OrderItemForm();
            orderItemForm.setItemId(itemId);
            orderItemForm.setDuration(1);
            orderItemForm.setQuantity(1);
            if (itemId == staffItemId) {
                orderItemForm.setBuyType((byte) 1);
            }
            orderItemList.add(orderItemForm);
        }

        riskCheckForm.setItemList(orderItemList);
        riskCheckForm.setKdtId(wscNoBuyKdtId);
        riskCheckForm.setAppId(873);
        riskCheckForm.setV2(true);
        logger.info("提交订单按钮风控参数：{}",JSON.toJSONString(riskCheckForm));
        PlainResult<List<ItemRiskResultApi>> riskResult
                = compareServiceImp.invoke(()->orderRemoteService.checkRiskForItemList(riskCheckForm));

    }


    /**
     * 新购旗舰版+服务包
     */
    @Test
    public void submitUltWithFuwuPackage() {
        closeWaitPayOrder(wscNoBuyKdtId);
        RiskCheckForm riskCheckForm = new RiskCheckForm();
        List<OrderItemForm> orderItemList = new ArrayList<>();
        List<Integer> itemIdList = Arrays.asList(ultimateItemId_2021,fuwuPackageItemId);
        for(Integer itemId:itemIdList) {
            OrderItemForm orderItemForm = new OrderItemForm();
            orderItemForm.setItemId(itemId);
            orderItemForm.setDuration(1);
            orderItemForm.setQuantity(1);
            if (itemId == staffItemId) {
                orderItemForm.setBuyType((byte) 1);
            }
            orderItemList.add(orderItemForm);
        }

        riskCheckForm.setItemList(orderItemList);
        riskCheckForm.setKdtId(wscNoBuyKdtId);
        riskCheckForm.setAppId(873);
        riskCheckForm.setV2(true);
        logger.info("提交订单按钮风控参数：{}",JSON.toJSONString(riskCheckForm));
        PlainResult<List<ItemRiskResultApi>> riskResult
                = compareServiceImp.invoke(()->orderRemoteService.checkRiskForItemList(riskCheckForm));

    }

    /**
     * 新购零售专业版+服务包
     */
    @Test
    public void submitLsProWithFuwuPackage() {
        closeWaitPayOrder(lsKdtId);
        RiskCheckForm riskCheckForm = new RiskCheckForm();
        List<OrderItemForm> orderItemList = new ArrayList<>();
        List<Integer> itemIdList = Arrays.asList(lsProItemId,lsfuwuPackageItemId);
        for(Integer itemId:itemIdList) {
            OrderItemForm orderItemForm = new OrderItemForm();
            orderItemForm.setItemId(itemId);
            orderItemForm.setDuration(1);
            orderItemForm.setQuantity(1);
            if (itemId == staffItemId) {
                orderItemForm.setBuyType((byte) 1);
            }
            orderItemList.add(orderItemForm);
        }

        riskCheckForm.setItemList(orderItemList);
        riskCheckForm.setKdtId(lsKdtId);
        riskCheckForm.setAppId(873);
        riskCheckForm.setV2(true);
        logger.info("提交订单按钮风控参数：{}",JSON.toJSONString(riskCheckForm));
        PlainResult<List<ItemRiskResultApi>> riskResult
                = compareServiceImp.invoke(()->orderRemoteService.checkRiskForItemList(riskCheckForm));

    }
}
