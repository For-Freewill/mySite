package com.youzan.test.apicase.yop.promotionRemoteService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplate;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.gift.request.CreatePresentAssetRequest;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.CreatePresentGiftAssetResponse;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import com.youzan.yop.api.GiftRemoteService;
import com.youzan.yop.api.request.ReceiveGiftRequest;
import com.youzan.yop.api.response.ReceiveGiftResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: bit-commerce
 * @description 领取礼包
 * @author: tianning
 * @create: 2021-03-24 14:32
 **/
public class ReceiveGiftTest extends TnBaseTest {

    @JSONData(value = "dataResource/apicase/yop/CreateGiftRequestData.json", key = "createPresentGiftRequest")
    private SaveGiftTemplateRequest createPresentGiftRequest;

    @Dubbo
    private GiftRemoteService giftRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void listBriefPromotionV2Test() {
        try {
            Long giftId = createGiftId();
            ReceiveGiftRequest request= new ReceiveGiftRequest();
            request.setGiftId(giftId);
            request.setKdtId(58821418L);
            PlainResult<ReceiveGiftResponse> receiveGiftResult = giftRemoteService.receiveGiftAsset(request);
            Assert.assertEquals(receiveGiftResult.getCode(), 200);
        } finally {
            deleteTemplateData();
        }
    }

    /**
     * 异常用例
     */
    @Test
    public void listBriefPromotionV2GiftIdNullTest() {
//        Long giftId = createGiftId();
        ReceiveGiftRequest request= new ReceiveGiftRequest();
        request.setGiftId(null);
        request.setKdtId(58821418L);
        PlainResult<ReceiveGiftResponse> receiveGiftResult = giftRemoteService.receiveGiftAsset(request);
        Assert.assertEquals(receiveGiftResult.getCode(), 130501);
    }


    /**
     * 创建礼包,生成giftId
     */

    public Long createGiftId() {
        Long template_id = null;

        PlainResult<SaveGiftTemplateResponse> createGiftAssetResult = createGiftTemplete(createPresentGiftRequest);

        Assert.assertEquals(createGiftAssetResult.getCode(), 200);

        String name = "创建买赠礼包模板";

        List<GiftTemplate> giftTemplateList =
                gfTemplateMapper.selectList(
                        new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, name).orderByDesc(GiftTemplate::getCreated_at));
        Assert.assertTrue(giftTemplateList.size() > 0);
        Assert.assertEquals(giftTemplateList.get(0).getName(), "创建买赠礼包模板");
        Assert.assertEquals(giftTemplateList.get(0).getType(), "PRESENT_GIFT");

        template_id = createGiftAssetResult.getData().getGiftTemplateDTO().getTemplateId();

        CreatePresentAssetRequest createPresentAssetRequest = new CreatePresentAssetRequest();
        List<Long> giftTemplateId = new ArrayList<>();
        giftTemplateId.add(0, template_id);
        createPresentAssetRequest.setGiftTemplateIds(giftTemplateId);

        List<String> giftTemplateIdStr = new ArrayList<>();
        giftTemplateIdStr.add(0, template_id.toString());
        createPresentAssetRequest.setGiftTemplateIdsStr(giftTemplateIdStr);
        createPresentAssetRequest.setDays(365);
        createPresentAssetRequest.setOperator("tianning");
        createPresentAssetRequest.setReason("买赠礼包发放测试");
        createPresentAssetRequest.setReceiveGiftType("By_HAND");

        //发放礼包的条件：一定是软件才可以给发礼包：pf_order表中：biz_order_type='trade_order' perform_state = 'performed' app_category='software'
        List<PfOrder> pfOrder =
                pfOrderMapper.selectList(
                        new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBuyKdtId, PRESENTKDTID).eq(PfOrder::getBizOrderType, "trade_order").eq(PfOrder::getPerformState, "performed").eq(PfOrder::getAppCategory, "software_meal").orderByDesc(PfOrder::getCreatedAt));
        List<String> pfOrderIdList = new ArrayList<>();
        Assert.assertTrue(pfOrder.size() > 0);

        Long pfOrderId = pfOrder.get(0).getId();

        pfOrderIdList.add(pfOrderId.toString());
        createPresentAssetRequest.setPfOrderIds(pfOrderIdList);

        PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<CreatePresentGiftAssetResponse>>() {

                    @Override
                    public PlainResult<CreatePresentGiftAssetResponse> doExecute() {
                        return giftAssetRemoteService.createPresentGiftAsset(createPresentAssetRequest);
                    }

                    @Override
                    public boolean handleResult(PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult) {
                        return presentGiftAssetResult.getCode() == 200;
                    }
                }, 5, 100);

        Long giftAssetId = presentGiftAssetResult.getData().getGiftAssetIds().get(0);

        return giftAssetId;
    }
}
