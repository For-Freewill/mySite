package com.youzan.test.market.basecase.activity;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrderItem;
import com.youzan.commerce.test.mapper.trade.TdOrderItemMapper;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.request.activity.QueryActivityDetailRequest;
import com.youzan.ycm.market.request.activity.SaveGoodsDiscountActivityRequest;
import com.youzan.ycm.market.request.activity.SaveOrderFullReduceActivityRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.response.activity.OrderFullReduceActivityDetailResponse;
import com.youzan.ycm.market.response.activity.SaveOrderFullReduceActivityResponse;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * @author leifeiyun
 * @date 2020/10/29
 **/
public class MarketActivityTest extends MarketActivityBaseTest {
    Long wscKdtId = 59527342L;

    @Autowired(required = false)
    TdOrderItemMapper tdOrderItemMapper;
    String fullOrderFullReduceActivityCreatePath = "src/test/resources/dataResource/basecase.activity/fullOrderFullReduceActivityCreate.json";
    String fullOrderCreateOrderPath = "src/test/resources/dataResource/basecase.activity/fullOrderFullReduceCreateOrder.json";
    String onlyActivityOrderFullReduceActivityCreatePath = "src/test/resources/dataResource/basecase.activity/onlyActivityOrderFullReduceActivityCreate.json";
    String onlyActivityOrderCreateOrderPath = "src/test/resources/dataResource/basecase.activity/onlyActivityOrderFullReduceCreateOrder.json";
    @JSONData("dataResource/basecase.activity/fullReduceCouponForMemberCard.json")
    private SaveCouponRequest saveFullReduceCoupon;
    @JSONData("dataResource/basecase.activity/discountCouponForMemberCard.json")
    private SaveCouponRequest saveDiscountCoupon;
    @JSONData("dataResource/basecase.activity/discountActivityForMemberCardCreate.json")
    private SaveGoodsDiscountActivityRequest saveGoodsDiscountActivityRequest;
    @JSONData("dataResource/basecase.activity/fullReducetActivityForMemberCardCreate.json")
    private SaveOrderFullReduceActivityRequest saveOrderFullReduceActivityRequest;
    @JSONData("dataResource/basecase.activity/confirmOrderForMemberCard.json")
    private ConfirmOrderForm confirmOrderForm;

    /**
     * 仅满减活动的场景->满减活动参与验证
     *
     * 验证所有商品一起购买可优惠
     * 配置商品A，B
     * 验证购买订单中，包含A&B+C，可参与满减
     * 满减金额验证，满减订单摊销验证,优惠摊销在A，B，C上
     *
     *
     * 1.创建满减活动，整单摊销
     * 2.查询满减活动与创建满减活动的关键字段一致
     * 3.购买商品，参与满减
     * 4.验证整单摊销
     * 5.关闭订单
     * 6.失效满减活动
     * 7.清理数据
     */
    @Test()
    public void testCreateFullReduceActivityAndAmortizationWithFullOrder() {
        String activityId = "";
        try {

            closeWaitPayOrder(wscKdtId);
            SaveOrderFullReduceActivityRequest activityRequest = JsonCovertUntil.getObjectFromjson(fullOrderFullReduceActivityCreatePath, SaveOrderFullReduceActivityRequest.class);
            String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
            String activityName = "auto-lfy-整单摊销" + dateString;
            activityRequest.getFullReduceActivityDTO().setName(activityName);
            PlainResult<SaveOrderFullReduceActivityResponse> saveOrderFullReduceActivityResult =
                    orderFullReduceActivityRemoteService.saveActivity(activityRequest);

            Assert.assertEquals(saveOrderFullReduceActivityResult.getCode(), 200);
            activityId = saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId();

            //查询满减活动，验证创建的满减活动与查询的满减活动信息
            QueryActivityDetailRequest detailRequest = new QueryActivityDetailRequest();
            detailRequest.setActivityId(activityId);
            PlainResult<OrderFullReduceActivityDetailResponse> queryResult = orderFullReduceActivityRemoteService.queryActivityById(detailRequest);
            Assert.assertEquals(queryResult.getCode(), 200);
            Assert.assertEquals(queryResult.getMessage(), "successful");
            Assert.assertEquals(queryResult.getData().getFullReduceActivityDTO(), saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO());


            //购买商品，确认订单页可参与满减活动
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(fullOrderCreateOrderPath, CreateOrderForm.class);

            createOrderForm.setKdtId(wscKdtId);
            createOrderForm.setUserId(userId);

            createOrderForm.getOrderPromotionList().get(0).setPromotionId(Long.valueOf(activityId));
            createOrderForm.getOrderPromotionList().get(0).setName(activityName);
            //创建订单
            PlainResult<OrderCreateApi> createResult = createOrder(createOrderForm);
            Assert.assertNotNull(createResult, "创建订单为空");
            Assert.assertEquals(createResult.getCode(), 200, createResult.getMessage());
            Assert.assertEquals(createResult.getMessage(), "successful");

            //验证摊销结果
            Long payOrderId = createResult.getData().getPayOrderId();
            List<TdOrderItem> orderItemList =
                    tdOrderItemMapper.selectList(new QueryWrapper<TdOrderItem>().inSql("td_no", "select td_no from td_order where id='" + payOrderId + "'")
                            .orderByAsc("item_orig_price"));
            float sum = 0;
            for (TdOrderItem tdOrderItem : orderItemList) {
                float afterGoodPromotionResult = (tdOrderItem.getSkuPrice() - tdOrderItem.getGoodsPromotionAmt()) * tdOrderItem.getSkuNum();
                sum += afterGoodPromotionResult;
            }
            float AAfterGoodPromotionResult = Math.round((orderItemList.get(0).getSkuPrice() - orderItemList.get(0).getGoodsPromotionAmt()) * orderItemList.get(0).getSkuNum() / sum * 20000 * 1000) / 1000;
            float BAfterGoodPromotionResult = Math.round((orderItemList.get(1).getSkuPrice() - orderItemList.get(1).getGoodsPromotionAmt()) * orderItemList.get(1).getSkuNum() / sum * 20000 * 1000) / 1000;


//        String result = String.format("%0.2f",staffAfterGoodPromotionResult);
            float CAfterGoodPromotionResult = 20000 - AAfterGoodPromotionResult - BAfterGoodPromotionResult;
            Assert.assertEquals(AAfterGoodPromotionResult, (float) orderItemList.get(0).getSharedPromotionAmt(), "error：A商品（原价365）摊销金额错误");
            Assert.assertEquals(BAfterGoodPromotionResult, (float) orderItemList.get(1).getSharedPromotionAmt(), "error：B商品（原价688）摊销金额错误");
            Assert.assertEquals(CAfterGoodPromotionResult, (float) orderItemList.get(2).getSharedPromotionAmt(), "error：C商品（原价6800）摊销金额错误");

            //关闭订单
            closeWaitPayOrder(wscKdtId);
            //失效满减活动
            expireFullReduceActivity(activityId);
        } catch (Exception e) {
        } finally {
            //删除配置的满减活动数据
            deleteActivityConfigData(activityId);
        }

    }

    /**
     * 1.创建满减活动，仅活动商品摊销
     * 2.查询满减活动与创建满减活动的关键字段一致
     * 3.购买商品，参与满减
     * 4.验证仅活动商品摊销
     * 5.关闭订单
     * 6.失效满减活动
     * 7.清理数据
     */
    @Test
    public void testCreateFullReduceActivityAndAmortizationWithOnlyActivityOrder() {
        String activityId = "";
        try {
            closeWaitPayOrder(wscKdtId);
            SaveOrderFullReduceActivityRequest activityRequest = JsonCovertUntil.getObjectFromjson(onlyActivityOrderFullReduceActivityCreatePath, SaveOrderFullReduceActivityRequest.class);
            String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
            String activityName = "auto-lfy-仅活动商品摊销" + dateString;
            activityRequest.getFullReduceActivityDTO().setName(activityName);
            PlainResult<SaveOrderFullReduceActivityResponse> saveOrderFullReduceActivityResult =
                    orderFullReduceActivityRemoteService.saveActivity(activityRequest);

            Assert.assertEquals(saveOrderFullReduceActivityResult.getCode(), 200);
            activityId = saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId();

            //查询满减活动，验证创建的满减活动与查询的满减活动信息
            QueryActivityDetailRequest detailRequest = new QueryActivityDetailRequest();
            detailRequest.setActivityId(activityId);
            PlainResult<OrderFullReduceActivityDetailResponse> queryResult = orderFullReduceActivityRemoteService.queryActivityById(detailRequest);
            Assert.assertEquals(queryResult.getCode(), 200);
            Assert.assertEquals(queryResult.getMessage(), "successful");
            Assert.assertEquals(queryResult.getData().getFullReduceActivityDTO(), saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO());


            //购买商品，确认订单页可参与满减活动
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(onlyActivityOrderCreateOrderPath, CreateOrderForm.class);

            createOrderForm.setKdtId(wscKdtId);
            createOrderForm.setUserId(userId);
            createOrderForm.setOrderMarketingCalType("BEST_CALC");

            createOrderForm.getOrderPromotionList().get(0).setPromotionId(Long.valueOf(activityId));
            createOrderForm.getOrderPromotionList().get(0).setName(activityName);
            //创建订单
            PlainResult<String> createResult = createOrderNormal(createOrderForm);
            Assert.assertNotNull(createResult, "创建订单为空");

            Assert.assertEquals(createResult.getCode(), 200, createResult.getMessage());
            Assert.assertEquals(createResult.getMessage(), "successful");

            //验证摊销结果
            Long payOrderId = Long.valueOf(createResult.getData());
            List<TdOrderItem> orderItemList =
                    tdOrderItemMapper.selectList(new QueryWrapper<TdOrderItem>().inSql("td_no", "select td_no from td_order where id='" + payOrderId + "'")
                            .orderByAsc("item_orig_price"));

            float staffAfterGoodPromotionResult = Math.round((orderItemList.get(0).getSkuPrice() - orderItemList.get(0).getGoodsPromotionAmt()) * orderItemList.get(0).getSkuNum());
            //微商城不满足摊销条件，故不摊销
            float wscAfterGoodPromotionResult = 0;
            Assert.assertEquals(staffAfterGoodPromotionResult, (float) orderItemList.get(0).getSharedPromotionAmt(), "error：员工摊销金额错误");
            Assert.assertEquals(wscAfterGoodPromotionResult, (float) orderItemList.get(1).getSharedPromotionAmt(), "error：微商城摊销金额错误");
            //失效满减活动
            expireFullReduceActivity(activityId);

            //关闭订单
            closeWaitPayOrder(wscKdtId);

        } catch (Exception e) {
        } finally {
            //删除配置的满减活动数据
            deleteActivityConfigData(activityId);
        }

    }

    /**
     * 1.设置活动参与次数为1次
     * 2.购买商品，确认订单页可参与满减活动
     * 3.创建订单
     * 4.验证只可参与1次
     */
    @Test
    public void testCreateFullReduceActivityAndJoinWithOnce() {
        String activityId = "";
        try {
            closeWaitPayOrder(wscKdtId);
            SaveOrderFullReduceActivityRequest activityRequest = JsonCovertUntil.getObjectFromjson(onlyActivityOrderFullReduceActivityCreatePath, SaveOrderFullReduceActivityRequest.class);
            String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
            String activityName = "auto-lfy-仅参与一次" + dateString;
            activityRequest.getFullReduceActivityDTO().setName(activityName);
            //设置活动参与次数为1次
            activityRequest.getFullReduceActivityDTO().setLimitType("JOIN_COUNT");
            PlainResult<SaveOrderFullReduceActivityResponse> saveOrderFullReduceActivityResult =
                    orderFullReduceActivityRemoteService.saveActivity(activityRequest);

            Assert.assertEquals(saveOrderFullReduceActivityResult.getCode(), 200, saveOrderFullReduceActivityResult.getMessage());
            activityId = saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId();

            //购买商品，确认订单页可参与满减活动
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(onlyActivityOrderCreateOrderPath, CreateOrderForm.class);

            createOrderForm.setKdtId(wscKdtId);
            createOrderForm.setUserId(userId);

            createOrderForm.getOrderPromotionList().get(0).setPromotionId(Long.valueOf(activityId));
            createOrderForm.getOrderPromotionList().get(0).setName(activityName);
            //创建订单
            PlainResult<OrderCreateApi> createResult = createOrder(createOrderForm);
            Assert.assertNotNull(createResult, "创建订单为空");
            Assert.assertEquals(createResult.getCode(), 200, createResult.getMessage());
            Assert.assertEquals(createResult.getMessage(), "successful");

            MkActivity mkActivity = activityMapper.selectOne(new QueryWrapper<MkActivity>().eq("id", activityId));
            Assert.assertEquals(mkActivity.getLimitJoinCount(), Integer.valueOf(1));

            //失效满减活动
            expireFullReduceActivity(activityId);
        } catch (Exception e) {
        } finally {
            //删除配置的满减活动数据
            deleteActivityConfigData(activityId);
        }

    }


    @BeforeClass
    public void beforeClass() {
        deleteTestDataYcmByKdtId(wscKdtId);
    }


    @Test(enabled = false)
    public void operateCancelActivityIn16252() {
        MkActivity mkActivity = new MkActivity();
        mkActivity.setState("CANCELED");
        activityMapper.update(mkActivity, new UpdateWrapper<MkActivity>()
                .inSql("id", "select distinct activity_id from mk_activity_rule where `conditions` like '%V2%'")
                .eq("state", "AUDITED_PASS"));
    }

    @Test(enabled = false)
    public void operateAuditedPassActivityIn16252() {
        MkActivity mkActivity = new MkActivity();
        mkActivity.setState("AUDITED_PASS");
        activityMapper.update(mkActivity, new UpdateWrapper<MkActivity>()
                .eq("id", "1901"));
    }

    @Test(enabled = false)
    public void test() {
        float staffAfterGoodPromotionResult = Math.round(182500d / 862500f * 20000 * 1000000) / 1000000;
        String result = String.format("%.2f", staffAfterGoodPromotionResult);
    }

}
