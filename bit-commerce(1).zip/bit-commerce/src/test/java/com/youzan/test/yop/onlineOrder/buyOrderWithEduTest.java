package com.youzan.test.yop.onlineOrder;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.test.yop.YopBaseTest;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.status.OpenAppOrderStatusApi;
import com.youzan.yop.api.enums.AppStatusState;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.yzcoin.api.AccountService;
import com.youzan.yop.yzcoin.api.dto.AccountBalanceInfoDTO;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * created by leifeiyun on 2020/1/7
 **/
public class buyOrderWithEduTest extends YopBaseTest {
    @Dubbo
    AccountService accountService;

    @Test(enabled = false)
    public void testPayOrderForEdu() {
        /**
         * 看下是否有待支付订单，有的话就关掉
         */
        closeWaitPayOrder(eduKdtId);
        PlainResult<PreparePayApi> preparePayResult = new PlainResult<>();
        PlainResult<Long> createOrderResult = new PlainResult<>();
        try {
            /**
             * 订购之前，查询有赞币余额
             */
            PlainResult<AccountBalanceInfoDTO> plainResult = accountService.getBalanceByKdtId(eduKdtId);
            Long yzcoinAccoutBeforePay = plainResult.getData().getBalance();
            //case1.测试支付订单
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            //有赞教育基础版一年期
            orderItemForms.add(ConstructionParam.getOrderItemForm(ItemInfo.EDU_BASE.getItemId(), ItemInfo.EDU_BASE.getQuantity()));
            //微商城扩展包一年
            orderItemForms.add(ConstructionParam.getOrderItemForm(ItemInfo.WSC_EXTEND_PACKAGE.getItemId(), ItemInfo.WSC_EXTEND_PACKAGE.getQuantity()));
            //优惠套餐12个月
            orderItemForms.add(ConstructionParam.getOrderItemForm(ItemInfo.DISCOUNT_PACKAGE.getItemId(), ItemInfo.DISCOUNT_PACKAGE.getQuantity()));
            //好友瓜分券12个月
            orderItemForms.add(ConstructionParam.getOrderItemForm(ItemInfo.FRIEND_PATITION_TICKET.getItemId(), ItemInfo.FRIEND_PATITION_TICKET.getQuantity()));
            //打包创建有赞教育系列商品
            createOrderResult = orderRemoteService.createOrder(ConstructionParam.getCreateOrderWithParam(eduKdtId, eduKdtName, orderItemForms, 0L));

            if (createOrderResult.getCode() != 200) {
                return;
            }

            //使用账户余额支付，验证预支付结果
            preparePayResult = preparePay(createOrderResult.getData(), (byte) 0);
            checkPreparePayResult(preparePayResult, true, (byte) 0);

            cashierPay(preparePayResult, account, eduKdtId);

            Thread.sleep(800);
            //查询店铺服务期
            PlainResult<PageApi<OpenAppOrderStatusApi>> orderStateResult = appStatusRemoteService.listOrderStateByStateAndPage(ConstructionParam.getSearchParam(eduKdtId, AppStatusState.EFFECT));
            Assert.assertNotNull(orderStateResult.getData().getContent());
            for (int i = 0; i < orderStateResult.getData().getContent().size(); i++) {
                Assert.assertTrue(orderStateResult.getData().getContent().get(i).getState() == AppStatusState.EFFECT);
            }
            Assert.assertEquals(orderStateResult.getCode(), 200);
            Assert.assertEquals(orderStateResult.getMessage(), "successful");

            //验证订单详情
            getOrderDetailInfo(eduKdtId, createOrderResult.getData(), 3);

            //检验应用状态
            checkAppStatus(eduKdtId, AppStatusState.EFFECT, Calendar.YEAR, 1);

            //case2:测试重复支付订单，只要重新调用支付接口，订单为上次创建成功的订单号
            preparePayResult = preparePay(createOrderResult.getData(), (byte) 0);
            Assert.assertEquals(preparePayResult.getCode(), 130716);
            Assert.assertEquals(preparePayResult.getMessage(), "支付失败 订单状态错误");

        } catch (Exception e) {
            logger.info("测试支付订单接口testPayOrder异常---->:" + e.getMessage());
        } finally {
            //订购单退款
            if (createOrderResult.getData() != null && createOrderResult.getCode() == 200) {
                refundOrder(String.valueOf(createOrderResult.getData()), new Date(), 100L, 100L, "BY_MANUAL");
            }
//            deleteOrderInfo(eduKdtId);
        }
    }
}
