package com.youzan.test.task.clearAccountPool;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.commerce.test.entity.dataobject.enable.EnableAccountPoolEntity;
import com.youzan.commerce.test.mapper.enable.EnableAccountPoolMapper;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import java.util.List;

/**
 * @author wuwu
 * @date 2021/4/14 10:20 AM
 */
public class TimingClearDataForAccountPool extends YunBaseTest {
    @Autowired(required = false)
    public EnableAccountPoolMapper enableAccountPoolMapper;
    int isApplied = 1;
    int isNew = 0;

    @Test
    public void clearDataForKdt() {
        List<String> failedClearKdtIds = Lists.newArrayList();


        //确保每次能清出300个店铺
        for (int i = 0; i<300; i++) {
            List<EnableAccountPoolEntity> enableAccountPools = getEnableAccountPools();

            if (enableAccountPools.size() > 0) {

                //开始清理数据
                for (EnableAccountPoolEntity enableAccountPool : enableAccountPools) {
                    try {
                        logger.info("开始店铺 {} 清理数据", enableAccountPool.getKdtId());
                        godBlessU(Long.valueOf(enableAccountPool.getKdtId()));
                        EnableAccountPoolEntity enableAccountPoolEntity = new EnableAccountPoolEntity();
                        logger.info("店铺 {} 清理完成，开始清商品缓存", enableAccountPool.getKdtId());
                        clearCache(enableAccountPool.getKdtId());
                        enableAccountPoolEntity.setIsApplied(0);
                        enableAccountPoolEntity.setIsNew(1);
                        enableAccountPoolMapper.update(enableAccountPoolEntity, new UpdateWrapper<EnableAccountPoolEntity>()
                                .eq("id", enableAccountPool.getId()));
                    } catch (Exception e) {
                        failedClearKdtIds.add(enableAccountPool.getKdtId());
                        logger.info("店铺 {} 清理数据异常: {}", enableAccountPool.getKdtId(), e.getMessage());
                    }
                }
            }else {
                break;
            }
        }
    }

    public List<EnableAccountPoolEntity> getEnableAccountPools() {
        List<EnableAccountPoolEntity> enableAccountPools = enableAccountPoolMapper.selectList(
                new QueryWrapper<EnableAccountPoolEntity>()
                        .lambda()
                        .eq(EnableAccountPoolEntity::getIsApplied, isApplied)
                        .eq(EnableAccountPoolEntity::getIsNew, isNew)
                        .orderByDesc(EnableAccountPoolEntity::getCreatedAt).last("limit 50"));

        return enableAccountPools;
    }

}
