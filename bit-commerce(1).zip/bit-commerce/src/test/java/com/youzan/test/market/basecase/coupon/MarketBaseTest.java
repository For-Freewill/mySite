package com.youzan.test.market.basecase.coupon;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.common.collect.Lists;
import com.youzan.api.common.response.PlainResult;
import com.youzan.bitcomparecommon.aop.CompareConfig;
import com.youzan.bitcomparecommon.aop.CompareUtil;
import com.youzan.commerce.test.StartTest;
import com.youzan.commerce.test.compare.config.DBCompareConfig;
import com.youzan.commerce.test.entity.dataobject.market.coupon.*;
import com.youzan.commerce.test.entity.enums.market.coupon.CouponStateEnum;
import com.youzan.commerce.test.mapper.market.coupon.*;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.api.CouponAssetRemoteService;
import com.youzan.ycm.market.api.CouponRemoteService;
import com.youzan.ycm.market.api.CouponSendRemoteService;
import com.youzan.ycm.market.dto.coupon.AllCouponDTO;
import com.youzan.ycm.market.dto.coupon.CouponAdmittanceExtDTO;
import com.youzan.ycm.market.dto.couponsend.CouponSendRuleDTO;
import com.youzan.ycm.market.request.coupon.QueryCouponRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.request.coupon.UpdateCouponStateRequest;
import com.youzan.ycm.market.request.couponasset.QueryCouponAssetRequest;
import com.youzan.ycm.market.request.couponsend.QueryCouponSendRuleRequest;
import com.youzan.ycm.market.request.couponsend.SaveSendCouponRequest;
import com.youzan.ycm.market.request.couponsend.SendCouponAssetRequest;
import com.youzan.ycm.market.response.coupon.SaveCouponResponse;
import com.youzan.ycm.market.response.coupon.UpdateCouponStateResponse;
import com.youzan.ycm.market.response.couponsend.QueryCouponSendRuleResponse;
import com.youzan.ycm.market.response.couponsend.SaveCouponSendRecordResponse;
import com.youzan.ycm.market.response.couponsend.SendCouponResponse;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.awaitility.Awaitility.with;


/**
 * @author qibu
 * @create 2020/9/1 8:57 PM
 */
public class MarketBaseTest extends StartTest {
    private static final Logger logger = LoggerFactory.getLogger(MarketBaseTest.class);
    @Dubbo
    private CouponRemoteService couponRemoteService;

    @Dubbo
    private CouponSendRemoteService couponSendRemoteService;

    @Dubbo
    private CouponAssetRemoteService couponAssetRemoteService;

    @Autowired(required = false)
    private CouponRuleMapper couponRuleMapper;

    @Autowired(required = false)
    private CouponMapper couponMapper;

    @Autowired(required = false)
    private CouponSendRecordMapper couponSendRecordMapper;

    @Autowired(required = false)
    private CouponAssetMapper couponAssetMapper;

    @Autowired(required = false)
    private CouponSnapshotMapper couponSnapshotMapper;

    @JSONData("/data/market/coupon/saveCouponRequest.json")
    private SaveCouponRequest saveCouponRequest;

    @JSONData("/data/market/coupon/coupon.json")
    private MkCoupon mkCouponBase;

    @JSONData("/data/market/coupon/couponRule.json")
    private MkCouponRule mkCouponRuleBase;

    @JSONData("/data/market/coupon/couponSnapshot.json")
    private MkCouponSnapshot mkCouponSnapshotBase;

    @JSONData("/data/market/coupon/saveCouponSendRecord.json")
    private SaveSendCouponRequest saveSendCouponRequest;

    private String couponNamePrefix = "七步测试";
    private String kdtId = "55434550";//七步的测试店铺wsc-ycm,老店铺

    @BeforeMethod
    public void beforeMethod() {
        //清理券数据
        deleteCouponByCouponNamePrefix(couponNamePrefix);
    }


    /**
     * 创建优惠券权益：用户标签
     */
    @Test
    public void couponuserTagTest() {
        //准备打折券权益数据
        String couponName = couponNamePrefix + new Random().nextInt(10000);
        SaveCouponRequest saveCouponRequest = SerializationUtils.clone(this.saveCouponRequest);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        CouponAdmittanceExtDTO couponAdmittanceExtDTO = allCouponDTO.getCouponAdmittanceExtDTO();
        //新签跟续签是针对产品线的

        couponAdmittanceExtDTO.setBuyerTags(Lists.newArrayList("REORDER"));//FIRST：新签，RENEW：续签
        couponAdmittanceExtDTO.setProductChannels(Lists.newArrayList("WSC"));
        allCouponDTO.setName(couponName);
        //创建打折券权益
        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result));
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        String couponId = result.getData().getAllCouponDTO().getCouponId();
        allCouponDTO.setCouponId(couponId);
        //上架打折券权益，验证上架成功
        UpdateCouponStateRequest updateCouponStateRequest = new UpdateCouponStateRequest();
        updateCouponStateRequest.setCouponState(CouponStateEnum.ONLINE.getAlias());
        updateCouponStateRequest.setCouponId(couponId);
        PlainResult<UpdateCouponStateResponse> updateCouponStateResult = couponRemoteService.updateCouponState(updateCouponStateRequest);
        Assert.assertTrue(updateCouponStateResult.isSuccess(), "上架权益券失败！");
        Assert.assertEquals(updateCouponStateResult.getData().getCouponState(), CouponStateEnum.ONLINE.getAlias(), "上架权益券失败！");

        //创建优惠券发券单,自动领取
        CouponSendRuleDTO couponSendRuleDTO = saveSendCouponRequest.getCouponSendRuleDTO();
        couponSendRuleDTO.setCouponId(couponId);
        couponSendRuleDTO.setCouponName(couponName);
        couponSendRuleDTO.setCouponReceiveType("AUTO_RECEIVE");
        couponSendRuleDTO.setKdtIdList(Lists.newArrayList(kdtId));
        PlainResult<SaveCouponSendRecordResponse> saveSendCouponResult = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);
        Assert.assertTrue(saveSendCouponResult.isSuccess(), "创建优惠券发券单失败！");

        //发放优惠券
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        String couponSendRecordId = saveSendCouponResult.getData().getCouponSendRuleDTO().getCouponSendRecordId();
        sendCouponAssetRequest.setCouponSendRecordId(couponSendRecordId);
        sendCouponAssetRequest.setSendOperator(couponNamePrefix);
        PlainResult<SendCouponResponse> sendCouponResult = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);
        Assert.assertTrue(sendCouponResult.isSuccess(), "发放优惠券失败！");
        //通过kdtId查看券发放成功，且自动领取成功
        QueryCouponAssetRequest queryCouponAssetRequest = new QueryCouponAssetRequest();
        queryCouponAssetRequest.setKdtId(kdtId);

        with().pollInterval(100, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> couponAssetRemoteService.queryCouponAssetListByKdtId(queryCouponAssetRequest).getData().getItems()
                        .stream().filter(e -> e.getCouponId().equals(couponId)).collect(Collectors.toList()).size() == 1);

        //使用优惠券

    }

    /**
     * 测试场景：创建权益，上架权益，发放优惠券，优惠券发放成功
     * 1. 创建打折券权益
     * 2. 验证权益状态为:待上架
     * 3. 上架权益
     * 4. 给指定商家创建优惠券发券单,自动领取
     * 5. biz后台查看发券成功
     * 6. 通过kdtId查看券发放成功，且自动领取成功
     */
    @Test
    public void createCouponTest() {
        //准备打折券权益数据
        String couponName = couponNamePrefix + new Random().nextInt(10000);
        SaveCouponRequest saveCouponRequest = SerializationUtils.clone(this.saveCouponRequest);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);

        //创建打折券权益
        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = result.getData().getAllCouponDTO().getCouponId();
        allCouponDTO.setCouponId(couponId);
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result));

        //验证打折券权益创建结果
        CompareConfig compareConfig = new CompareConfig();
        compareConfig.getIgnoredPaths().add("/allCouponDTO/orderReduceCouponDTO/goodsConditions");
        CompareUtil.projectRequestCompare(saveCouponRequest, result.getData(), compareConfig);

        //验证已经创建的打折券权益状态为：待上架
        QueryCouponRequest queryCouponRequest = new QueryCouponRequest();
        queryCouponRequest.setCouponId(couponId);
        PlainResult<AllCouponDTO> allCouponDTOResult = couponRemoteService.queryCouponById(queryCouponRequest);
        Assert.assertTrue(allCouponDTOResult.isSuccess(), "查询权益券失败！");
        Assert.assertEquals(allCouponDTOResult.getData().getCouponState(), CouponStateEnum.WAIT_EFFECT.getAlias());

        //上架打折券权益，验证上架成功
        UpdateCouponStateRequest updateCouponStateRequest = new UpdateCouponStateRequest();
        updateCouponStateRequest.setCouponState(CouponStateEnum.ONLINE.getAlias());
        updateCouponStateRequest.setCouponId(couponId);
        PlainResult<UpdateCouponStateResponse> updateCouponStateResult = couponRemoteService.updateCouponState(updateCouponStateRequest);
        Assert.assertTrue(updateCouponStateResult.isSuccess(), "上架权益券失败！");
        Assert.assertEquals(updateCouponStateResult.getData().getCouponState(), CouponStateEnum.ONLINE.getAlias(), "上架权益券失败！");

        //下架券权益，验证下架成功
        updateCouponStateRequest.setCouponState(CouponStateEnum.OFFLINE.getAlias());
        PlainResult<UpdateCouponStateResponse> updateCouponStateResult2 = couponRemoteService.updateCouponState(updateCouponStateRequest);
        Assert.assertTrue(updateCouponStateResult2.isSuccess(), "上架权益券失败！");
        Assert.assertEquals(updateCouponStateResult2.getData().getCouponState(), CouponStateEnum.OFFLINE.getAlias(), "下架权益券失败！");

        //上架打折券权益，验证上架成功
        updateCouponStateRequest.setCouponState(CouponStateEnum.ONLINE.getAlias());
        PlainResult<UpdateCouponStateResponse> updateCouponStateResult3 = couponRemoteService.updateCouponState(updateCouponStateRequest);
        Assert.assertTrue(updateCouponStateResult.isSuccess(), "上架权益券失败！");
        Assert.assertEquals(updateCouponStateResult3.getData().getCouponState(), CouponStateEnum.ONLINE.getAlias(), "上架权益券失败！");
        //创建优惠券发券单,自动领取
        CouponSendRuleDTO couponSendRuleDTO = saveSendCouponRequest.getCouponSendRuleDTO();
        couponSendRuleDTO.setCouponId(couponId);
        couponSendRuleDTO.setCouponName(couponName);
        couponSendRuleDTO.setCouponReceiveType("AUTO_RECEIVE");
        couponSendRuleDTO.setKdtIdList(Lists.newArrayList(kdtId));
        PlainResult<SaveCouponSendRecordResponse> saveSendCouponResult = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);
        Assert.assertTrue(saveSendCouponResult.isSuccess(), "创建优惠券发券单失败！");

        //发放优惠券
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        String couponSendRecordId = saveSendCouponResult.getData().getCouponSendRuleDTO().getCouponSendRecordId();
        sendCouponAssetRequest.setCouponSendRecordId(couponSendRecordId);
        sendCouponAssetRequest.setSendOperator(couponNamePrefix);
        PlainResult<SendCouponResponse> sendCouponResult = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);
        Assert.assertTrue(sendCouponResult.isSuccess(), "发放优惠券失败！");

        //biz后台查看发券成功
        QueryCouponSendRuleRequest queryCouponSendRuleRequest = new QueryCouponSendRuleRequest();
        queryCouponSendRuleRequest.setCouponSendRecordId(couponSendRecordId);
        PlainResult<QueryCouponSendRuleResponse> queryCouponSendRuleByIdResult = couponSendRemoteService.queryCouponSendRuleById(queryCouponSendRuleRequest);
        Assert.assertTrue(queryCouponSendRuleByIdResult.isSuccess(), "发放优惠券失败！");
        couponSendRuleDTO.setCouponSendRecordId(couponSendRecordId);
        CompareConfig couponSendRuleCompareConfig = new CompareConfig();
        couponSendRuleCompareConfig.getIgnoredPaths().add("/totalSendCount");
        couponSendRuleCompareConfig.getIgnoredPaths().add("/deadlineTime");
        couponSendRuleCompareConfig.getIgnoredPaths().add("/sendEndTime");
        couponSendRuleCompareConfig.getIgnoredPaths().add("/manualReceiveDays");
        CompareUtil.projectRequestCompare(couponSendRuleDTO, queryCouponSendRuleByIdResult.getData().getCouponSendRuleDTO(), couponSendRuleCompareConfig);

        //通过kdtId查看券发放成功，且自动领取成功
        QueryCouponAssetRequest queryCouponAssetRequest = new QueryCouponAssetRequest();
        queryCouponAssetRequest.setKdtId(kdtId);

        with().pollInterval(100, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> couponAssetRemoteService.queryCouponAssetListByKdtId(queryCouponAssetRequest).getData().getItems()
                        .stream().filter(e -> e.getCouponId().equals(couponId)).collect(Collectors.toList()).size() == 1);

    }

    /**
     * saveCoupon接口测试
     */
    @Test
    public void saveCouponTest() {
        //构造新券数据
        String couponName = couponNamePrefix + new Random().nextInt(10000);
        SaveCouponRequest saveCouponRequest = SerializationUtils.clone(this.saveCouponRequest);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);
        //生成券
        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        allCouponDTO.setCouponId(result.getData().getAllCouponDTO().getCouponId());
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        logger.info(JSONObject.toJSONString(result));
        CompareConfig compareConfig = new CompareConfig();
        compareConfig.getIgnoredPaths().add("/allCouponDTO/orderReduceCouponDTO/goodsConditions");
        CompareUtil.projectRequestCompare(saveCouponRequest, result.getData(), compareConfig);
        //验证coupon表
        Long couponId = Long.valueOf(result.getData().getAllCouponDTO().getCouponId());
        MkCoupon coupon = couponMapper.selectById(couponId);
        logger.info("coupon表：{}" + JSONObject.toJSONString(coupon));
        mkCouponBase.setName(couponName);
        CompareConfig dbCompareConfig = new DBCompareConfig();
        CompareUtil.projectRequestCompare(coupon, mkCouponBase, dbCompareConfig);
        //验证couponRule表
        MkCouponRule couponRule = couponRuleMapper.selectOne(new QueryWrapper<MkCouponRule>().lambda()
                .eq(MkCouponRule::getCouponId, couponId));
        logger.info("couponRule表：{}" + JSONObject.toJSONString(couponRule));
        mkCouponRuleBase.setCouponId(couponId);
        CompareUtil.projectRequestCompare(couponRule, mkCouponRuleBase, dbCompareConfig);
        //验证couponSnapshot表
        MkCouponSnapshot couponSnapshot = couponSnapshotMapper.selectOne(new QueryWrapper<MkCouponSnapshot>().lambda()
                .eq(MkCouponSnapshot::getCouponId, couponId));
        logger.info("couponSnapshot表：{}" + JSONObject.toJSONString(couponSnapshot));
        mkCouponSnapshotBase.setName(couponName);
        mkCouponSnapshotBase.setCouponId(couponId);
        CompareUtil.projectRequestCompare(couponSnapshot, mkCouponSnapshotBase, dbCompareConfig);
        logger.info("couponSnapshot表：{}" + JSONObject.toJSONString(couponSnapshot));
    }

    /**
     * 通过优惠券前缀批量删除优惠券
     *
     * @param couponNamePrefixPrefix
     */
    public void deleteCouponByCouponNamePrefix(String couponNamePrefixPrefix) {
        if (StringUtils.isEmpty(couponNamePrefixPrefix)) {
            return;
        }
        List<Long> couponIdList = couponMapper.selectList(new QueryWrapper<MkCoupon>().lambda()
                .likeRight(MkCoupon::getName, couponNamePrefixPrefix)).stream().map(MkCoupon::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(couponIdList)) {
            couponMapper.deleteBatchIds(couponIdList);
            couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().lambda().in(MkCouponRule::getCouponId, couponIdList));
            couponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshot>().lambda().in(MkCouponSnapshot::getCouponId, couponIdList));
            couponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecord>().lambda().in(MkCouponSendRecord::getCouponId, couponIdList));
            couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().lambda().in(MkCouponAsset::getCouponId, couponIdList));
        }
    }
}
