package com.youzan.test.concurrent;

import com.youzan.commerce.test.StartTest;
import com.youzan.commerce.test.utils.CompareSCUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;

/**
 * @author leifeiyun
 * @date 2021/1/7
 **/
public class ConcurrentBaseTest extends StartTest {
    final static public Logger logger = LoggerFactory.getLogger(StartTest.class);
    @BeforeMethod
    public void beforeMethod(){
        CompareSCUtil.resetSC();
        logger.info("beforeMethod测试sc：" + CompareSCUtil.getSC());
    }

}
