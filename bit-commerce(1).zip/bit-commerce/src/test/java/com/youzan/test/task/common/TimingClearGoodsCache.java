package com.youzan.test.task.common;


import com.alibaba.fastjson.JSON;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.GoodsToolsRemoteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import java.util.List;

@Slf4j
public class TimingClearGoodsCache extends BaseTest {
    @JSONData("/dataResource/clearData/timingClearSpuId.json")
    private List<Integer> SpudIds;

    @Dubbo
    private GoodsToolsRemoteService goodsToolsRemoteService;

    @Test
    public void clearDataForKdt() {
        //批量清理商品SPU ID的缓存
        for (Integer spuId : SpudIds) {
            try {
                goodsToolsRemoteService.flushGoodsAllCatch(spuId);
                log.info("清理商品缓存成功="+spuId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
