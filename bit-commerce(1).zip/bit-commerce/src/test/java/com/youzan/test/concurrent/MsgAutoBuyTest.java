package com.youzan.test.concurrent;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.platform.push.api.pushMsg.PushMsgService;
import com.youzan.platform.push.api.stock.MsgSmsStockService;
import com.youzan.platform.push.api.stock.dto.StockDecResultDTO;
import com.youzan.platform.push.api.stock.dto.StockDecreaseDTO;
import com.youzan.platform.push.api.stock.dto.StockInfoDTO;
import com.youzan.platform.push.api.stock.dto.StockQueryDTO;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.StockRemoteService;
import com.youzan.yop.api.form.order.AutoBuyMsgOrderForm;
import com.youzan.yop.api.response.AutoBuyMsgResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * @author leifeiyun
 * @date 2021/2/23
 **/
public class MsgAutoBuyTest extends ConcurrentBaseTest {
    @Dubbo
    PushMsgService pushMsgService;
    @Dubbo
    MsgSmsStockService msgSmsStockService;
    @Dubbo
    StockRemoteService stockRemoteService;
    @Autowired(required = false)
    TdOrderMapper tdOrderMapper;

    /**
     * 验证短信扣减，并发的场景
     * 每次扣减都触发自动充值的门槛（模拟每次扣减时都小于配置的条数）
     * 预期结果，在5s内，即便触发扣减条件，也只充值一次
     * 预期结果，在10s内，能充值2次
     *
     *
     * 结果数据：
     *
     * 充值时间                       充值条数
     * 2021-02-23 11:18:45          1000条 × 1
     * 2021-02-23 11:18:51          1000条 × 1
     */
    @Test(enabled = false,threadPoolSize=1, invocationCount=10)
    public void testDecreaseStockPushMsg() {
        List<Long> kdtIds = Arrays.asList(58720364L);
        for (Long kdtId : kdtIds) {
            StockDecreaseDTO stockDecreaseDTO = new StockDecreaseDTO();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            StockQueryDTO stockQueryDTO = new StockQueryDTO();
            stockQueryDTO.setKdtId(kdtId);
            PlainResult<StockInfoDTO> result = msgSmsStockService.getStock(stockQueryDTO);
            if(result.getData().getTotalStock()>50){
                stockDecreaseDTO.setStock(result.getData().getValidStock());
                stockDecreaseDTO.setSerialNo(generate23Sequence());
                stockDecreaseDTO.setDecReason("lfy_test");
                stockDecreaseDTO.setKdtId(kdtId);
                PlainResult<StockDecResultDTO> decreaseResult = msgSmsStockService.decrease(stockDecreaseDTO);
            }
        }
    }

    @Test(threadPoolSize=2, invocationCount=10,enabled = false)
    public void testAutoRechargeMsg(){
        Long kdtId = 58720364L;
        AutoBuyMsgOrderForm autoBuyMsgOrderForm = new AutoBuyMsgOrderForm();
        autoBuyMsgOrderForm.setAppId(BaseTest.ItemInfo.SMS_1000.getAppId());
        autoBuyMsgOrderForm.setItemId(BaseTest.ItemInfo.SMS_1000.getItemId());
        autoBuyMsgOrderForm.setApplyKdtId(kdtId);
        autoBuyMsgOrderForm.setFromApp("msg-push");
        PlainResult<AutoBuyMsgResponse> result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        logger.info(""+result.getData());
       /* TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>()
                .eq("buyer_id",kdtId)
                .eq("order_way","AUTO")
                .orderByDesc("created_at")
                .last(" limit 1"));
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getMessage(),"successful");
        Assert.assertEquals(tdOrder.getId(),result.getData().getOrderId(),"短信自动订购tdOrderId与实际不符合");
*/
        //充值后记得退款
//        refundBykdtIdAndAppId();
    }


    public String generate23Sequence() {
        //16位
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYYMMddHHmmssSSS");
        String randomString = simpleDateFormat.format(new Date()) + (int) Math.random() * 100;
        logger.info("生成随机E单：" + "EAUTO" + randomString);
        return "EAUTO" + randomString;
    }

}
