package com.youzan.test.task.common;

import com.youzan.test.basecase.DeductBaseTest;
import org.testng.annotations.Test;

/**
 * @author wuwu
 * @date 2020/12/28 5:03 PM
 */
public class ClearCouponByCouponId extends DeductBaseTest {
    @Test(enabled = false)
    public void clearCouponData() {
        deleteCouponData(3810L);
    }

}
