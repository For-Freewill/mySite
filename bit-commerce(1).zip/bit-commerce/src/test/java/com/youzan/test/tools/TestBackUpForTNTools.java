package com.youzan.test.tools;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jayway.jsonpath.JsonPath;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.utils.CompareSCUtil;
import com.youzan.pay.core.utils.HttpUtils;
import com.youzan.ycm.market.api.redeemcode.RedeemCodeManagerService;
import com.youzan.ycm.market.request.redeemcode.GetRedeemCodeDataRequest;
import com.youzan.ycm.market.response.redeemcode.GetRedeemCodeDataResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;

import java.net.URLEncoder;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author tianning
 * @date 2020/11/05 3:59 下午
 */
@Slf4j
public class TestBackUpForTNTools {
    private double minFailedRate = 0.1;//单个case的失败次数➗执行总次数
    private int minFailedExeCount = 1;//单个case的失败次数➗执行总次数
    private String faildCase="";

    /**
     * 统计指定jenkins job的失败case
     */
    @Test
    public void testGetFailedCases(){
        List<String> ycmJobList = Arrays.asList("bit-commerce-baseCase");
        Long begintimeOfWeek = getBeginDayOfWeek();

        System.out.println("商业化case统计数据：======================================");
        getFailedCases(ycmJobList,"7606",begintimeOfWeek);//商业化
    }

    /**
     *
     * @param jobNameList jenkins的 jobNameList
     * @param projectId gitlab的projectId
     */
    public void getFailedCases(List<String> jobNameList,String projectId,Long minTime){
        HashMap<String, Integer> allCaseResultMap = Maps.newHashMap();
        HashMap<String, Integer> failCaseResultMap = Maps.newHashMap();
        JSONArray buildsArrayAll = new JSONArray();
        //获取jobNameList里面的所有build
        for(String jobName :jobNameList){
            String jobUrl = "http://shangyehua-jenkins.cd-qa.qima-inc.com/job/"+jobName+"/api/json?pretty=true";
            String jobResult = HttpUtils.get(jobUrl);
            //获取所有执行结果，进行遍历
            JSONArray buildsArray =JSONObject.parseObject(jobResult).getJSONArray("builds");
            buildsArray.stream().forEach(e-> buildsArrayAll.add(e));
        }
        //分析单个build 的结果
        for(Object build:buildsArrayAll) {
            JSONObject buildJSONObject = JSONObject.parseObject(build.toString());
            String testResultUrl = buildJSONObject.getString("url");
            try {
                String jobResultStr = HttpUtils.get(testResultUrl + "/api/json");
                JSONObject jobResultJSONObject = JSONObject.parseObject(jobResultStr);
                //不分析执行时间不在范围内的build
                if(jobResultJSONObject.getLongValue("timestamp")<minTime){
                    continue;
                }
                //不分析获取不到执行结果的build
                String bulidResult = HttpUtils.get(testResultUrl + "testReport/api/json");
                if(StringUtils.isEmpty(bulidResult)){
                    continue;
                }
                //捞取执行build的所有case的结果
                JSONArray testJobResultArray = JSON.parseArray(JSON.toJSONString(JsonPath.read
                        (bulidResult, "$.suites[0].cases")));
                ArrayList<String> failedCaseList = Lists.newArrayList();
                ArrayList<String> allCaseList = Lists.newArrayList();
                //统计case
                for (Object testJobResult : testJobResultArray) {
                    JSONObject casesJSONObject = JSONObject.parseObject(testJobResult.toString());
                    String status = casesJSONObject.getString("status");
                    String methodsStr = casesJSONObject.getString("className") + "."
                            + casesJSONObject.getString("name");
                    //统计所有的case用来计算成功率
                    if(!allCaseList.contains(methodsStr)){//同一个build执行，每个case只会被统计一次
                        allCaseList.add(methodsStr);
                        if(allCaseResultMap.containsKey(methodsStr)){
                            allCaseResultMap.replace(methodsStr,allCaseResultMap.get(methodsStr).intValue()+1);
                        }else{
                            allCaseResultMap.put(methodsStr,1);
                        }
                    }
                    //统计失败的case
                    if (status.equals("FAILED")  || status.equals("REGRESSION")) {
                        if(StringUtils.isNotEmpty(faildCase)&&methodsStr.equals(faildCase)){
                            log.info(testResultUrl);
                        }
                        //数据驱动的case单次build执行，如果失败，只统计一次
                        if(failedCaseList.contains(methodsStr)){//同一个build执行，每个case只会被统计一次
                            continue;
                        }
                        failedCaseList.add(methodsStr);
                        if(failCaseResultMap.containsKey(methodsStr)){
                            failCaseResultMap.replace(methodsStr,failCaseResultMap.get(methodsStr).intValue()+1);
                        }else{
                            failCaseResultMap.put(methodsStr,1);
                        }
                    }
                }
            } catch (Exception e) {
                log.error("执行异常url："+testResultUrl+e.getMessage());
            }
        }
        //按失败次数进行排序
        Map<String, Integer> finalMap = new LinkedHashMap<>();
        failCaseResultMap.entrySet().stream()//.filter((e) -> e.getValue()>minFailedCount)
                .sorted(Map.Entry.<String, Integer>comparingByValue()
                        .reversed()).forEachOrdered(e -> finalMap.put(e.getKey(), e.getValue()));
        System.out.println("全部的失败case及次数：");
        System.out.println(JSONObject.toJSONString(finalMap));
        System.out.println("失败率大于"+minFailedRate+"、失败次数大于"+minFailedExeCount+"次的case：");
        int index=1;
        for(String key:finalMap.keySet()){
            if (finalMap.get(key)>allCaseResultMap.get(key)*minFailedRate
                    &&finalMap.get(key)>minFailedExeCount){
                System.out.println(index+++"\t"+key+"\t"+finalMap.get(key)+"\t"+allCaseResultMap.get(key)
                        +"\t"+getAuthor(key,projectId));
            }
        }
    }

    /**
     * 获取当天的数据
     * @return
     */
    private Long getBeginDayOfWeek() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK,1);
        cal.add(Calendar.WEEK_OF_YEAR,0);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        return cal.getTimeInMillis();
    }


    /**
     * 通过gitlab接口获取当前失败case的author
     * @param path
     * @return
     */
    public String getAuthor(String path,String projectId){
        try{
            path = path.substring(0,path.lastIndexOf("."));
            path = path.replaceAll("\\.","/");
            path = "src/test/java/"+path+".java";
            try{
                path = URLEncoder.encode(path,"UTF-8");
            }catch (Exception e){
                e.printStackTrace();
            }
            String url = "http://gitlab.qima-inc.com/api/v4/projects/"+projectId+"/repository/files/"+path+"?ref=master&private_token=FEqT9BukMPt3JTs22sEZ";
            String jobResult = null;
            try {
                jobResult = com.youzan.test.tools.HttpUtils.sendGet(url);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(StringUtils.isEmpty(jobResult)){
                return "";
            }
            String content =  JSONObject.parseObject(jobResult).getString("content");
            Base64.Decoder decoder = Base64.getDecoder();
            content = new String(decoder.decode(content));
            //正则获取author行
            Pattern bugNumber = Pattern.compile("@auth.*",Pattern.CASE_INSENSITIVE);
            Matcher matcher = bugNumber.matcher(content);
            if(matcher.find()){
                String auth = matcher.group(0);
                if(auth.lastIndexOf(" ")>0){
                    return auth.substring(auth.lastIndexOf(" ")).trim();
                }
            }

            bugNumber = Pattern.compile("created by.*on",Pattern.CASE_INSENSITIVE);
            matcher = bugNumber.matcher(content);
            if(matcher.find()){
                String auth = matcher.group(0);
                auth = auth.toLowerCase();
                return auth.substring(auth.indexOf("created by")+10,auth.indexOf("on")).trim();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 自动计算值班同学
     */
    @Test
    public void testG(){
        System.out.println(getMobile("ycm"));
    }

    public String getMobile(String line){
        List<String> nameList = new ArrayList<>();
        List<String> ycmList = Arrays.asList("18351892832","15601678473","15988140519","15558185305","18507556052");
        List<String> crmList = Arrays.asList("15381035876","15068726948","13691463606","13732211627","15988199415");
        if(line.equals("ycm")){
            nameList = ycmList;
        }else if(line.equals("crm")){
            nameList = crmList;
        }
        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int week = cal.get(Calendar.WEEK_OF_YEAR)+2;
        int index = week % nameList.size();
        return nameList.get(index);
    }

    /**
     * 测试tether
     */
    @Test
    public void doInvoke() {
        CompareSCUtil.resetSC();
        // 当前应用配置
        ApplicationConfig application = new ApplicationConfig();
        // 当前应用配置
        application.setName("qibu-test");
        // 引用远程服务
        // 该实例很重量，里面封装了所有与注册中心及服务提供方连接，请缓存
        ReferenceConfig<RedeemCodeManagerService> reference = new ReferenceConfig<>();
        reference.setApplication(application);

        //  第二步：不需要再设置registry，下面注释的这行代码可以删除
        reference.setProtocol("dubbo");
        reference.setInterface(RedeemCodeManagerService.class);
        // 第三步：添加一行代码(地址需要参考文档确定，下面只是一个示例)
        reference.setUrl("dubbo://tether-qa.s.qima-inc.com:8700");


        //获取优惠码
        GetRedeemCodeDataRequest getRedeemCodeDataRequest = new GetRedeemCodeDataRequest();
        getRedeemCodeDataRequest.setConfigId(728L);
        RedeemCodeManagerService redeemCodeManagerService = reference.get();
        PlainResult<List<GetRedeemCodeDataResponse>> result = redeemCodeManagerService.getRedeemCodeData(getRedeemCodeDataRequest);
        System.out.println("======"+ JSON.toJSONString(result));
    }


}
