package com.youzan.test.onlineTrade.basecase.beautyBvt;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author baoyan
 * @date 2021/5/24 4:07 PM
 */
public class beautyOnlineBvt extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(beautyOnlineBvt.class);
    public Long beautyKdtId = 59919115L;
    public String beautyKdtName = "CI-美业BVT";
    public Integer beautyPro = 8168;
    public Integer beautyStore = 8166;
    public String beautySoftYcmAppId = "combine_spu_youzan_beauty";
    public String beautyStoreYcmAppId = "combine_spu_youzan_beauty_store";
    public Integer beautySoftYopAppId = 6281 ;
    public Integer beautyStoreYopAppId = 11228;
    public String beautySoftYcmItemIdForTwoYears =  "atom_sku_youzan_beauty_store_two_year";


    @BeforeClass
    public void beforeClass() {
        rechargeShopBalance(beautyKdtId.toString(),cny+1000);
    }

    @Test
    public void newCreateOrderAndPerform() {
        initShopByKdtId(beautyKdtId);

        Map<Integer,List<Long>> itemInfo = new HashMap<>();
        List<Long> applyHpKdtIds = new ArrayList<>();
        List<Long> applyStoreKdtIds = new ArrayList<>();
        itemInfo.put(beautyPro,applyHpKdtIds);
        itemInfo.put(beautyStore,applyStoreKdtIds);
        Byte buyType = 1;

        PlainResult<OrderCreateApi> resultCreateOrderV2 = createOrderV2WithMultiApp(beautyKdtId,beautyKdtName,itemInfo,3,buyType,0L);

        logger.info("创建订单结果："+ JSON.toJSONString(resultCreateOrderV2));

        Assert.assertEquals(resultCreateOrderV2.getCode(),200,resultCreateOrderV2.getMessage());
        if (resultCreateOrderV2.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(resultCreateOrderV2.getData().getPayOrderId(), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, beautyKdtId);
        }

        //订单返回的td order id
        Long orderId = resultCreateOrderV2.getData().getPayOrderId();

        //等待履约
        waitForSplitOrder(orderId);
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        waitForPerform(beautyKdtId,6281L,orderId);

        List<PfOrder> storePfOrders = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautyStoreYcmAppId));

        PfOrder softPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautySoftYcmAppId));

        /**
         * 校验门店pf order 表的biz_ext的周期和数量正确
         */
        Assert.assertEquals(storePfOrders.size(),3,"美业门店生成数量不正确");
        for(PfOrder pfOrder : storePfOrders) {
            Assert.assertEquals(pfOrder.getPerformState(),"wait_perform","新购的美业门店生效状态不是待履约");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","duration 值不正确");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","quantity 值不正确");
        }

        Assert.assertEquals(softPfOrder.getPerformState(),"performed");



    }

    @Test
    public void renewCreateOrderAndPerformWithExpiredStatus() {
        initShopByKdtId(beautyKdtId);

        //item参数
        Map<Integer,List<Long>> itemInfo = new HashMap<>();
        List<Long> applyHpKdtIds = new ArrayList<>();
        applyHpKdtIds.add(59919115L);
        List<Long> applyStoreKdtIds = new ArrayList<>();
        applyStoreKdtIds.add(59919116L);
        applyStoreKdtIds.add(59920920L);
        itemInfo.put(beautyPro,applyHpKdtIds);
        itemInfo.put(beautyStore,applyStoreKdtIds);
        Byte buyType = 2;

        PlainResult<OrderCreateApi> resultCreateOrderV2 = createOrderV2WithMultiApp(beautyKdtId,beautyKdtName,itemInfo,1,buyType,0L);

        logger.info("创建订单结果："+ JSON.toJSONString(resultCreateOrderV2));

        Assert.assertEquals(resultCreateOrderV2.getCode(),200,resultCreateOrderV2.getMessage());
        if (resultCreateOrderV2.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(resultCreateOrderV2.getData().getPayOrderId(), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, beautyKdtId);
        }

        //订单返回的td order id
        Long orderId = resultCreateOrderV2.getData().getPayOrderId();

        //等待拆单
        waitForSplitOrder(orderId);
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        waitForPerform(beautyKdtId,6281L,orderId);
        List<PfOrder> storePfOrders = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautyStoreYcmAppId));

        PfOrder softPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautySoftYcmAppId));

        /**
         * 校验门店pf order 表的biz_ext的周期和数量正确
         */
        Assert.assertEquals(storePfOrders.size(),2,"美业门店生成数量不正确");
        for(PfOrder pfOrder : storePfOrders) {
            Assert.assertEquals(pfOrder.getPerformState(),"performed","新购的美业门店生效状态不是已履约");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","duration 值不正确");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","quantity 值不正确");

            /**
             * 校验服务期为当前时间+2年，即总天数为730
             */
            checkPfOrderStatus(pfOrder.getId(),beautySoftYcmItemIdForTwoYears,2);


        }

        Assert.assertEquals(softPfOrder.getPerformState(),"performed");

    }

    @Test
    public void renewCreateOrderAndPerformWithNotExpiredStatus() {
        initShopByKdtId(beautyKdtId);

        //item参数
        Map<Integer,List<Long>> itemInfo = new HashMap<>();
        List<Long> applyHpKdtIds = new ArrayList<>();
        applyHpKdtIds.add(59919115L);
        List<Long> applyStoreKdtIds = new ArrayList<>();
        applyStoreKdtIds.add(59919116L);
        applyStoreKdtIds.add(59920920L);
        itemInfo.put(beautyPro,applyHpKdtIds);
        itemInfo.put(beautyStore,applyStoreKdtIds);
        Byte buyType = 2;

        PlainResult<OrderCreateApi> resultCreateOrderV2 = createOrderV2WithMultiApp(beautyKdtId,beautyKdtName,itemInfo,1,buyType,0L);

        logger.info("创建订单结果："+ JSON.toJSONString(resultCreateOrderV2));

        Assert.assertEquals(resultCreateOrderV2.getCode(),200,resultCreateOrderV2.getMessage());
        if (resultCreateOrderV2.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(resultCreateOrderV2.getData().getPayOrderId(), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, beautyKdtId);
        }

        //订单返回的td order id
        Long orderId = resultCreateOrderV2.getData().getPayOrderId();

        //等待拆单
        waitForSplitOrder(orderId);
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        waitForPerform(beautyKdtId,6281L,orderId);

        List<PfOrder> storePfOrders = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautyStoreYcmAppId));

        PfOrder softPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautySoftYcmAppId));

        /**
         * 校验门店pf order 表的biz_ext的周期和数量正确
         */
        Assert.assertEquals(storePfOrders.size(),2,"美业门店生成数量不正确");
        for(PfOrder pfOrder : storePfOrders) {
            Assert.assertEquals(pfOrder.getPerformState(),"performed","新购的美业门店生效状态不是已履约");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","duration 值不正确");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","quantity 值不正确");

            /**
             * 校验服务期为当前时间+2年，即总天数为730
             */
            checkPfOrderStatus(pfOrder.getId(),beautySoftYcmItemIdForTwoYears,2);


        }

        Assert.assertEquals(softPfOrder.getPerformState(),"performed");


        PlainResult<OrderCreateApi> renewResultCreateOrderV2 = createOrderV2WithMultiApp(beautyKdtId,beautyKdtName,itemInfo,1,buyType,0L);

        logger.info("创建订单结果："+ JSON.toJSONString(renewResultCreateOrderV2));

        Assert.assertEquals(renewResultCreateOrderV2.getCode(),200,resultCreateOrderV2.getMessage());
        if (renewResultCreateOrderV2.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(renewResultCreateOrderV2.getData().getPayOrderId(), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, beautyKdtId);
        }

        //订单返回的td order id
        Long orderIdRenew = renewResultCreateOrderV2.getData().getPayOrderId();

        //等待拆单
        waitForSplitOrder(orderIdRenew);
        TdOrder tdOrderRenew = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderIdRenew));
        waitForPerform(beautyKdtId,6281L,orderIdRenew);
        List<PfOrder> storePfOrdersRenew = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrderRenew.getTdNo()).eq("app_id", beautyStoreYcmAppId));

        PfOrder softPfOrderRenew = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrderRenew.getTdNo()).eq("app_id", beautySoftYcmAppId));

        /**
         * 校验门店pf order 表的biz_ext的周期和数量正确
         */
        Assert.assertEquals(storePfOrdersRenew.size(),2,"美业门店生成数量不正确");
        for(PfOrder pfOrder : storePfOrdersRenew) {
            Assert.assertEquals(pfOrder.getPerformState(),"performed","新购的美业门店生效状态不是已履约");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","duration 值不正确");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","quantity 值不正确");

            /**
             * 校验服务期为当前时间+2年
             */
            checkPfOrderStatus(pfOrder.getId(),beautySoftYcmItemIdForTwoYears,2);

        }

        Assert.assertEquals(softPfOrderRenew.getPerformState(),"performed");
    }

    @Test
    public void AddBeautyStore() {
        initShopByKdtId(beautyKdtId);

        Map<Integer,List<Long>> itemInfo = new HashMap<>();
        List<Long> applyHpKdtIds = new ArrayList<>();
        List<Long> applyStoreKdtIds = new ArrayList<>();
        itemInfo.put(beautyPro,applyHpKdtIds);
        itemInfo.put(beautyStore,applyStoreKdtIds);
        Byte buyType = 3;

        PlainResult<OrderCreateApi> resultCreateOrderV2 = createOrderV2WithMultiApp(beautyKdtId,beautyKdtName,itemInfo,3,buyType,0L);

        logger.info("创建订单结果："+ JSON.toJSONString(resultCreateOrderV2));

        Assert.assertEquals(resultCreateOrderV2.getCode(),200,resultCreateOrderV2.getMessage());
        if (resultCreateOrderV2.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(resultCreateOrderV2.getData().getPayOrderId(), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, beautyKdtId);
        }

        //订单返回的td order id
        Long orderId = resultCreateOrderV2.getData().getPayOrderId();

        //等待履约
        waitForSplitOrder(orderId);
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        waitForPerform(beautyKdtId,6281L,orderId);

        List<PfOrder> storePfOrders = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautyStoreYcmAppId));

        PfOrder softPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", beautySoftYcmAppId));

        /**
         * 校验门店pf order 表的biz_ext的周期和数量正确
         */
        Assert.assertEquals(storePfOrders.size(),3,"美业门店生成数量不正确");
        for(PfOrder pfOrder : storePfOrders) {
            Assert.assertEquals(pfOrder.getPerformState(),"wait_perform","新购的美业门店生效状态不是待履约");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","duration 值不正确");
            Assert.assertEquals(JSONObject.parseObject(pfOrder.getBizExt()).get("duration"),"1","quantity 值不正确");
        }

        Assert.assertEquals(softPfOrder.getPerformState(),"performed");



    }


}
