package com.youzan.test.market.apicase.market;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.goods.GdAtomBasic;
import com.youzan.commerce.test.entity.dataobject.market.MkBizRecord;
import com.youzan.commerce.test.entity.dataobject.market.MkItemResult;
import com.youzan.commerce.test.entity.dataobject.market.MkJoinRecord;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivitySnapshot;
import com.youzan.commerce.test.entity.dataobject.market.coupon.*;
import com.youzan.commerce.test.mapper.goods.GdAtomBasicMapper;
import com.youzan.commerce.test.mapper.goods.GdGoodsIdMappingMapper;
import com.youzan.commerce.test.mapper.market.JoinRecordMapper;
import com.youzan.commerce.test.mapper.market.MkItemResultMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityRuleMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivitySnapchatMapper;
import com.youzan.commerce.test.mapper.market.coupon.*;
import com.youzan.commerce.test.mapper.trade.BizRecordMapper;
import com.youzan.test.market.apicase.YcmMarketBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.api.*;
import com.youzan.ycm.market.request.activity.SaveGoodsDiscountActivityRequest;
import com.youzan.ycm.market.request.activity.UpdateActivityStateRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.request.coupon.UpdateCouponStateRequest;
import com.youzan.ycm.market.request.couponasset.RecycleCouponAssetRequest;
import com.youzan.ycm.market.request.couponsend.SaveSendCouponRequest;
import com.youzan.ycm.market.request.couponsend.SendCouponAssetRequest;
import com.youzan.ycm.market.response.activity.GoodsDiscountActivityResponse;
import com.youzan.ycm.market.response.activity.SaveGoodsDiscountActivityResponse;
import com.youzan.ycm.market.response.coupon.SaveCouponResponse;
import com.youzan.ycm.market.response.coupon.UpdateCouponStateResponse;
import com.youzan.ycm.market.response.couponasset.RecycleCouponAssetResponse;
import com.youzan.ycm.market.response.couponsend.SaveCouponSendRecordResponse;
import com.youzan.ycm.market.response.couponsend.SendCouponResponse;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author leifeiyun
 * @date 2020/11/17
 **/
public class TradeRemoteServiceBaseTest extends YcmMarketBaseTest {
    @Dubbo
    CouponRemoteService couponRemoteService;
    @Dubbo
    CouponSendRemoteService couponSendRemoteService;
    @Dubbo
    OrderFullReduceActivityRemoteService orderFullReduceActivityRemoteService;
    @Dubbo
    GoodsDicountActivityuRemoteService goodsDicountActivityuRemoteService;
    @Dubbo
    CouponAssetRemoteService couponAssetRemoteService;
    @Autowired(required = false)
    ActivityRuleMapper activityRuleMapper;
    @Autowired(required = false)
    ActivityMapper activityMapper;
    @Autowired(required = false)
    ActivitySnapchatMapper activitySnapchatMapper;
    @Autowired(required = false)
    JoinRecordMapper joinRecordMapper;
    @Autowired(required = false)
    BizRecordMapper bizRecordMapper;
    @Autowired(required = false)
    MkItemResultMapper mkItemResultMapper;
    @Autowired(required = false)
    CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    CouponMapper couponMapper;
    @Autowired(required = false)
    CouponRuleMapper couponRuleMapper;
    @Autowired(required = false)
    CouponSnapshotMapper couponSnapshotMapper;
    @Autowired(required = false)
    CouponSendRecordMapper couponSendRecordMapper;
    @Autowired(required = false)
    CouponSendRecordDetailMapper couponSendRecordDetailMapper;
    @Autowired(required = false)
    GdAtomBasicMapper gdAtomBasicMapper;
    @Autowired(required = false)
    GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @JSONData("dataResource/basecase.activity/couponSendRecord.json")
    private SaveSendCouponRequest saveSendCouponRequest;
    @JSONData("dataResource/basecase.activity/couponSendRecord.json")
    private SaveSendCouponRequest saveSendCouponRequestTemp;


    @JSONData("dataResource/basecase.activity/couponSendRecordForCrm.json")
    private SaveSendCouponRequest saveSendCouponForCrmRequest;
    @JSONData("dataResource/basecase.activity/couponSendRecordForCrm.json")
    private SaveSendCouponRequest saveSendCouponForCrmRequestTemp;


    public void deleteActivityConfigData(String activityId) {
        logger.info("开始清理活动数据，活动id---->:" + activityId);
        activityMapper.delete(new QueryWrapper<MkActivity>()
                .eq("id", activityId));
        activityRuleMapper.delete(new QueryWrapper<MkActivityRule>()
                .eq("activity_id", activityId));
        activitySnapchatMapper.delete(new QueryWrapper<MkActivitySnapshot>()
                .eq("activity_id", activityId));
        List<MkJoinRecord> mkJoinRecordList = joinRecordMapper.selectList(new QueryWrapper<MkJoinRecord>()
                .eq("mk_id", activityId));
        if (mkJoinRecordList.size() > 0) {
            mkItemResultMapper.delete(new QueryWrapper<MkItemResult>()
                    .in("join_record_id", mkJoinRecordList.stream().map(MkJoinRecord::getId).collect(Collectors.toList())));
            joinRecordMapper.delete(new QueryWrapper<MkJoinRecord>()
                    .eq("mk_id", activityId));
        }


    }

    /**
     * 清除券数据
     * @param couponId
     */
    public void deleteCouponData(Long couponId) {
        logger.info("-----------开始清理礼包券配置信息----------");
        logger.info("-----------礼包券id+" + couponId + "----------");
        couponMapper.delete(new QueryWrapper<MkCoupon>().eq("id", couponId));
        couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().eq("coupon_id", couponId));
        couponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshot>().eq("coupon_id", couponId));
        couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().eq("coupon_id", couponId));
        List<MkCouponSendRecord> mkCouponSendRecordList = couponSendRecordMapper.selectList((new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId)));
        couponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId));

        if (mkCouponSendRecordList != null) {
            for(MkCouponSendRecord mkCouponSendRecord : mkCouponSendRecordList){
                couponSendRecordDetailMapper.delete(new QueryWrapper<MkCouponSendRecordDetail>().eq("send_record_id", mkCouponSendRecord.getId()));
            }
        }
    }


    /**
     * 上架优惠券
     * @param couponId
     */
    public void updateCouponState(String couponId) {
        UpdateCouponStateRequest updateCouponStateRequest = new UpdateCouponStateRequest();
        updateCouponStateRequest.setOperator("leifeiyun");
        updateCouponStateRequest.setCouponState("ONLINE");
        updateCouponStateRequest.setCouponId(couponId);
        PlainResult<UpdateCouponStateResponse> updateCouponStateResponsePlainResult = couponRemoteService.updateCouponState(updateCouponStateRequest);
        Assert.assertEquals(updateCouponStateResponsePlainResult.getCode(), 200);

    }

    /**
     * 生成发券单并发送优惠券
     * @param couponId
     * @param couponName
     */
    public void generateSendRecordAndSendCoupon(String couponId, String couponName) {
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String sendRecordCouponName = couponName + dateString;
        //组装发券单
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponId(couponId);
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponName(sendRecordCouponName);
        PlainResult<SaveCouponSendRecordResponse> discountCouponSendRecord = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);
        //发放优惠券券
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        sendCouponAssetRequest.setCouponSendRecordId(discountCouponSendRecord.getData().getCouponSendRuleDTO().getCouponSendRecordId());
        sendCouponAssetRequest.setSendOperator("leifeiyun");
        PlainResult<SendCouponResponse> sendResult = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);
        Assert.assertEquals(sendResult.getCode(), 200);
    }

    /**
     * 生成发券单,销售发放
     * @param couponId
     * @param couponName
     */
    public String generateSendRecordForBatch(String couponId, String couponName) {
        saveSendCouponForCrmRequestTemp = SerializationUtils.clone(this.saveSendCouponForCrmRequest);


        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String sendRecordCouponName = couponName + dateString;
        //组装发券单
        saveSendCouponForCrmRequestTemp.getCouponSendRuleDTO().setCouponId(couponId);
        saveSendCouponForCrmRequestTemp.getCouponSendRuleDTO().setCouponName(sendRecordCouponName);
        PlainResult<SaveCouponSendRecordResponse> discountCouponSendRecord = couponSendRemoteService.saveCouponSendRecord(saveSendCouponForCrmRequestTemp);
        String  couponSendRecordId = discountCouponSendRecord.getData().getCouponSendRuleDTO().getCouponSendRecordId();
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        sendCouponAssetRequest.setCouponSendRecordId(couponSendRecordId);
        sendCouponAssetRequest.setSendOperator("leifeiyun");
        //消息发放到crm
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        PlainResult<SendCouponResponse> result = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);

        Assert.assertEquals(result.getCode(),200);
        return couponSendRecordId;

    }


    /**
     * 创建权益券
     * @param couponName
     * @param saveCouponRequest
     * @return
     */
    public String createCoupon(String couponName, SaveCouponRequest saveCouponRequest) {
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String discountCouponName = couponName + dateString;
        saveCouponRequest.getAllCouponDTO().setName(discountCouponName);
        PlainResult<SaveCouponResponse> discountSaveResult = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = discountSaveResult.getData().getAllCouponDTO().getCouponId();
        Assert.assertEquals(discountSaveResult.getCode(), 200);
        return couponId;
    }

    /**
     * 回收券资产
     * @param couponId
     */
    public void recycleCouponAsset(String couponId) {
        RecycleCouponAssetRequest recycleCouponAssetRequest = new RecycleCouponAssetRequest();
        recycleCouponAssetRequest.setCouponAssetId(couponId);
        recycleCouponAssetRequest.setOpScene("BIZ");
        PlainResult<RecycleCouponAssetResponse> recycleCouponAssetResult = couponAssetRemoteService.recycleCouponAsset(recycleCouponAssetRequest);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Assert.assertNotNull(recycleCouponAssetResult.getData().getCouponAssetDTO());
        Assert.assertEquals(recycleCouponAssetResult.getCode(), 200);
        Assert.assertEquals(recycleCouponAssetResult.getMessage(), "successful");

    }

    /**
     * 失效打折活动
     * @param activityId
     */
    public void expireDiscountActivity(String activityId) {
        //失效打折活动
        UpdateActivityStateRequest updateActivityStateRequest = new UpdateActivityStateRequest();
        updateActivityStateRequest.setActivityId(activityId);
        updateActivityStateRequest.setActivityState("EXPIRED");
        updateActivityStateRequest.setOperator("leifeiyun");
        PlainResult<GoodsDiscountActivityResponse> stateChangeResult =
                goodsDicountActivityuRemoteService.updateActivityState(updateActivityStateRequest);

        Assert.assertEquals(stateChangeResult.getCode(), 200, stateChangeResult.getMessage());
        Assert.assertEquals(stateChangeResult.getMessage(), "successful");
        Assert.assertEquals(stateChangeResult.getData().getGoodsDiscountActivityDTO().getActivityState(), "EXPIRED");
    }

    /**
     * 优惠类型:1:打折，2:赠送，3:打包购买优惠，4:硬件，5:礼包，6:有赞币,8:搭配购,9:插件套餐，21:满减活动，22:券资产，23:打折活动
     *
     * @see -com.youzan.yop.market.enums.PreferentialPackageType
     */
    public PreferentialDescApi generatePreferential(String promotionId, Byte type) {
        //21:满减活动，22:券资产，23:打折活动
        PreferentialDescApi preferentialDescApi = new PreferentialDescApi();
        switch (type) {
            case 21:
                MkActivity mkActivity = getMKActivity(promotionId);
                preferentialDescApi.setName(mkActivity.getName());
                break;
            case 22:
                MkCouponAsset mkCouponAsset = getMKCoupon(promotionId);
                preferentialDescApi.setName(mkCouponAsset.getName());
                break;
            case 23:
                mkActivity = getMKActivity(promotionId);
                preferentialDescApi.setName(mkActivity.getName());
                break;
        }
        preferentialDescApi.setPromotionId(Long.valueOf(promotionId));
        preferentialDescApi.setType(type);
        return preferentialDescApi;
    }

    public MkCouponAsset getMKCoupon(String couponAssetId) {
        MkCouponAsset mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("id", couponAssetId));
        return mkCouponAsset;
    }

    public MkActivity getMKActivity(String activityId) {
        MkActivity mkActivity = activityMapper.selectOne(new QueryWrapper<MkActivity>().eq("id", activityId));
        return mkActivity;
    }


    public Map<String, String> generateDiscountCouponAndDiscountActivity(SaveCouponRequest saveDiscountCoupon, SaveGoodsDiscountActivityRequest saveGoodsDiscountActivityRequest) {
        String discountActivityId = "";
        String discountCouponId = "";


        //创建打折券
        discountCouponId = createCoupon("auto-lfy-打折券", saveDiscountCoupon);
        //上架打折券
        updateCouponState(discountCouponId);
        //组装发放打折券
        generateSendRecordAndSendCoupon(discountCouponId, "auto-lfy-打折券-发券单");

        //创建打折活动
        PlainResult<SaveGoodsDiscountActivityResponse> saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveGoodsDiscountActivityRequest);
        if (saveDiscountActivityResult.getCode() == 703) {
            //打折活动已创建，则失效掉

            List<MkActivity> queryResult = activityMapper.selectList(new QueryWrapper<MkActivity>()
                    .eq("state", "AUDITED_PASS")
                    .eq("is_delete", 0)
                    .like("name", getAppNameByAppId(saveGoodsDiscountActivityRequest.getGoodsDiscountActivityDTO().getAllGoodsDiscountRuleDTOS().get(0).getAppId()))
                    .gt("expire_time", new Date())

            );
            for (int i = 0; i < queryResult.size(); i++) {
                expireDiscountActivity(String.valueOf(queryResult.get(i).getId()));
            }
            saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveGoodsDiscountActivityRequest);
        }
        discountActivityId = saveDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId();

        MkCouponAsset discountCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("coupon_id", discountCouponId));
        String discountAssetId = String.valueOf(discountCouponAsset.getId());

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put("discountAssetId", discountAssetId);
        resultMap.put("discountActivityId", discountActivityId);
        resultMap.put("discountCouponId", discountCouponId);
        return resultMap;

    }

    public void clearDiscountData(Map<String, String> paramMap) {

        recycleCouponAsset(paramMap.get("discountAssetId"));

//        expireDiscountActivity(paramMap.get("discountActivityId"));
        //删除配置的优惠券数据
        deleteCouponData(Long.valueOf(paramMap.get("discountCouponId")));
        //删除配置的打折活动数据
        deleteActivityConfigData(paramMap.get("discountActivityId"));

    }

    public String getAppNameByAppId(String appId) {
        /*GdGoodsIdMapping gdGoodsIdMapping = gdGoodsIdMappingMapper.selectOne(new QueryWrapper<GdGoodsIdMapping>()
                .eq("yop_id", appId)
                .eq("type", "spu"));*/
        GdAtomBasic gdAtomBasic = gdAtomBasicMapper.selectOne(new QueryWrapper<GdAtomBasic>()
                .eq("atom_app_id", appId)
                .last(" limit 1"));
        return gdAtomBasic.getName();
    }

    public void setRecordState(String bizNo,String State){
        MkBizRecord mkBizRecord = new MkBizRecord();
        mkBizRecord.setBizState(State);
        MkJoinRecord mkJoinRecord = new MkJoinRecord();
        mkJoinRecord.setState(State);
        bizRecordMapper.update(mkBizRecord,new QueryWrapper<MkBizRecord>().eq("biz_order_id",bizNo));
        joinRecordMapper.update(mkJoinRecord,new QueryWrapper<MkJoinRecord>().eq("biz_order_id",bizNo));
    }

    /**
     * 批量回收券资产
     */
    public void bachRecycleMkCouponAsset(String kdtId){
        List<MkCouponAsset> couponAssetList = couponAssetMapper.selectList(new QueryWrapper<MkCouponAsset>().eq("belongto_yid",kdtId)
        .eq("state","RECEIVED"));
        for(MkCouponAsset mkCouponAsset : couponAssetList){
            recycleCouponAsset(String.valueOf(mkCouponAsset.getId()));
        }
    }


    public void deleteLfyCouponData(){
        List<MkCoupon> mkCouponList = couponMapper.selectList(new QueryWrapper<MkCoupon>().like("name","auto-lfy"));
        for (MkCoupon mkCoupon : mkCouponList) {
            deleteCouponData(Long.valueOf(mkCoupon.getId()));
        }
    }

    public void deleteLfyActivityData(){
        List<MkActivity> mkActivities = activityMapper.selectList(new QueryWrapper<MkActivity>().like("name","auto-lfy"));
        for (MkActivity mkActivity : mkActivities) {
            deleteActivityConfigData(String.valueOf(mkActivity.getId()));
        }
    }

  /*  @AfterClass
    public void afterClass(){
        deleteLfyCouponData();
        deleteLfyActivityData();
    }*/


}
