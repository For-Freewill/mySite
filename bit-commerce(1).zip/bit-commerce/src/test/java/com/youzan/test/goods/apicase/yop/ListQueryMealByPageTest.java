package com.youzan.test.goods.apicase.yop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.apicase.market.YcmMarketBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.MealRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.form.appOperationDtos.MealBasicInfoApiDto;
import com.youzan.yop.api.form.appOperationDtos.QueryMealListForm;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2020/9/25 3:59 下午
 * 分页查询插件套餐列表
 * @大爷
 */
public class ListQueryMealByPageTest extends YcmMarketBaseTest {

    @Dubbo
    public MealRemoteService mealRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void queryCollocationByIdNormalTest() {
        QueryMealListForm queryMealListForm = new QueryMealListForm();
        queryMealListForm.setName("店铺员工");

        PlainResult<PageApi<MealBasicInfoApiDto>> queryMealListFormResult = mealRemoteService.listQueryMealByPage(queryMealListForm);
        Assert.assertEquals(queryMealListFormResult.getCode(), 200);
    }

    /**
     *  异常用例--参数为null
     */
    @Test
    public void queryCollocationByIdRequestNullTest() {
        PlainResult<PageApi<MealBasicInfoApiDto>> queryMealListFormResult = mealRemoteService.listQueryMealByPage(null);
        Assert.assertEquals(queryMealListFormResult.getCode(), 130501);
    }

    /**
     * 异常用例--Name为null
     */
    @Test
    public void queryCollocationByIdNameNullTest() {
        QueryMealListForm queryMealListForm = new QueryMealListForm();
        queryMealListForm.setName(null);

        PlainResult<PageApi<MealBasicInfoApiDto>> queryMealListFormResult = mealRemoteService.listQueryMealByPage(queryMealListForm);
        Assert.assertEquals(queryMealListFormResult.getCode(), 200);
    }

}
