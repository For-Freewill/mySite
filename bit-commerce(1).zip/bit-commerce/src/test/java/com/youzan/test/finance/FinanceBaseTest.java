package com.youzan.test.finance;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.commerce.test.entity.dataobject.finance.*;
import com.youzan.commerce.test.mapper.finance.*;
import com.youzan.test.BaseTest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by baoyan on 11/16/21.
 */
@Slf4j
public class FinanceBaseTest extends BaseTest {
    @Autowired(required = false)
    CaAccountingPlanMapper caAccountingPlanMapper;
    @Autowired(required = false)
    CaCommissionAccountLogMapper caCommissionAccountLogMapper;
    @Autowired(required = false)
    CaCommissionAccountMapper caCommissionAccountMapper;
    @Autowired(required = false)
    CaCommissionSettleOrderMapper caCommissionSettleOrderMapper;
    @Autowired(required = false)
    CaSettleOrderExtSaasMapper caSettleOrderExtSaasMapper;
    @Autowired(required = false)
    CaPerformanceOrderMapper caPerformanceOrderMapper;
    @Autowired(required = false)
    CaPerformanceOrderExtMapper caPerformanceOrderExtMapper;

   /**
    update ca_accounting_plan set stage = 'INIT',biz_ext= '{}' where id = 1;
    delete from ca_commission_settle_order where plan_no = '1';
    delete from ca_settle_order_ext_saas where settle_no not in  (select settle_no from ca_commission_settle_order);
    delete from ca_performance_order where plan_no = '1';
    delete from ca_performance_order_ext where performance_no not in (select performance_no from ca_performance_order);
    delete from ca_commission_account_log where ca_id in ('12130','12133','12132','12131');
    delete from ca_commission_account where ca_id in ('12130','12133','12132','12131');
    */

    public void reset(List<String> providerIds,Long planNo){
        //  重置核算计划状态为初始化ca_accounting_plan
        LambdaUpdateWrapper<CaAccountingPlanDO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(CaAccountingPlanDO::getStage, "INIT").eq(CaAccountingPlanDO::getId,planNo);
        CaAccountingPlanDO caAccountingPlanDO = caAccountingPlanMapper.selectById(planNo);
        caAccountingPlanMapper.update(null, updateWrapper);
        //  删除佣金结算单ca_commission_settle_order
        caCommissionSettleOrderMapper.delete(new UpdateWrapper<CaCommissionSettleOrderDO>().eq("plan_no", planNo));
        //  删除结算单SaaS订单拓展信息ca_settle_order_ext_saas
        List<String> settleNos = caCommissionSettleOrderMapper.selectList(null).stream().map(CaCommissionSettleOrderDO::getSettleNo).collect(Collectors.toList());
        caSettleOrderExtSaasMapper.delete(new UpdateWrapper<CaSettleOrderExtSaaSDO>().notIn("settle_no",settleNos));
        //  删除佣金结算业绩单ca_performance_order
        caPerformanceOrderMapper.delete(new UpdateWrapper<CaPerformanceOrderDO>().eq("plan_no", planNo));
        //  删除业绩单-SaaS拓展信息ca_performance_order_ext
        List<String> performanceNos = caPerformanceOrderMapper.selectList(null).stream().map(CaPerformanceOrderDO::getPerformanceNo).collect(Collectors.toList());
        caPerformanceOrderExtMapper.delete(new UpdateWrapper<CaPerformanceOrderExtDO>().notIn("performance_no",performanceNos));
        //  删除佣金账户信息ca_commission_account
        for(String providerId : providerIds){
            caCommissionAccountMapper.delete(new UpdateWrapper<CaCommissionAccountDO>().eq("ca_id",providerId));
        }
        //  佣金账户余额变更流水ca_commission_account_log
        for(String providerId : providerIds){
            caCommissionAccountLogMapper.delete(new UpdateWrapper<CaCommissionAccountLogDO>().eq("ca_id",providerId));
        }
    }
}
