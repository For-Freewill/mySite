package com.youzan.test.market.basecase.activity;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.dto.activity.ActivityBaseDTO;
import com.youzan.ycm.market.request.activity.PageQueryActivityRequest;
import com.youzan.ycm.market.request.activity.SaveGoodsDiscountActivityRequest;
import com.youzan.ycm.market.response.PageResponse;
import com.youzan.ycm.market.response.activity.SaveGoodsDiscountActivityResponse;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.apache.commons.lang3.SerializationUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author leifeiyun
 * @date 2021/3/9
 **/
public class DisCountActivityLfyTest extends ActivityToolTest {
    @JSONData("dataResource/basecase.activity/ladderDiscountActivityCreate.json")
    private SaveGoodsDiscountActivityRequest saveLadderGoodsDiscountActivityRequest;
    @JSONData("dataResource/basecase.activity/A+BDiscountActivityCreate.json")
    private SaveGoodsDiscountActivityRequest saveABGoodsDiscountActivityRequest;
    @JSONData("dataResource/basecase.activity/confirmOrderForjichengPlugin3.json")
    private ConfirmOrderForm confirmOrderForm;
    @JSONData("dataResource/basecase.activity/confirmOrderForjichengPlugin3.json")
    private ConfirmOrderForm confirmOrderFormTemp;

    /**
     * 仅打折活动场景->打折活动参与验证
     * <p>
     * 配置A商品阶梯打折
     * 验证A商品参与打折，默认选择最优阶梯
     * 打折金额计算正确
     */
    @Test
    public void testLadderDiscountActivity() {
        String discountActivityId = "";
        confirmOrderFormTemp = SerializationUtils.clone(this.confirmOrderForm);
        try {
            //1.创建阶梯打折活动
            //创建打折活动
            PlainResult<SaveGoodsDiscountActivityResponse> saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveLadderGoodsDiscountActivityRequest);
            if (saveDiscountActivityResult.getCode() == 703) {
                //706,活动参与限制配置请求参数非法
                //打折活动已创建，则失效掉
                //http://biz.qa.s.qima-inc.com/#/market/tools/discount/copy/13729
                PageQueryActivityRequest pageQueryActivityRequest = new PageQueryActivityRequest();
                pageQueryActivityRequest.setKeyword("集成测试插件-3");
                PlainResult<PageResponse<ActivityBaseDTO>> queryResult = goodsDicountActivityuRemoteService.pageQueryActivityList(pageQueryActivityRequest);
                for (int i = 0; i < queryResult.getData().getItems().size(); i++) {
                    expireDiscountActivity(queryResult.getData().getItems().get(i).getActivityId());
                }
                saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveLadderGoodsDiscountActivityRequest);
            }
            discountActivityId = saveDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId();

            //21:满减活动，22:券资产，23:打折活动
            //设置打折活动
            confirmOrderFormTemp.getItems().get(0).getItemPromotionList().set(0, generatePreferential(discountActivityId, (byte) 23));
            PlainResult<OrderConfirmApi> confirmApiPlainResult = orderRemoteService.confirmOrder(confirmOrderFormTemp);

            Long totalSumPrice = Long.valueOf((long) (128800 * 0.88));
            Long totalPrice = Long.valueOf((long) (128800 * 0.88));
            Long totalDiscountPrice = Long.valueOf((long) 128800 - (long) (128800 * 0.88));
            Assert.assertEquals(totalSumPrice, confirmApiPlainResult.getData().getTotalSumPrice(), "营销小计错误");
            Assert.assertEquals(totalPrice, confirmApiPlainResult.getData().getTotalRealPrice(), "营销金额错误");
            Assert.assertEquals(Long.valueOf(128800), Long.valueOf(confirmApiPlainResult.getData().getTotalPrice()));
            Assert.assertEquals(totalDiscountPrice, confirmApiPlainResult.getData().getTotalDiscountPrice(), "总优惠价格计算错误");
            //失效活动
            expireDiscountActivity(discountActivityId);

        } catch (Exception e) {
        } finally {
            //删除配置的打折活动数据
            deleteActivityConfigData(discountActivityId);
        }

    }

    /**
     * 仅打折活动场景->打折活动参与验证
     * <p>
     * 配置A商品打折，B商品打折
     * 验证购买A商品时，优惠为A商品对应的折扣，88折
     * 验证购买B商品时，优惠为B商品对应的折扣，78折
     * 打折金额计算正确
     */
    @Test
    public void testABSeparateDiscountActivity() {
        String discountActivityId = "";
        ConfirmOrderForm confirmOrderFormTempA = SerializationUtils.clone(this.confirmOrderForm);
        ConfirmOrderForm confirmOrderFormTempB = SerializationUtils.clone(this.confirmOrderForm);

        try {
            //1.创建阶梯打折活动
            //创建打折活动
            PlainResult<SaveGoodsDiscountActivityResponse> saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveABGoodsDiscountActivityRequest);
            if (saveDiscountActivityResult.getCode() == 703) {
                //706,活动参与限制配置请求参数非法
                //打折活动已创建，则失效掉
                //http://biz.qa.s.qima-inc.com/#/market/tools/discount/copy/13729
                PageQueryActivityRequest pageQueryActivityRequest = new PageQueryActivityRequest();
                pageQueryActivityRequest.setKeyword("打折活动-阶梯-A+B型");
                PlainResult<PageResponse<ActivityBaseDTO>> queryResult = goodsDicountActivityuRemoteService.pageQueryActivityList(pageQueryActivityRequest);
                for (int i = 0; i < queryResult.getData().getItems().size(); i++) {
                    expireDiscountActivity(queryResult.getData().getItems().get(i).getActivityId());
                }
                saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveABGoodsDiscountActivityRequest);
            }
            discountActivityId = saveDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId();

            //21:满减活动，22:券资产，23:打折活动
            //设置打折活动

            confirmOrderFormTempA.getItems().get(0).getItemPromotionList().set(0, generatePreferential(discountActivityId, (byte) 23));
            confirmOrderFormTempB.getItems().get(0).getItemPromotionList().set(0, generatePreferential(discountActivityId, (byte) 23));
            //A商品的itemId与配置文件一样，B的itemId需要改
            confirmOrderFormTempB.getItems().get(0).setItemId(74198);

            PlainResult<OrderConfirmApi> confirmApiPlainResultA = orderRemoteService.confirmOrder(confirmOrderFormTempA);
            PlainResult<OrderConfirmApi> confirmApiPlainResultB = orderRemoteService.confirmOrder(confirmOrderFormTempB);


            Long totalSumPriceA = Long.valueOf((long) (128800 * 0.88));
            Long totalPriceA = Long.valueOf((long) (128800 * 0.88));
            Long totalDiscountPriceA = Long.valueOf((long) 128800 - (long) (128800 * 0.88));
            Assert.assertEquals(totalSumPriceA, confirmApiPlainResultA.getData().getTotalSumPrice(), "A商品营销小计错误");
            Assert.assertEquals(totalPriceA, confirmApiPlainResultA.getData().getTotalRealPrice(), "A商品营销金额错误");
            Assert.assertEquals(Long.valueOf(128800), Long.valueOf(confirmApiPlainResultA.getData().getTotalPrice()));
            Assert.assertEquals(totalDiscountPriceA, confirmApiPlainResultA.getData().getTotalDiscountPrice(), "A商品总优惠价格计算错误");

            Long totalSumPriceB = Long.valueOf((long) (128800 * 0.78));
            Long totalPriceB = Long.valueOf((long) (128800 * 0.78));
            Long totalDiscountPriceB = Long.valueOf((long) 128800 - (long) (128800 * 0.78));
            Assert.assertEquals(totalSumPriceB, confirmApiPlainResultB.getData().getTotalSumPrice(), "B商品营销小计错误");
            Assert.assertEquals(totalPriceB, confirmApiPlainResultB.getData().getTotalRealPrice(), "B商品营销金额错误");
            Assert.assertEquals(Long.valueOf(128800), Long.valueOf(confirmApiPlainResultB.getData().getTotalPrice()));
            Assert.assertEquals(totalDiscountPriceB, confirmApiPlainResultB.getData().getTotalDiscountPrice(), "B商品总优惠价格计算错误");

            //失效活动
            expireDiscountActivity(discountActivityId);

        } catch (Exception e) {
        } finally {
            //删除配置的打折活动数据
            deleteActivityConfigData(discountActivityId);
        }

    }


    /**
     * 仅打折活动场景->打折活动参与验证
     * <p>
     * 配置A商品打折，B商品打折
     * 验证购买A+B商品,优惠分别为A与B对应的折扣
     * 打折金额计算正确
     */
    @Test
    public void testABTogetherDiscountActivity() {
        String discountActivityId = "";
//        ConfirmOrderForm confirmOrderFormTempA = SerializationUtils.clone(this.confirmOrderForm);
        ConfirmOrderForm confirmOrderFormTemp = SerializationUtils.clone(this.confirmOrderForm);

        try {
            //1.创建阶梯打折活动
            //创建打折活动
            PlainResult<SaveGoodsDiscountActivityResponse> saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveABGoodsDiscountActivityRequest);
            if (saveDiscountActivityResult.getCode() == 703) {
                //706,活动参与限制配置请求参数非法
                //打折活动已创建，则失效掉
                //http://biz.qa.s.qima-inc.com/#/market/tools/discount/copy/13729
                PageQueryActivityRequest pageQueryActivityRequest = new PageQueryActivityRequest();
                pageQueryActivityRequest.setKeyword("打折活动-阶梯-A+B型");
                PlainResult<PageResponse<ActivityBaseDTO>> queryResult = goodsDicountActivityuRemoteService.pageQueryActivityList(pageQueryActivityRequest);
                for (int i = 0; i < queryResult.getData().getItems().size(); i++) {
                    expireDiscountActivity(queryResult.getData().getItems().get(i).getActivityId());
                }
                saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveABGoodsDiscountActivityRequest);
            }
            discountActivityId = saveDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId();

            //21:满减活动，22:券资产，23:打折活动
            //设置打折活动

            confirmOrderFormTemp.getItems().get(0).getItemPromotionList().set(0, generatePreferential(discountActivityId, (byte) 23));
            //A商品的itemId与配置文件一样
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            orderItemForms.add(confirmOrderFormTemp.getItems().get(0));
            //B的itemId需要改

            OrderItemForm orderItemFormsB = SerializationUtils.clone(confirmOrderFormTemp.getItems().get(0));
            orderItemFormsB.setItemId(74198);
            orderItemForms.add(orderItemFormsB);

            confirmOrderFormTemp.setItems(orderItemForms);

            PlainResult<OrderConfirmApi> confirmApiPlainResultAB = orderRemoteService.confirmOrder(confirmOrderFormTemp);

            Long totalSumPriceA = Long.valueOf((long) (128800 * 0.88 + 128800 * 0.78));
            Long totalPriceA = Long.valueOf((long) (128800 * 0.88 + 128800 * 0.78));
            Long totalDiscountPriceA = Long.valueOf((long) (128800 * 0.12 + 128800 * 0.22));
            Assert.assertEquals(totalSumPriceA, confirmApiPlainResultAB.getData().getTotalSumPrice(), "A+B商品营销小计错误");
            Assert.assertEquals(totalPriceA, confirmApiPlainResultAB.getData().getTotalRealPrice(), "A+B商品营销金额错误");
            Assert.assertEquals(Long.valueOf(128800 * 2), Long.valueOf(confirmApiPlainResultAB.getData().getTotalPrice()));
            Assert.assertEquals(totalDiscountPriceA, confirmApiPlainResultAB.getData().getTotalDiscountPrice(), "A+B商品总优惠价格计算错误");

            //失效活动
            expireDiscountActivity(discountActivityId);

        } catch (Exception e) {
        } finally {
            //删除配置的打折活动数据
            deleteActivityConfigData(discountActivityId);
        }

    }


    @Test(enabled = false)
    public void test() {
        List<String> s = Arrays.asList("13747", "13744");
        for (String discountActivityId : s) {
            deleteActivityConfigData(discountActivityId);

        }

    }

}
