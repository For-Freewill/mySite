package com.youzan.test.apicase.bizConsole;

import com.alibaba.fastjson.JSONObject;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by baoyan on 6/4/21.
 */
public class AppServicePeriodTest extends YunBaseTest {
    @Http("bizConsole")
    HttpUtil httpUtil;

    @Test
    public void AppServicePeriodNormalTest(){
        String result = httpUtil.doGetReturnResponse("/order/appServicePeriod?kdtId=60005458&appId=873");
        JSONObject resultAfterParse = JSONObject.parseObject(result);
        Assert.assertEquals(resultAfterParse.getString("msg"),"操作成功");
        Assert.assertEquals(resultAfterParse.getString("code"),"0");
        Map dataValue = getMap(resultAfterParse.getString("data"));
        Assert.assertEquals(dataValue.get("expireTime"),"2022-06-04T15:26:52.000+0800");
    }

    public  Map<String, Object> getMap(String json) {
        JSONObject jsonObject = JSONObject.parseObject(json);
        Map<String, Object> valueMap = new HashMap<String, Object>();
        valueMap.putAll(jsonObject);
        return valueMap;
    }
}
