package com.youzan.test.checkTest.marketActivty;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.bitcomparecommon.aop.CompareConfig;
import com.youzan.bitcomparecommon.aop.CompareUtil;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCoupon;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponRule;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.api.PresentRemoteService;
import com.youzan.ycm.market.dto.condition.ItemBuyerMeetTagConditionDTO;
//import com.youzan.ycm.market.dto.present.MultipleRulePresentPromotionDTO;
import com.youzan.ycm.market.request.present.SavePresentPromotionRequest;
import com.youzan.ycm.market.response.present.SavePresentPromotionResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/8/19 3:10 PM
 */
public class CreatePresentActivity extends DeductBaseTest {

    @Dubbo
    public PresentRemoteService presentRemoteService;

    @JSONData(value = "dataResource/check/savePresentPromotionRequest.json",key = "savePresentPromotionRequest")
    public SavePresentPromotionRequest savePresentPromotionRequest;

    @Test(threadPoolSize = 1, invocationCount = 1,dataProvider = "buyerTag",enabled = false)
    public void createPresentActivityWithBuyerTag(String buyerTag) {
        ItemBuyerMeetTagConditionDTO itemBuyerMeetTagConditionDTO = savePresentPromotionRequest.getPresentPromotionDTO().getPresentRuleDTOList().get(0).getItemBuyerMeetTagConditionDTO();
        List<String> buyerTags = Arrays.asList(buyerTag);
        itemBuyerMeetTagConditionDTO.setBuyerTags(buyerTags);
        //Long kdtId = 61049501L;


        JSONArray result = compareServiceImp.invoke(() -> createAndCheckPresent(savePresentPromotionRequest));
       // PlainResult<SavePresentPromotionResponse> result = compareServiceImp.invoke(() -> presentRemoteService.saveItemPresentPromotion(savePresentPromotionRequest));

        logger.info("校验结果"+JSON.toJSONString(result));
    }

    @Test(threadPoolSize = 1, invocationCount = 1,dataProvider = "buyerTag",enabled = false)
    public void createPresentActivityWithBuyerTag1(String buyerTag) {
        ItemBuyerMeetTagConditionDTO itemBuyerMeetTagConditionDTO = savePresentPromotionRequest.getPresentPromotionDTO().getPresentRuleDTOList().get(0).getItemBuyerMeetTagConditionDTO();
        List<String> buyerTags = Arrays.asList(buyerTag);
        itemBuyerMeetTagConditionDTO.setBuyerTags(buyerTags);
        //Long kdtId = 61049501L;


        JSONArray result = compareServiceImp.invoke(() -> createAndCheckPresent(savePresentPromotionRequest));
        // PlainResult<SavePresentPromotionResponse> result = compareServiceImp.invoke(() -> presentRemoteService.saveItemPresentPromotion(savePresentPromotionRequest));

        logger.info("校验结果"+JSON.toJSONString(result));
    }

    @DataProvider
    public Object[][] buyerTag() {
        return new Object[][]{
                {"FIRST"},//新购
//                {"RENEW"},//复购
//                {"NOT_LIMIT"},//不限
        };
    }

    public JSONArray buildConditions(Long promotionId, String type ) {
        if(type == "activity"){
            MkActivity mkActivity = activityMapper.selectOne(new QueryWrapper<MkActivity>().eq("id",promotionId));

            List<MkActivityRule> mkActivityRuleList = activityRuleMapper.selectList(new QueryWrapper<MkActivityRule>().eq("activity_id",promotionId));

            JSONArray mkActivityConditions = JSONArray.parseArray(mkActivity.getConditions());
            JSONArray conditions = new JSONArray();

            conditions.add("以下是公共condition");
            for(int i =0;i< mkActivityConditions.size();i++) {
                conditions.add(mkActivityConditions.getJSONObject(i));
            }
            for(MkActivityRule mkActivityRule:mkActivityRuleList) {
                conditions.add("以下是rule的condition");
                JSONArray mkActivityRuleConditions = JSONArray.parseArray(mkActivityRule.getConditions());
                JSONArray mkActivityRuleActions =JSONArray.parseArray(mkActivityRule.getActions());
                for(int j =0;j< mkActivityRuleConditions.size();j++) {
                    conditions.add(mkActivityRuleConditions.getJSONObject(j));
                }
                conditions.add("以下是action");
                for(int k =0;k< mkActivityRuleActions.size();k++) {
                    conditions.add(mkActivityRuleActions.getJSONObject(k));
                }
            }
            logger.info(JSON.toJSONString(conditions));
            return conditions;
        } else if(type == "coupon") {
            MkCoupon mkCoupon = couponMapper.selectOne(new QueryWrapper<MkCoupon>().eq("id",promotionId));

            List<MkCouponRule> mkCouponRuleList = couponRuleMapper.selectList(new QueryWrapper<MkCouponRule>().eq("coupon_id",promotionId));

            JSONArray mkCouponConditions = JSONArray.parseArray(mkCoupon.getConditions());
            JSONArray conditions = new JSONArray();
            conditions.add("以下是公共condition");
            for(int i =0;i< mkCouponConditions.size();i++) {
                conditions.add(mkCouponConditions.getJSONObject(i));
            }

//            for(int j =0;j< mkCouponRuleConditions.size();j++) {
//                conditions.add(mkCouponRuleConditions.getJSONObject(j));
//            }
            for(MkCouponRule mkCouponRule:mkCouponRuleList) {
                conditions.add("以下是rule的condition");
                JSONArray mkCouponRuleConditions = JSONArray.parseArray(mkCouponRule.getConditions());
                JSONArray mkCouponRuleActions =JSONArray.parseArray(mkCouponRule.getActions());
                for(int j =0;j< mkCouponRuleConditions.size();j++) {
                    conditions.add(mkCouponRuleConditions.getJSONObject(j));
                }
                conditions.add("以下是action");
                for(int k =0;k< mkCouponRuleActions.size();k++) {
                    conditions.add(mkCouponRuleActions.getJSONObject(k));
                }
            }

            logger.info(JSON.toJSONString(conditions));
            return conditions;
        }else {
            return null;
        }
    }

    @Test(enabled = false)
    public void printConditions() {
        JSONArray conditionsBase = buildConditions(33147L,"coupon");
        JSONArray conditionsPrj = buildConditions(9456L,"coupon");
//        logger.info("基础环境："+JSON.toJSONString(conditionsBase));
//        logger.info("sc环境"+JSON.toJSONString(conditionsPrj));
        System.out.println(conditionsBase);
        System.out.println(conditionsPrj);
        CompareConfig compareConfig = new CompareConfig();
        CompareUtil.projectRequestCompare(conditionsBase, conditionsPrj, compareConfig);


    }



    public void deletePresentActivity(Long promotionId) {
        //1. 由promotionId 找到mk activity rule

        //2. 由mk activity rule 找到 present 数据
    }

    public JSONArray createAndCheckPresent(SavePresentPromotionRequest request) {
        logger.info("参数："+JSON.toJSONString(request));
        PlainResult<SavePresentPromotionResponse> savePresentPromotionResponse = presentRemoteService.saveItemPresentPromotion(savePresentPromotionRequest);
        logger.info("创建买赠活动结果："+JSON.toJSONString(savePresentPromotionResponse));
        JSONArray conditions = buildConditions(savePresentPromotionResponse.getData().getPresentPromotionId(),"activity");
        return conditions;
    }

}
