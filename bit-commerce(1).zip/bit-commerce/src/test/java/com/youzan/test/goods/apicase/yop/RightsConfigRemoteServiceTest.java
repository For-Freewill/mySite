package com.youzan.test.goods.apicase.yop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.cloudService.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.RightsConfigRemoteService;
import com.youzan.yop.api.entity.OpenAppLevelApi;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.right.OpenAppRightInfoApi;
import com.youzan.yop.api.entity.right.OpenAppRightsConfigApi;
import com.youzan.yop.api.form.RightsConfigForm;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @author wulei
 * @date 2021/12/9 15:12
 */
public class RightsConfigRemoteServiceTest extends YunBaseTest {
    @Dubbo
    private RightsConfigRemoteService rightsConfigRemoteService;

    @Test()
    public void getLevelsTest() {
        RightsConfigForm request = new RightsConfigForm();
        request.setAppId(873L);
        PlainResult<OpenAppRightInfoApi> result = rightsConfigRemoteService.queryRightsConfigInfo(request);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getHeadInfoList().size()==3, true);
        Assert.assertEquals(result.getData().getRightConfigList().size()==5, true);
    }

    @Test()
    public void queryRightsConfigListTest() {
        RightsConfigForm request = new RightsConfigForm();
        request.setAppId(873L);
        PlainResult<PageApi<OpenAppRightsConfigApi>> result = rightsConfigRemoteService.queryRightsConfigList(request);
        Assert.assertEquals(result.getCode(), 200);
    }

}
