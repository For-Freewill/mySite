package com.youzan.test.cloudService.apicase.yop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.status.OpenAppOrderStatusApi;
import com.youzan.yop.api.enums.AppStatusState;
import com.youzan.yop.api.form.status.SearchAppOrderStatusListForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2020/9/28 11:00
 * 分页查询服务期--服务中心/已购服务
 * @大爷
 */
public class ListOrderStateByStateAndPageTest extends YunBaseTest {
    public static Long wsc_qijian = 57313015L;
    public static String wsc_qijian_name = "微商城单店11111";

    public static Long wsc_null = 57507053L;
    public static String wsc_null_name = "微商城空店-自动化";
    @Dubbo
    public AppStatusRemoteService appStatusRemoteService;
    private Logger logger = LoggerFactory.getLogger(ListOrderStateByStateAndPageTest.class);

    /**
     * @desc 场景1：通过测试-微商城旗舰店
     */
    @Test
    public void listOrderStateByStateAndPageTestNormal() {
        PlainResult<PageApi<OpenAppOrderStatusApi>> result = appStatusRemoteService.listOrderStateByStateAndPage(form(wsc_qijian, AppStatusState.EFFECT));
        Assert.assertEquals(result.getCode(), 200);
        if (result.getData().getContent() != null) {
            Assert.assertEquals(result.getData().getContent().toString().contains("有伴服务"), true);
        }
    }

    /**
     * @desc 场景2：通过测试-未订购服务店铺
     */
    @Test
    public void listOrderStateByStateAndPageTest2() {
        PlainResult<PageApi<OpenAppOrderStatusApi>> result = appStatusRemoteService.listOrderStateByStateAndPage(form(wsc_null, AppStatusState.EFFECT));
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getTotalPages(), 0);
    }

    /**
     * @desc 场景3：kdtid为空，返回正常
     */
    @Test
    public void listOrderStateByStateAndPageTest3() {
        PlainResult<PageApi<OpenAppOrderStatusApi>> result = appStatusRemoteService.listOrderStateByStateAndPage(form(null, AppStatusState.EFFECT));
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getTotalPages(), 0);
    }

    /**
     * @desc 场景4：state为空，返回异常
     */
    @Test
    public void listOrderStateByStateAndPageTest4() {
        PlainResult<PageApi<OpenAppOrderStatusApi>> result = appStatusRemoteService.listOrderStateByStateAndPage(form(wsc_null, null));
        Assert.assertEquals(result.getCode(), 150005);
    }

    /**
     * 入参
     *
     * @param kdtId
     * @param state
     * @return
     */
    public SearchAppOrderStatusListForm form(Long kdtId, AppStatusState state) {
        SearchAppOrderStatusListForm searchAppOrderStatusListForm = new SearchAppOrderStatusListForm();
        searchAppOrderStatusListForm.setKdtId(kdtId);
        searchAppOrderStatusListForm.setState(state);
        searchAppOrderStatusListForm.setPageNum(1);
        searchAppOrderStatusListForm.setPageSize(20);
        return searchAppOrderStatusListForm;
    }
}
