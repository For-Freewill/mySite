package com.youzan.test.market.basecase.yzYunActivity;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.open.api.YcmCouponService;
import com.youzan.ycm.open.request.market.YcmSaveCouponRequest;
import com.youzan.ycm.open.request.market.YcmUpdateCouponRequest;
import com.youzan.ycm.open.response.market.YcmSaveCouponResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * @author wuwu
 * @date 2021/9/13 7:21 PM
 */
public class CreateYzYunCoupon extends DeductBaseTest {
    @Dubbo
    public YcmCouponService ycmCouponService;

    @JSONData(value = "/dataResource/basecase.activity/yzYunSaveCoupon.json",key = "saveCouponRequest")
    private YcmSaveCouponRequest saveCouponByAppidRequest;

    @JSONData(value = "/dataResource/basecase.activity/yzYunSaveCoupon.json",key = "saveCouponByCategoryRequest")
    private YcmSaveCouponRequest saveCouponByCategoryRequest;

    @JSONData(value = "/dataResource/basecase.activity/yzYunSaveCoupon.json",key = "saveCouponByItemIdRequest")
    private YcmSaveCouponRequest saveCouponByItemIdRequest;


    @JSONData(value = "/dataResource/basecase.activity/yzYunSaveCoupon.json",key = "ycmUpdateCouponRequest")
    private YcmUpdateCouponRequest ycmUpdateCouponRequest;

    @BeforeClass
    public void beforeClassTest() {
        saveCouponByAppidRequest.getAllCouponDTO().setExpireTime(new Date());
        saveCouponByAppidRequest.getAllCouponDTO().setEffectTime(getTomorrow());

        saveCouponByCategoryRequest.getAllCouponDTO().setEffectTime(new Date());
        saveCouponByCategoryRequest.getAllCouponDTO().setEffectTime(getTomorrow());

        saveCouponByItemIdRequest.getAllCouponDTO().setEffectTime(new Date());
        saveCouponByItemIdRequest.getAllCouponDTO().setEffectTime(getTomorrow());

    }

    /**
     * 创建有赞云满减券-按appid
     */
    @Test
    public void createYzYunCouponByAppIdTest() {
        String couponId = null;
        try {

            PlainResult<YcmSaveCouponResponse> result = ycmCouponService.saveCoupon(saveCouponByAppidRequest);
            logger.info(JSON.toJSONString(result));
            Assert.assertEquals(result.getCode(),200,result.getMessage());
            couponId = result.getData().getId();

            //更新券状态
//            YcmSaveCouponRequest ycmSaveCouponRequest = new YcmSaveCouponRequest();
//            AllCouponDTO allCouponDTO = new AllCouponDTO();
//            allCouponDTO.setCouponId(couponId);
//            allCouponDTO.setCouponState("ONLINE");
//            ycmSaveCouponRequest.setChannel("YZYUN_MARKET");
            ycmUpdateCouponRequest.setCouponId(couponId);
            ycmCouponService.updateCouponState(ycmUpdateCouponRequest);

            //券

        }finally {
            deleteCouponDataAll(Long.valueOf(couponId));
        }
    }

    /**
     * 创建有赞云满减券-按类目id
     */
    @Test
    public void createYzYunCouponByCategoryIdTest() {
        String couponId = null;
        try {

            PlainResult<YcmSaveCouponResponse> result = ycmCouponService.saveCoupon(saveCouponByCategoryRequest);
            logger.info(JSON.toJSONString(result));
            Assert.assertEquals(result.getCode(),200,result.getMessage());
            couponId = result.getData().getId();

        }finally {
            deleteCouponDataAll(Long.valueOf(couponId));
        }
    }

    /**
     * 创建有赞云满减券-按skuid
     */
    @Test
    public void createYzYunCouponByItemIdTest() {
        String couponId = null;
        try {

            PlainResult<YcmSaveCouponResponse> result = ycmCouponService.saveCoupon(saveCouponByItemIdRequest);
            logger.info(JSON.toJSONString(result));
            Assert.assertEquals(result.getCode(),200,result.getMessage());
            couponId = result.getData().getId();

        }finally {
            deleteCouponDataAll(Long.valueOf(couponId));
        }
    }
}
