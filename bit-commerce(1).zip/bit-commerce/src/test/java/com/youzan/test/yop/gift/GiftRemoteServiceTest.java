package com.youzan.test.yop.gift;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.yop.Gift;
import com.youzan.commerce.test.mapper.yop.OpenApplicationGiftMapper;
import com.youzan.commerce.test.mapper.yop.OpenApplicationStatusMapper;
import com.youzan.commerce.test.utils.DateUtil;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.test.yop.YopBaseTest;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.GiftRemoteService;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.gift.GiftAssetDTO;
import com.youzan.yop.api.entity.status.OpenAppOrderStatusApi;
import com.youzan.yop.api.enums.AppStatusState;
import com.youzan.yop.api.request.*;
import com.youzan.yop.api.response.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import static com.youzan.yop.api.enums.AppStatusState.EFFECT;
import static com.youzan.yop.api.enums.AppStatusState.EXPIRE_SOON;
import static org.awaitility.Awaitility.with;
import static org.hamcrest.Matchers.equalTo;

/**
 * created by leifeiyun on 2019/7/29
 **/
public class GiftRemoteServiceTest extends YopBaseTest {
    Logger logger = LoggerFactory.getLogger(GiftRemoteServiceTest.class);

    @Dubbo
    GiftRemoteService giftRemoteService;
    @Dubbo
    MarketRemoteService marketRemoteService;
    @Dubbo
    AppStatusRemoteService appStatusRemoteService;
    @Dubbo
    PromotionRemoteService promotionRemoteService;

    @Autowired(required = false)
    OpenApplicationGiftMapper openApplicationGiftMapper;

    @Autowired(required = false)
    OpenApplicationStatusMapper openApplicationStatusMapper;

    /**
     * 1.创建周期型礼包
     * 2.查询礼包详情
     * 3.创建后的对象与创建前的参数对象进行比较
     * 4.编辑周期型礼包,编辑后的对象与编辑前的参数对象进行比较，编辑后返回的对象与入参对象保持一致
     * 5.发送礼包
     * 6.查询礼包资产id
     * 7.验证礼包状态为待领取
     * 8.领取礼包
     * 9.礼包状态为已领取
     * 10.检验领取后，店铺服务期
     * 11.回收礼包
     * 12.礼包状态为已回收
     * 13.验证在生效状态的应用为0
     * <p>
     * 礼包领取状态, 0：未领取，1：已领取，2：已过期 3 未开始 4已回收
     */
    @Test
    public void test_cyclePluginGift() {
        String createGiftRequestDataFilePath = "src/test/resources/data/gift/CreateGiftRequestData.json";
        CreateGiftRequest createGiftRequest = JsonCovertUntil.getObjectFromjson(createGiftRequestDataFilePath, CreateGiftRequest.class);

        String editGiftRequestDataFilePath = "src/test/resources/data/gift/EditGiftRequestData.json";
        EditGiftRequest editGiftRequest = JsonCovertUntil.getObjectFromjson(editGiftRequestDataFilePath, EditGiftRequest.class);
        int giftId = 0;
        try {
            //1.创建周期型礼包
            PlainResult<CreateGiftResponse> giftResponsePlainResult = giftRemoteService.createGift(createGiftRequest);
            giftId = giftResponsePlainResult.getData().getId();

            //2.查询礼包详情
            QueryGiftDetailRequest queryGiftDetailRequest = new QueryGiftDetailRequest();
            queryGiftDetailRequest.setId(Long.valueOf(giftId));
            PlainResult<QueryGiftDetailResponse> giftDetailResponsePlainResult = giftRemoteService.queryGiftDetail(queryGiftDetailRequest);

            //
            Assert.assertEquals(giftDetailResponsePlainResult.getData().getGiftDTO().getGiftItemDTOS(), createGiftRequest.getGiftDTO().getGiftItemDTOS(), "创建礼包后的对象与创建前的参数对象不一致");

            //4.编辑周期型礼包
            editGiftRequest.getGiftDTO().setId(giftId);
            PlainResult<EditGiftResponse> editGiftResponsePlainResult = giftRemoteService.editGift(editGiftRequest);
            //编辑后的对象与编辑前的参数对象进行比较，编辑后返回的对象与入参对象保持一致
//            Assert.assertEquals(editGiftResponsePlainResult.getData().getGiftDTO().getGiftItemDTOS(), editGiftRequest.getGiftDTO().getGiftItemDTOS());
//            Assert.assertEquals(editGiftResponsePlainResult.getData().getGiftDTO().getPrice(),editGiftRequest.getGiftDTO().getPrice());
            //5.发送礼包
            SendGiftRequest sendGiftRequest = new SendGiftRequest();
            sendGiftRequest.setGiftIds(Arrays.asList(Long.valueOf(giftId)));
            sendGiftRequest.setKdtIds(Arrays.asList(Long.valueOf(giftKdtId)));
            sendGiftRequest.setSendKdtType((byte) 1);
            sendGiftRequest.setOperatorName("leifeiyun");
            sendGiftRequest.setReceiveType((byte) 1);//手动领取
            sendGiftRequest.setSendReason("MAKE_UP");
            sendGiftRequest.setReceivePeriod(Long.valueOf(7));

            PlainResult<SendGiftResponse> sendGiftResponsePlainResult = giftRemoteService.sendGift(sendGiftRequest);


            //6.查询礼包资产id
            Gift giftAsset = openApplicationGiftMapper.selectOne(new QueryWrapper<Gift>().eq("kdt_id", giftKdtId).orderByDesc("create_time").last("limit 1"));

            //发送成功的礼包资产id即为生成的礼包id
            Assert.assertEquals(sendGiftResponsePlainResult.getData().getGiftAssetIds().get(0).intValue(), giftAsset.getId().intValue());

            //7.验证礼包状态为待领取
            PageQueryGiftAssetRequest pageQueryGiftAssetRequest = new PageQueryGiftAssetRequest();
            pageQueryGiftAssetRequest.setKdtKeywords(String.valueOf(giftKdtId));
            PlainResult<PageApi<GiftAssetDTO>> pageApiPlainResult = giftRemoteService.pageQueryGiftAsset(pageQueryGiftAssetRequest);
            //礼包状态为待领取
            Assert.assertEquals(pageApiPlainResult.getData().getContent().get(0).getState().intValue(), 0);
            Assert.assertEquals(sendGiftResponsePlainResult.getCode(), 200);


            //8.领取礼包
            PlainResult<Boolean> receiveResult = promotionRemoteService.receiveGift(giftKdtId, Long.valueOf(pageApiPlainResult.getData().getContent().get(0).getGiftAssetId()));
            Assert.assertTrue(receiveResult.getData().booleanValue());

            pageQueryGiftAssetRequest = new PageQueryGiftAssetRequest();
            pageQueryGiftAssetRequest.setKdtKeywords(String.valueOf(giftKdtId));
            pageApiPlainResult = giftRemoteService.pageQueryGiftAsset(pageQueryGiftAssetRequest);

            //9.礼包状态为已领取
            Assert.assertEquals(pageApiPlainResult.getData().getContent().get(0).getState().intValue(), 1);
            Assert.assertEquals(receiveResult.getCode(), 200);

            //10.检验领取后，店铺服务期

            PlainResult<PageApi<OpenAppOrderStatusApi>> orderStateResult = appStatusRemoteService.listOrderStateByStateAndPage(ConstructionParam.getSearchParam(giftKdtId, EXPIRE_SOON));
            Assert.assertNotNull(orderStateResult.getData().getContent());
            for (int i = 0; i < orderStateResult.getData().getContent().size(); i++) {
                PlainResult<PageApi<OpenAppOrderStatusApi>> finalOrderStateResult = orderStateResult;
                int finalI = i;

                with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                        () -> finalOrderStateResult.getData().getContent().get(finalI).getState() == EXPIRE_SOON);

                //验证服务期往后+2天，因为发了2天的礼包
                with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                        new Callable<Boolean>() {
                            @Override
                            public Boolean call() {
                                return DateUtil.compareDate(finalOrderStateResult.getData().getContent().get(finalI).getEffectTime(),
                                        finalOrderStateResult.getData().getContent().get(finalI).getExpireTime(),
                                        Calendar.DATE, 2);
                            }
                        }, equalTo(true));
            }
            Assert.assertEquals(orderStateResult.getCode(), 200);
            Assert.assertEquals(orderStateResult.getMessage(), "successful");

            //11.回收礼包
            RecycleGiftRequest recycleGiftRequest = new RecycleGiftRequest();
            recycleGiftRequest.setGiftId(Long.valueOf(pageApiPlainResult.getData().getContent().get(0).getGiftAssetId()));
            recycleGiftRequest.setRemark("自动化测试回收");
            PlainResult<RecycleGiftResponse> recycleGiftResponsePlainResult = giftRemoteService.recycleGiftAsset(recycleGiftRequest);

            pageQueryGiftAssetRequest = new PageQueryGiftAssetRequest();
            pageQueryGiftAssetRequest.setKdtKeywords(String.valueOf(giftKdtId));
            pageApiPlainResult = giftRemoteService.pageQueryGiftAsset(pageQueryGiftAssetRequest);
            //12.礼包状态为已回收
            Assert.assertEquals(pageApiPlainResult.getData().getContent().get(0).getState().intValue(), 4);
            Assert.assertEquals(recycleGiftResponsePlainResult.getCode(), 200);

            //13.验证在生效状态的应用为0
            orderStateResult = appStatusRemoteService.listOrderStateByStateAndPage(ConstructionParam.getSearchParam(giftKdtId, EFFECT));
            Assert.assertTrue(orderStateResult.getData().getContent() == null);

        } /*catch (Exception e) {
            //catch块只在调试的时候用，job上不用
            logger.info("----------->"+e.getMessage());
        } */ finally {
            //获取参数中的所有appId；
            int giftItemDtoLength = createGiftRequest.getGiftDTO().getGiftItemDTOS().size();
            int count = 0;
            List appIds = new ArrayList(10);

            for (int i = 0; i < giftItemDtoLength; i++) {
                appIds.add(createGiftRequest.getGiftDTO().getGiftItemDTOS().get(count).getAppId());
            }
            //删除本次用例产生是的所有数据
            deleteGiftOrderInfo(giftKdtId, giftId, appIds);
        }

    }


    /**
     * 先发送云pos1年，再增购
     */
    @Test
    public void test_staffGift() {
        Integer staffYearGiftId = null;
        Integer staffDayGiftId = null;
        try {
            //创建店铺员工1年期礼包

            String createGiftYearDataFilePath = "src/test/resources/data/gift/createGiftStaffYear.json";
            CreateGiftRequest createGiftStaffYear = JsonCovertUntil.getObjectFromjson(createGiftYearDataFilePath, CreateGiftRequest.class);

            PlainResult<CreateGiftResponse> giftResponsePlainResult = giftRemoteService.createGift(createGiftStaffYear);
            staffYearGiftId = giftResponsePlainResult.getData().getId();

            //创建店铺员工【增购礼包】
            String createGiftDayDataFilePath = "src/test/resources/data/gift/createGiftStaffDay.json";
            CreateGiftRequest createGiftStaffDay = JsonCovertUntil.getObjectFromjson(createGiftDayDataFilePath, CreateGiftRequest.class);

            giftResponsePlainResult = giftRemoteService.createGift(createGiftStaffDay);
            staffDayGiftId = giftResponsePlainResult.getData().getId();


            //发送云pos一年期礼包
            SendGiftRequest sendYearGiftRequest = new SendGiftRequest();
            sendYearGiftRequest.setGiftIds(Arrays.asList(Long.valueOf(staffYearGiftId)));
            sendYearGiftRequest.setKdtIds(Arrays.asList(Long.valueOf(giftKdtId)));
            sendYearGiftRequest.setSendKdtType((byte) 1);
            sendYearGiftRequest.setOperatorName("leifeiyun");
            sendYearGiftRequest.setReceiveType((byte) 0);//自动领取
            sendYearGiftRequest.setSendReason("MAKE_UP");
            sendYearGiftRequest.setReceivePeriod(Long.valueOf(7));

            PlainResult<SendGiftResponse> sendGiftResponsePlainResult = giftRemoteService.sendGift(sendYearGiftRequest);

            //查询礼包资产id
            Gift giftAsset = openApplicationGiftMapper.selectOne(new QueryWrapper<Gift>().eq("kdt_id", giftKdtId).orderByDesc("create_time").last("limit 1"));

            //发送成功的礼包资产id即为生成的礼包id
            Assert.assertEquals(sendGiftResponsePlainResult.getData().getGiftAssetIds().get(0).intValue(), giftAsset.getId().intValue());


            PlainResult<PageApi<OpenAppOrderStatusApi>> orderStateResult = appStatusRemoteService.listOrderStateByStateAndPage(ConstructionParam.getSearchParam(giftKdtId, AppStatusState.EFFECT));
            Assert.assertNotNull(orderStateResult.getData().getContent());
            for (int i = 0; i < orderStateResult.getData().getContent().size(); i++) {
                PlainResult<PageApi<OpenAppOrderStatusApi>> finalOrderStateResult = orderStateResult;
                int finalI = i;

                with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                        () -> finalOrderStateResult.getData().getContent().get(finalI).getState() == AppStatusState.EFFECT);


                //验证服务期往后挪一年
                with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                        new Callable<Boolean>() {
                            @Override
                            public Boolean call() {
                                return DateUtil.compareDate(finalOrderStateResult.getData().getContent().get(finalI).getEffectTime(),
                                        finalOrderStateResult.getData().getContent().get(finalI).getExpireTime(),
                                        Calendar.YEAR, 1);
                            }
                        }, equalTo(true));
            }
            Assert.assertEquals(orderStateResult.getCode(), 200);
            Assert.assertEquals(orderStateResult.getMessage(), "successful");

            //验证员工个数
            Assert.assertEquals(getCycleStockCount(giftKdtId, 31458).intValue(), 2);


            //发送增购礼包
            //发送店铺员工
            SendGiftRequest sendDayGiftRequest = new SendGiftRequest();
            sendDayGiftRequest.setGiftIds(Arrays.asList(Long.valueOf(staffDayGiftId)));
            sendDayGiftRequest.setKdtIds(Arrays.asList(Long.valueOf(giftKdtId)));
            sendDayGiftRequest.setSendKdtType((byte) 1);
            sendDayGiftRequest.setOperatorName("leifeiyun");
            sendDayGiftRequest.setReceiveType((byte) 0);//自动领取
            sendDayGiftRequest.setSendReason("MAKE_UP");
            sendDayGiftRequest.setReceivePeriod(Long.valueOf(7));

            sendGiftResponsePlainResult = giftRemoteService.sendGift(sendDayGiftRequest);

            //查询礼包资产id
            giftAsset = openApplicationGiftMapper.selectOne(new QueryWrapper<Gift>()
                    .eq("kdt_id", giftKdtId)
                    .orderByDesc("create_time")
                    .last("limit 1"));

            //发送成功的礼包资产id即为生成的礼包id
            Assert.assertEquals(sendGiftResponsePlainResult.getData().getGiftAssetIds().get(0).intValue(), giftAsset.getId().intValue());


            orderStateResult = appStatusRemoteService.listOrderStateByStateAndPage(ConstructionParam.getSearchParam(giftKdtId, AppStatusState.EFFECT));
            Assert.assertNotNull(orderStateResult.getData().getContent());
            for (int i = 0; i < orderStateResult.getData().getContent().size(); i++) {
                PlainResult<PageApi<OpenAppOrderStatusApi>> finalOrderStateResult = orderStateResult;
                int finalI = i;
                //验证服务期往后挪一年
                with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                        new Callable<Boolean>() {
                            @Override
                            public Boolean call() {
                                return DateUtil.compareDate(finalOrderStateResult.getData().getContent().get(finalI).getEffectTime(),
                                        finalOrderStateResult.getData().getContent().get(finalI).getExpireTime(),
                                        Calendar.YEAR, 1);
                            }
                        }, equalTo(true));
            }


            Assert.assertEquals(orderStateResult.getCode(), 200);
            Assert.assertEquals(orderStateResult.getMessage(), "successful");

            //验证员工个数[增购后]

            with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                    () -> getCycleStockCount(giftKdtId, 31458).intValue() == 2 + 3);


        } finally {
            //回收两个礼包
            RecycleGiftRequest recycleGiftRequest = null;
            PageQueryGiftAssetRequest pageQueryGiftAssetRequest = new PageQueryGiftAssetRequest();
            PlainResult<RecycleGiftResponse> recycleGiftResponsePlainResult = null;
            pageQueryGiftAssetRequest.setKdtKeywords(String.valueOf(giftKdtId));
            PlainResult<PageApi<GiftAssetDTO>> pageApiPlainResult = giftRemoteService.pageQueryGiftAsset(pageQueryGiftAssetRequest);

            List<GiftAssetDTO> giftAssetDTOS = pageApiPlainResult.getData().getContent();
            for (int i = 0; i < 2; i++) {
                recycleGiftRequest = new RecycleGiftRequest();
                recycleGiftRequest.setGiftId(Long.valueOf(giftAssetDTOS.get(i).getGiftAssetId()));
                recycleGiftRequest.setRemark("自动化测试回收");
                recycleGiftResponsePlainResult = giftRemoteService.recycleGiftAsset(recycleGiftRequest);
                //12.礼包状态为已回收
//                Assert.assertEquals(pageApiPlainResult.getData().getContent().get(i).getState().intValue(), 4);

                int finalI = i;
                PlainResult<PageApi<GiftAssetDTO>> finalPageApiPlainResult = giftRemoteService.pageQueryGiftAsset(pageQueryGiftAssetRequest);
                with().pollInterval(100, TimeUnit.MILLISECONDS).and().with().pollDelay(10, TimeUnit.MILLISECONDS).until(
                        () -> finalPageApiPlainResult.getData().getContent().get(finalI).getState().intValue() == 4);


                Assert.assertEquals(recycleGiftResponsePlainResult.getCode(), 200);
            }


            //删除本次用例产生是的所有数据
            deleteGiftOrderInfo(giftKdtId, staffYearGiftId, Arrays.asList(31458));
            deleteGiftOrderInfo(giftKdtId, staffDayGiftId, Arrays.asList(31458));
        }

    }

}
