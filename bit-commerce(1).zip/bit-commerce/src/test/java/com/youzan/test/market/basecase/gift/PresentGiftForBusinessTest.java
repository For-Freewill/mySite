package com.youzan.test.market.basecase.gift;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplate;
import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateMapper;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.gift.api.GiftAssetRemoteService;
import com.youzan.ycm.gift.dto.GiftAssetDTO;
import com.youzan.ycm.gift.request.*;
import com.youzan.ycm.gift.response.*;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author tianning
 * @date 2021/1/14 5:19 下午
 * 礼包四部曲：
 * 商家订购后发放买赠礼包接口
 * 创建礼包模板：com.youzan.ycm.gift.api.GiftTemplateRemoteService#saveGiftTemplate
 * 发放并领取买赠礼包资产（有个中间状态，先create 然后再commit）
 * com.youzan.ycm.gift.api.GiftAssetRemoteService#createGiftAssetBatch
 * com.youzan.ycm.gift.api.GiftAssetRemoteService#batchCommitGiftAsset
 * 回收礼包：com.youzan.ycm.gift.api.GiftAssetRemoteService#recycleGiftAsset
 */

public class PresentGiftForBusinessTest extends TnBaseTest {
    @Dubbo
    GiftAssetRemoteService giftAssetRemoteService;

    @Autowired(required = false)
    public GfTemplateGoodsMapper gfTemplateGoodsMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gAssetGoodsMapper;

    @JSONData(value = "dataResource/basecase.gift/CreatePresentGiftRequestData.json", key = "createPresentGiftTemplateRequest")
    private SaveGiftTemplateRequest createPresentGiftTemplateRequest;
    
    /**
     * 创建礼包模板
     * 发放并领取买赠礼包或试用期礼包资产（有个中间状态，先create 然后再commit）
     * 回收礼包资产
     */
    @Test
    public void presentGiftTest() {
        Long template_id = null;

        try {
            //1. 创建礼包模板
            PlainResult<SaveGiftTemplateResponse> createGiftAssetResult = createGiftTemplete(createPresentGiftTemplateRequest);

            template_id = createGiftAssetResult.getData().getGiftTemplateDTO().getTemplateId();

            List<GiftTemplate> giftTemplateList =
                    gfTemplateMapper.selectList(
                            new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getId, template_id).orderByDesc(GiftTemplate::getCreated_at));

            Assert.assertTrue(CollectionUtils.isNotEmpty(giftTemplateList));

            GenerateAssetRequest request = new GenerateAssetRequest();
            request.setGiftTemplateId(template_id);
            request.setGiftTemplateIdStr(template_id.toString());
            request.setYcmId("59136383");
            request.setYcmIdType("KDT_ID");

            PlainResult<GenerateAssetResponse> generateAssetResult = giftTemplateRemoteService.generateAsset(request);


            List<GiftAssetDTO> giftAssetDTOList = new ArrayList<>();
            GiftAssetDTO giftAssetDTO = generateAssetResult.getData().getGiftAssetDTO();
            giftAssetDTO.setOriginType("PRESENT");
            giftAssetDTO.setBizId("23201910151018352108010");
            giftAssetDTO.setBizType("YCM_TRADE_NO");
            giftAssetDTOList.add(generateAssetResult.getData().getGiftAssetDTO());

            CreateGiftAssetBatchRequest createGiftAssetBatchRequest = new CreateGiftAssetBatchRequest();
            createGiftAssetBatchRequest.setGiftAssetDTOList(giftAssetDTOList);

            //发放买赠礼包（批量发放，为了性能问题）
            PlainResult<CreateGiftAssetBatchResponse> createGiftAssetBatchResult = giftAssetRemoteService.createGiftAssetBatch(createGiftAssetBatchRequest);
            Assert.assertEquals(createGiftAssetBatchResult.getCode(), 200);

            List<GiftAsset> giftAssetList =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, template_id).orderByDesc(GiftAsset::getCreatedAt));

            Assert.assertTrue(CollectionUtils.isNotEmpty(giftAssetList));
            giftAssetList.forEach(item -> {
                Assert.assertEquals(item.getState(), "CREATED");
                Assert.assertEquals(item.getType(), "PRESENT_GIFT");
            });

            BatchCommitGiftAssetRequest batchCommitGiftAssetRequest = new BatchCommitGiftAssetRequest();

            List<String> giftAssetIds = new ArrayList<>();
            giftAssetIds.add(giftAssetList.get(0).getId().toString());
            batchCommitGiftAssetRequest.setGiftAssetIds(giftAssetIds);
            batchCommitGiftAssetRequest.setState("RECEIVED");
            batchCommitGiftAssetRequest.setBeginTime("2020-11-16 19:50:09");
            batchCommitGiftAssetRequest.setEndTime("2024-11-16 19:50:09");
            //批量提交礼包，更改状态（交易流程提交订单后）
            PlainResult<BatchCommitGiftAssetResponse> batchCommitGiftAssetResult = giftAssetRemoteService.batchCommitGiftAsset(batchCommitGiftAssetRequest);
            Assert.assertEquals(batchCommitGiftAssetResult.getCode(), 200);

            template_id = batchCommitGiftAssetResult.getData().getGiftAssetSimpleDTOS().get(0).getTemplateId();
            List<GiftAsset> giftAssetListCommit =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, template_id).orderByDesc(GiftAsset::getCreatedAt));

            Assert.assertTrue(CollectionUtils.isNotEmpty(giftAssetListCommit));
            giftAssetListCommit.forEach(itemCommit -> {
                Assert.assertEquals(itemCommit.getState(), "RECEIVED");
                Assert.assertEquals(itemCommit.getType(), "PRESENT_GIFT");
            });

            //回收有效的礼包资产
            RecycleGiftAssetRequest recycleGiftAssetRequest = new RecycleGiftAssetRequest();
            recycleGiftAssetRequest.setGiftAssetId(batchCommitGiftAssetResult.getData().getGiftAssetSimpleDTOS().get(0).getId());
            recycleGiftAssetRequest.setGiftAssetIdStr(batchCommitGiftAssetResult.getData().getGiftAssetSimpleDTOS().get(0).getId().toString());
            recycleGiftAssetRequest.setIgnoreRecycled(false);
            recycleGiftAssetRequest.setType("PRESENT_GIFT");
            recycleGiftAssetRequest.setRemark("");
            PlainResult<RecycleGiftAssetResponse> recycleGiftAssetResult = giftAssetRemoteService.recycleGiftAsset(recycleGiftAssetRequest);
            Assert.assertEquals(recycleGiftAssetResult.getCode(), 200);

            template_id = recycleGiftAssetResult.getData().getGiftAssetDTO().getTemplateId();
            List<GiftAsset> giftAssetListRecycle =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, template_id).orderByDesc(GiftAsset::getCreatedAt));

            Assert.assertTrue(CollectionUtils.isNotEmpty(giftAssetListRecycle));
            giftAssetListRecycle.forEach(itemRecycle -> {
                Assert.assertEquals(itemRecycle.getState(), "RECYCLED");
                Assert.assertEquals(itemRecycle.getType(), "PRESENT_GIFT");
            });
        } finally {
            deleteTemplateData();
        }
    }
}
