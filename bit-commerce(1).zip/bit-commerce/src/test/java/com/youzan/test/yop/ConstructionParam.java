package com.youzan.test.yop;

import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.entity.OfflineOrderForm;
import com.youzan.yop.api.entity.OpenActivationCodeApplyApi;
import com.youzan.yop.api.entity.OpenActivationCodeCheckApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.enums.AppStatusState;
import com.youzan.yop.api.form.order.*;
import com.youzan.yop.api.form.status.QueryAppStatusListForm;
import com.youzan.yop.api.form.status.SearchAppOrderStatusListForm;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 * created by leifeiyun on 2018/9/6
 **/
@Component
public class ConstructionParam extends YopBaseTest {
    @Dubbo
    public static OrderRemoteService orderRemoteService;

    public static SearchAppOrderStatusListForm getSearchParam(Long kdtId, AppStatusState state) {

        SearchAppOrderStatusListForm searchParam = new SearchAppOrderStatusListForm();
        searchParam.setKdtId(kdtId);
        searchParam.setState(state);
        searchParam.setPageNum(1);
        searchParam.setPageSize(10);
        return searchParam;
    }

    /**
     * 封装创建订单的数据，因为每个用例需要的数据可能不一样，所以就不在base方法里面进行封装
     * @return
     */

    /**
     * 创建订单参数构造
     *
     * @param kdtId
     * @param kdtName
     * @param items
     * @param yzCoin
     * @return
     */

    public static CreateOrderForm getCreateOrderWithParam(Long kdtId, String kdtName, List<OrderItemForm> items, Long yzCoin) {
        CreateOrderForm createOrderForm = new CreateOrderForm();
        createOrderForm.setItems(items);
        createOrderForm.setKdtId(kdtId);
        createOrderForm.setUserId(userId);
        createOrderForm.setYzbPrice(yzCoin);
        createOrderForm.setKdtName(kdtName);
//        createOrderForm.setInviteCode(inviteCode);
        createOrderForm.setRemark("ci用例，购物车测试订单创建");
        return createOrderForm;
    }

    /**
     * 需要塞入满减活动的创建订单参数
     *
     * @param kdtId
     * @param kdtName
     * @param items
     * @param orderPromotionList
     * @param yzCoin
     * @return
     */
    public static CreateOrderForm getCreateOrderWithParam(Long kdtId, String kdtName, List<OrderItemForm> items, List<PreferentialDescApi> orderPromotionList, Long yzCoin) {
        CreateOrderForm createOrderForm = new CreateOrderForm();
        createOrderForm.setItems(items);
        createOrderForm.setKdtId(kdtId);
        createOrderForm.setUserId(userId);
        createOrderForm.setYzbPrice(yzCoin);
        createOrderForm.setKdtName(kdtName);
        createOrderForm.setOrderPromotionList(orderPromotionList);
//        createOrderForm.setInviteCode(inviteCode);
        createOrderForm.setRemark("ci用例，购物车测试订单创建");
        return createOrderForm;
    }


    /**
     * 构造商品信息
     *
     * @param itemId
     * @param quantity
     * @return
     */
    public static OrderItemForm getOrderItemForm(int itemId, int quantity) {
        OrderItemForm orderItemForm = new OrderItemForm();
        orderItemForm.setItemId(itemId);
        orderItemForm.setQuantity(quantity);
        return orderItemForm;
    }

    /**
     * 构造需要商品级优惠的商品信息
     *
     * @param itemId
     * @param quantity
     * @param itemPromotionList
     * @return
     */

    public static OrderItemForm getOrderItemForm(int itemId, int quantity, List<PreferentialDescApi> itemPromotionList) {
        OrderItemForm orderItemForm = new OrderItemForm();
        orderItemForm.setItemId(itemId);
        orderItemForm.setQuantity(quantity);
        orderItemForm.setItemPromotionList(itemPromotionList);
        return orderItemForm;
    }

    public static List<PreferentialDescApi> getItemPromotionList(Long promotionId) {
        Byte type = 6;
        PreferentialDescApi preferentialDescApi = new PreferentialDescApi();
        preferentialDescApi.setPromotionId(promotionId);
        preferentialDescApi.setType(type);
        preferentialDescApi.setSelected(true);
        List<PreferentialDescApi> itemPromotionlist = new ArrayList<>();
        itemPromotionlist.add(preferentialDescApi);
        return itemPromotionlist;
    }


    /**
     * 构造创建订单参数里的订单级优惠
     *
     * @param kdtId
     * @param kdtName
     * @param itemId
     * @param promotionId
     * @param quantity
     * @return
     */
    public static List<PreferentialDescApi> getOrderPromotionList(Long kdtId, String kdtName, int itemId, Long promotionId, int quantity) {
        if (promotionId != null) {
            PreferentialDescApi orderPromotion = getOrderPromotion(promotionId, (byte) 21);
            List<PreferentialDescApi> orderPromotionList = new ArrayList<>();
            orderPromotionList.add(orderPromotion);
            return orderPromotionList;
        } else {
            return null;
        }
    }

    public static PreferentialDescApi getOrderPromotion(Long promotionId, Byte type) {
        PreferentialDescApi orderPromotion = new PreferentialDescApi();
        orderPromotion.setPromotionId(promotionId);
        orderPromotion.setType(type);
        return orderPromotion;

    }

    /**
     * 确认订购参数构造
     *
     * @param kdtId
     * @param kdtName
     * @param items
     * @return
     */
    public static ConfirmOrderForm getConfirmOrderForm(Long kdtId, String kdtName, List<OrderItemForm> items) {
        ConfirmOrderForm confirmOrderForm = new ConfirmOrderForm();
//        confirmOrderForm.setIsUpgrade(isUpgrade);
        confirmOrderForm.setKdtId(kdtId);
        confirmOrderForm.setKdtName(kdtName);
        confirmOrderForm.setUserId(userId);
        confirmOrderForm.setItems(items);
        confirmOrderForm.setTradePhase("CALC_ORDER");
        return confirmOrderForm;
    }

    /**
     * 确认订单计算参数构造
     *
     * @param kdtId
     * @param kdtName
     * @param items
     * @return
     */
    public static CalOrderPriceForm getCalOrderPriceForm(Long kdtId, String kdtName, List<OrderItemForm> items) {
        CalOrderPriceForm calOrderPriceForm = new CalOrderPriceForm();
        calOrderPriceForm.setKdtId(kdtId);
        calOrderPriceForm.setKdtName(kdtName);
        calOrderPriceForm.setUserId(userId);
        calOrderPriceForm.setItems(items);
        calOrderPriceForm.setTradePhase("CALC_ORDER");
        return calOrderPriceForm;
    }

    /**
     * 订购记录参数构造
     *
     * @param kdtId
     * @param state
     * @return
     */
    public static SearchOrderListForm getSearchOrderListForm(Long kdtId, byte state) {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        searchOrderListForm.setPageNo(1);
        searchOrderListForm.setPageSize(10);
        searchOrderListForm.setUserId(userId);
        searchOrderListForm.setKdtId(kdtId);
        searchOrderListForm.setState(state);//0为待付款
        return searchOrderListForm;

    }

    /**
     * 订单详情参数构造
     *
     * @param kdtId
     * @param orderId
     * @return
     */
    public static OrderDetailForm getOrderDetailForm(Long kdtId, Long orderId) {
        OrderDetailForm orderDetailForm = new OrderDetailForm();
        orderDetailForm.setKdtId(kdtId);
        orderDetailForm.setUserId(userId);
        orderDetailForm.setId(orderId);
        return orderDetailForm;
    }

    /**
     * 激活码参数校验构造
     *
     * @param activeCode
     * @param kdtId
     * @return
     */
    public static OpenActivationCodeCheckApi getCodeCheckParam(String activeCode, Long kdtId) {
        //为了防止跑集成的时候，ip次数过多使用，故使用随机数
        OpenActivationCodeCheckApi openActivationCodeCheckApi = new OpenActivationCodeCheckApi();
        openActivationCodeCheckApi.setIp("192.168.10." + new Random().nextInt(100));
        openActivationCodeCheckApi.setActivationCode(activeCode);
        openActivationCodeCheckApi.setKdtId(kdtId);
        openActivationCodeCheckApi.setUserId(Long.valueOf(new Random().nextInt(100)));
        return openActivationCodeCheckApi;
    }

    /**
     * 激活码使用参数构造
     *
     * @param activeCode
     * @param kdtId
     * @return
     */
    public static OpenActivationCodeApplyApi getCodeApplyParam(String activeCode, Long kdtId) {
        OpenActivationCodeApplyApi openActivationCodeApplyApi = new OpenActivationCodeApplyApi();
        openActivationCodeApplyApi.setIp("192.168.10." + new Random().nextInt(100));
        openActivationCodeApplyApi.setActivationCode(activeCode);
        openActivationCodeApplyApi.setKdtId(kdtId);
        openActivationCodeApplyApi.setUserId(Long.valueOf(new Random().nextInt(100)));
        return openActivationCodeApplyApi;
    }

    /**
     * 线下订单，参数构造
     *
     * @param itemFormList
     * @param kdtId
     * @param kdtName
     * @param realPrice
     * @return
     */
    public static OfflineOrderForm getOfflineOrderParam(List<OrderItemForm> itemFormList, Long kdtId, String kdtName, Integer realPrice) {
        OfflineOrderForm offlineOrderForm = new OfflineOrderForm();
        offlineOrderForm.setItems(itemFormList);
        offlineOrderForm.setKdtId(kdtId);
        offlineOrderForm.setKdtName(kdtName);
        offlineOrderForm.setRealPrice(realPrice);
        offlineOrderForm.setOperatorId(userId);
        return offlineOrderForm;
    }

    /**
     * 推荐页参数构造
     *
     * @param kdtId
     * @param itemId
     * @param userId
     * @param isUpgrade
     * @return
     */
    public static RecommendOrderForm getRecommendOrderParam(Long kdtId, Integer itemId, Long userId, Boolean isUpgrade) {
        RecommendOrderForm recommendOrderForm = new RecommendOrderForm();
        recommendOrderForm.setKdtId(kdtId);
        recommendOrderForm.setItemId(itemId);
        recommendOrderForm.setUserId(userId);
        recommendOrderForm.setIsUpgrade(isUpgrade);
        return recommendOrderForm;
    }

    /**
     * 构造查询应用状态参数
     *
     * @param kdtId
     * @param appIds
     * @return
     */
    public static QueryAppStatusListForm getQueryAppStatusListForm(Long kdtId, List<Integer> appIds) {
        QueryAppStatusListForm queryAppStatusListForm = new QueryAppStatusListForm();
        queryAppStatusListForm.setAppIds(appIds);
        queryAppStatusListForm.setKdtId(kdtId);
        return queryAppStatusListForm;
    }


}
