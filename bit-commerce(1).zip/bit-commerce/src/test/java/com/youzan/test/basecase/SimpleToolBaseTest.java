package com.youzan.test.basecase;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.sms.SmsStockDetailEntity;
import com.youzan.commerce.test.entity.dataobject.sms.SmsStockEntity;
import com.youzan.commerce.test.mapper.sms.SmsStockDetailMapper;
import com.youzan.commerce.test.mapper.sms.SmsStockMapper;
import com.youzan.platform.service_chain.concurrent.FrameworkCallable;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.entity.status.AppStatusInfoApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.awaitility.core.ConditionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static com.youzan.commerce.test.utils.DateUtil.compareDate;
import static java.lang.Thread.sleep;
import static org.awaitility.Awaitility.with;

/**
 * @author leifeiyun
 * @date 2020/10/23
 **/
public class SimpleToolBaseTest extends BaseTest {
    @Dubbo
    AppStatusRemoteService appStatusRemoteService;


    @Autowired(required = false)
    SmsStockDetailMapper smsStockDetailMapper;
    @Autowired(required = false)
    SmsStockMapper smsStockMapper;



    public static Long userId = 690258785L;
    //E单是E+23位时间序列，自动化标记auto，占4位EAUTO+17位

    public String generate23Sequence() {
        //16位
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYYMMddHHmmssSSS");
        String randomString = simpleDateFormat.format(new Date()) + (int) Math.random() * 100;
        logger.info("生成随机E单：" + "EAUTO" + randomString);
        return "EAUTO" + randomString;
    }

    public String generateCrmDistributeStockBizNo(Long kdtId) {
        //1603960486553_2135_1_58115659 当前时间时间戳+userid+kdtid
        String tempTime = String.valueOf(System.currentTimeMillis());
        return tempTime + "_2135_auto_" + kdtId;
    }


    public PlainResult<OrderCreateApi> createOrder(CreateOrderForm createOrderForm) {


        PlainResult<OrderCreateApi> result = orderRemoteService.createOrderV2(createOrderForm);

        for (int count = 0; count < 6; count++) {
            if (result.getCode() == 200) {
                logger.info("哦豁，创建订购-->:" + result.getCode() + ":" + result.getMessage());
                break;
            } else {
                try {
                    //10秒
                    sleep(10000);
                    result = orderRemoteService.createOrderV2(createOrderForm);
                    logger.info("哦豁，创建订购-->:" + result.getCode() + ":" + result.getMessage());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
      /*  if (result.getCode() == 200) {
            return result;
        } else {
            return null;
        }*/
        return result;

    }

    public PlainResult<String> createOrderNormal(CreateOrderForm createOrderForm) {
        PlainResult<String> result = orderRemoteService.createNormalOrder(createOrderForm);
        logger.info("哦豁，创建订购-->:" + result.getCode() + ":" + result.getMessage());


        for (int count = 0; count < 6; count++) {
            if (result.getCode() == 200) {
                break;
            } else {
                try {
                    //10秒
                    sleep(10000);
                    result = orderRemoteService.createNormalOrder(createOrderForm);
                    logger.info("哦豁，创建订购-->:" + result.getCode() + ":" + result.getMessage());

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        if (result.getCode() == 200) {
            return result;
        } else {
            return null;
        }

    }


    public PlainResult<Long> createOrderSelf(CreateOrderForm createOrderForm) {


        PlainResult<Long> result = orderRemoteService.createOrder(createOrderForm);

        for (int count = 0; count < 6; count++) {
            if (result.getCode() == 200) {
                logger.info("哦豁，创建订购-->:" + result.getCode() + ":" + result.getMessage());
                break;
            } else {
                try {
                    //10秒
                    sleep(10000);
                    result = orderRemoteService.createOrder(createOrderForm);
                    logger.info("哦豁，创建订购-->:" + result.getCode() + ":" + result.getMessage());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        if (result.getCode() == 200) {
            return result;
        } else {
            return null;
        }

    }


    public PlainResult<OrderCreateApi> createOrder1(CreateOrderForm createOrderForm) {
        AtomicReference<PlainResult<OrderCreateApi>> createApiPlainResult = new AtomicReference<>(new PlainResult<>());

        with().await("哦豁--创建订购了--").and().pollInterval(10, TimeUnit.SECONDS).and().atMost(60, TimeUnit.SECONDS)
                .until(
                        () -> {
                            createApiPlainResult.set(orderRemoteService.createOrderV2(createOrderForm));
                            logger.info("createApiPlainResult.getCode()--->" + createApiPlainResult.get().getCode() + "  message:" + createApiPlainResult.get().getMessage());
                            return (Long.valueOf(createApiPlainResult.get().getCode()) == 200L);
                        }

                );

        if (createApiPlainResult.get().getCode() == 200) {
            return createApiPlainResult.get();
        } else {
            logger.info("哦豁，创建订购挂了-->:" + createApiPlainResult.get().getCode() + ":" + createApiPlainResult.get().getMessage());
            return null;
        }

    }

    /**
     * 这个暂时不用，因为Callable不会把sc信息透传下去
     *
     * @param createOrderForm
     * @return
     */
    public PlainResult<String> createOrderNormal3(CreateOrderForm createOrderForm) {
        AtomicReference<PlainResult<String>> createApiPlainResult = new AtomicReference<>(new PlainResult<>());

        with().await("哦豁--创建订购了--").and().pollInterval(10, TimeUnit.SECONDS).and().atMost(60, TimeUnit.SECONDS)
                .until(
                        () -> {
                            createApiPlainResult.set(orderRemoteService.createNormalOrder(createOrderForm));
                            logger.info("createApiPlainResult.getCode()--->" + createApiPlainResult.get().getCode() + "  message:" + createApiPlainResult.get().getMessage());
                            return (Long.valueOf(createApiPlainResult.get().getCode()) == 200L);
                        }

                );

        if (createApiPlainResult.get().getCode() == 200) {
            return createApiPlainResult.get();
        } else {
            logger.info("哦豁，创建订购挂了-->:" + createApiPlainResult.get().getCode() + ":" + createApiPlainResult.get().getMessage());
            return null;
        }

    }


    /**
     * FrameworkCallable用法待研究，我得再想想
     *
     * @param createOrderForm
     * @return
     */
    public PlainResult<String> createOrderNormal2(CreateOrderForm createOrderForm) {
//        AtomicReference<PlainResult<String>> createApiPlainResult = new AtomicReference<>(new PlainResult<>());
        Map map = new HashMap<>();
        map.put("createOrderForm", createOrderForm);
        map.put("frameworkCallable", null);
        ConditionFactory with = with();
        with.await("哦豁--创建订购了--");
        with.and();
        with.pollInterval(10, TimeUnit.SECONDS);
        with.atMost(60, TimeUnit.SECONDS);
        final PlainResult<String>[] result = new PlainResult[]{new PlainResult<>()};
        with.until(() -> {

            new FrameworkCallable(
//                logger.info("createApiPlainResult.getCode()--->" + result[0].getCode() + "  message:" + result[0].getMessage());
                    (Callable) orderRemoteService.createNormalOrder(createOrderForm)

            );
            return (Long.valueOf(result[0].getCode()) == 200L);
        });
        if (result[0].getCode() == 200) {
            return result[0];
        } else {
            logger.info("哦豁，创建订购挂了-->:" + result[0].getCode() + ":" + result[0].getMessage());
            return null;
        }
    }


    public FrameworkCallable<Boolean> te(Map map) {

        CreateOrderForm createOrderForm = (CreateOrderForm) map.get("createOrderForm");
        FrameworkCallable frameworkCallable = (FrameworkCallable) map.get("frameworkCallable");
        final PlainResult<String>[] result = new PlainResult[]{orderRemoteService.createNormalOrder(createOrderForm)};

        frameworkCallable = new FrameworkCallable(() -> {
            return result[0] = orderRemoteService.createNormalOrder(createOrderForm);
        });

        if (result[0].getCode() == 200) {
            return frameworkCallable;
        } else {
            logger.info("哦豁，创建订购挂了-->:" + result[0].getCode() + ":" + result[0].getMessage());
            return null;
        }

    }

    /**
     * 对于订购应用，验证该应用服务期往后推一定的时间，可用这个方法进行校验，具体到appId维度
     *
     * @param kdtId
     * @param calendarType
     * @param count
     * @param appIds
     */
    public void checkAppStatusWithAppIs(Long kdtId, Integer calendarType, Integer count, List<Integer> appIds) {
        long start = System.currentTimeMillis();
        logger.info("checkAppStatusWithAppIs start:" + new Date());

        AtomicReference<PlainResult<List<AppStatusInfoApi>>> appStatusListInfo = new AtomicReference<>(new PlainResult<>());
//        Assert.assertNotNull(appStatusListInfo.get().getData());
        //开始轮询前，等待1分钟，如果未设置pollDelay，则取pollInterval的值
        with().pollInterval(40, TimeUnit.SECONDS)
                .and().with().pollDelay(10, TimeUnit.SECONDS)
                .and().with().atMost(4, TimeUnit.MINUTES)
                .await("验证服务期生成，别慌，要淡定")
                .until(
                        () -> {
                            appStatusListInfo.set(appStatusRemoteService.getAppStatusListInfo(ConstructionParam.getQueryAppStatusListForm(kdtId, appIds)));
                            logger.info("appStatusListInfo-->" + appStatusListInfo.get());
                            for (int i = 0; i < appStatusListInfo.get().getData().size(); i++) {
                                logger.info("appStatusListInfo.getData().get(i).getExpireTime():--->" + appStatusListInfo.get().getData().get(i).getExpireTime());
                                boolean compareResult = compareDate(new Date(), appStatusListInfo.get().getData().get(i).getExpireTime(), calendarType, count);
                                logger.info("compareResult：---->" + compareResult);
                                if (compareResult == false) {
                                    return false;
                                }
                            }
                            return true;
                        });
        long end = System.currentTimeMillis() - start;
        logger.info("checkAppStatusWithAppIs end:" + new Date());
        logger.info("checkAppStatusWithAppIs need time:" + end + "ms");
        Assert.assertEquals(appStatusListInfo.get().getCode(), 200);
        Assert.assertEquals(appStatusListInfo.get().getMessage(), "successful");

    }

    /**
     * 删除业务方短信记录
     * @param kdtId
     */
    public void deleteSmsData(Long kdtId){
        logger.info("开始清理短信数据---kdtid---"+kdtId);
        smsStockDetailMapper.delete(new QueryWrapper<SmsStockDetailEntity>().eq("kdt_id",kdtId)) ;
        smsStockMapper.delete(new QueryWrapper<SmsStockEntity>().eq("kdt_id",kdtId)) ;
    }

    @Test(enabled = false)
    public void test() {
        logger.info(generate23Sequence());
    }

    /**
     * kdtid:
     *
     * 58300258:wsc-market-自动化-活动-2:买赠礼包券相关
     * 58113442：wsc-自动化-4201102：多网点&&店铺员工
     * 58114950：retail-自动化-2：云pos相关
     * 58115659：wsc-market-自动化-1201104：优惠券码相关
     */
}
