package com.youzan.test.task.boss;

import com.alibaba.fastjson.JSONObject;
import com.youzan.test.BaseTest;
import com.youzan.test.tools.HttpUtils;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2021/9/16 17:07
 */
public class AlertBossRobert extends BaseTest {
    @Test
    public void clearCouponData() throws Exception {
        String url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=591edaf8-904c-4809-a1db-6e83af942778";
        String data = "{\n" +
                "    \"msgtype\": \"text\",\n" +
                "    \"text\": {\n" +
                "        \"content\": \"广州今日天气：29度，大部分多云，降雨概率：60%\",\n" +
                "        \"mentioned_list\":[\"@all\"],\n" +
                "        \"mentioned_mobile_list\":[\"@all\"]\n" +
                "    }\n" +
                "}\n";
        ;
        HttpUtils.doPost(url,JSONObject.parseObject(data));
    }
}
