package com.youzan.test.concurrent;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.enums.market.coupon.CouponAssetStateEnum;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.CouponAssetRemoteService;
import com.youzan.ycm.market.api.redeemcode.RedeemCodeRemoteService;
import com.youzan.ycm.market.constant.YcmIDTypeConstant;
import com.youzan.ycm.market.dto.RedeemCodeRecordDTO;
import com.youzan.ycm.market.request.couponasset.SaveCouponAssetRequest;
import com.youzan.ycm.market.request.redeemcode.CodeRedeemRequest;
import com.youzan.ycm.market.response.couponasset.SaveCouponAssetResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * @author leifeiyun
 * @date 2021/1/6
 **/
public class TestSaveCouponAssetConcurrent extends ConcurrentBaseTest {

    @Dubbo
    CouponAssetRemoteService couponAssetRemoteService;


    @DataProvider(parallel = true,name="saveCouponAssetData")
    public Object[][] datas() {
       Object[][] objects = new Object[][]{
               {"58802859","XXX","lfy0000000980"}
       };
       return objects;
    }

    @Test(threadPoolSize=5, invocationCount=20,dataProvider = "saveCouponAssetData")
    public void testSaveCouponAssetConcurrent(String kdtId,String couponId,String bizNO){

        SaveCouponAssetRequest request = new SaveCouponAssetRequest();
        request.setSourceOrderType("REDEEM_CODE_RECORD");
        request.setSourceOrderId(bizNO);

        request.setUrl("https://youzan.com");
        request.setCouponId(Long.valueOf(couponId));

        request.setBelongtoYidType(YcmIDTypeConstant.KDT_ID);
        request.setBelongtoYid(kdtId);

        request.setState(CouponAssetStateEnum.RECEIVED.getState());

        request.setReceiveBeginTime(new Date());
        request.setReceiveEndTime(new Date());

        request.setReceiveTime(new Date());
        request.setUseEndTime(new Date());
        request.setUseBeginTime(new Date());

        PlainResult<SaveCouponAssetResponse> result =  couponAssetRemoteService.saveCouponAsset(request);
        logger.info("SaveCouponAssetResponse.getData()--》："+result.getData());

    }
}
