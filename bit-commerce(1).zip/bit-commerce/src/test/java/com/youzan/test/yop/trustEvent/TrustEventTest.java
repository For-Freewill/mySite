package com.youzan.test.yop.trustEvent;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.yop.Status;
import com.youzan.commerce.test.mapper.yop.OpenApplicationStatusMapper;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.YopBaseTest;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.entity.TrustCompensateRecordApi;
import com.youzan.yop.api.request.TrustEventPointApi;
import com.youzan.yop.api.request.TrustEventReqApi;
import org.testng.annotations.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * created by leifeiyun on 2020/2/18
 **/
public class TrustEventTest extends YopBaseTest {

    @Dubbo
    MarketRemoteService marketRemoteService;
    OpenApplicationStatusMapper openApplicationStatusMapper;

    @Test(enabled = false)
    public void createCompensateRecordBatch() {


        List<TrustEventReqApi> trustEventReqApis = new ArrayList<>();
        TrustEventReqApi trustEventReqApi = new TrustEventReqApi();
        List<TrustEventPointApi> eventPointApiList = new ArrayList<>();
        TrustEventPointApi trustEventPointApi = new TrustEventPointApi();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        /**
         * 假设一个月发生故障的次数为3，够多了吧
         * 这里设置的时间为
         * 2018-08-12 00:00:00---2018-08-13 00:00:00
         * 2018-08-14 00:00:00---2018-08-15 00:00:00
         * 2018-08-16 00:00:00---2018-08-17 00:00:00
         */

        for (int i = 12; i < 18; i++) {
            trustEventPointApi = new TrustEventPointApi();
            try {
                trustEventPointApi.setStartTime(simpleDateFormat.parse("2018-08-" + i + " 00:00:00"));
                trustEventPointApi.setEndTime(simpleDateFormat.parse("2018-08-" + ++i + " 00:00:00"));
                eventPointApiList.add(trustEventPointApi);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }


        List<Status> statusList = openApplicationStatusMapper.selectList(new QueryWrapper<Status>()
                .eq("app_id", 873)
                .ge("effective_time", "2017-05-01 00:00:00")
                .ge("expire_time", "2018-08-05 00:00:00")
                .le("expire_time", "2019-05-01 00:00:00")
                .notInSql("kdt_id", "select kdt_id from open_trust_compensate_record where action_date='201907' and gift_id=-1")
                .notIn("kdt_id", "540974,30160506,30160505,30160500,30160502,30160503,30160504")
        );

        for (int j = 0; j < statusList.size(); j++) {
            trustEventReqApis = new ArrayList<>();
            trustEventReqApi = new TrustEventReqApi();
            trustEventReqApi.setDate(new Date());
            trustEventReqApi.setAppId(statusList.get(j).getAppId());
            trustEventReqApi.setKdtId(statusList.get(j).getKdtId());
            trustEventReqApi.setTimeGroups(eventPointApiList);
            trustEventReqApis.add(trustEventReqApi);
            try {
                marketRemoteService.calCompensateRecord(trustEventReqApis);
            } catch (Exception e) {
                logger.info("出错的kdtid：" + trustEventReqApi.getKdtId());
            }

        }
        logger.info("记录条数：------->" + String.valueOf(statusList.size()));


        //生成赔付记录  540974

    }

    @Test(enabled = true)
    public void createCompensateRecordSingle() {

        Long kdtId = 54522404L;
        List<TrustEventReqApi> trustEventReqApis = new ArrayList<>();
        TrustEventReqApi trustEventReqApi = new TrustEventReqApi();
        List<TrustEventPointApi> eventPointApiList = new ArrayList<>();
        TrustEventPointApi trustEventPointApi1 = new TrustEventPointApi();
        TrustEventPointApi trustEventPointApi2 = new TrustEventPointApi();


        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        /**
         * 假设一个月发生故障的次数为3，够多了吧
         * 这里设置的时间为
         * 2018-08-12 00:00:00---2018-08-13 00:00:00
         * 2018-08-14 00:00:00---2018-08-15 00:00:00
         * 2018-08-16 00:00:00---2018-08-17 00:00:00
         */

        trustEventPointApi1 = new TrustEventPointApi();
        try {
            trustEventPointApi1.setStartTime(simpleDateFormat.parse("2021-06-16 18:08:52"));
            trustEventPointApi1.setEndTime(simpleDateFormat.parse("2021-06-18 17:08:52"));
      /*      trustEventPointApi2.setStartTime(simpleDateFormat.parse("2021-04-23 04:50:13"));
            trustEventPointApi2.setEndTime(simpleDateFormat.parse("2021-04-23 05:55:13"));*/
;

        } catch (ParseException e) {
            e.printStackTrace();
        }
        eventPointApiList.add(trustEventPointApi1);
//        eventPointApiList.add(trustEventPointApi2);


        trustEventReqApis = new ArrayList<>();
        trustEventReqApi = new TrustEventReqApi();
        trustEventReqApi.setDate(new Date());
        trustEventReqApi.setTimeGroups(eventPointApiList);
        trustEventReqApis.add(trustEventReqApi);
        List<Integer> kdtids = Arrays.asList(60034200,60034409,60034105,60034304,60034204,60034305);
        for (Integer kdt : kdtids) {
            trustEventReqApi.setKdtId(Long.valueOf(kdt));
            marketRemoteService.calCompensateRecord(trustEventReqApis);

        }
//        marketRemoteService.calCompensateRecord(trustEventReqApis);
    }

    @Test(enabled = false)
    public void getCompensateRecordTest() {
        Long kdtid = 54501801L;
        Integer appid = 873;

        PlainResult<List<TrustCompensateRecordApi>> recordResult = marketRemoteService.getCompensateRecord(kdtid, 2020, 873);
        System.out.println(recordResult.getData());
    }

}

