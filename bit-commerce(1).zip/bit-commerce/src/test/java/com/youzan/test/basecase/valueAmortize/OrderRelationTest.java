package com.youzan.test.basecase.valueAmortize;

/**
 * @author wuwu
 * @date 2021/4/2 3:43 PM
 */
public class OrderRelationTest {
}
