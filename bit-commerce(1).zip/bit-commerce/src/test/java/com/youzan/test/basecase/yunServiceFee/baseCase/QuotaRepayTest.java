package com.youzan.test.basecase.yunServiceFee.baseCase;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageDO;
import com.youzan.commerce.test.mapper.market.yunfee.FeeResourcePackageMapper;
import com.youzan.commerce.test.mapper.market.yunfee.FeeYopProtocolMapper;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.ycm.perform.response.advance.CanAdvanceOrderQuotaResponse;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;

/**
 * @author wulei
 * @date 2020-10-19
 * 订单额度，预支，回扣
 */
public class QuotaRepayTest extends YunBaseTest {
    public static String yunKdtName10 = "zidonghu3-抵扣升级";
    public static String yunKdtName11 = "zidonghua4-repay";
    @Autowired(required = false)
    public FeeResourcePackageMapper feeResourcePackageMapper;
    @Autowired(required = false)
    public FeeYopProtocolMapper feeYopProtocolMapper;

    @Test // 买1续2，消耗额度后，抵扣升级到专业版1年，产生欠额
    public void testUpgradeDebt() {
        Long kdt = newWscKdtId();
        // 买1，续2
        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdt, yunKdtName11, wscWXItemId_2021, 1);

        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, yunKdtName11, wscWXItemId_2021, 2);

        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支1次
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 0);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // 预支2次
        PlainResult<Boolean> advanceResult2 = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 1);

        // 等待计费侧3条数据落库
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(
                        new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt.toString())).size() == 3);

        // 计费消耗全部额度
        updateFeeResourcePackage(kdt, Boolean.TRUE, Boolean.FALSE);

        // 可用额度校验-全部预支后为0
        updateFeeResource(kdt);

        // 购买1年专业版-抵扣升级
        logger.info("开始抵扣升级专业版");
        PlainResult<OrderCreateApi> result3 = testCreateOrder(kdt, yunKdtName11, wscProfessionItemId_2021, 2);
        logger.info("购买专业版结束");

        // 可用额度校验-抵扣升级后为0
        testQueryTotalQuota(kdt, 20000);
        // 校验-可用额度为0
        testQueryAvailableQuota(kdt, 0);
        // 回收记录表详情
        Map<String, Integer> result4 = calcDebtRecord(kdt);
        // 校验-欠额
        Assert.assertEquals(result4.get("owe"), Integer.valueOf(10000));
    }

    @Test() // 买1续2，消耗额度后，抵扣升级到专业版1年，产生欠额,预支抵扣
    public void testUpgradeDebtRenew() {
        Long kdt = newWscKdtId();
        // 买1，续2
        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdt, yunKdtName10, wscWXItemId_2021, 1);

        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, yunKdtName10, wscWXItemId_2021, 2);

        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支1次
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 0);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // 预支2次
        PlainResult<Boolean> advanceResult2 = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 1);

        // 等待计费侧3条数据落库
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(
                        new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt.toString())).size() == 3);


        // 计费消耗全部额度
        updateFeeResource(kdt);

        // 等待计费侧全部消耗
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(
                        new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt.toString()).eq("used", 0).eq("state", 1)).size() == 0);

        // 可用额度校验-全部预支后为0
        testQueryAvailableQuota(kdt, 0);

        // 购买1年专业版-抵扣升级
        logger.info("开始抵扣升级专业版");
        PlainResult<OrderCreateApi> result3 = testCreateOrder(kdt, yunKdtName10, wscProfessionItemId_2021, 2);
        logger.info("购买专业版结束");

        // 可用额度校验-抵扣升级后为0
        testQueryTotalQuota(kdt, 20000);
        // 校验-可用额度为0
        testQueryAvailableQuota(kdt, 0);
        // 回收记录表详情
        Map<String, Integer> result = calcDebtRecord(kdt);
        // 校验-欠额
        Assert.assertEquals(result.get("owe"), Integer.valueOf(10000));
        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult2 = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支1次
        PlainResult<Boolean> advanceResult3 = testAdvanceOrderQuota(kdt, canAdvanceResult2.getData().getOrderId().toString(), 1);
        // 预期无法预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult3 = testCanAdvanceOrderQuota(kdt.toString(), Boolean.FALSE);
        // 可用额度校验-再次预支后
        testQueryTotalQuota(kdt, 40000);
        // 校验-可用额度为10000
        testQueryAvailableQuota(kdt, 10000);
        // 回收记录表详情
        Map<String, Integer> resultafterenew = calcDebtRecord(kdt);
        // 校验-欠额-为0
        Assert.assertEquals(resultafterenew.get("owe"), Integer.valueOf(0));
        // 校验-回收为0
        Assert.assertEquals(resultafterenew.get("recover"), Integer.valueOf(0));
        // 校验-应该回收30000
        Assert.assertEquals(resultafterenew.get("shouldReocvery"), Integer.valueOf(30000));
        godCannotHelpU(kdt);
    }

    @Test // 买1续2，消耗额度后，抵扣升级到专业版1年，产生欠额,单独订购抵扣
    public void testUpgradeDebtRenew2() {
        Long kdt = newWscKdtId();

        // 买1，续2
        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdt, yunKdtName11, wscWXItemId_2021, 1);

        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, yunKdtName11, wscWXItemId_2021, 2);

        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支1次
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 0);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // 预支2次
        PlainResult<Boolean> advanceResult2 = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 1);

        // 等待计费侧3条数据落库
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(
                        new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt.toString())).size() == 3);

        // 计费消耗全部额度
        updateFeeResource(kdt);

        // 等待计费侧全部消耗
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(
                        new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt.toString()).eq("used", 0).eq("state", 1)).size() == 0);

        // 可用额度校验-全部预支后为0
        testQueryAvailableQuota(kdt, 0);

        // 购买1年专业版-抵扣升级
        logger.info("开始抵扣升级专业版");
        PlainResult<OrderCreateApi> result3 = testCreateOrder(kdt, yunKdtName11, wscProfessionItemId_2021, 2);
        logger.info("购买专业版结束");

        // 可用额度校验-抵扣升级后为0
        testQueryTotalQuota(kdt, 20000);
        // 校验-可用额度为0
        testQueryAvailableQuota(kdt, 0);
        // 回收记录表详情
        Map<String, Integer> result = calcDebtRecord(kdt);
        // 校验-欠额
        Assert.assertEquals(result.get("owe"), Integer.valueOf(10000));
        // 线下下单2单-0元单和非0元单，总计5000订单额度
        offlineOrder(kdt, yunKdtName11, 7284, 1000, 0);
        offlineOrder(kdt, yunKdtName11, 7284, 4000, 1);
        // 预期：此时总25000，欠额5000，可用0
        testQueryTotalQuota(kdt, 25000);
        testQueryAvailableQuota(kdt, 0);

        Map<String, Integer> resultAfterOffline = calcDebtRecord(kdt);
        // 校验-欠额：5000
        Assert.assertEquals(resultAfterOffline.get("owe"), Integer.valueOf(5000));
        godCannotHelpU(kdt);
    }

//    public enum ItemInfos {
//        SMS_1000("短信充值1000条", 9638, 613, 5000),
//        FAPIAO_1000("发票1000条", 17485, 752, 10000),
//        TUIGUANG_200("推广分析200条", 21719, 7008, 20000),
//        RETAILSHOP("零售交付服务-门店版", 34294, 7183, 200000),
//        RETAILCHAIN("零售交付服务-连锁版", 38393, 7225, 250000),
//        STANDSERVICE("标准服务升级包", 50238, 8323, 750000),
//        QUICKONLINE("快速上线指导包", 50239, 8324, 1750000);
//
//        private String name;
//        private Integer appId;
//        private Integer itemId;
//        private Integer money;
//
//        /**
//         * 扩展字段，激活码id
//         */
//        private Integer extend;
//
//        ItemInfos(String name, Integer appId, Integer itemId, Integer money) {
//            this.name = name;
//            this.appId = appId;
//            this.itemId = itemId;
//            this.money = money;
//        }
//
//        public String getName() {
//            return name;
//        }
//
//        public Integer getAppId() {
//            return appId;
//        }
//
//        public Integer getItemId() {
//            return itemId;
//        }
//
//        public Integer getMoney() {
//            return money;
//        }
//
//        public void setExtend(Integer extend) {
//            this.extend = extend;
//        }
//
//
//    }

//    @Test // 买1续2，消耗额度后，抵扣升级到专业版1年，产生欠额,单独订购抵扣
//    public void testUpgradeDebtRenew3() {
//        testQueryAvailableQuota(yunKdtId12,100);
//    }
//    @Test(dataProvider = "offLineList")
//    public void offlineStockProduct(Long kdtId, Integer itemId, String appid, String pfOrderItemID, int pfOrderStockRecordSize, int order_stock) throws InterruptedException {
//        // 清理商品缓存
//        clearPfGoodsCache(pfOrderItemID);
//        // 线下落单：发票1000张
//        PlainResult<List<Long>> result1 = bizOfflineOrder(kdtId, itemId, 1, 10000);
//        Assert.assertEquals(200, result1.getCode());
//        List<PfOrder> pf_orders = queryPfOrder(kdtId.toString(), pfOrderItemID);
//        if (pf_orders.size() > 0) {
//            String pf_order_id = pf_orders.get(0).getId().toString();
//            List<SendNsqMessageDO> nsq1 = querySendNsq(kdtId.toString(), "notify_crm_order_effect", appid, pf_order_id);
//            Assert.assertEquals(1, nsq1.size());
//            Assert.assertEquals(pfOrderStockRecordSize, pfOrderStockMapper.selectList(new QueryWrapper<PfOrderStock>().eq("pf_order_id", pf_order_id)).size());
//        }
//        // 清理商品缓存
//        clearPfGoodsCache(pfOrderItemID);
//        PlainResult<List<Long>> result2 = bizOfflineOrder(kdtId, itemId, 1, 10000);
//        Assert.assertEquals(200, result2.getCode());
//        List<PfOrder> pf_orders2 = queryPfOrder(kdtId.toString(), pfOrderItemID);
//        Assert.assertEquals(2, pf_orders2.size());
//        if (pf_orders2.size() > 0) {
//            String pf_order_id = pf_orders2.get(1).getId().toString();
//            List<SendNsqMessageDO> nsq1 = querySendNsq(kdtId.toString(), "notify_crm_order_effect", appid, pf_order_id);
//            // pf_order_stock表记录条数
//            Assert.assertEquals(pfOrderStockRecordSize, pfOrderStockMapper.selectList(new QueryWrapper<PfOrderStock>().eq("pf_order_id", pf_order_id)).size());
//        }
//        Thread.sleep(3000);
//    }

//    @DataProvider
//    private Object[][] offLineList() {
//        return new Object[][]{
//                // 例子{kdt_id, ItemInfos.FAPIAO_1000.getItemId(), ItemInfos.FAPIAO_1000.getAppId().toString(), pf_order表的item_id, pf_order_stock表记录数,pf_order_stock.order_stock值},
//                //{yunKdtId11, ItemInfos.FAPIAO_1000.getItemId(), ItemInfos.FAPIAO_1000.getAppId().toString(), "atom_sku_invoice_one_thousand", 0, 0},
//                {yunKdtId13, ItemInfos.TUIGUANG_200.getItemId(), ItemInfos.TUIGUANG_200.getAppId().toString(), "atom_sku_promote_analysis_two_hundred", 0, 0},
//                {yunKdtId13, ItemInfos.RETAILSHOP.getItemId(), ItemInfos.RETAILSHOP.getAppId().toString(), "atom_sku_retail_store_delivery_service_once", 1, 1},
//                {yunKdtId13, ItemInfos.RETAILCHAIN.getItemId(), ItemInfos.RETAILCHAIN.getAppId().toString(), "atom_sku_chain_retail_store_delivery_service_once", 1, 1},
//                {yunKdtId13, ItemInfos.STANDSERVICE.getItemId(), ItemInfos.STANDSERVICE.getAppId().toString(), "atom_sku_standard_service_upgrade_package", 1, 1},
//                {yunKdtId13, ItemInfos.QUICKONLINE.getItemId(), ItemInfos.QUICKONLINE.getAppId().toString(), "atom_sku_quick_online_guide_package", 1, 7}
//        };
//    }
}
