package com.youzan.test.refund.basecase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.shop.ShopProdRelation;
import com.youzan.commerce.test.entity.dataobject.shop.ShopProdVersionRelation;
import com.youzan.commerce.test.kv.KvdsConstants;
import com.youzan.commerce.test.mapper.perform.PfRegulationExecMapper;
import com.youzan.commerce.test.mapper.perform.PfRegulationMapper;
import com.youzan.framework.redis.RedisClient;
import com.youzan.shopcenter.shop.entity.LongServiceResult;
import com.youzan.shopcenter.shop.entity.request.WscCreateRequest;
import com.youzan.shopcenter.shop.service.ShopCreateService;
import com.youzan.shopcenter.shopprod.api.entity.ShopProd;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.uic.api.user.model.MobileUserInfoModel;
import com.youzan.uic.api.user.param.UserInfoQueryParam;
import com.youzan.uic.api.user.param.UserRegisterPasswordParam;
import com.youzan.uic.api.user.service.UserInfoService;
import com.youzan.uic.api.user.service.UserRegisterService;
import com.youzan.yop.api.response.ItemPreferentialInfoResultApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.util.*;

import static org.assertj.core.util.DateUtil.now;

//import com.youzan.ycm.market.api.CouponSendRemoteService;
//import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableNewKdtIdResponse;
//import com.youzan.ycm.qa.enable.platform.api.service.enable.EnableNewShopPoolService;
//import com.youzan.yop.api.entity.pay.PreparePayApi;

/**
 * @author wuwu
 * @date 2020/11/9 7:38 PM
 */
public class test extends DeductBaseTest {
    @Autowired(required = false)
    public PfRegulationMapper pfRegulationMapper;

    @Autowired(required = false)
    public PfRegulationExecMapper pfRegulationExecMapper;
    @Resource
    private RedisClient redisClient;

    @Dubbo
    public UserInfoService userInfoService;

    @Dubbo(timeout = 8000)
    public ShopCreateService shopCreateService;

    @Dubbo
    public UserRegisterService userRegisterService;
//    @Dubbo
//    private EnableNewShopPoolService enableNewShopPoolService;


    Logger logger = LoggerFactory.getLogger(test.class);

    @Test(enabled = false)
    public void test1() {
        initShopByKdtId(58520922L);
    }

    @Test(enabled = false)
    public void createOrder11() {
        PlainResult<List<ItemPreferentialInfoResultApi>> itempreferentialInfoResult = fetchItemPreferentialInfoOnline(58719461L,1,8159,1,1);

        logger.info("获取优惠信息：{}",JSON.toJSON(itempreferentialInfoResult));
    }

    @Test(enabled = false)
    public void createNormalOrder1() {
        closeWaitPayOrder(59415203L);
        refundOrderByKdtId(59415203L);
        PlainResult<String> result = createNormalOrder(59415203L,wscNoPromtionKdtName,professionItemId_2021,1,0L);

        logger.info("创建订单结果：{}",result);
    }
    @Test(enabled = false)
    public void createOrderForAnalysis() {
        closeWaitPayOrder(wscKdtId);
        refundOrderByKdtId(wscKdtId);
        PlainResult<Long> result = createOrder(wscKdtId,wscKdtName,promoteAnalysisItemId_500,1,0L);

        logger.info("推广分析创建订单返回结果：{}",result);
    }

    @Test(enabled = false)
    public void createOrderMultiApp() {
        closeWaitPayOrder(59415203L);
        refundOrderByKdtId(59415203L);
        //enableAllPromotion(wscHasAllPromotionKdtId,wscHasAllPromotionKdtName,basicWechatItemId_2021,1);
        PlainResult<String> result = createNormalOrderWithMultiApp(59415203L,wscHasAllPromotionKdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId,7014,57,7166),1,yzb);

        logger.info("订单返回结果：{}",result);
    }
    @Test(enabled = false)
    public void kvTest() {
        String key = String.format(KvdsConstants.SHOP_PROD_RELATION,59124082);
        redisClient.opsForKey().del(key);

    }

    @Test(enabled = false)
    public void resetTryTime() {
        setShopTryTime(59127455L);
    }

    @Test(enabled = false)
    public void testForlogCheck() {
        PlainResult<String>  result = createNormalOrder(59109024L,"券包-6",basicWechatItemId_2021,1,1000000L);
        logger.info("创建订单返回结果：{}",result);
    }


    @Test(enabled = false)
//            (enabled = false,threadPoolSize=10, invocationCount=10)
    public void getNewKdtIdTest() {
        long id = Thread.currentThread().getId();
//        EnableNewKdtIdResponse result = getKdtId("retailChain");
        Long result1 = newRetailChainKdtId();
        Long result2 = newWscChainKdtId();
        logger.info("零售连锁" +JSON.toJSONString(result1));
        logger.info("微商城连锁" +JSON.toJSONString(result2));

    }

    @Test(enabled = false)
    public void getShopProd() {
        PlainResult<ShopProd> result = prodReadService.queryShopProd(59127455L);
        logger.info(JSON.toJSONString(result));
    }

    /**
     * 设置试用期时间为当前时间到7天后
     * @param kdtId
     */
    @Override
    public void setShopTryTime(Long kdtId) {
//        Date beginTime = now();
//        Calendar calendar = Calendar.getInstance();//日历对象
//        calendar.setTime(now());
//        calendar.add(Calendar.DATE,7);
//        Date endtIme = calendar.getTime();

        //Date now = now();
        Calendar calendar = Calendar.getInstance();//日历对象
        calendar.setTime(now());
        calendar.add(Calendar.DATE,1);
        Date endtIme = calendar.getTime();

        Calendar calendar2 = Calendar.getInstance();//日历对象
        calendar.setTime(endtIme);
        calendar.add(Calendar.DATE,-7);
        Date beginTime = calendar.getTime();


        String status = "try";
        /**更新店铺 shop_prod_version_relation 表
         * lifecycle_status = 'try';
         * lifecycle_begin_time = now();
         * lifecycle_end_time = now()+7day
         */

        //获取shop_prod_version_relation 表数据
        ShopProdVersionRelation shopProdVersionRelation = shopProdVersionRelationMapper.selectOne(new QueryWrapper<ShopProdVersionRelation>()
                .eq("kdt_id",kdtId)
                .eq("prod_code","wsc"));
        shopProdVersionRelation.setLifecycleBeginTime(beginTime);
        shopProdVersionRelation.setLifecycleEndTime(endtIme);
        shopProdVersionRelation.setLifecycleStatus(status);
        shopProdVersionRelationMapper.updateById(shopProdVersionRelation);

        /**更新店铺 shop_prod_relation 表
         * lifecycle_status = 'try';
         * begin_time = now();
         * end_time = now()+7day
         */
        //获取shop_prod_relation 表数据
        ShopProdRelation shopProdRelation = shopProdRelationMapper.selectOne(new QueryWrapper<ShopProdRelation>()
                .eq("kdt_id",kdtId)
                .eq("prod_code","wsc"));
        shopProdRelation.setBeginTime(beginTime);
        shopProdRelation.setEndTime(endtIme);
        shopProdRelation.setLifecycleStatus(status);
        shopProdRelationMapper.updateById(shopProdRelation);

        //设置team_close状态为0
        setShopTeamCloseConfig(kdtId,"0");

        //清两个数据表的缓存
        String key = String.format(KvdsConstants.SHOP_PROD_RELATION,kdtId);
        redisClient.opsForKey().del(key);

    }

    @Test(dataProvider = "phoneNo",enabled = false)
    public void createWscShop(String phoneNo) {

        LongServiceResult result = createWscNewShop(phoneNo);
        logger.info("创建店铺结果：" +result);

        //创建订单
        //createNormalOrder(result.getData(),"老带新测试",basicWechatItemId_2021,1,0L);

//        } catch (Exception e) {
        //return new Result().setSuccess(false).setResult("创建店铺过程异常," + e.getMessage());
        //plainResult.setSuccess();

        //log.info("创建店铺过程异常," + e.getMessage());

        //return result;
        //}
        //plainResult.setSuccess(result.); = result;

    }

    @Test(enabled = false)
    public void getActivityBuyerTag() {
        Set<String> buyerTag = new HashSet<>();
        List<MkActivity> mkActivityList = activityMapper.selectList(new QueryWrapper<MkActivity>()
                .eq("activity_type","G_DISCOUNT")
                .like("conditions","buyerTagEnumList"));

        for(MkActivity mkActivity:mkActivityList) {
            String conditions = mkActivity.getConditions();

            JSONArray jsonArray = JSONArray.parseArray(conditions);
            JSONObject jsonObject = jsonArray.getJSONObject(3);
//            buyerTag.add(jsonObject.getString("buyerTagEnumList"));
            buyerTag.add(jsonObject.getString("buyerTagEnumList"));
        }
        System.out.println(buyerTag);

//        List<String> buyerPresentTag = new ArrayList<>();
        Set<String> buyerPresentTag = new HashSet<>();

        List<MkActivity> mkActivityPresentList = activityMapper.selectList(new QueryWrapper<MkActivity>()
                .eq("activity_type","G_PRESENT")
                .like("conditions","buyerTagEnum"));

        for(MkActivity mkActivity:mkActivityPresentList) {
            String presentConditions = mkActivity.getConditions();

            JSONArray jsonArray = JSONArray.parseArray(presentConditions);
            JSONObject jsonObject = jsonArray.getJSONObject(2);
            buyerPresentTag.add(jsonObject.getString("buyerTagEnum"));
        }
        System.out.println(buyerPresentTag);



    }

    public LongServiceResult createWscNewShop(String phoneNo) {
        //String phoneNo = "18507556077";
        //AssertUtil.isAllNotNone(phoneNo, "手机号不能为空");
        try {
            PlainResult<Long> accountResult = createMobileAccount(phoneNo);

            PlainResult<LongServiceResult> plainResult = new PlainResult<>();


            //try {
            UserInfoQueryParam userInfoQueryParam = new UserInfoQueryParam();
            userInfoQueryParam.setMobile(phoneNo);
            userInfoQueryParam.setWithPassword(true);
            userInfoQueryParam.setAppName("shangyehua-CI");

            //Long accountStart = System.currentTimeMillis();
            PlainResult<MobileUserInfoModel> userResult = userInfoService.getMobileInfo(userInfoQueryParam);
            if (userResult.getData() == null) {
                plainResult.setSuccess(false);
                logger.info("手机号异常");
            }
            Long accountId = userResult.getData().getUserId();
            //acountCost = System.currentTimeMillis() - accountStart;


            String shopName = "CI-syh-" + System.currentTimeMillis();

            WscCreateRequest request = new WscCreateRequest();
            //shopName = StringUtils.isNotEmpty(shopName) ? shopName + RandomStringUtils.randomNumeric(4) : UniqueIDGenerator.create().replaceAll("^(\\d{4})", "");
            request.setShopName(shopName);
            request.setBusiness(35);
            request.setProvince("浙江省");
            request.setCity("杭州市");
            request.setArea("西湖区");
            request.setAddress("文三路黄龙万科中心");
            request.setCountyId(310000);
            request.setAccountId(accountId);
            //Long ironStart = System.currentTimeMillis();
            LongServiceResult result = shopCreateService.createWscShop(request);
            logger.info("创建订单结果：" + JSON.toJSONString(result));
            return result;
        } catch (Exception e) {
            LongServiceResult longServiceResult = new LongServiceResult();
            longServiceResult.setErrorDesc(e.getMessage());
            return longServiceResult;
        }
    }

    @DataProvider(name = "phoneNo")
    public Object[][] threeYears() {
        return new Object[][] {
                {"18507558004"},
//                {"18507559017"},
//                {"18507559018"},
        };
    }


    public PlainResult<Long> createMobileAccount(String phoneNo) {
        try {
            UserRegisterPasswordParam userRegisterPasswordParam = new UserRegisterPasswordParam();
            userRegisterPasswordParam.setCountryCode("+86");
            userRegisterPasswordParam.setMobile(phoneNo);
            userRegisterPasswordParam.setPassword("123456");
            userRegisterPasswordParam.setGroupId(1L);

            PlainResult<Long> result = userRegisterService.registerByPassword(userRegisterPasswordParam);
            return result;
        } catch (Exception e) {
            try {
                throw new Exception("创建账号失败："+ e.getMessage());
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        return null;
    }

}

