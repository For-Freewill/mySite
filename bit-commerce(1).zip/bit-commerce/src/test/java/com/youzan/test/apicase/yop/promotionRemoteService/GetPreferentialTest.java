package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.promotion.crm.OpenAppCrmPromotionApi;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2020/9/28 16:00
 * 根据id查询优惠信息
 */
public class GetPreferentialTest extends BaseTest {
    @Dubbo
    public PromotionRemoteService promotionRemoteService;

    /**
     * @desc 场景1:正常测试-查询一年期礼包
     */
    @Test
    public void enableKdtPromotionNormalTest() {

        PlainResult<OpenAppCrmPromotionApi> result = promotionRemoteService.getPreferential(2741);
        Assert.assertEquals(result.getCode(), 200);
        if (result.getData().getCrmPreferentialList().get(0) != null) {
            Assert.assertEquals(result.getData().getCrmPreferentialList().get(0).getName(), "微商城专业版1年期礼包");
        }

    }

    /**
     * @desc 场景2:正常测试-活动不存在
     * open_application_preferential.id 393 不存在
     */
    @Test
    public void enableKdtPromotionNoIdTest() {

        PlainResult<OpenAppCrmPromotionApi> result = promotionRemoteService.getPreferential(393);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getCrmPreferentialList().size(), 0);

    }

    /**
     * @desc 场景3:异常测试-ID为空
     * open_application_preferential.id 393 不存在
     */
    @Test
    public void enableKdtPromotionIdNullTest() {

        PlainResult<OpenAppCrmPromotionApi> result = promotionRemoteService.getPreferential(null);
        Assert.assertEquals(result.getCode(), 130102);
        Assert.assertEquals(result.getMessage(), "参数非法");

    }
}
