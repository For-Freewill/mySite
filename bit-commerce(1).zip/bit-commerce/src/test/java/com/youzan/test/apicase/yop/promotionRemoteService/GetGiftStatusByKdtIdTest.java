package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.StartTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.OpenAppGiftApi;
import com.youzan.yop.api.entity.StateQueryParam;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @program: bit-commerce
 * @description 获取礼包列表
 * @author: tianning
 * @create: 2021-03-24 14:24
 **/
public class GetGiftStatusByKdtIdTest extends StartTest {

    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void getGiftStatusByKdtIdTest() {
        StateQueryParam stateQueryParam = new StateQueryParam();
        stateQueryParam.setKdtId(58711819L);
        stateQueryParam.setState((byte)-1);
        PlainResult<List<OpenAppGiftApi>> getGiftStatusByKdtIdResult = promotionRemoteService.getGiftStatusByKdtId(stateQueryParam);
        Assert.assertEquals(getGiftStatusByKdtIdResult.getCode(), 200);
        Assert.assertNotNull(getGiftStatusByKdtIdResult.getData());
    }

    /**
     * 异常用例
     */
    @Test
    public void getGiftStatusByKdtIdStateNullTest() {
        StateQueryParam stateQueryParam = new StateQueryParam();
        stateQueryParam.setKdtId(58711819L);
        stateQueryParam.setState(null);
        PlainResult<List<OpenAppGiftApi>> getGiftStatusByKdtIdResult = promotionRemoteService.getGiftStatusByKdtId(stateQueryParam);
        Assert.assertEquals(getGiftStatusByKdtIdResult.getCode(), 200);
        Assert.assertNotNull(getGiftStatusByKdtIdResult.getData());
    }
}
