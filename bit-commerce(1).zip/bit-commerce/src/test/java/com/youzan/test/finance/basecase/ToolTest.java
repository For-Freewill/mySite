package com.youzan.test.finance.basecase;

import com.youzan.test.finance.FinanceBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by baoyan on 11/16/21.
 */
public class ToolTest extends FinanceBaseTest {
/*
    @Dubbo
    PlanExecuteRemoteService planExecuteRemoteService;*/
    @Test
    public void settleLineTest(){
        List<String> providerIds = new ArrayList<>();
        providerIds.add("12130");
        providerIds.add("12131");
        providerIds.add("12132");
        providerIds.add("12133");
        reset(providerIds,1l);
    }

}
