package com.youzan.test.apicase.yop.promotionRemoteService;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.dto.BriefPromotionDTO;
import com.youzan.yop.api.request.ListBriefPromotionV2Request;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

/**
 * @program: bit-commerce
 * @description  后台查询营销列表
 * @author: tianning
 * @create: 2021-03-23 13:14
 **/
public class ListBriefPromotionV2Test extends TnBaseTest {

    @JSONData(value = "dataResource/apicase/yop/ListBriefPromotionV2RequestData.json", key = "listBriefPromotionV2")
    private ListBriefPromotionV2Request listBriefPromotionV2;

    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    Long promotion = null;

    /**
     * 正常用例
     */
    @Test
    public void listBriefPromotionV2Test() {
        try {
            promotion = createPromotion().getData();
            Assert.assertNotNull(promotion);
            List<String> globalBuyTags = Arrays.asList("FIRST","REORDER","SIGN_BACK");

            listBriefPromotionV2.setId(promotion);
            ListResult<BriefPromotionDTO> listBriefPromotionV2Result = promotionRemoteService.listBriefPromotionV2(listBriefPromotionV2);
            Assert.assertEquals(listBriefPromotionV2Result.getCode(), 200);
//            Assert.assertEquals(listBriefPromotionV2Result.getData().get(0).getAppId(), "combine_spu_wsc");
            Assert.assertEquals(listBriefPromotionV2Result.getData().get(0).getType(), "ACTIVITY");
            Assert.assertEquals(listBriefPromotionV2Result.getData().get(0).getGlobalBuyTags(), globalBuyTags);
            Assert.assertFalse(listBriefPromotionV2Result.getData().get(0).getIsInvalid());
        }finally {
            invalidPresentActivity(promotion);
            activityMapper.delete(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, promotion));
            activityRuleMapper.delete(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, promotion));
        }
    }

    /**
     * 异常用例--PromotionNull
     */
    @Test
    public void listBriefPromotionV2PromotionNullTest() {
        listBriefPromotionV2.setId(null);
        ListResult<BriefPromotionDTO> listBriefPromotionV2Result = promotionRemoteService.listBriefPromotionV2 (listBriefPromotionV2);
        Assert.assertEquals(listBriefPromotionV2Result.getCode(),200);
        Assert.assertEquals(listBriefPromotionV2Result.getData().get(0).getType(),"ACTIVITY");
    }

    /**
     * 异常用例--typeNull
     */
    @Test(enabled = false)
    /**
     * 注调的原因，内部使用的yop的接口，没有意义
     */
    public void listBriefPromotionV2typeNullTest() {
        PlainResult<Long> promotion = createPromotion();
        Assert.assertNotNull(promotion);
        listBriefPromotionV2.setType("");
        ListResult<BriefPromotionDTO> listBriefPromotionV2Result = promotionRemoteService.listBriefPromotionV2 (listBriefPromotionV2);
        Assert.assertEquals(listBriefPromotionV2Result.getCode(),200);
        Assert.assertEquals(listBriefPromotionV2Result.getData().get(0).getAppId(),"combine_spu_wsc");
        Assert.assertEquals(listBriefPromotionV2Result.getData().get(0).getType(),"ACTIVITY");
        Assert.assertEquals(listBriefPromotionV2Result.getData().get(0).getGlobalBuyTags().get(0),"NOT_LIMIT");
        Assert.assertTrue(listBriefPromotionV2Result.getData().get(0).getIsInvalid());
    }
}
