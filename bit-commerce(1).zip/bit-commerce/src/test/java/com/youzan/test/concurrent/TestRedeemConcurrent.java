package com.youzan.test.concurrent;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.redeemcode.RedeemCodeRemoteService;
import com.youzan.ycm.market.dto.RedeemCodeRecordDTO;
import com.youzan.ycm.market.request.redeemcode.CodeRedeemRequest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


/**
 * @author leifeiyun
 * @date 2021/1/6
 **/
public class TestRedeemConcurrent extends ConcurrentBaseTest {
    @Dubbo
    RedeemCodeRemoteService redeemCodeRemoteService;

    @DataProvider(parallel = true,name="redeemData")
    public Object[][] datas() {
       Object[][] objects = new Object[][]{
               {"58802859","7SQ7NQHC"},
               {"58801973","ABPD2ZQ4"}
       };
       return objects;
    }

    @Test(threadPoolSize=5, invocationCount=20,dataProvider = "redeemData")
    public void testRedeemConcurrent(String belongToId,String redeemCode){
        CodeRedeemRequest codeRedeemRequest = new CodeRedeemRequest();
        codeRedeemRequest.setRedeemChannel("PC");
        codeRedeemRequest.setOperator("leifeiyun");
        codeRedeemRequest.setBelongToType("KDT_ID");

        codeRedeemRequest.setBelongToId(belongToId);
        codeRedeemRequest.setRedeemCode(redeemCode);
        PlainResult<RedeemCodeRecordDTO> redeemCodeRecordDTOPlainResult =  redeemCodeRemoteService.redeem(codeRedeemRequest);
        logger.info("redeemCodeRecordDTOPlainResult.getData()--》："+redeemCodeRecordDTOPlainResult.getData());;

    }
}
