package com.youzan.test.onlineTrade.basecase.period_count;

/**
 * @author baoyan
 * @date 2020/8/19
 **/

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.perform.PfOrderMapper;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.pay.unified.cashier.api.request.v3.request.PreOrderPayRequest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * ##新搞了个账号：17413462002/123456abc
 * ##在这个账号下的集成店铺
 * ##edu:54610673【edu-自动化-2-白】
 * ###retail:54617205【retail-自动化-1-白】
 */
public class StaffTest extends PeriodCountBaseTest {
    public static Long userId = 690258785L;
    @Autowired(required = false)
    PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    TdOrderMapper tdOrderMapper;
//    private Long staffKdtId = 59327549L;
    private Long staffKdtId = newWscKdtId();

    private String wscKdtName = "员工-自动化-1";

    /**
     * 店铺员工->店铺员工新购
     * <p>
     * 微商城新购店铺员工
     * 验证新购服务期&员工个数
     * <p>
     * 1.创建员工订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证员工订购个数
     * 5.验证员工服务期
     * 6.验证员工购买标签为新签
     * 7.退款
     */


    @Test(priority = 0)
    public void test_newBuyStaff_0() {
        logger.info("\ntest_newBuyStaff_0--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResult = new PlainResult<>();
        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(staffKdtId);
            //存在店铺员工订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(staffKdtId, Long.valueOf(ItemInfo.STAFF_YEARS.getAppId()), "", "BY_VALUE", new Date());
            String createNewStaffDataFilePath = "src/test/resources/dataResource/basecase.plugin/staffnewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewStaffDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(staffKdtId);
            //1.创建员工订单
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResult = createOrder(createOrderForm);
            if (orderCreateApiPlainResult == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResult.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResult.getMessage());
            Assert.assertEquals(orderCreateApiPlainResult.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResult.getData().getPayOrderId(), orderCreateApiPlainResult.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResult.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResult.getData().getPayOrderId()));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证员工服务期
            checkAppStatusWithAppIs(staffKdtId, 1, 1, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");

        } catch (Exception e) {
            logger.info("test_newBuyStaff--case--异常：" + e.getMessage());
            if(orderCreateApiPlainResult==null || orderCreateApiPlainResult.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }
        } finally {
            if (orderCreateApiPlainResult != null && orderCreateApiPlainResult.getCode() == 200 && orderCreateApiPlainResult.getData().getPayOrderId() != null) {
                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResult.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_newBuyStaff_0--end:" + new Date());
        }


    }

    /**
     * 店铺员工->增购员工增购
     * <p>
     * 微商城增购店铺员工
     * 验证新购服务期&员工个数
     * <p>
     * 1.创建员工订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证员工订购个数
     * 5.验证员工服务期
     * 6.验证员工购买标签为新签
     * 7.增购员工
     * 8.调用预支付
     * 9.支付订单
     * 10.验证员工订购个数
     * 11.验证员工服务期
     * 12.验证员工购买标签为增购
     */
    @Test(priority = 1)
    public void test_addBuyStaff_1() {
        logger.info("\ntest_addBuyStaff_1--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultAdd = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(staffKdtId);
            //存在店铺员工订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(staffKdtId, Long.valueOf(ItemInfo.STAFF_YEARS.getAppId()), "", "BY_VALUE", new Date());
            String createNewStaffDataFilePath = "src/test/resources/dataResource/basecase.plugin/staffnewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewStaffDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(staffKdtId);
            //1.创建员工订单，订购5个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            PreOrderPayRequest preOrderPayRequest = new PreOrderPayRequest();
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
//        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
//                .inSql("biz_order_id","select td_no from td_order where id="+orderCreateApiPlainResult.getData().getPayOrderId()+""));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证员工服务期
            checkAppStatusWithAppIs(staffKdtId, 1, 1, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");
            Thread.sleep(1000);
            //6.增购员工,增购6个
            OrderItemForm orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 3);
            orderItemForm.setQuantity(6);
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultAdd = createOrder(createOrderForm);
            if (orderCreateApiPlainResultAdd == null) {
                return;
            }
            logger.info("test_addBuyStaff_1+orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);
            if (orderCreateApiPlainResultAdd.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(staffKdtId, orderCreateApiPlainResultAdd.getData().getPayOrderId());
                orderCreateApiPlainResultAdd = createOrder(createOrderForm);
                if (orderCreateApiPlainResultAdd == null) {
                    return;
                }
                logger.info("增购并续费员工创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            }

            Assert.assertEquals(orderCreateApiPlainResultAdd.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultAdd.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultAdd.getData().getPayOrderId(), orderCreateApiPlainResultAdd.getMessage());
            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultAdd.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultAdd.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("6"));
            //4.验证员工服务期
            checkAppStatusWithAppIs(staffKdtId, 1, 1, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为增购
            Assert.assertEquals(pfOrder.getBuyType(), "add_sign");


        } catch (Exception e) {
            logger.info("test_AddBuyStaff--case--异常：" + e.getMessage());
        } finally {
            System.out.println("orderCreateApiPlainResultAdd：" + orderCreateApiPlainResultAdd);
            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultAdd == null || orderCreateApiPlainResultAdd.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }
            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultAdd != null && orderCreateApiPlainResultAdd.getCode() == 200 && orderCreateApiPlainResultAdd.getData().getPayOrderId() != null) {

                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultAdd.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_addBuyStaff_1--end:" + new Date());
        }


    }

    /**
     * 店铺员工->续费店铺员工
     * <p>
     * 微商城增购店铺员工
     * 验证新购服务期&员工个数
     * <p>
     * 1.创建员工订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证员工订购个数
     * 5.验证员工服务期
     * 6.验证员工购买标签为新签
     * 7.续费员工
     * 8.调用预支付
     * 9.支付订单
     * 10.验证员工订购个数
     * 11.验证员工服务期
     * 12.验证员工购买标签为续费
     */

    @Test(priority = 2)
    public void test_ReNewBuyStaff_2() {
        logger.info("\ntest_ReNewBuyStaff_2--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultReNew = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(staffKdtId);
            //存在店铺员工订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(staffKdtId, Long.valueOf(ItemInfo.STAFF_YEARS.getAppId()), "", "BY_VALUE", new Date());
            String createNewStaffDataFilePath = "src/test/resources/dataResource/basecase.plugin/staffnewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewStaffDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(staffKdtId);
            //1.创建员工订单，订购5个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            PreOrderPayRequest preOrderPayRequest = new PreOrderPayRequest();
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
//        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
//                .inSql("biz_order_id","select td_no from td_order where id="+orderCreateApiPlainResult.getData().getPayOrderId()+""));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证员工服务期
            checkAppStatusWithAppIs(staffKdtId, 1, 1, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");
            logger.info("check end ----------");
            Thread.sleep(1000);
            //6.续费员工,续费10个
            OrderItemForm orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 2);
            orderItemForm.setQuantity(10);
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);

            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultReNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultReNew.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(staffKdtId, orderCreateApiPlainResultReNew.getData().getPayOrderId());
                orderCreateApiPlainResultReNew = createOrder(createOrderForm);
                if (orderCreateApiPlainResultReNew == null) {
                    return;
                }
                logger.info("增购并续费员工创建订单失败：" + orderCreateApiPlainResultReNew.getMessage());
            }

            Assert.assertEquals(orderCreateApiPlainResultReNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultReNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultReNew.getData().getPayOrderId(), orderCreateApiPlainResultReNew.getMessage());

            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultReNew.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultReNew.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("10"));
            //4.验证员工服务期，2年
            Thread.sleep(500);
            checkAppStatusWithAppIs(staffKdtId, 1, 2, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为续费
            Assert.assertEquals(pfOrder.getBuyType(), "renew_sign");


        } catch (Exception e) {
            logger.info("test_reNewBuyStaff--case--异常：" + e.getMessage());
        } finally {
            logger.info("orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultReNew);
            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultReNew==null || orderCreateApiPlainResultReNew.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }

            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultReNew != null && orderCreateApiPlainResultReNew.getCode() == 200 && orderCreateApiPlainResultReNew.getData().getPayOrderId() != null) {

                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultReNew.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_ReNewBuyStaff_2--end:" + new Date());
        }


    }

    /**
     * 店铺员工->续费后增购员工
     * <p>
     * 微商城增购店铺员工
     * 验证新购服务期&员工个数
     * <p>
     * 1.创建员工订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证员工订购个数
     * 5.验证员工服务期
     * 6.验证员工购买标签为新签
     * 7.续费员工
     * 8.调用预支付
     * 9.支付订单
     * 10.验证员工订购个数
     * 11.验证员工服务期
     * 12.验证员工购买标签为续费
     * 13.增购员工
     * 14.调用预支付
     * 15.支付订单
     * 16.验证员工服务期
     * 17.验证员工购买标签为增购
     * 18.验证员工个数
     */
    @Test(priority = 3)
    public void test_ReNewBuyStaffWithAdd_3() {
        logger.info("\ntest_ReNewBuyStaffWithAdd_3--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultReNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultAdd = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(staffKdtId);
            //存在店铺员工订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(staffKdtId, Long.valueOf(ItemInfo.STAFF_YEARS.getAppId()), "", "BY_VALUE", new Date());
            String createNewStaffDataFilePath = "src/test/resources/dataResource/basecase.plugin/staffnewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewStaffDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(staffKdtId);
            //1.创建员工订单，订购5个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            PreOrderPayRequest preOrderPayRequest = new PreOrderPayRequest();
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
//        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
//                .inSql("biz_order_id","select td_no from td_order where id="+orderCreateApiPlainResult.getData().getPayOrderId()+""));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证员工服务期
            checkAppStatusWithAppIs(staffKdtId, 1, 1, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");

            //6.续费员工,续费10个
            Thread.sleep(1000);
            OrderItemForm orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 2);
            orderItemForm.setQuantity(10);
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);

            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultReNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultReNew == null) {
                return;
            }
            logger.info("test_ReNewBuyStaffWithAdd_3+orderCreateApiPlainResultReNew:" + orderCreateApiPlainResultReNew);
            if (orderCreateApiPlainResultReNew.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(staffKdtId, orderCreateApiPlainResultReNew.getData().getPayOrderId());
                orderCreateApiPlainResultReNew = createOrder(createOrderForm);
                if (orderCreateApiPlainResultReNew == null) {
                    return;
                }
                logger.info("增购并续费员工创建订单失败：" + orderCreateApiPlainResultReNew.getMessage());
            }
            Assert.assertEquals(orderCreateApiPlainResultReNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultReNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultReNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultReNew.getData().getPayOrderId(), orderCreateApiPlainResultReNew.getMessage());
            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultReNew.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultReNew.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("10"));
            //4.验证员工服务期，2年
            checkAppStatusWithAppIs(staffKdtId, 1, 2, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为续费
            Assert.assertEquals(pfOrder.getBuyType(), "renew_sign");

            //7.增购员工,增购20个
            Thread.sleep(1000);
            orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 3);
            orderItemForm.setQuantity(20);
            orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultAdd = createOrder(createOrderForm);
            if (orderCreateApiPlainResultAdd == null) {
                return;
            }
            logger.info("test_ReNewBuyStaffWithAdd_3+orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);
            if (orderCreateApiPlainResultAdd.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(staffKdtId, orderCreateApiPlainResultAdd.getData().getPayOrderId());
                orderCreateApiPlainResultAdd = createOrder(createOrderForm);
                if (orderCreateApiPlainResultAdd == null) {
                    return;
                }
                logger.info("增购并续费员工创建订单失败:" + orderCreateApiPlainResultAdd.getMessage());

            }
            Assert.assertEquals(orderCreateApiPlainResultAdd.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultAdd.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultAdd.getData().getPayOrderId(), orderCreateApiPlainResultAdd.getMessage());


            //8.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultAdd.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultAdd.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //9.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("20"));
            //10.验证员工服务期，2年
            checkAppStatusWithAppIs(staffKdtId, 1, 2, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //11.验证员工购买标签为增购
            Assert.assertEquals(pfOrder.getBuyType(), "add_sign");


        } catch (Exception e) {
            logger.info("test_ReNewBuyStaffWithAdd--case--异常:" + e.getMessage());
        } finally {
            logger.info("orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);
            logger.info("orderCreateApiPlainResultReNew:" + orderCreateApiPlainResultReNew);
            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultReNew==null || orderCreateApiPlainResultReNew.getData()==null
                    || orderCreateApiPlainResultAdd == null || orderCreateApiPlainResultAdd.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }

            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultReNew != null && orderCreateApiPlainResultReNew.getCode() == 200 && orderCreateApiPlainResultReNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultAdd != null && orderCreateApiPlainResultAdd.getCode() == 200 && orderCreateApiPlainResultAdd.getData().getPayOrderId() != null
            ) {

                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultReNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultAdd.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_ReNewBuyStaffWithAdd_3--end:" + new Date());
        }
    }


    /**
     * 店铺员工->增购并续费员工增购
     * <p>
     * 微商城增购店铺员工
     * 验证新购服务期&员工个数
     * <p>
     * 1.创建员工订单，包含5个员工
     * 2.调用预支付
     * 3.支付订单
     * 4.验证员工订购个数
     * 5.验证员工服务期
     * 6.验证员工购买标签为新签
     * 7.平移服务期，使得服务期剩余小于30天
     * 8.增购10个，选择增购并续费
     * 9.则实际产生2笔订单，增购的为10个，续费的为10+5=15个
     * 10.验证员工订购个数
     * 11.验证员工服务期
     * 12.验证员工购买标签分别为增购和续费
     * 13.退款
     */
    @Test(priority = 4)
    public void test_addAndReNewBuyStaff_4() {
        logger.info("\ntest_addAndReNewBuyStaff_4--start" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultAdd = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(staffKdtId);
            //存在店铺员工订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(staffKdtId, Long.valueOf(ItemInfo.STAFF_YEARS.getAppId()), "", "BY_VALUE", new Date());
            Thread.sleep(500);
            String createNewStaffDataFilePath = "src/test/resources/dataResource/basecase.plugin/staffnewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewStaffDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(staffKdtId);
            //1.创建员工订单，订购5个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证员工订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证员工服务期
            checkAppStatusWithAppIs(staffKdtId, 1, 1, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //5.验证员工购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");

            //平移服务期，使得服务期小于30天
            Thread.sleep(1000);
            moveAppStatus(staffKdtId, "atom_spu_shop_staff", 345);

            String createAddAndRenewStaffDataFilePath = "src/test/resources/dataResource/basecase.plugin/staffAddAndRenewCreateData.json";
            CreateOrderForm createOrderFormAdd = JsonCovertUntil.getObjectFromjson(createAddAndRenewStaffDataFilePath, CreateOrderForm.class);
            createOrderFormAdd.setUserId(userId);
            createOrderFormAdd.setKdtId(staffKdtId);
            PreferentialDescApi preferentialDescApi = new PreferentialDescApi();
            preferentialDescApi.setPromotionId(57L);
            preferentialDescApi.setType((byte) 21);
            preferentialDescApi.setName("店铺员工循环满减 每满10减1-自动化测试专用勿删");
            List<PreferentialDescApi> preferentialDescApiList = new ArrayList<>(1);
            preferentialDescApiList.add(preferentialDescApi);
//            createOrderFormAdd.setOrderPromotionList(preferentialDescApiList);

            //6.增购并续费员工,增购10个，续费15个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultAdd = createOrder(createOrderFormAdd);
            if (orderCreateApiPlainResultAdd == null) {
                return;
            }
            if (orderCreateApiPlainResultAdd.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(staffKdtId, orderCreateApiPlainResultAdd.getData().getPayOrderId());
                orderCreateApiPlainResultAdd = createOrder(createOrderForm);
                if (orderCreateApiPlainResultAdd == null) {
                    return;
                }
                logger.info("增购并续费员工创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            }
            Assert.assertEquals(orderCreateApiPlainResultAdd.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultAdd.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultAdd.getData().getPayOrderId(), orderCreateApiPlainResultAdd.getMessage());
            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultAdd.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, staffKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultAdd.getData().getPayOrderId()));
            //9.验证生成2笔子订单
            List<PfOrder> pfOrderList = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            Assert.assertEquals(pfOrderList.size(), 2);

            //获取续费的订单
            PfOrder renewPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("item_id", "atom_sku_shop_staff_year"));
            //获取增购的订单
            PfOrder addPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("item_id", "atom_sku_shop_staff_day"));

            //10.验证增购的个数
            Assert.assertTrue(JSONObject.parseObject(addPfOrder.getBizExt()).get("quantity").equals("10"));
            //11.验证续费的个数
            Assert.assertTrue(JSONObject.parseObject(renewPfOrder.getBizExt()).get("quantity").equals("15"));


            //12.验证员工服务期（385=20（增购的天数）+365（续费的天数））
            checkAppStatusWithAppIs(staffKdtId, 6, 385, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));
            //13.分别验证员工购买标签为增购和续费
            Assert.assertEquals(addPfOrder.getBuyType(), "add_sign");
            Assert.assertEquals(renewPfOrder.getBuyType(), "renew_sign");


        } catch (Exception e) {
            logger.info("test_addAndReNewBuyStaff--case--异常:" + e.getMessage());
        } finally {
            System.out.println("orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);

            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultAdd == null || orderCreateApiPlainResultAdd.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }

            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultAdd != null && orderCreateApiPlainResultAdd.getCode() == 200 && orderCreateApiPlainResultAdd.getData().getPayOrderId() != null) {
                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(staffKdtId, null, String.valueOf(orderCreateApiPlainResultAdd.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_addAndReNewBuyStaff_4--end" + new Date());
        }

    }

  /*  @BeforeClass
    public void beforeClass() {
        rechargeShopBalance(String.valueOf(staffKdtId),99999);
    }*/
    @BeforeMethod
        public void beforeMethod(){
        try {
            rechargeShopBalance(String.valueOf(staffKdtId),9999);
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
