package com.youzan.test.protocol.apicase.yop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.cloudService.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.ProtocolsRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.protocol.NeedAdminSignApi;
import com.youzan.yop.api.entity.protocol.ProtocolsApi;
import com.youzan.yop.api.form.protocol.ProtocolParams;
import com.youzan.yop.api.form.protocol.ProtocolsDownloadForm;
import com.youzan.yop.api.form.protocol.ProtocolsRequestForm;
import com.youzan.yop.api.request.BatchQueryAgreementsRequest;
import com.youzan.yop.api.request.QueryProtocolDetailRequest;
import com.youzan.yop.api.request.QueryProtocolIdsRequest;
import com.youzan.yop.api.request.QueryProtocolListPageRequest;
import com.youzan.yop.api.response.BatchQueryAgreementsResponse;
import com.youzan.yop.api.response.QueryProtocolIdsResponse;
import com.youzan.yop.api.response.dto.ProtocolDTO;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wulei
 * @date 2021/11/26 11:24
 */
public class ProtocolsRemoteServiceTest extends YunBaseTest {
    @Dubbo
    private ProtocolsRemoteService protocolsRemoteService;

    // 获取服务协议分页记录
    @Test
    public void listProtocolsWithAggregationTest() {
        ProtocolsRequestForm request = new ProtocolsRequestForm();
        request.setKdtId(63014707L);
        PlainResult<PageApi<ArrayList<List<ProtocolsApi>>>>  result = protocolsRemoteService.listProtocolsWithAggregation(request);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getTotal(), 9);
    }

    // 查询协议详情：protocols表
    @Test
    public void getProtocolDetailTest() {
        PlainResult<ProtocolsApi>  result = protocolsRemoteService.getProtocolDetail(63014707L,"311637897644468",623138L);
        Assert.assertEquals(result.getCode(), 200);
    }

    // 打印记录
    @Test
    public void recordProtocolDownloadTest() {
        ProtocolsDownloadForm request = new ProtocolsDownloadForm();
        request.setKdtId(63014707L);
        request.setProtocolId(623138L);
        request.setProtocolName("有赞微商城订购及服务协议-非常不权威版");
        request.setAdminId(15601678473L);
        PlainResult<Integer>  result = protocolsRemoteService.recordProtocolDownload(request);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertTrue(result.getData()>=1);
    }

    // 根据id获取正文详情
    @Test
    public void getContextTest() {
        PlainResult<ProtocolsApi>  result = protocolsRemoteService.getContext(63014707L,623138L);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getAppId(), Integer.valueOf(873));
        Assert.assertEquals(result.getData().getItemId(), Integer.valueOf(8533));
        Assert.assertEquals(result.getData().getPartyB(), "杭州有赞科技有限公司");
    }

    // 查询详情：序列化错误
//    @Test
//    public void listProtocolDetailByQueryParamsTest() {
//        ProtocolParams request = new ProtocolParams();
//        request.setKdtId(63014707L);
//        PlainResult<List<ProtocolsApi>>  result = protocolsRemoteService.listProtocolDetailByQueryParams(request);
//        Assert.assertEquals(result.getCode(), 200);
//    }

    // batchQueryAgreementsByTypes :{"channel":"YZYUN","sceneTypes":null,"agreementIds":[346]}
    @Test
    public void batchQueryAgreementsByTypesTest() {
        BatchQueryAgreementsRequest request = new BatchQueryAgreementsRequest();
        request.setChannel("YZYUN");
        request.setAgreementIds(Arrays.asList(346L));
        PlainResult<BatchQueryAgreementsResponse>  result = protocolsRemoteService.batchQueryAgreementsByTypes(request);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getAgreementsMap().size()==1, true);
    }

    @Test
    public void listProtocolsForPageTest() {
        QueryProtocolListPageRequest request = new QueryProtocolListPageRequest();
        request.setStatus(Byte.valueOf("1"));
        request.setOwnerYcmId("combine_spu_wsc");
        PlainResult<PageApi<ProtocolDTO>>  result = protocolsRemoteService.listProtocolsForPage(request);
        Assert.assertEquals(result.getCode(), 200);
    }

    @Test
    public void queryProtocolsIdsTest() {
        QueryProtocolIdsRequest request = new QueryProtocolIdsRequest();
        request.setOwnerYcmId("combine_spu_wsc");
        request.setAgreementIds(Arrays.asList(346L));
        PlainResult<QueryProtocolIdsResponse>  result = protocolsRemoteService.queryProtocolsIds(request);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getProtocolIds().size()==10, true);
    }

    @Test
    public void needAdminSignByPayOrderIdTest() {
        PlainResult<List<NeedAdminSignApi>>  result = protocolsRemoteService.needAdminSignByPayOrderId(Arrays.asList(6641498347268079616L));
        Assert.assertEquals(result.getCode(), 200);
    }

    @Test
    public void needAdminSignTest() {
        PlainResult<NeedAdminSignApi>  result = protocolsRemoteService.needAdminSign(6641498347268079616L,null);
        Assert.assertEquals(result.getCode(), 200);
    }

    @Test
    public void updateAdminSignByKdtIdTest() {
        PlainResult<Boolean>  result = protocolsRemoteService.updateAdminSignByKdtId(6641498347268079616L,null);
        Assert.assertEquals(result.getCode(), 200);
    }

    @Test
    public void queryProtocolDetailForYzYunTest() {
        QueryProtocolDetailRequest request = new QueryProtocolDetailRequest();
        request.setOwnerYcmId("combine_spu_wsc");
        PlainResult<ProtocolsApi>  result = protocolsRemoteService.queryProtocolDetailForYzYun(request);
        Assert.assertEquals(result.getCode(), 200);
    }

}
