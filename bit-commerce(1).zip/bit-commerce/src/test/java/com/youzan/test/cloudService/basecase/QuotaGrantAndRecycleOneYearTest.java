package com.youzan.test.cloudService.basecase;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * Created by wulei on 2020-07-27.
 */
public class QuotaGrantAndRecycleOneYearTest extends YunBaseTest {
    /**
     * 场景：
     * 1、订购微商城基础版1年期；
     * 2、查询计费侧额度是否正常发放；
     * 3、判断是否可以预支；
     * 4、退款；
     * 5、查询计费测额度是否正常回收；
     * 6、继续订购微商城专业版两年期；
     * 7、查询计费侧额度是否正常发放，查询商业化侧是否生成延期发放记录；
     * 8、判断当前店铺是否可以预支；
     * 9、预支额度；
     * 10、查询计费侧额度是否正常发放；
     * 11、重复预支；
     * 12、退款；
     * 13、查询计费测额度是否正常回收。
     */
    @Test
    public void testQuatoGrantAndRecycle() {

        long yunKdtId1 = newWscKdtId();

        PlainResult<OrderCreateApi> result1 = testCreateOrder(yunKdtId1, yunKdtName1, wscWXItemId_2021, 1);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  查询计费额度是否成功发放
        testQueryTotalQuota(yunKdtId1, 10000);
        //  判断是否可以预支额度
        //    testCanAdvanceOrderQuota(yunKdtId1.toString(), "KDT_ID", false);

        //  退款
        Long payOrderId = result1.getData().getPayOrderId();

        refundOrderNew(payOrderId, new Date(), 0L, 0L, "BY_MANUAL");

        // 查看计费侧额度是否正常回收
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId1, 0);

        //  手动回收额度
        //    testQuotaByRefund(yunKdtId1,311596125650314L,3158694128734521038L);

    }

}



