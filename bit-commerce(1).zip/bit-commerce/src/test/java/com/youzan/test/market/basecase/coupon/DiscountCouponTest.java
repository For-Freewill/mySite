package com.youzan.test.market.basecase.coupon;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.coupon.*;
import com.youzan.commerce.test.entity.enums.market.coupon.CouponStateEnum;
import com.youzan.commerce.test.mapper.market.coupon.*;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.ycm.market.api.CouponRemoteService;
import com.youzan.ycm.market.api.CouponSendRemoteService;
import com.youzan.ycm.market.dto.coupon.AllCouponDTO;
import com.youzan.ycm.market.dto.coupon.CouponAdmittanceExtDTO;
import com.youzan.ycm.market.dto.rule.GoodsDiscountRuleDTO;
import com.youzan.ycm.market.request.coupon.QueryCouponRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.request.coupon.UpdateCouponStateRequest;
import com.youzan.ycm.market.request.couponsend.SaveSendCouponRequest;
import com.youzan.ycm.market.request.couponsend.SendCouponAssetRequest;
import com.youzan.ycm.market.response.coupon.SaveCouponResponse;
import com.youzan.ycm.market.response.coupon.UpdateCouponStateResponse;
import com.youzan.ycm.market.response.couponsend.SaveCouponSendRecordResponse;
import com.youzan.ycm.market.response.couponsend.SendCouponResponse;
import com.youzan.yop.api.entity.order.CalOrderPriceApi;
import com.youzan.yop.api.form.order.CalOrderPriceForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.response.ItemPreferentialInfoResultApi;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by baoyan on 2021-01-11.
 */
public class DiscountCouponTest extends YunBaseTest {
    @Dubbo
    private CouponRemoteService couponRemoteService;
    @Dubbo
    private CouponSendRemoteService couponSendRemoteService;


    @Autowired(required = false)
    private CouponRuleMapper couponRuleMapper;

    @Autowired(required = false)
    private CouponMapper couponMapper;

    @Autowired(required = false)
    private CouponSendRecordMapper couponSendRecordMapper;

    @Autowired(required = false)
    private CouponAssetMapper couponAssetMapper;

    @Autowired(required = false)
    private CouponSnapshotMapper couponSnapshotMapper;
    @JSONData("dataResource/basecase.activity/couponSendRecord.json")
    private SaveSendCouponRequest saveSendCouponRequest;

    private String saveCouponRequestJsonPath = "src/test/resources/data/market/coupon/discountCouponRequest.json";
    private String couponNamePrefix = "by测试";
    private String couponName = couponNamePrefix + new Random().nextInt(10000);
    private String kdtWSC = "58817788";
    private String kdtLS = "58819626";
    private String kdtJY = "58819630";
    private String kdtJYLS = "58819538";
    private String kdtMYLS = "58819641";
    private String kdtLSLS = "58819640";
    private String kdtRenew = "58816633";

    private String appId = "445427";
    private String itemId = "73766";
    private String itemId1 = "73771";

    private String couponAppId = "atom_spu_plugin_2021011212044116";
    private String couponItemId = "atom_sku_2021011212044172_year";



    @BeforeMethod
    public void beforeMethod() {
        logger.info("before method 清理数据");
        deleteCouponByCouponNamePrefix(couponNamePrefix);
    }

    /**
     * 产品线验证
     * 权益：支持微商城&零售单店产品线
     * 验证微商城可用，零售单店可用，教育单店，美业连锁，教育连锁，零售连锁不可用
     */
    @Test
    public void couponDiscountProlineTest() {
        //准备打折券权益数据
        SaveCouponRequest saveCouponRequest = JsonCovertUntil.getObjectFromjson(saveCouponRequestJsonPath, SaveCouponRequest.class);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);
        List<GoodsDiscountRuleDTO> discountRuleList = new ArrayList<>();
        GoodsDiscountRuleDTO goodsDiscountRuleDTO = new GoodsDiscountRuleDTO();
        goodsDiscountRuleDTO.setAppId(couponAppId);
        goodsDiscountRuleDTO.setItemId(couponItemId);
        goodsDiscountRuleDTO.setDiscount(9000l);
        goodsDiscountRuleDTO.setMeetQuantity(1l);
        discountRuleList.add(goodsDiscountRuleDTO);
        allCouponDTO.getGoodsDiscountCouponExtDTO().setDiscountRuleList(discountRuleList);
        CouponAdmittanceExtDTO couponAdmittanceExtDTO = new CouponAdmittanceExtDTO();
        //"FIRST", "REORDER", "SIGN_BACK";
        couponAdmittanceExtDTO.setBuyerTags(Arrays.asList("FIRST"));
        List<String> productChannel = new ArrayList<>();
        productChannel.add("WSC");
        productChannel.add("RETAIL");
        couponAdmittanceExtDTO.setProductChannels(productChannel);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);

        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = result.getData().getAllCouponDTO().getCouponId();
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result));

        //验证已经创建的打折券权益状态为：待上架
        QueryCouponRequest queryCouponRequest = new QueryCouponRequest();
        queryCouponRequest.setCouponId(couponId);
        PlainResult<AllCouponDTO> allCouponDTOResult = couponRemoteService.queryCouponById(queryCouponRequest);
        Assert.assertTrue(allCouponDTOResult.isSuccess(), "查询权益券失败！");
        Assert.assertEquals(allCouponDTOResult.getData().getCouponState(), CouponStateEnum.WAIT_EFFECT.getAlias());
        updateCouponState(couponId);

        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(Integer.valueOf(itemId), 1);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        //  微商城店铺可使用
        generateSendRecordAndSendCoupon(couponId, couponName, kdtWSC);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(Long.parseLong(kdtWSC), 1, Integer.valueOf(itemId), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResult.getCode(), 200);
        Assert.assertEquals(itemPreferentialInfoResult.getData().get(0).getItemId().toString(), itemId);
        Assert.assertEquals(itemPreferentialInfoResult.getData().get(0).getPromotionList().get(0).getName(), couponName);

        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtWSC), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResult));
        Assert.assertEquals(calOrderPriceApiPlainResult.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemId().toString(), itemId);
        Assert.assertTrue(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemPromotionList().size() > 0);
        Assert.assertEquals(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemPromotionList().get(0).getName(), couponName);

        //  零售单店可使用
        generateSendRecordAndSendCoupon(couponId, couponName, kdtLS);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResultLS = fetchItemPreferentialInfoOnline(Long.parseLong(kdtLS), 1, Integer.valueOf(itemId), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResultLS.getCode(), 200);
        Assert.assertEquals(itemPreferentialInfoResultLS.getData().get(0).getItemId().toString(), itemId);
        Assert.assertEquals(itemPreferentialInfoResultLS.getData().get(0).getPromotionList().get(0).getName(), couponName);
        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceFormLS = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtLS), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResultLS = orderRemoteService.calOrderPrice(calOrderPriceFormLS);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResultLS));
        Assert.assertEquals(calOrderPriceApiPlainResultLS.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResultLS.getData().getItems().get(0).getItemId().toString(), itemId);
        Assert.assertTrue(calOrderPriceApiPlainResultLS.getData().getItems().get(0).getItemPromotionList().size() > 0);
        Assert.assertEquals(calOrderPriceApiPlainResultLS.getData().getItems().get(0).getItemPromotionList().get(0).getName(), couponName);

        //  教育单店不可使用
        generateSendRecordAndSendCoupon(couponId, couponName, kdtJY);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResultJY = fetchItemPreferentialInfoOnline(Long.parseLong(kdtJY), 1, Integer.valueOf(itemId), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResultJY.getCode(), 200);
        logger.info(itemPreferentialInfoResultJY.toString());
        Assert.assertTrue(itemPreferentialInfoResultJY.getData().size() == 0);
        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceFormoJY = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtJY), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResultJY = orderRemoteService.calOrderPrice(calOrderPriceFormoJY);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResultJY));
        Assert.assertEquals(calOrderPriceApiPlainResultJY.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResultJY.getData().getItems().get(0).getItemId().toString(), itemId);
        Assert.assertTrue(calOrderPriceApiPlainResultJY.getData().getItems().get(0).getItemPromotionList().size() == 0);

        //  教育连锁不可使用
        generateSendRecordAndSendCoupon(couponId,couponName,kdtJYLS);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResultJYLS = fetchItemPreferentialInfoOnline(Long.parseLong(kdtJYLS),1,Integer.valueOf(itemId),1,1);
        Assert.assertEquals(itemPreferentialInfoResultJYLS.getCode(),200);
        logger.info(itemPreferentialInfoResultJYLS.toString());
        Assert.assertTrue(itemPreferentialInfoResultJYLS.getData().size() == 0);
        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceFormoJYLS = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtJYLS), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResultJYLS = orderRemoteService.calOrderPrice(calOrderPriceFormoJYLS);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResultJYLS));
        Assert.assertEquals(calOrderPriceApiPlainResultJYLS.getCode(),200);
        Assert.assertEquals(calOrderPriceApiPlainResultJYLS.getData().getItems().get(0).getItemId().toString(),itemId);
        Assert.assertTrue(calOrderPriceApiPlainResultJYLS.getData().getItems().get(0).getItemPromotionList().size()==0);

        //  零售连锁不可使用
        generateSendRecordAndSendCoupon(couponId,couponName,kdtLSLS);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResultLSLS = fetchItemPreferentialInfoOnline(Long.parseLong(kdtLSLS),1,Integer.valueOf(itemId),1,1);
        Assert.assertEquals(itemPreferentialInfoResultLSLS.getCode(),200);
        logger.info(itemPreferentialInfoResultLSLS.toString());
        Assert.assertTrue(itemPreferentialInfoResultLSLS.getData().size() == 0);
        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceFormoLSLS = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtLSLS), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResultLSLS = orderRemoteService.calOrderPrice(calOrderPriceFormoLSLS);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResultLSLS));
        Assert.assertEquals(calOrderPriceApiPlainResultLSLS.getCode(),200);
        Assert.assertEquals(calOrderPriceApiPlainResultLSLS.getData().getItems().get(0).getItemId().toString(),itemId);
        Assert.assertTrue(calOrderPriceApiPlainResultLSLS.getData().getItems().get(0).getItemPromotionList().size()==0);

        //  美业连锁不可使用
        generateSendRecordAndSendCoupon(couponId,couponName,kdtMYLS);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResultMYLS = fetchItemPreferentialInfoOnline(Long.parseLong(kdtMYLS),1,Integer.valueOf(itemId),1,1);
        Assert.assertEquals(itemPreferentialInfoResultMYLS.getCode(),200);
        logger.info(itemPreferentialInfoResultMYLS.toString());
        Assert.assertTrue(itemPreferentialInfoResultMYLS.getData().size() == 0);
        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceFormoMYLS = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtMYLS), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResultMYLS = orderRemoteService.calOrderPrice(calOrderPriceFormoMYLS);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResultMYLS));
        Assert.assertEquals(calOrderPriceApiPlainResultMYLS.getCode(),200);
        Assert.assertEquals(calOrderPriceApiPlainResultMYLS.getData().getItems().get(0).getItemId().toString(),itemId);
        Assert.assertTrue(calOrderPriceApiPlainResultMYLS.getData().getItems().get(0).getItemPromotionList().size()==0);
    }

    /**
     * 仅打折券的场景->打折用户标签验证
     *
     * 权益：仅支持新签商家
     * 验证新签商家可用，续签时不可用
     */
    @Test
    public void couponDiscountNewSignTest() {
        //准备打折券权益数据
        SaveCouponRequest saveCouponRequest = JsonCovertUntil.getObjectFromjson(saveCouponRequestJsonPath, SaveCouponRequest.class);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);
        List<GoodsDiscountRuleDTO> discountRuleList = new ArrayList<>();
        GoodsDiscountRuleDTO goodsDiscountRuleDTO = new GoodsDiscountRuleDTO();
        goodsDiscountRuleDTO.setAppId(couponAppId);
        goodsDiscountRuleDTO.setItemId(couponItemId);
        goodsDiscountRuleDTO.setDiscount(9000l);
        goodsDiscountRuleDTO.setMeetQuantity(1l);
        discountRuleList.add(goodsDiscountRuleDTO);
        allCouponDTO.getGoodsDiscountCouponExtDTO().setDiscountRuleList(discountRuleList);
        CouponAdmittanceExtDTO couponAdmittanceExtDTO = new CouponAdmittanceExtDTO();
        //"FIRST", "REORDER", "SIGN_BACK";
        couponAdmittanceExtDTO.setBuyerTags(Arrays.asList("FIRST"));
        List<String> productChannel = new ArrayList<>();
        productChannel.add("WSC");
        couponAdmittanceExtDTO.setProductChannels(productChannel);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);
        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = result.getData().getAllCouponDTO().getCouponId();
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result));

        //验证已经创建的打折券权益状态为：待上架
        QueryCouponRequest queryCouponRequest = new QueryCouponRequest();
        queryCouponRequest.setCouponId(couponId);
        PlainResult<AllCouponDTO> allCouponDTOResult = couponRemoteService.queryCouponById(queryCouponRequest);
        Assert.assertTrue(allCouponDTOResult.isSuccess(), "查询权益券失败！");
        Assert.assertEquals(allCouponDTOResult.getData().getCouponState(), CouponStateEnum.WAIT_EFFECT.getAlias());
        updateCouponState(couponId);

        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(Integer.valueOf(itemId), 1);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);
        //  新签店铺可使用
        generateSendRecordAndSendCoupon(couponId, couponName, kdtWSC);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(Long.parseLong(kdtWSC), 1, Integer.valueOf(itemId), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResult.getCode(), 200);
        Assert.assertEquals(itemPreferentialInfoResult.getData().get(0).getItemId().toString(), itemId);
        Assert.assertEquals(itemPreferentialInfoResult.getData().get(0).getPromotionList().get(0).getName(), couponName);

        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtWSC), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResult));
        Assert.assertEquals(calOrderPriceApiPlainResult.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemId().toString(), itemId);
        Assert.assertTrue(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemPromotionList().size() > 0);
        Assert.assertEquals(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemPromotionList().get(0).getName(), couponName);

        //  续签店铺不可使用
        generateSendRecordAndSendCoupon(couponId,couponName,kdtRenew);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResultRenew = fetchItemPreferentialInfoOnline(Long.parseLong(kdtRenew),1,Integer.valueOf(itemId),1,1);
        Assert.assertEquals(itemPreferentialInfoResultRenew.getCode(),200);
        logger.info(itemPreferentialInfoResultRenew.toString());
        Assert.assertTrue(itemPreferentialInfoResultRenew.getData().size() == 0);
        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceFormoRenew = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtRenew), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResultRenew = orderRemoteService.calOrderPrice(calOrderPriceFormoRenew);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResultRenew));
        Assert.assertEquals(calOrderPriceApiPlainResultRenew.getCode(),200);
        Assert.assertEquals(calOrderPriceApiPlainResultRenew.getData().getItems().get(0).getItemId().toString(),itemId);
        Assert.assertTrue(calOrderPriceApiPlainResultRenew.getData().getItems().get(0).getItemPromotionList().size()==0);

    }

    /**
     * 仅打折券的场景->打折用户标签验证
     *
     * 权益：仅支持续签商家
     * 验证续签商家可用，新签时不可用
     */
    @Test
    public void couponDiscountReNewSignTest() {
        //准备打折券权益数据
        SaveCouponRequest saveCouponRequest = JsonCovertUntil.getObjectFromjson(saveCouponRequestJsonPath, SaveCouponRequest.class);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);
        List<GoodsDiscountRuleDTO> discountRuleList = new ArrayList<>();
        GoodsDiscountRuleDTO goodsDiscountRuleDTO = new GoodsDiscountRuleDTO();
        goodsDiscountRuleDTO.setAppId(couponAppId);
        goodsDiscountRuleDTO.setItemId(couponItemId);
        goodsDiscountRuleDTO.setDiscount(9000l);
        goodsDiscountRuleDTO.setMeetQuantity(1l);
        discountRuleList.add(goodsDiscountRuleDTO);
        allCouponDTO.getGoodsDiscountCouponExtDTO().setDiscountRuleList(discountRuleList);
        CouponAdmittanceExtDTO couponAdmittanceExtDTO = new CouponAdmittanceExtDTO();
        //"FIRST", "REORDER", "SIGN_BACK";
        couponAdmittanceExtDTO.setBuyerTags(Arrays.asList("REORDER"));
        List<String> productChannel = new ArrayList<>();
        productChannel.add("WSC");
        productChannel.add("RETAIL");
        couponAdmittanceExtDTO.setProductChannels(productChannel);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);
        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = result.getData().getAllCouponDTO().getCouponId();
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result));

        //验证已经创建的打折券权益状态为：待上架
        QueryCouponRequest queryCouponRequest = new QueryCouponRequest();
        queryCouponRequest.setCouponId(couponId);
        PlainResult<AllCouponDTO> allCouponDTOResult = couponRemoteService.queryCouponById(queryCouponRequest);
        Assert.assertTrue(allCouponDTOResult.isSuccess(), "查询权益券失败！");
        Assert.assertEquals(allCouponDTOResult.getData().getCouponState(), CouponStateEnum.WAIT_EFFECT.getAlias());
        updateCouponState(couponId);

        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(Integer.valueOf(itemId), 1);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);
        //  续签店铺可使用
        generateSendRecordAndSendCoupon(couponId, couponName, kdtRenew);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(Long.parseLong(kdtRenew), 1, Integer.valueOf(itemId), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResult.getCode(), 200);
        Assert.assertEquals(itemPreferentialInfoResult.getData().get(0).getItemId().toString(), itemId);
        Assert.assertEquals(itemPreferentialInfoResult.getData().get(0).getPromotionList().get(0).getName(), couponName);

        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtRenew), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResult));
        Assert.assertEquals(calOrderPriceApiPlainResult.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemId().toString(), itemId);
        Assert.assertTrue(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemPromotionList().size() > 0);
        Assert.assertEquals(calOrderPriceApiPlainResult.getData().getItems().get(0).getItemPromotionList().get(0).getName(), couponName);

        //  续签店铺不可使用
        generateSendRecordAndSendCoupon(couponId,couponName,kdtWSC);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResultNew = fetchItemPreferentialInfoOnline(Long.parseLong(kdtWSC),1,Integer.valueOf(itemId),1,1);
        Assert.assertEquals(itemPreferentialInfoResultNew.getCode(),200);
        logger.info(itemPreferentialInfoResultNew.toString());
        Assert.assertTrue(itemPreferentialInfoResultNew.getData().size() == 0);
        //订单级别优惠优惠校验
        CalOrderPriceForm calOrderPriceFormoNew = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtWSC), "11", orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResultNew = orderRemoteService.calOrderPrice(calOrderPriceFormoNew);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResultNew));
        Assert.assertEquals(calOrderPriceApiPlainResultNew.getCode(),200);
        Assert.assertEquals(calOrderPriceApiPlainResultNew.getData().getItems().get(0).getItemId().toString(),itemId);
        Assert.assertTrue(calOrderPriceApiPlainResultNew.getData().getItems().get(0).getItemPromotionList().size()==0);

    }
    /**
     * 仅打折券场景->打折商品验证
     *
     * 权益：配置单个商品
     * 不选规格
     * 验证该spu下，所有sku可参与打折
     * 打折金额验证正确
     */
    @Test
    public void couponDiscountWithOnlyAppIdTest() {
        //准备打折券权益数据
        SaveCouponRequest saveCouponRequest = JsonCovertUntil.getObjectFromjson(saveCouponRequestJsonPath, SaveCouponRequest.class);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);
        List<GoodsDiscountRuleDTO> discountRuleList = new ArrayList<>();
        GoodsDiscountRuleDTO goodsDiscountRuleDTO = new GoodsDiscountRuleDTO();
        goodsDiscountRuleDTO.setAppId(couponAppId);
        goodsDiscountRuleDTO.setDiscount(9000l);
        goodsDiscountRuleDTO.setMeetQuantity(1l);
        discountRuleList.add(goodsDiscountRuleDTO);
        allCouponDTO.getGoodsDiscountCouponExtDTO().setDiscountRuleList(discountRuleList);
        CouponAdmittanceExtDTO couponAdmittanceExtDTO = new CouponAdmittanceExtDTO();
        //"FIRST", "REORDER", "SIGN_BACK";
        couponAdmittanceExtDTO.setBuyerTags(Arrays.asList("FIRST"));
        List<String> productChannel = new ArrayList<>();
        productChannel.add("WSC");
        couponAdmittanceExtDTO.setProductChannels(productChannel);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);
        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = result.getData().getAllCouponDTO().getCouponId();
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result));

        //验证已经创建的打折券权益状态为：待上架
        QueryCouponRequest queryCouponRequest = new QueryCouponRequest();
        queryCouponRequest.setCouponId(couponId);
        PlainResult<AllCouponDTO> allCouponDTOResult = couponRemoteService.queryCouponById(queryCouponRequest);
        Assert.assertTrue(allCouponDTOResult.isSuccess(), "查询权益券失败！");
        Assert.assertEquals(allCouponDTOResult.getData().getCouponState(), CouponStateEnum.WAIT_EFFECT.getAlias());
        updateCouponState(couponId);

        //构造item1参数
        OrderItemForm orderItemForm1 = ConstructionParam.getOrderItemForm(Integer.valueOf(itemId), 1);
        List<OrderItemForm> orderItemFormList1 = new ArrayList<>();
        orderItemFormList1.add(orderItemForm1);

        //构造item2参数
        OrderItemForm orderItemForm2 = ConstructionParam.getOrderItemForm(Integer.valueOf(itemId1), 1);
        List<OrderItemForm> orderItemFormList2 = new ArrayList<>();
        orderItemFormList2.add(orderItemForm2);

        //  发放
        generateSendRecordAndSendCoupon(couponId, couponName, kdtWSC);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验item1
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult1 = fetchItemPreferentialInfoOnline(Long.parseLong(kdtWSC), 1, Integer.valueOf(itemId), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResult1.getCode(), 200);
        Assert.assertEquals(itemPreferentialInfoResult1.getData().get(0).getItemId().toString(), itemId);
        Assert.assertEquals(itemPreferentialInfoResult1.getData().get(0).getPromotionList().get(0).getName(), couponName);
        Assert.assertEquals(itemPreferentialInfoResult1.getData().get(0).getPromotionList().get(0).getReduceAmount().longValue(),10000l);
        //订单级别优惠优惠校验item1
        CalOrderPriceForm calOrderPriceForm1 = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtWSC), "11", orderItemFormList1);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult1 = orderRemoteService.calOrderPrice(calOrderPriceForm1);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResult1));
        Assert.assertEquals(calOrderPriceApiPlainResult1.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemId().toString(), itemId);
        Assert.assertTrue(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemPromotionList().size() > 0);
        Assert.assertEquals(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemPromotionList().get(0).getName(), couponName);
        Assert.assertEquals(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemPromotionList().get(0).getReduceAmount().longValue(), 10000l);


        //  商品级别优惠校验item2
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult2 = fetchItemPreferentialInfoOnline(Long.parseLong(kdtWSC), 1, Integer.valueOf(itemId1), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResult2.getCode(), 200);
        Assert.assertEquals(itemPreferentialInfoResult2.getData().get(0).getItemId().toString(), itemId1);
        Assert.assertEquals(itemPreferentialInfoResult2.getData().get(0).getPromotionList().get(0).getName(), couponName);
        Assert.assertEquals(itemPreferentialInfoResult2.getData().get(0).getPromotionList().get(0).getReduceAmount().longValue(), 100l);

        //订单级别优惠优惠校验item2
        CalOrderPriceForm calOrderPriceForm2 = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtWSC), "11", orderItemFormList2);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult2 = orderRemoteService.calOrderPrice(calOrderPriceForm2);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResult2));
        Assert.assertEquals(calOrderPriceApiPlainResult2.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResult2.getData().getItems().get(0).getItemId().toString(), itemId1);
        Assert.assertTrue(calOrderPriceApiPlainResult2.getData().getItems().get(0).getItemPromotionList().size() > 0);
        Assert.assertEquals(calOrderPriceApiPlainResult2.getData().getItems().get(0).getItemPromotionList().get(0).getName(), couponName);
        Assert.assertEquals(calOrderPriceApiPlainResult2.getData().getItems().get(0).getItemPromotionList().get(0).getReduceAmount().longValue(), 100l);

    }

    /**
     *仅打折券场景->打折商品验证
     *
     * 权益：配置单个商品
     * 选定规格
     * 验证该spu下，仅配置的sku可参与打折
     * 打折金额验证正确
     */
    @Test
    public void couponDiscountWithAppIdAndItemIdTest() {
        //准备打折券权益数据
        SaveCouponRequest saveCouponRequest = JsonCovertUntil.getObjectFromjson(saveCouponRequestJsonPath, SaveCouponRequest.class);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);
        List<GoodsDiscountRuleDTO> discountRuleList = new ArrayList<>();
        GoodsDiscountRuleDTO goodsDiscountRuleDTO = new GoodsDiscountRuleDTO();
        goodsDiscountRuleDTO.setAppId(couponAppId);
        goodsDiscountRuleDTO.setItemId(couponItemId);
        goodsDiscountRuleDTO.setDiscount(9000l);
        goodsDiscountRuleDTO.setMeetQuantity(1l);
        discountRuleList.add(goodsDiscountRuleDTO);
        allCouponDTO.getGoodsDiscountCouponExtDTO().setDiscountRuleList(discountRuleList);
        CouponAdmittanceExtDTO couponAdmittanceExtDTO = new CouponAdmittanceExtDTO();
        //"FIRST", "REORDER", "SIGN_BACK";
        couponAdmittanceExtDTO.setBuyerTags(Arrays.asList("FIRST"));
        List<String> productChannel = new ArrayList<>();
        productChannel.add("WSC");
        couponAdmittanceExtDTO.setProductChannels(productChannel);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);
        PlainResult<SaveCouponResponse> result = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = result.getData().getAllCouponDTO().getCouponId();
        Assert.assertTrue(result.isSuccess(), "创建权益券失败！");
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result));

        //验证已经创建的打折券权益状态为：待上架
        QueryCouponRequest queryCouponRequest = new QueryCouponRequest();
        queryCouponRequest.setCouponId(couponId);
        PlainResult<AllCouponDTO> allCouponDTOResult = couponRemoteService.queryCouponById(queryCouponRequest);
        Assert.assertTrue(allCouponDTOResult.isSuccess(), "查询权益券失败！");
        Assert.assertEquals(allCouponDTOResult.getData().getCouponState(), CouponStateEnum.WAIT_EFFECT.getAlias());
        updateCouponState(couponId);

        //构造item1参数
        OrderItemForm orderItemForm1 = ConstructionParam.getOrderItemForm(Integer.valueOf(itemId), 1);
        List<OrderItemForm> orderItemFormList1 = new ArrayList<>();
        orderItemFormList1.add(orderItemForm1);

        //构造item2参数
        OrderItemForm orderItemForm2 = ConstructionParam.getOrderItemForm(Integer.valueOf(itemId1), 1);
        List<OrderItemForm> orderItemFormList2 = new ArrayList<>();
        orderItemFormList2.add(orderItemForm2);

        //  发放
        generateSendRecordAndSendCoupon(couponId, couponName, kdtWSC);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  商品级别优惠校验item1
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult1 = fetchItemPreferentialInfoOnline(Long.parseLong(kdtWSC), 1, Integer.valueOf(itemId), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResult1.getCode(), 200);
        Assert.assertEquals(itemPreferentialInfoResult1.getData().get(0).getItemId().toString(), itemId);
        Assert.assertEquals(itemPreferentialInfoResult1.getData().get(0).getPromotionList().get(0).getName(), couponName);
        Assert.assertEquals(itemPreferentialInfoResult1.getData().get(0).getPromotionList().get(0).getReduceAmount().longValue(),10000l);
        //订单级别优惠优惠校验item1
        CalOrderPriceForm calOrderPriceForm1 = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtWSC), "11", orderItemFormList1);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult1 = orderRemoteService.calOrderPrice(calOrderPriceForm1);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResult1));
        Assert.assertEquals(calOrderPriceApiPlainResult1.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemId().toString(), itemId);
        Assert.assertTrue(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemPromotionList().size() > 0);
        Assert.assertEquals(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemPromotionList().get(0).getName(), couponName);
        Assert.assertEquals(calOrderPriceApiPlainResult1.getData().getItems().get(0).getItemPromotionList().get(0).getReduceAmount().longValue(), 10000l);


        //  商品级别优惠校验item2
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult2 = fetchItemPreferentialInfoOnline(Long.parseLong(kdtWSC), 1, Integer.valueOf(itemId1), 1, 1);
        Assert.assertEquals(itemPreferentialInfoResult2.getCode(), 200);
        Assert.assertTrue(itemPreferentialInfoResult2.getData().size()==0);

        //订单级别优惠优惠校验item2
        CalOrderPriceForm calOrderPriceForm2 = ConstructionParam.getCalOrderPriceForm(Long.parseLong(kdtWSC), "11", orderItemFormList2);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult2 = orderRemoteService.calOrderPrice(calOrderPriceForm2);
        logger.info("确认订单-订单计算返回数据：{}", JSON.toJSON(calOrderPriceApiPlainResult2));
        Assert.assertEquals(calOrderPriceApiPlainResult2.getCode(), 200);
        Assert.assertEquals(calOrderPriceApiPlainResult2.getData().getItems().get(0).getItemId().toString(), itemId1);
        Assert.assertTrue(calOrderPriceApiPlainResult2.getData().getItems().get(0).getItemPromotionList().size() == 0);

    }


    /**
     * 上架权益
     *
     * @param couponId
     */
    public void updateCouponState(String couponId) {
        UpdateCouponStateRequest updateCouponStateRequest = new UpdateCouponStateRequest();
        updateCouponStateRequest.setOperator("baoyan");
        updateCouponStateRequest.setCouponState("ONLINE");
        updateCouponStateRequest.setCouponId(couponId);
        PlainResult<UpdateCouponStateResponse> updateCouponStateResponsePlainResult = couponRemoteService.updateCouponState(updateCouponStateRequest);
        Assert.assertEquals(updateCouponStateResponsePlainResult.getCode(), 200);

    }

    /**
     * 生成发券单并发送优惠券
     *
     * @param couponId
     * @param couponName
     */
    public void generateSendRecordAndSendCoupon(String couponId, String couponName,String kdtId) {
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String sendRecordCouponName = couponName + dateString;
        //组装发券单
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponId(couponId);
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponName(sendRecordCouponName);
        List<String> kdtidList = new ArrayList<>();
        kdtidList.add(kdtId);
        saveSendCouponRequest.getCouponSendRuleDTO().setKdtIdList(kdtidList);
        saveSendCouponRequest.getCouponSendRuleDTO().setRemark("by-test");
        PlainResult<SaveCouponSendRecordResponse> discountCouponSendRecord = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);
        //发放优惠券券
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        sendCouponAssetRequest.setCouponSendRecordId(discountCouponSendRecord.getData().getCouponSendRuleDTO().getCouponSendRecordId());
        sendCouponAssetRequest.setSendOperator("baoyan");
        PlainResult<SendCouponResponse> sendResult = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);
        Assert.assertEquals(sendResult.getCode(), 200);
    }

    //  删除数据
    public void deleteCouponByCouponNamePrefix(String couponNamePrefixPrefix) {
        if (StringUtils.isEmpty(couponNamePrefixPrefix)) {
            return;
        }
        List<Long> couponIdList = couponMapper.selectList(new QueryWrapper<MkCoupon>().lambda()
                .likeRight(MkCoupon::getName, couponNamePrefixPrefix)).stream().map(MkCoupon::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(couponIdList)) {
            couponMapper.deleteBatchIds(couponIdList);
            couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().lambda().in(MkCouponRule::getCouponId, couponIdList));
            couponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshot>().lambda().in(MkCouponSnapshot::getCouponId, couponIdList));
            couponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecord>().lambda().in(MkCouponSendRecord::getCouponId, couponIdList));
            couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().lambda().in(MkCouponAsset::getCouponId, couponIdList));
        }
    }



}