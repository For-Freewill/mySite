package com.youzan.test.goods;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.commerce.test.entity.dataobject.goods.*;
import com.youzan.commerce.test.entity.dataobject.yop.*;
import com.youzan.commerce.test.mapper.goods.*;
import com.youzan.commerce.test.mapper.yop.*;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.ycm.goods.request.atom.AtomGoodsCompleteCreateRequest;
import com.youzan.ycm.goods.request.atom.AtomSpuEditRequest;
import com.youzan.ycm.goods.request.combine.CombineSkuCreateRequest;
import com.youzan.ycm.goods.request.combine.CombineSpuCreateRequest;
import com.youzan.ycm.goods.request.rights.SaveRightsRequest;
import com.youzan.ycm.open.request.goods.UpdateCombineGoodsSkuRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.awaitility.Awaitility.with;

/**
 * @author wulei
 * @date 2021/2/3 16:42
 * 商品操作
 */
@Slf4j
public class GoodsBaseTest extends YunBaseTest {
    //YOP数据库-5
    @Autowired(required = false)
    public OpenApplicationBasicMapper openApplicationBasicMapper;
    @Autowired(required = false)
    public OpenApplicationItemMapper openApplicationItemMapper;
    @Autowired(required = false)
    public OpenApplicationBasicExtMapper openApplicationBasicExtMapper;
    @Autowired(required = false)
    public OpenApplicationAgreementRelationMapper openApplicationAgreementRelationMapper;
    @Autowired(required = false)
    public OpenApplicationItemShopRelationMapper openApplicationItemShopRelationMapper;
    @Autowired(required = false)
    public PluginItemRelationMapper pluginItemRelationMapper;
    //YCM数据库-10
    @Autowired(required = false)
    public GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @Autowired(required = false)
    public GdAtomBasicMapper gdAtomBasicMapper;
    @Autowired(required = false)
    public GdAtomItemMapper gdAtomItemMapper;
    @Autowired(required = false)
    public GdOrderWayConfigMapper gdOrderWayConfigMapper;
    @Autowired(required = false)
    public GdOperateLogMapper gdOperateLogMapper;
    @Autowired(required = false)
    public GdAtomItemPropertyRelationMapper gdAtomItemPropertyRelationMapper;
    //组合
    @Autowired(required = false)
    public GdCombineBasicMapper gdCombineBasicMapper;
    @Autowired(required = false)
    public GdCombineItemMapper gdCombineItemMapper;
    @Autowired(required = false)
    public GdCombineTemplateMapper gdCombineTemplateMapper;
    @Autowired(required = false)
    public GdCombineTemplateContentMapper gdCombineTemplateContentMapper;
    //new gd 6 table
    @Autowired(required = false)
    public GdSkuMapper gdSkuMapper;
    @Autowired(required = false)
    public GdSkuSnapshotMapper gdSkuSnapshotMapper;
    @Autowired(required = false)
    public GdSkuContentMapper gdSkuContentMapper;
    @Autowired(required = false)
    public GdSpuMapper gdSpuMapper;
    @Autowired(required = false)
    public GdSpuSnapshotMapper gdSpuSnapshotMapper;
    @Autowired(required = false)
    public GdGoodsRightsRelationMapper gdGoodsRightsRelationMapper;
    @Autowired(required = false)
    public GdRightsMapper gdRightsMapper;

    // 组合SPU校验
    public void combineNewSpuCheck(Integer app_id, CombineSpuCreateRequest request) {
        if (StringUtils.isNotEmpty(app_id.toString())) {
            // gd_combine_basic
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdCombineBasicMapper.selectList(new QueryWrapper<GdCombineBasic>().lambda().eq(GdCombineBasic::getAppId, app_id)).size() >= 1);
            // gd_spu
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdSpuMapper.selectList(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id)).size() >= 2);
            //校验：gd_combine_basic
            GdCombineBasic gdCombineBasic = gdCombineBasicMapper.selectList(new QueryWrapper<GdCombineBasic>().lambda().eq(GdCombineBasic::getAppId, app_id).eq(GdCombineBasic::getCategory, "software_meal")).get(0);
            Assert.assertEquals(gdCombineBasic.getName(), request.getSpuName());
            Assert.assertEquals(gdCombineBasic.getIcon(), request.getIcon());
            Assert.assertEquals(gdCombineBasic.getDescInfo(), request.getDescInfo());
            Assert.assertEquals(gdCombineBasic.getState(), "off_shelf");
            Assert.assertEquals(gdCombineBasic.getIsSupportYzb(), Byte.valueOf("1"));
            Assert.assertEquals(gdCombineBasic.getOwnerType(), "YOUZAN");
            Assert.assertEquals(gdCombineBasic.getMainGoodAppId(), request.getMainGoodsId());
            Assert.assertEquals(gdCombineBasic.getBizExt(), "{\"agreementId\":\"" + request.getAgreementId() + "\"}");

            //校验：gd_spu
            GdSpuEntity gdSpuEntity = gdSpuMapper.selectList(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id).eq(GdSpuEntity::getGoodsType, "combine").orderByDesc(GdSpuEntity::getSnapshotNo)).get(0);
            Assert.assertEquals(gdSpuEntity.getSpuName(), request.getSpuName());
            Assert.assertEquals(gdSpuEntity.getIcon(), request.getIcon());
            Assert.assertEquals(gdSpuEntity.getDescInfo(), request.getDescInfo());
            Assert.assertEquals(gdSpuEntity.getShelfState(), "off_shelf");
            Assert.assertEquals(gdSpuEntity.getIsSupportYzb(), Byte.valueOf("1"));
            Assert.assertEquals(gdSpuEntity.getOwnerType(), "YOUZAN");
            Assert.assertEquals(gdSpuEntity.getMainSpuId(), request.getMainGoodsId());
            Assert.assertEquals(gdSpuEntity.getBizExt(), "{\"agreementId\":\"" + request.getAgreementId() + "\",\"isRelItemAgreement\":false}");
            log.info("组合商品" + app_id + " 新表落库校验成功");

        }
    }

    //原子新落库校验
    public void atomNewTableCheck(Integer app_id, AtomGoodsCompleteCreateRequest request, String type) {
        //落库等待
        atomNewDb(app_id);
        //gd_spu
        GdSpuEntity gdSpuEntity = gdSpuMapper.selectOne(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id));
        Assert.assertEquals(gdSpuEntity.getAppId(), app_id);
        Assert.assertEquals(gdSpuEntity.getGoodsType(), "atom");
        Assert.assertEquals(gdSpuEntity.getSpuName(), request.getSpuCreateRequest().getSpuName());
        Assert.assertEquals(gdSpuEntity.getIcon(), request.getSpuCreateRequest().getIcon());
        Assert.assertEquals(gdSpuEntity.getCategory(), request.getSpuCreateRequest().getCategory());
        Assert.assertEquals(gdSpuEntity.getOrderDeclare(), request.getSpuCreateRequest().getOrderDesc());
        Assert.assertEquals(gdSpuEntity.getDescInfo(), request.getSpuCreateRequest().getDescInfo());
        Assert.assertEquals(gdSpuEntity.getIsSupportYzb(), Byte.valueOf("1"));
        Assert.assertEquals(gdSpuEntity.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuEntity.getPerformType(), request.getSkuCreateRequestList().get(0).getSpecification().getPerformType());
        Assert.assertEquals(gdSpuEntity.getMainSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuEntity.getPageId(), request.getSpuCreateRequest().getPageId());
        Assert.assertEquals(gdSpuEntity.getWscUrl(), request.getSpuCreateRequest().getWscUrl());
        Assert.assertEquals(gdSpuEntity.getStoreUrl(), request.getSpuCreateRequest().getStoreUrl());
        Assert.assertEquals(gdSpuEntity.getOwnerId(), request.getSpuCreateRequest().getOwnerId());
        Assert.assertEquals(gdSpuEntity.getOwnerType(), request.getSpuCreateRequest().getOwnerType());
        Assert.assertEquals(gdSpuEntity.getShelfState(), "off_shelf");

        //gd_spu_snapshot
        GdSpuSnapshotEntity gdSpuSnapshotEntity = gdSpuSnapshotMapper.selectOne(new QueryWrapper<GdSpuSnapshotEntity>().lambda().eq(GdSpuSnapshotEntity::getAppId, app_id).orderByDesc(GdSpuSnapshotEntity::getSnapshotNo).last("limit 1"));
        Assert.assertEquals(gdSpuSnapshotEntity.getAppId(), app_id);
        Assert.assertEquals(gdSpuSnapshotEntity.getSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuSnapshotEntity.getGoodsType(), "atom");
        Assert.assertEquals(gdSpuSnapshotEntity.getSpuName(), request.getSpuCreateRequest().getSpuName());
        Assert.assertEquals(gdSpuSnapshotEntity.getIcon(), request.getSpuCreateRequest().getIcon());
        Assert.assertEquals(gdSpuSnapshotEntity.getCategory(), request.getSpuCreateRequest().getCategory());
        Assert.assertEquals(gdSpuSnapshotEntity.getOrderDeclare(), request.getSpuCreateRequest().getOrderDesc());
        Assert.assertEquals(gdSpuSnapshotEntity.getDescInfo(), request.getSpuCreateRequest().getDescInfo());
        Assert.assertEquals(gdSpuSnapshotEntity.getIsSupportYzb(), Byte.valueOf("1"));
        Assert.assertEquals(gdSpuSnapshotEntity.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuSnapshotEntity.getPerformType(), request.getSkuCreateRequestList().get(0).getSpecification().getPerformType());
        Assert.assertEquals(gdSpuSnapshotEntity.getMainSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuSnapshotEntity.getPageId(), request.getSpuCreateRequest().getPageId());
        Assert.assertEquals(gdSpuSnapshotEntity.getWscUrl(), request.getSpuCreateRequest().getWscUrl());
        Assert.assertEquals(gdSpuSnapshotEntity.getStoreUrl(), request.getSpuCreateRequest().getStoreUrl());
        Assert.assertEquals(gdSpuSnapshotEntity.getOwnerId(), request.getSpuCreateRequest().getOwnerId());
        Assert.assertEquals(gdSpuSnapshotEntity.getOwnerType(), request.getSpuCreateRequest().getOwnerType());
        Assert.assertEquals(gdSpuSnapshotEntity.getShelfState(), "off_shelf");

        //gd_sku
        List<GdSkuEntity> gdSkuEntities = gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id));
        Long snapshotSku = gdSkuEntities.get(0).getSnapshotNo();
        for (GdSkuEntity gdSkuEntity : gdSkuEntities) {
            if (gdSkuEntity.getSpecPeriodUnit() == "day") {
                Assert.assertEquals(gdSkuEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuEntity.getBizExt(), "{\"isPackageSale\":false}");
                Assert.assertEquals(gdSkuEntity.getPrice(), Long.valueOf(100));
                Assert.assertEquals(gdSkuEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuEntity.getShelfState(), "on_shelf");


            } else if (gdSkuEntity.getSpecPeriodUnit() == "year") {
                Assert.assertEquals(gdSkuEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuEntity.getPrice(), Long.valueOf(100000));
                Assert.assertEquals(gdSkuEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuEntity.getShelfState(), "on_shelf");
            }
        }
        //gd_sku_snapshot
        List<GdSkuSnapshotEntity> gdSkuSnapshotEntities = gdSkuSnapshotMapper.selectList(new QueryWrapper<GdSkuSnapshotEntity>().lambda().eq(GdSkuSnapshotEntity::getAppId, app_id).orderByDesc(GdSkuSnapshotEntity::getSnapshotNo));
        Assert.assertEquals(gdSkuSnapshotEntities.get(0).getSnapshotNo(), snapshotSku, "gd_sku_snapshot 快照号错误");
        for (GdSkuSnapshotEntity gdSkuSnapshotEntity : gdSkuSnapshotEntities) {
            if (gdSkuSnapshotEntity.getSpecPeriodUnit() == "day") {
                Assert.assertEquals(gdSkuSnapshotEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuSnapshotEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuSnapshotEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuSnapshotEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuSnapshotEntity.getBizExt(), "{\"isPackageSale\":false}");
                Assert.assertEquals(gdSkuSnapshotEntity.getPrice(), Long.valueOf(100));
                Assert.assertEquals(gdSkuSnapshotEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "on_shelf");


            } else if (gdSkuSnapshotEntity.getSpecPeriodUnit() == "year") {
                Assert.assertEquals(gdSkuSnapshotEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuSnapshotEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuSnapshotEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuSnapshotEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuSnapshotEntity.getPrice(), Long.valueOf(100000));
                Assert.assertEquals(gdSkuSnapshotEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "on_shelf");
            }
        }

        //区分原子插件，软件
        if (type.equals("plugin")) {
            Assert.assertEquals(gdSpuEntity.getBizExt(), "{\"agreementId\":\"" + request.getSpuCreateRequest().getAgreementId() + "\"}");
            Assert.assertEquals(gdSpuSnapshotEntity.getBizExt(), "{\"agreementId\":\"" + request.getSpuCreateRequest().getAgreementId() + "\"}");
        } else if (type.equals("software")) {
            Assert.assertEquals(gdSpuEntity.getBizExt(), "{}");
            Assert.assertEquals(gdSpuSnapshotEntity.getBizExt(), "{}");
        }

        log.info("原子商品" + type + ":" + app_id + " 新表落库校验成功");
    }

    //原子old落库校验
    public void atomOldTableCheck(Integer app_id, AtomGoodsCompleteCreateRequest request, String type) {
        //open_application_basic
        OpenApplicationBasicEntity openApplicationBasicEntity = openApplicationBasicMapper.selectOne(new QueryWrapper<OpenApplicationBasicEntity>().lambda().eq(OpenApplicationBasicEntity::getAppid, app_id));
        Assert.assertEquals(openApplicationBasicEntity.getAppid(), app_id);
        Assert.assertEquals(openApplicationBasicEntity.getName(), request.getSpuCreateRequest().getSpuName());
        Assert.assertEquals(openApplicationBasicEntity.getIcon(), request.getSpuCreateRequest().getIcon());
        Assert.assertEquals(openApplicationBasicEntity.getCategory(), Integer.valueOf("0"));
        Assert.assertEquals(openApplicationBasicEntity.getOrderDesc(), request.getSpuCreateRequest().getOrderDesc());
        Assert.assertEquals(openApplicationBasicEntity.getDescInfo(), request.getSpuCreateRequest().getDescInfo());
        Assert.assertEquals(openApplicationBasicEntity.getUseYzb(), Integer.valueOf("1"));
        Assert.assertEquals(openApplicationBasicEntity.getIsFree(), Integer.valueOf("0"));
        Assert.assertEquals(openApplicationBasicEntity.getIsInner(), Integer.valueOf("1"));
        Assert.assertEquals(openApplicationBasicEntity.getDeveloper(), "有赞官方");


        Assert.assertEquals(openApplicationBasicEntity.getState(), Integer.valueOf("0"));

        //open_application_item
        List<OpenApplicationItemEntity> openApplicationItemEntityList = openApplicationItemMapper.selectList(new QueryWrapper<OpenApplicationItemEntity>().lambda().eq(OpenApplicationItemEntity::getAppid, app_id));
        Assert.assertEquals(openApplicationItemEntityList.size(), 2);

        //open_application_basic_ext
        OpenApplicationBasicExtEntity openApplicationBasicExtEntity = openApplicationBasicExtMapper.selectOne(new QueryWrapper<OpenApplicationBasicExtEntity>().lambda().eq(OpenApplicationBasicExtEntity::getAppId, app_id));
        Assert.assertEquals(openApplicationBasicExtEntity.getPageId(), request.getSpuCreateRequest().getPageId());
        Assert.assertEquals(openApplicationBasicExtEntity.getWscUrl(), request.getSpuCreateRequest().getWscUrl());
        Assert.assertEquals(openApplicationBasicExtEntity.getStoreUrl(), request.getSpuCreateRequest().getStoreUrl());
        //open_application_item_shop_relation
        List<OpenApplicationItemShopRelationEntity> openApplicationItemShopRelationEntityList = openApplicationItemShopRelationMapper.selectList(new QueryWrapper<OpenApplicationItemShopRelationEntity>().lambda().eq(OpenApplicationItemShopRelationEntity::getAppId, app_id));

        //open_application_agreement_relation
        List<OpenApplicationAgreementRelationEntity> openApplicationAgreementRelationEntityList = openApplicationAgreementRelationMapper.selectList(new QueryWrapper<OpenApplicationAgreementRelationEntity>().lambda().eq(OpenApplicationAgreementRelationEntity::getAppId, app_id));
        for (OpenApplicationAgreementRelationEntity openApplicationAgreementRelationEntity : openApplicationAgreementRelationEntityList) {
            Assert.assertEquals(openApplicationAgreementRelationEntity.getAgreementId().toString(), request.getSpuCreateRequest().getAgreementId());
        }

        //gd_atom_basic
        GdAtomBasic gdAtomBasic = gdAtomBasicMapper.selectOne(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAppId, app_id));
        Assert.assertEquals(gdAtomBasic.getName(), request.getSpuCreateRequest().getSpuName());
        Assert.assertEquals(gdAtomBasic.getIcon(), request.getSpuCreateRequest().getIcon());
        Assert.assertEquals(gdAtomBasic.getOrderDesc(), request.getSpuCreateRequest().getOrderDesc());
        Assert.assertEquals(gdAtomBasic.getDescInfo(), request.getSpuCreateRequest().getDescInfo());
        Assert.assertEquals(gdAtomBasic.getIsSupportYzb(), Byte.valueOf("1"));
        Assert.assertEquals(gdAtomBasic.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdAtomBasic.getOwnerType(), "YOUZAN");
        Assert.assertEquals(gdAtomBasic.getState(), "off_shelf");
        Assert.assertEquals(gdAtomBasic.getPerformType(), "period");
        //gd_atom_item
        List<GdAtomItem> gdAtomItemList = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAppId, app_id));
        Assert.assertEquals(gdAtomItemList.size(), 2);
        for (GdAtomItem gdAtomItem : gdAtomItemList) {
            if (gdAtomItem.getSpecPeriodUnit().equals("day")) {
                Assert.assertEquals(gdAtomItem.getPrice(), Long.valueOf(100));
            } else {
                Assert.assertEquals(gdAtomItem.getPrice(), Long.valueOf(10000));
            }
        }
        //区分原子插件，软件
        if (type.equals("plugin")) {
            Assert.assertEquals(openApplicationBasicEntity.getAppGroup(), Integer.valueOf("1"));
            Assert.assertEquals(openApplicationItemShopRelationEntityList.size(), 2);
            Assert.assertEquals(openApplicationAgreementRelationEntityList.size(), 2);
            Assert.assertEquals(gdAtomBasic.getCategory(), type);

        } else if (type.equals("software")) {
            Assert.assertEquals(openApplicationBasicEntity.getAppGroup(), Integer.valueOf("3"));
            Assert.assertEquals(openApplicationItemShopRelationEntityList.size(), 0);
            Assert.assertEquals(openApplicationAgreementRelationEntityList.size(), 0);
            Assert.assertEquals(gdAtomBasic.getCategory(), type);
        }
        log.info("原子商品" + type + ":" + app_id + " 老表落库校验成功");

    }

    //原子SPU编辑后落库校验
    public void atomEditCheck(Integer app_id, AtomSpuEditRequest request, String type) {
        //open_application_basic
        OpenApplicationBasicEntity openApplicationBasicEntity = openApplicationBasicMapper.selectOne(new QueryWrapper<OpenApplicationBasicEntity>().lambda().eq(OpenApplicationBasicEntity::getAppid, app_id));
        Assert.assertEquals(openApplicationBasicEntity.getAppid(), app_id);
        Assert.assertEquals(openApplicationBasicEntity.getName(), request.getSpuName());
        Assert.assertEquals(openApplicationBasicEntity.getIcon(), request.getIcon());
        Assert.assertEquals(openApplicationBasicEntity.getCategory(), Integer.valueOf("0"));
        Assert.assertEquals(openApplicationBasicEntity.getOrderDesc(), request.getOrderDesc());
        Assert.assertEquals(openApplicationBasicEntity.getDescInfo(), request.getDescInfo());
        Assert.assertEquals(openApplicationBasicEntity.getUseYzb(), Integer.valueOf("0"));
        Assert.assertEquals(openApplicationBasicEntity.getIsFree(), Integer.valueOf("0"));
        Assert.assertEquals(openApplicationBasicEntity.getIsInner(), Integer.valueOf("1"));
        Assert.assertEquals(openApplicationBasicEntity.getDeveloper(), "有赞官方");
        Assert.assertEquals(openApplicationBasicEntity.getState(), Integer.valueOf("1"));

        //open_application_basic_ext
        OpenApplicationBasicExtEntity openApplicationBasicExtEntity = openApplicationBasicExtMapper.selectOne(new QueryWrapper<OpenApplicationBasicExtEntity>().lambda().eq(OpenApplicationBasicExtEntity::getAppId, app_id));
        Assert.assertEquals(openApplicationBasicExtEntity.getPageId(), request.getPageId());
        Assert.assertEquals(openApplicationBasicExtEntity.getWscUrl(), request.getWscUrl());
        Assert.assertEquals(openApplicationBasicExtEntity.getStoreUrl(), request.getStoreUrl());
        //open_application_item_shop_relation
        List<OpenApplicationItemShopRelationEntity> openApplicationItemShopRelationEntityList = openApplicationItemShopRelationMapper.selectList(new QueryWrapper<OpenApplicationItemShopRelationEntity>().lambda().eq(OpenApplicationItemShopRelationEntity::getAppId, app_id));
        //open_application_agreement_relation
        List<OpenApplicationAgreementRelationEntity> openApplicationAgreementRelationEntityList = openApplicationAgreementRelationMapper.selectList(new QueryWrapper<OpenApplicationAgreementRelationEntity>().lambda().eq(OpenApplicationAgreementRelationEntity::getAppId, app_id));
        for (OpenApplicationAgreementRelationEntity openApplicationAgreementRelationEntity : openApplicationAgreementRelationEntityList) {
            Assert.assertEquals(openApplicationAgreementRelationEntity.getAgreementId().toString(), request.getAgreementId());
        }
        //gd_atom_basic
        GdAtomBasic gdAtomBasic = gdAtomBasicMapper.selectOne(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAppId, app_id).orderByDesc(GdAtomBasic::getSnapshotNo).last("limit 1"));
        Assert.assertEquals(gdAtomBasic.getName(), request.getSpuName());
        Assert.assertEquals(gdAtomBasic.getIcon(), request.getIcon());
        Assert.assertEquals(gdAtomBasic.getOrderDesc(), request.getOrderDesc());
        Assert.assertEquals(gdAtomBasic.getDescInfo(), request.getDescInfo());
        Assert.assertEquals(gdAtomBasic.getIsSupportYzb(), Byte.valueOf("0"));
        Assert.assertEquals(gdAtomBasic.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdAtomBasic.getOwnerType(), "YOUZAN");
        Assert.assertEquals(gdAtomBasic.getState(), "on_shelf");
        Assert.assertEquals(gdAtomBasic.getPerformType(), "period");
        //gd_atom_item
        List<GdAtomItem> gdAtomItemList = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAppId, app_id));
        Assert.assertEquals(gdAtomItemList.size(), 2);
        for (GdAtomItem gdAtomItem : gdAtomItemList) {
            if (gdAtomItem.getSpecPeriodUnit().equals("day")) {
                Assert.assertEquals(gdAtomItem.getPrice(), Long.valueOf(100));
            } else {
                Assert.assertEquals(gdAtomItem.getPrice(), Long.valueOf(10000));
            }
        }
        //gd_spu
        GdSpuEntity gdSpuEntity = gdSpuMapper.selectOne(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id));
        Assert.assertEquals(gdSpuEntity.getAppId(), app_id);
        Assert.assertEquals(gdSpuEntity.getGoodsType(), "atom");
        Assert.assertEquals(gdSpuEntity.getSpuName(), request.getSpuName());
        Assert.assertEquals(gdSpuEntity.getIcon(), request.getIcon());
        Assert.assertEquals(gdSpuEntity.getCategory(), request.getCategory());
        Assert.assertEquals(gdSpuEntity.getOrderDeclare(), request.getOrderDesc());
        Assert.assertEquals(gdSpuEntity.getDescInfo(), request.getDescInfo());
        Assert.assertEquals(gdSpuEntity.getIsSupportYzb(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuEntity.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuEntity.getPerformType(), "period");
        Assert.assertEquals(gdSpuEntity.getMainSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuEntity.getPageId(), request.getPageId());
        Assert.assertEquals(gdSpuEntity.getWscUrl(), request.getWscUrl());
        Assert.assertEquals(gdSpuEntity.getStoreUrl(), request.getStoreUrl());
        Assert.assertEquals(gdSpuEntity.getOwnerId(), request.getOwnerId());
        Assert.assertEquals(gdSpuEntity.getOwnerType(), request.getOwnerType());
        Assert.assertEquals(gdSpuEntity.getShelfState(), "on_shelf");

        //gd_spu_snapshot
        GdSpuSnapshotEntity gdSpuSnapshotEntity = gdSpuSnapshotMapper.selectOne(new QueryWrapper<GdSpuSnapshotEntity>().lambda().eq(GdSpuSnapshotEntity::getAppId, app_id).orderByDesc(GdSpuSnapshotEntity::getSnapshotNo).last("limit 1"));
        Assert.assertEquals(gdSpuSnapshotEntity.getAppId(), app_id);
        Assert.assertEquals(gdSpuSnapshotEntity.getSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuSnapshotEntity.getGoodsType(), "atom");
        Assert.assertEquals(gdSpuSnapshotEntity.getSpuName(), request.getSpuName());
        Assert.assertEquals(gdSpuSnapshotEntity.getIcon(), request.getIcon());
        Assert.assertEquals(gdSpuSnapshotEntity.getCategory(), request.getCategory());
        Assert.assertEquals(gdSpuSnapshotEntity.getOrderDeclare(), request.getOrderDesc());
        Assert.assertEquals(gdSpuSnapshotEntity.getDescInfo(), request.getDescInfo());
        Assert.assertEquals(gdSpuSnapshotEntity.getIsSupportYzb(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuSnapshotEntity.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuSnapshotEntity.getPerformType(), "period");
        Assert.assertEquals(gdSpuSnapshotEntity.getMainSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuSnapshotEntity.getPageId(), request.getPageId());
        Assert.assertEquals(gdSpuSnapshotEntity.getWscUrl(), request.getWscUrl());
        Assert.assertEquals(gdSpuSnapshotEntity.getStoreUrl(), request.getStoreUrl());
        Assert.assertEquals(gdSpuSnapshotEntity.getOwnerId(), request.getOwnerId());
        Assert.assertEquals(gdSpuSnapshotEntity.getOwnerType(), request.getOwnerType());
        Assert.assertEquals(gdSpuSnapshotEntity.getShelfState(), "on_shelf");

        //gd_sku
        List<GdSkuEntity> gdSkuEntities = gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id));
        Long snapshotSku = gdSkuEntities.get(0).getSnapshotNo();
        for (GdSkuEntity gdSkuEntity : gdSkuEntities) {
            if (gdSkuEntity.getSpecPeriodUnit() == "day") {
                Assert.assertEquals(gdSkuEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuEntity.getBizExt(), "{\"isPackageSale\":false}");
                Assert.assertEquals(gdSkuEntity.getPrice(), Long.valueOf(100));
                Assert.assertEquals(gdSkuEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuEntity.getShelfState(), "on_shelf");


            } else if (gdSkuEntity.getSpecPeriodUnit() == "year") {
                Assert.assertEquals(gdSkuEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuEntity.getPrice(), Long.valueOf(100000));
                Assert.assertEquals(gdSkuEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuEntity.getShelfState(), "on_shelf");
            }
        }
        //gd_sku_snapshot
        List<GdSkuSnapshotEntity> gdSkuSnapshotEntities = gdSkuSnapshotMapper.selectList(new QueryWrapper<GdSkuSnapshotEntity>().lambda().eq(GdSkuSnapshotEntity::getAppId, app_id).orderByDesc(GdSkuSnapshotEntity::getSnapshotNo));
        Assert.assertEquals(gdSkuSnapshotEntities.get(0).getSnapshotNo(), snapshotSku, "gd_sku_snapshot 快照号错误");
        for (GdSkuSnapshotEntity gdSkuSnapshotEntity : gdSkuSnapshotEntities) {
            if (gdSkuSnapshotEntity.getSpecPeriodUnit() == "day") {
                Assert.assertEquals(gdSkuSnapshotEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuSnapshotEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuSnapshotEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuSnapshotEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuSnapshotEntity.getBizExt(), "{\"isPackageSale\":false}");
                Assert.assertEquals(gdSkuSnapshotEntity.getPrice(), Long.valueOf(100));
                Assert.assertEquals(gdSkuSnapshotEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "on_shelf");


            } else if (gdSkuSnapshotEntity.getSpecPeriodUnit() == "year") {
                Assert.assertEquals(gdSkuSnapshotEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuSnapshotEntity.getSkuName(), null);
                Assert.assertEquals(gdSkuSnapshotEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuSnapshotEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuSnapshotEntity.getPrice(), Long.valueOf(100000));
                Assert.assertEquals(gdSkuSnapshotEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "on_shelf");
            }
        }

        //区分原子插件，软件
        if (type.equals("plugin")) {
            Assert.assertEquals(openApplicationBasicEntity.getAppGroup(), Integer.valueOf("1"));
            Assert.assertEquals(openApplicationItemShopRelationEntityList.size(), 2);
            Assert.assertEquals(openApplicationAgreementRelationEntityList.size(), 2);
            Assert.assertEquals(gdAtomBasic.getCategory(), type);
            Assert.assertEquals(gdAtomBasic.getBizExt(), "{\"agreementId\":\"" + request.getAgreementId() + "\"}");
            Assert.assertEquals(gdSpuSnapshotEntity.getBizExt(), "{\"agreementId\":\"" + request.getAgreementId() + "\"}");


        } else if (type.equals("software")) {
            Assert.assertEquals(openApplicationBasicEntity.getAppGroup(), Integer.valueOf("3"));
            Assert.assertEquals(openApplicationItemShopRelationEntityList.size(), 0);
            Assert.assertEquals(openApplicationAgreementRelationEntityList.size(), 0);
            Assert.assertEquals(gdAtomBasic.getCategory(), type);
            Assert.assertEquals(gdAtomBasic.getBizExt(), "{}");
            Assert.assertEquals(gdSpuSnapshotEntity.getBizExt(), "{}");
        }
        log.info("原子商品" + type + ":" + app_id + " 编辑SPU落库校验成功");
    }

    //原子SPU新增SKU后校验
    public void atomNewSKUCheck(Integer app_id, String type) {
        //SPU
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(() -> openApplicationItemMapper.selectList(new QueryWrapper<OpenApplicationItemEntity>().lambda().eq(OpenApplicationItemEntity::getAppid, app_id)).size() >= 3);

        //open_application_item
        List<OpenApplicationItemEntity> openApplicationItemEntityList = openApplicationItemMapper.selectList(new QueryWrapper<OpenApplicationItemEntity>().lambda().eq(OpenApplicationItemEntity::getAppid, app_id));
        Assert.assertEquals(openApplicationItemEntityList.size(), 3);

        //open_application_item_shop_relation
        List<OpenApplicationItemShopRelationEntity> openApplicationItemShopRelationEntityList = openApplicationItemShopRelationMapper.selectList(new QueryWrapper<OpenApplicationItemShopRelationEntity>().lambda().eq(OpenApplicationItemShopRelationEntity::getAppId, app_id));
        //open_application_agreement_relation
        List<OpenApplicationAgreementRelationEntity> openApplicationAgreementRelationEntityList = openApplicationAgreementRelationMapper.selectList(new QueryWrapper<OpenApplicationAgreementRelationEntity>().lambda().eq(OpenApplicationAgreementRelationEntity::getAppId, app_id));
        for (OpenApplicationAgreementRelationEntity openApplicationAgreementRelationEntity : openApplicationAgreementRelationEntityList) {
            Assert.assertEquals(openApplicationAgreementRelationEntity.getAgreementId().toString(), "48");
        }
        //gd_atom_basic
        GdAtomBasic gdAtomBasic = gdAtomBasicMapper.selectOne(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAppId, app_id).orderByDesc(GdAtomBasic::getSnapshotNo).last("limit 1"));
        Assert.assertEquals(gdAtomBasic.getIsSupportYzb(), Byte.valueOf("0"));
        Assert.assertEquals(gdAtomBasic.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdAtomBasic.getOwnerType(), "YOUZAN");
        Assert.assertEquals(gdAtomBasic.getState(), "on_shelf");
        Assert.assertEquals(gdAtomBasic.getPerformType(), "period");
        //gd_atom_item
        List<GdAtomItem> gdAtomItemList = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAppId, app_id));
        Assert.assertEquals(gdAtomItemList.size(), 3);
        for (GdAtomItem gdAtomItem : gdAtomItemList) {
            if (gdAtomItem.getSpecPeriodUnit().equals("year")) {
                Assert.assertEquals(gdAtomItem.getPrice(), Long.valueOf(10000));
            } else if (gdAtomItem.getName().equals("半年期")) {
                Assert.assertEquals(gdAtomItem.getPrice(), Long.valueOf(5000));
                Assert.assertEquals(gdAtomItem.getState(), "on_shelf");
                //区分原子插件，软件
                if (type.equals("plugin")) {
                    Assert.assertEquals(gdAtomItem.getIsShow(), Byte.valueOf("1"));
                } else if (type.equals("software")) {
                    Assert.assertEquals(gdAtomItem.getIsShow(), Byte.valueOf("0"));
                }
                Assert.assertEquals(gdAtomItem.getSpecPeriod(), Long.valueOf(180));
                Assert.assertEquals(gdAtomItem.getPerformType(), "period");

            }
        }
        //gd_spu
        GdSpuEntity gdSpuEntity = gdSpuMapper.selectOne(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id));
        Assert.assertEquals(gdSpuEntity.getAppId(), app_id);
        Assert.assertEquals(gdSpuEntity.getGoodsType(), "atom");
        Assert.assertEquals(gdSpuEntity.getIsSupportYzb(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuEntity.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuEntity.getPerformType(), "period");
        Assert.assertEquals(gdSpuEntity.getMainSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuEntity.getShelfState(), "on_shelf");

        //gd_spu_snapshot
        GdSpuSnapshotEntity gdSpuSnapshotEntity = gdSpuSnapshotMapper.selectOne(new QueryWrapper<GdSpuSnapshotEntity>().lambda().eq(GdSpuSnapshotEntity::getAppId, app_id).orderByDesc(GdSpuSnapshotEntity::getSnapshotNo).last("limit 1"));
        Assert.assertEquals(gdSpuSnapshotEntity.getAppId(), app_id);
        Assert.assertEquals(gdSpuSnapshotEntity.getSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuSnapshotEntity.getGoodsType(), "atom");
        Assert.assertEquals(gdSpuSnapshotEntity.getIsSupportYzb(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuSnapshotEntity.getIsFree(), Byte.valueOf("0"));
        Assert.assertEquals(gdSpuSnapshotEntity.getPerformType(), "period");
        Assert.assertEquals(gdSpuSnapshotEntity.getMainSpuId(), yopId2ycmId(app_id));
        Assert.assertEquals(gdSpuSnapshotEntity.getShelfState(), "on_shelf");

        //gd_sku
        List<GdSkuEntity> gdSkuEntities = gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id));
        Long snapshotSku = gdSkuEntities.get(0).getSnapshotNo();
        Assert.assertEquals(gdAtomItemList.size(), 3);

        for (GdSkuEntity gdSkuEntity : gdSkuEntities) {
            if (gdSkuEntity.getSkuName().equals("半年期")) {
                Assert.assertEquals(gdSkuEntity.getPrice(), Long.valueOf(5000));
                Assert.assertEquals(gdSkuEntity.getShelfState(), "on_shelf");
                //区分原子插件，软件
                if (type.equals("plugin")) {
                    Assert.assertEquals(gdSkuEntity.getIsShow(), Byte.valueOf("1"));
                } else if (type.equals("software")) {
                    Assert.assertEquals(gdSkuEntity.getIsShow(), Byte.valueOf("0"));
                }
                Assert.assertEquals(gdSkuEntity.getSpecPeriod(), Long.valueOf(180));
                Assert.assertEquals(gdSkuEntity.getPerformType(), "period");

            } else if (gdSkuEntity.getSpecPeriodUnit().equals("year")) {
                Assert.assertEquals(gdSkuEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuEntity.getSkuName(), "");
                Assert.assertEquals(gdSkuEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuEntity.getPrice(), Long.valueOf(10000));
                Assert.assertEquals(gdSkuEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuEntity.getShelfState(), "off_shelf");
            }
        }
        //gd_sku_snapshot
        List<GdSkuSnapshotEntity> gdSkuSnapshotEntities = gdSkuSnapshotMapper.selectList(new QueryWrapper<GdSkuSnapshotEntity>().lambda().eq(GdSkuSnapshotEntity::getAppId, app_id).orderByDesc(GdSkuSnapshotEntity::getSnapshotNo).last("limit 3"));
        Assert.assertEquals(gdSkuSnapshotEntities.get(0).getSnapshotNo(), snapshotSku, "gd_sku_snapshot 快照号错误");
        for (GdSkuSnapshotEntity gdSkuSnapshotEntity : gdSkuSnapshotEntities) {
            if (gdSkuSnapshotEntity.getSkuName().equals("day")) {
                Assert.assertEquals(gdSkuSnapshotEntity.getPrice(), Long.valueOf(5000));
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "on_shelf");
                Assert.assertEquals(gdSkuSnapshotEntity.getIsShow(), Byte.valueOf("1"));
                Assert.assertEquals(gdSkuSnapshotEntity.getSpecPeriod(), Long.valueOf(180));
                Assert.assertEquals(gdSkuSnapshotEntity.getPerformType(), "period");


            } else if (gdSkuSnapshotEntity.getSpecPeriodUnit() == "year") {
                Assert.assertEquals(gdSkuSnapshotEntity.getGoodsType(), "atom");
                Assert.assertEquals(gdSkuSnapshotEntity.getSkuName(), "");
                Assert.assertEquals(gdSkuSnapshotEntity.getLevel(), "default");
                Assert.assertEquals(gdSkuSnapshotEntity.getEdition(), "normal");
                Assert.assertEquals(gdSkuSnapshotEntity.getPrice(), Long.valueOf(10000));
                Assert.assertEquals(gdSkuSnapshotEntity.getSpecPeriod(), Long.valueOf(1));
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "off_shelf");
            }
        }

        //区分原子插件，软件
        if (type.equals("plugin")) {
            Assert.assertEquals(gdAtomBasic.getCategory(), type);
            Assert.assertEquals(openApplicationItemShopRelationEntityList.size(), 7);
            Assert.assertEquals(openApplicationAgreementRelationEntityList.size(), 3);


        } else if (type.equals("software")) {
            Assert.assertEquals(gdAtomBasic.getCategory(), type);
            Assert.assertEquals(openApplicationItemShopRelationEntityList.size(), 0);
            Assert.assertEquals(openApplicationAgreementRelationEntityList.size(), 0);


        }

        log.info("原子商品" + type + ":" + app_id + " 新增SKU落库校验成功");
    }

    //落库等待校验
    public void atomNewDb(Integer app_id) {
        if (StringUtils.isNotEmpty(app_id.toString())) {
            //SPU
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdSpuMapper.selectList(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id)).size() >= 1);

            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdSpuSnapshotMapper.selectList(new QueryWrapper<GdSpuSnapshotEntity>().lambda().eq(GdSpuSnapshotEntity::getAppId, app_id)).size() >= 1);

            //SKU
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id)).size() >= 1);

            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdSkuSnapshotMapper.selectList(new QueryWrapper<GdSkuSnapshotEntity>().lambda().eq(GdSkuSnapshotEntity::getAppId, app_id)).size() >= 1);

        }
    }

    //yop-ycm
    public String yopId2ycmId(Integer yopId) {
        try {
            List<GdGoodsIdMapping> gdGoodsIdMappings = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().lambda().eq(GdGoodsIdMapping::getYopId, yopId));
            if (gdGoodsIdMappings.size() > 0) {
                return gdGoodsIdMappings.get(0).getYcmId();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "商品信息查询为空";
    }

    //yop-ycm
    public String ycmId2yopId(String ycmId) {
        try {
            List<GdGoodsIdMapping> gdGoodsIdMappings = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().lambda().eq(GdGoodsIdMapping::getYcmId, ycmId));
            if (gdGoodsIdMappings.size() > 0) {
                return gdGoodsIdMappings.get(0).getYopId().toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "商品信息查询为空";
    }

    //原子商品SPU-上/下架判断
    public void isOnOffShelfAtomSpu(Integer yopId, Boolean onShelf) {
        OpenApplicationBasicEntity openApplicationBasicEntity = openApplicationBasicMapper.selectOne(new QueryWrapper<OpenApplicationBasicEntity>().lambda().eq(OpenApplicationBasicEntity::getAppid, yopId));
        List<OpenApplicationItemEntity> openApplicationItemEntityList = openApplicationItemMapper.selectList(new QueryWrapper<OpenApplicationItemEntity>().lambda().eq(OpenApplicationItemEntity::getAppid, yopId));
        String ycmId = yopId2ycmId(yopId);
        GdAtomBasic gdAtomBasic = gdAtomBasicMapper.selectList(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAppId, yopId.toString()).orderByDesc(GdAtomBasic::getSnapshotNo).last("limit 1")).get(0);
        List<GdAtomItem> gdAtomItemList = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAtomAppId, ycmId).orderByDesc(GdAtomItem::getSnapshotNo).last("limit 1"));
        GdSpuEntity gdSpuEntity = gdSpuMapper.selectOne(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, yopId));
        List<GdSpuSnapshotEntity> gdSpuSnapshotEntityList = gdSpuSnapshotMapper.selectList(new QueryWrapper<GdSpuSnapshotEntity>().lambda().eq(GdSpuSnapshotEntity::getAppId, yopId).orderByDesc(GdSpuSnapshotEntity::getSnapshotNo).last("limit 1"));
        List<GdSkuEntity> gdSkuEntityList = gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, yopId));
        List<GdSkuSnapshotEntity> gdSkuSnapshotEntityList = gdSkuSnapshotMapper.selectList(new QueryWrapper<GdSkuSnapshotEntity>().lambda().eq(GdSkuSnapshotEntity::getAppId, yopId).orderByDesc(GdSkuSnapshotEntity::getSnapshotNo));

        if (onShelf) {
            //SPU上架，SKU上下架不确定
            //open_application_basic state=0
            Assert.assertEquals(openApplicationBasicEntity.getState(), Integer.valueOf(1));
            //gd_atom_basic state=off_shelf
            Assert.assertEquals(gdAtomBasic.getState(), "on_shelf");
            //gd_spu state=off_shelf
            Assert.assertEquals(gdSpuEntity.getShelfState(), "on_shelf");
            //gd_atom_item state=0
            for (GdAtomItem gdAtomItem : gdAtomItemList) {
                Assert.assertEquals(gdAtomItem.getState(), "off_shelf");
            }
            //gd_sku state=off_shelf
            for (GdSkuEntity gdSkuEntity : gdSkuEntityList) {
                Assert.assertEquals(gdSkuEntity.getShelfState(), "off_shelf");
            }
            //gd_sku_snapshot state=off_shelf
            for (GdSkuSnapshotEntity gdSkuSnapshotEntity : gdSkuSnapshotEntityList) {
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "off_shelf");
            }
        } else {
            //SPU下架：SKU全部下架
            //open_application_basic state=0
            Assert.assertEquals(openApplicationBasicEntity.getState(), Integer.valueOf(0));
            //open_application_item state=0
            for (OpenApplicationItemEntity openApplicationItemEntity : openApplicationItemEntityList) {
                Assert.assertEquals(openApplicationItemEntity.getState(), Integer.valueOf(0));
            }
            //gd_atom_basic state=off_shelf
            Assert.assertEquals(gdAtomBasic.getState(), "off_shelf");
            //gd_atom_item state=0
            for (GdAtomItem gdAtomItem : gdAtomItemList) {
                Assert.assertEquals(gdAtomItem.getState(), "off_shelf");
            }
            //gd_spu state=off_shelf
            Assert.assertEquals(gdSpuEntity.getShelfState(), "off_shelf");
            //gd_spu_snapshot state=off_shelf
            for (GdSpuSnapshotEntity gdSpuSnapshotEntity : gdSpuSnapshotEntityList) {
                Assert.assertEquals(gdSpuSnapshotEntity.getShelfState(), "off_shelf");
            }
            //gd_sku state=off_shelf
            for (GdSkuEntity gdSkuEntity : gdSkuEntityList) {
                Assert.assertEquals(gdSkuEntity.getShelfState(), "off_shelf");
            }
            //gd_sku_snapshot state=off_shelf
            for (GdSkuSnapshotEntity gdSkuSnapshotEntity : gdSkuSnapshotEntityList) {
                Assert.assertEquals(gdSkuSnapshotEntity.getShelfState(), "off_shelf");
            }
        }

    }


    /**
     * 原子商品SPU+SKU信息校验
     * 仅校验YCM库（YOP库后续下掉）：
     * gd_atom_basic
     * gd_atom_item
     * gd_order_way_config
     * gd_goods_id_mapping
     *
     * @param atom_app_id
     */
    public Map<String, List<String>> queryAtomSpuAndSku(String atom_app_id) {
        Map<String, List<String>> result = new HashMap<>();
        //gd_atom_basic-商品SPU ID
        log.info("原子商品SPU-id=" + atom_app_id);

        //gd_atom_item-商品SKU列表
        List<GdAtomItem> gdAtomItemList = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAtomAppId, atom_app_id));
        // 商品SKU=atom_skus-商品SKU item_id 列表
        List<String> gdAtomItemLists = gdAtomItemList.stream().map(GdAtomItem::getAtomItemId).collect(Collectors.toList());
        gdAtomItemLists.add(atom_app_id);
        log.info("原子商品SKu列表=" + gdAtomItemLists.toString());

        //gd_goods_id_mapping
        List<GdGoodsIdMapping> gdGoodsIdMappings = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().lambda().in(GdGoodsIdMapping::getYcmId, gdAtomItemLists));
        // YOP ids
        List<String> yopAppIds = gdGoodsIdMappings.stream().map(GdGoodsIdMapping::getYopId).map((ele) -> String.valueOf(ele)).collect(Collectors.toList());
        log.info("原子商品Yop-APP-id列表=" + yopAppIds.toString());
        result.put("atom_sku_items", gdAtomItemLists);
        result.put("yop_app_ids", yopAppIds);
        return result;
    }

    /**
     * 原子商品SPU+SKU信息校验
     * 仅校验YCM库（YOP库后续下掉）：
     * gd_atom_basic
     * gd_atom_item
     * gd_order_way_config
     * gd_goods_id_mapping
     *
     * @param combine_app_id
     */
    public Map<String, List<String>> queryCombineSpuAndSku(String combine_app_id) {
        Map<String, List<String>> result = new HashMap<>();
        //gd_combine_basic-组合商品SPU ID
        log.info("组合商品SPU-id=" + combine_app_id);

        //gd_combine_item-商品SKU列表
        List<GdCombineItem> gdAtomItemList = gdCombineItemMapper.selectList(new QueryWrapper<GdCombineItem>().lambda().eq(GdCombineItem::getCombineAppId, combine_app_id));
        // 商品SKU=atom_skus-商品SKU item_id 列表
        List<String> gdAtomItemLists = gdAtomItemList.stream().map(GdCombineItem::getCombineItemId).collect(Collectors.toList());
        gdAtomItemLists.add(combine_app_id);
        log.info("组合商品SKU列表=" + gdAtomItemLists.toString());

        //gd_goods_id_mapping
        List<GdGoodsIdMapping> gdGoodsIdMappings = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().lambda().in(GdGoodsIdMapping::getYcmId, gdAtomItemLists));
        // YOP ids
        List<String> yopAppIds = gdGoodsIdMappings.stream().map(GdGoodsIdMapping::getYopId).map((ele) -> String.valueOf(ele)).collect(Collectors.toList());
        // gd_combine_template id
        List<String> combine_templates = gdCombineTemplateMapper.selectList(new QueryWrapper<GdCombineTemplate>().lambda().eq(GdCombineTemplate::getCombineAppId, combine_app_id)).stream().map(GdCombineTemplate::getId).map((ele) -> ele.toString()).collect(Collectors.toList());
        ;
        log.info("组合商品Yop-APP-id列表=" + yopAppIds.toString());
        result.put("combine_sku_items", gdAtomItemLists);
        result.put("yop_app_ids", yopAppIds);
        result.put("combine_templates", combine_templates);
        return result;
    }

    /**
     * 组合商品SKU查询
     */
    public Map<String, List<String>> queryGoodsDetail(Integer app_id) {
        HashMap<String, List<String>> result = new HashMap<>();
        if (app_id != null) {
            // gd_goods_id_mapping:获取关联的原子软件，组合软件
            List<String> ycm_ids = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().lambda().eq(GdGoodsIdMapping::getYopId, app_id)).stream().map((e) -> e.getYcmId()).collect(Collectors.toList());
            result.put("ycm_ids", ycm_ids);
            // gd_sku
            List<GdSkuEntity> gdSkuEntityList = gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id));
            List<String> sku_ids = gdSkuEntityList.stream().map((entity) -> entity.getSkuId()).collect(Collectors.toList());
            List<String> item_ids = gdSkuEntityList.stream().map((entity) -> entity.getItemId().toString()).collect(Collectors.toList());
            item_ids.add(0, app_id.toString());

            result.put("sku_ids", sku_ids);
            result.put("item_ids", item_ids);
            //gd_combine_item
            List<String> combine_template_ids = gdCombineItemMapper.selectList(new QueryWrapper<GdCombineItem>().lambda().eq(GdCombineItem::getAppId, app_id)).stream().map((entity) -> entity.getCombineTemplateId().toString()).collect(Collectors.toList());
            result.put("combine_template_ids", combine_template_ids);
            // 权益商品：gd_goods_rights_relation
            List<String> rights_ids = gdGoodsRightsRelationMapper.selectList(new QueryWrapper<GdGoodsRightsRelationEntity>().lambda().in(GdGoodsRightsRelationEntity::getAppId,ycm_ids)).stream().map((e)->e.getRightsId().toString()).collect(Collectors.toList());
            Set<String> set_ids = new HashSet<>();
            set_ids.addAll(rights_ids);
            rights_ids.clear();
            rights_ids.addAll(set_ids);
            result.put("rights_ids", rights_ids);
            // 输出
            for (String string : result.keySet()) {
                log.info(string + "=" + result.get(string));
            }


        }
        return result;
    }

    /**
     * ！！根据原子软件的app_id（插件，软件），清理原子软件+组合SPU+组合SKU全部信息
     *
     * @param app_id 1000445696 必须大于这个值的自定义插件才支持删除
     * @return
     */
    public Boolean clearAllByAppId(Integer app_id) {
        Assert.assertEquals(app_id >= 1000445696, true, "危险操作，删除的原子软件app_id必须大于1000445696且是自定义的软件");
        //落库等待
        atomNewDb(app_id);
        //查询
        Map<String, List<String>> queryResult = queryGoodsDetail(app_id);
        if (queryResult != null) {
            if (queryResult.get("item_ids").size() > 0) {
                List<String> item_ids = queryResult.get("item_ids");
                // 删除open_** 表
                //open_application_basic
                openApplicationBasicMapper.delete(new QueryWrapper<OpenApplicationBasicEntity>().lambda().in(OpenApplicationBasicEntity::getAppid, item_ids));
                //open_application_basic_ext
                openApplicationBasicExtMapper.delete(new QueryWrapper<OpenApplicationBasicExtEntity>().lambda().in(OpenApplicationBasicExtEntity::getAppId, item_ids));
                //open_application_item
                openApplicationItemMapper.delete(new QueryWrapper<OpenApplicationItemEntity>().lambda().in(OpenApplicationItemEntity::getAppid, item_ids));
                //open_application_agreement_relation
                openApplicationAgreementRelationMapper.delete(new QueryWrapper<OpenApplicationAgreementRelationEntity>().lambda().in(OpenApplicationAgreementRelationEntity::getAppId, item_ids));
                //open_application_item_shop_relation
                openApplicationItemShopRelationMapper.delete(new QueryWrapper<OpenApplicationItemShopRelationEntity>().lambda().in(OpenApplicationItemShopRelationEntity::getAppId, item_ids));
                //plugin_item_relation(插件套餐)
                pluginItemRelationMapper.delete(new QueryWrapper<PluginItemRelationEntity>().lambda().in(PluginItemRelationEntity::getParentItemId, item_ids));
                // YCM 表
                //gd_atom_basic
                gdAtomBasicMapper.delete(new QueryWrapper<GdAtomBasic>().lambda().in(GdAtomBasic::getAppId, item_ids));
                //gd_atom_item
                gdAtomItemMapper.delete(new QueryWrapper<GdAtomItem>().lambda().in(GdAtomItem::getAppId, item_ids));
                //gd_combine_basic
                gdCombineBasicMapper.delete(new QueryWrapper<GdCombineBasic>().lambda().in(GdCombineBasic::getAppId, item_ids));
                //gd_combine_item
                gdCombineItemMapper.delete(new QueryWrapper<GdCombineItem>().lambda().in(GdCombineItem::getAppId, item_ids));
                //gd_order_way_config
                if (queryResult.get("ycm_ids").size() > 0) {
                    gdOrderWayConfigMapper.delete(new QueryWrapper<GdOrderWayConfigEntity>().lambda().in(GdOrderWayConfigEntity::getSpuId, queryResult.get("ycm_ids")));
                }
                if (queryResult.get("combine_template_ids").size() > 0) {
                    //gd_combine_template
                    gdCombineTemplateMapper.delete(new QueryWrapper<GdCombineTemplate>().lambda().in(GdCombineTemplate::getId, queryResult.get("combine_template_ids")));
                    //gd_combine_template_content
                    gdCombineTemplateContentMapper.delete(new QueryWrapper<GdCombineTemplateContent>().lambda().in(GdCombineTemplateContent::getCombineTemplateId, queryResult.get("combine_template_ids")));
                }
                // 新表
                gdSpuMapper.delete(new QueryWrapper<GdSpuEntity>().lambda().in(GdSpuEntity::getAppId, item_ids));
                gdSpuSnapshotMapper.delete(new QueryWrapper<GdSpuSnapshotEntity>().lambda().in(GdSpuSnapshotEntity::getAppId, item_ids));
                gdSkuMapper.delete(new QueryWrapper<GdSkuEntity>().lambda().in(GdSkuEntity::getAppId, item_ids));
                gdSkuSnapshotMapper.delete(new QueryWrapper<GdSkuSnapshotEntity>().lambda().in(GdSkuSnapshotEntity::getAppId, item_ids));
                if (queryResult.get("sku_ids").size() > 0) {
                    //gd_sku_content
                    gdSkuContentMapper.delete(new QueryWrapper<GdSkuContentEntity>().lambda().in(GdSkuContentEntity::getSkuId, queryResult.get("sku_ids")));
                    //gd_atom_item_property_relation
                    gdAtomItemPropertyRelationMapper.delete(new QueryWrapper<GdAtomItemPropertyRelation>().lambda().in(GdAtomItemPropertyRelation::getAtomItemId, queryResult.get("sku_ids")));
                    //gd_operate_log
                    gdOperateLogMapper.delete(new QueryWrapper<GdOperateLogEntity>().lambda().in(GdOperateLogEntity::getBizNo, queryResult.get("sku_ids")));
                }

                //gd_goods_id_mapping
                gdGoodsIdMappingMapper.delete(new QueryWrapper<GdGoodsIdMapping>().lambda().in(GdGoodsIdMapping::getYopId, item_ids));
                //gd_goods_rights_relation 权益商品
                if (queryResult.get("ycm_ids").size() > 0) {
                    gdGoodsRightsRelationMapper.delete(new QueryWrapper<GdGoodsRightsRelationEntity>().lambda().in(GdGoodsRightsRelationEntity::getAppId, queryResult.get("ycm_ids")));
                }
                //gd_rights   权益商品
                if (queryResult.get("rights_ids").size() > 0) {
                    if(queryResult.get("rights_ids").contains("256")){ //PS:gd_rights.id=256的是 服务类默认权益，千万别删
                        log.info("gd_rights.id==256,不可以删除");
                    }else {
                        gdRightsMapper.delete(new QueryWrapper<GdRightsEntity>().lambda().in(GdRightsEntity::getId, queryResult.get("rights_ids")));
                        log.info("gd_rights.id!=256,可以删除");
                    }
                }
                log.info("根据原子app_id删除全部数据成功！");
                return Boolean.TRUE;
            }
            log.info("失败！根据原子app_id删除全部数据失败！");
            return Boolean.FALSE;
        }
        log.info("失败！根据原子app_id删除全部数据失败！");
        return Boolean.FALSE;
    }

    /**
     * 有赞云-应用市场，上下架
     */
    public void checkAppStateByAppId(String atom_app_id, String state) {
        //gd_atom_basic
        GdAtomBasic gdAtomBasic = gdAtomBasicMapper.selectOne(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAtomAppId, atom_app_id).orderByDesc(GdAtomBasic::getSnapshotNo).last("limit 1"));
        Assert.assertEquals(gdAtomBasic.getState(), state, "有赞云应用-商业化-01-SKU 旗舰版：查询结果错误");
        String snapshot = gdAtomBasic.getSnapshotNo().toString();
        log.info("atom_app_id gd_atom_basic 最新snapshot=" + snapshot);
        //gd_atom_item
        int gdAtomItem_size = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAtomAppId, atom_app_id).eq(GdAtomItem::getSnapshotNo, snapshot).eq(GdAtomItem::getState, state)).size();
        Assert.assertEquals(gdAtomItem_size, 6, "atom_app_id gd_atom_item表状态更新失败");
    }

    /**
     * 有赞云新增应用查询
     */
    public void newYZYAppCheck(String new_spu_id, String new_sku_id) {
        // 1-gd_atom_basic 表全检验
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> gdAtomBasicMapper.selectList(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAtomAppId, new_spu_id)).size() >= 1);

        int basic_size = gdAtomBasicMapper.selectList(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAtomAppId, new_spu_id)).size();

        if (basic_size == 1) {
            log.info("创建有赞云应用市场应用SPU成功:" + new_spu_id + ",开始落库校验");
            GdAtomBasic gdAtomBasic = gdAtomBasicMapper.selectOne(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAtomAppId, new_spu_id));
            Assert.assertEquals(gdAtomBasic.getAtomAppId(), new_spu_id, "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getAppId(), "-1", "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getName(), "有赞云应用市场SPU-WL-CI", "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getCategory(), "plugin", "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getState(), "on_shelf", "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getSnapshotNo(), Long.valueOf(1), "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getIsSupportYzb(), Byte.valueOf("0"), "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getIsFree(), Byte.valueOf("0"), "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getOwnerId(), "10001077008238", "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getOwnerType(), "YZYUN_DEVELOPER", "有赞云应用市场gd_atom_basic表落库错误");
            Assert.assertEquals(gdAtomBasic.getPerformType(), "period", "有赞云应用市场gd_atom_basic表落库错误");
        }
        // 2-gd_atom_item 表全检验
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAtomAppId, new_spu_id)).size() >= 1);

        int item_size = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAtomAppId, new_spu_id)).size();


        if (item_size == 1) {
            log.info("创建有赞云应用市场应用SKU成功:" + new_sku_id + ",开始落库校验");
            GdAtomItem gdAtomItem = gdAtomItemMapper.selectOne(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAtomAppId, new_spu_id));
            Assert.assertEquals(gdAtomItem.getAtomItemId(), new_sku_id, "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getItemId(), "-1", "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getAtomAppId(), new_spu_id, "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getAppId(), "-1", "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getName(), "SKU1", "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getEdition(), "normal", "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getSnapshotNo(), Long.valueOf(1), "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getPrice(), Long.valueOf(1), "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getState(), "on_shelf", "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getIsShow(), Byte.valueOf("0"), "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getIsFree(), Byte.valueOf("0"), "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getPerformType(), "period", "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getSpecPeriod(), Long.valueOf(31), "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getSpecPeriodUnit(), "day", "有赞云应用市场gd_atom_item表落库错误");
            Assert.assertEquals(gdAtomItem.getSpecQuantity(), Long.valueOf(0), "有赞云应用市场gd_atom_item表落库错误");
        }

        int sku_pro_size = gdAtomItemPropertyRelationMapper.selectList(new QueryWrapper<GdAtomItemPropertyRelation>().lambda().eq(GdAtomItemPropertyRelation::getAtomItemId, new_sku_id)).size();
        Assert.assertEquals(sku_pro_size, 3, "有赞云应用市场gd_atom_item_property_relation表落库错误");
    }

    /**
     * 删除有赞云应用落表
     *
     * @param new_spu_id
     * @param new_sku_id
     */
    public void clearYZYApp(String new_spu_id, String new_sku_id) {
        if (StringUtils.isNotEmpty(new_spu_id) && StringUtils.isNotEmpty(new_sku_id)) {
            gdAtomBasicMapper.delete(new QueryWrapper<GdAtomBasic>().lambda().eq(GdAtomBasic::getAtomAppId, new_spu_id));
            gdAtomItemMapper.delete(new QueryWrapper<GdAtomItem>().lambda().eq(GdAtomItem::getAtomItemId, new_sku_id));
            gdAtomItemPropertyRelationMapper.delete(new QueryWrapper<GdAtomItemPropertyRelation>().lambda().eq(GdAtomItemPropertyRelation::getAtomItemId, new_sku_id));
            log.info("有赞云应用市场应用删除成功SPU=" + new_spu_id + ",SKU=" + new_sku_id);
        }
    }


    /**
     * 组合商品SKU查询
     */
    public Map<String, String> combineSkuQuery(Integer app_id, CombineSkuCreateRequest request) {
        HashMap<String, String> result = new HashMap<>();
        if (app_id != null) {
            //落库-gd_goods_id_mapping 查询记录大于1
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().lambda().eq(GdGoodsIdMapping::getYopId, app_id)).size() >= 1);

            //落库-Open库 open_application_item 查询记录大于3(原子软件创建了天/年的2个SKU)
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> openApplicationItemMapper.selectList(new QueryWrapper<OpenApplicationItemEntity>().lambda().eq(OpenApplicationItemEntity::getAppid, app_id)).size() >= 3);

            //落库-Open库 open_application_agreement_relation 查询记录大于1
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> openApplicationAgreementRelationMapper.selectList(new QueryWrapper<OpenApplicationAgreementRelationEntity>().lambda().eq(OpenApplicationAgreementRelationEntity::getAppId, app_id)).size() >= 1);

            //落库-YCM库 gd_spu 查询记录大于1
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdSpuMapper.selectList(new QueryWrapper<GdSpuEntity>().lambda().eq(GdSpuEntity::getAppId, app_id).eq(GdSpuEntity::getGoodsType, "combine")).size() >= 1);

            //落库-YCM库 gd_sku 查询记录=3
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id)).size() == 3);

            // gd_goods_id_mapping:获取关联的原子软件，组合软件
            List<String> ycm_ids = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().lambda().eq(GdGoodsIdMapping::getYopId, app_id)).stream().map((e) -> e.getYcmId()).collect(Collectors.toList());
            String main_good_app_id = new String();
            String combine_app_id = new String();
            for (String s : ycm_ids) {
                if (s.startsWith("combine")) {
                    main_good_app_id = s;
                } else if (s.startsWith("atom")) {
                    combine_app_id = s;
                }
            }
            log.info("原子软件的ycm_id,main_good_app_id=" + main_good_app_id);
            log.info("组合套餐SKU的combine_app_id=" + combine_app_id);
            result.put("main_good_app_id", main_good_app_id);
            result.put("combine_app_id", combine_app_id);

            // gd_sku
            List<GdSkuEntity> gdSkuEntityList = gdSkuMapper.selectList(new QueryWrapper<GdSkuEntity>().lambda().eq(GdSkuEntity::getAppId, app_id));
            String year_atom_sku = new String();
            String day_atom_sku = new String();
            String year_combine_sku = new String();
            Long year_combine_sku_snapshot_no = 1L;

            for (GdSkuEntity gdSkuEntity : gdSkuEntityList) {
                if (gdSkuEntity.getGoodsType().equals("atom") && gdSkuEntity.getSpecPeriodUnit().equals("year")) {
                    year_atom_sku = gdSkuEntity.getSkuId();
                }
                if (gdSkuEntity.getGoodsType().equals("atom") && gdSkuEntity.getSpecPeriodUnit().equals("day")) {
                    day_atom_sku = gdSkuEntity.getSkuId();
                }
                if (gdSkuEntity.getGoodsType().equals("combine") && gdSkuEntity.getSpecPeriodUnit().equals("year")) {
                    year_combine_sku = gdSkuEntity.getSkuId();
                    year_combine_sku_snapshot_no = gdSkuEntity.getSnapshotNo();
                }
            }
            log.info("原子软件天SKU=" + day_atom_sku);
            log.info("原子软件年SKU=" + year_atom_sku);
            log.info("组合套餐年SKU=" + year_combine_sku);
            log.info("组合套餐年SKU最新SNAPSHOT=" + year_combine_sku_snapshot_no);

            result.put("day_atom_sku", day_atom_sku);
            result.put("year_atom_sku", year_atom_sku);
            result.put("year_combine_sku", year_combine_sku);
            //gd_sku_snapshot
            GdSkuSnapshotEntity gdSkuSnapshotEntity = gdSkuSnapshotMapper.selectOne(new QueryWrapper<GdSkuSnapshotEntity>().lambda().eq(GdSkuSnapshotEntity::getSpuId, main_good_app_id).eq(GdSkuSnapshotEntity::getGoodsType, "combine").orderByDesc(GdSkuSnapshotEntity::getSnapshotNo).last("limit 1"));
            Assert.assertEquals(gdSkuSnapshotEntity.getSnapshotNo(), year_combine_sku_snapshot_no, "gd_sku_snapshot 表snapshot_no error");


            // gd_combine_basic
            GdCombineBasic gdCombineBasic = gdCombineBasicMapper.selectOne(new QueryWrapper<GdCombineBasic>().lambda().eq(GdCombineBasic::getAppId, app_id));
            Assert.assertEquals(gdCombineBasic.getCombineAppId(), main_good_app_id, "gd_combine_basic 表的combine_app_id与gd_goods_id_mapping表不一致");
            Assert.assertEquals(gdCombineBasic.getMainGoodAppId(), combine_app_id, "gd_combine_basic 表的main_good_app_id与gd_goods_id_mapping表不一致");

            // gd_combine_item
            GdCombineItem gdCombineItem = gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>().lambda().eq(GdCombineItem::getAppId, app_id));
            String combine_item_id = gdCombineItem.getCombineItemId();
            String item_id = gdCombineItem.getItemId();
            String combine_template_id = String.valueOf(gdCombineItem.getCombineTemplateId());

            log.info("组合套餐SKU的combine_item_id=" + combine_item_id);
            log.info("组合套餐SKU的item_id=" + item_id);
            log.info("组合套餐SKU的combine_template_id=" + combine_template_id);

            Assert.assertEquals(gdCombineItem.getCombineAppId(), main_good_app_id, "gd_combine_item combine_app_id 错误");
            Assert.assertEquals(gdCombineItem.getTemplateType(), "fixed", "gd_combine_item template_type 错误");
            Assert.assertEquals(gdCombineItem.getIsShow(), Byte.valueOf("1"), "gd_combine_item is_show 错误");
            Assert.assertEquals(gdCombineItem.getSpecPeriod(), "1", "gd_combine_item spec_period 错误");
            Assert.assertEquals(gdCombineItem.getSpecPeriodUnit(), "year", "gd_combine_item spec_period_unit 错误");
            Assert.assertEquals(gdCombineItem.getEdition(), "normal", "gd_combine_item edition 错误");
            result.put("combine_item_id", combine_item_id);
            result.put("item_id", item_id);
            result.put("combine_template_id", combine_template_id);

            // gd_combine_template
            GdCombineTemplate gdCombineTemplate = gdCombineTemplateMapper.selectOne(new QueryWrapper<GdCombineTemplate>().lambda().eq(GdCombineTemplate::getCombineAppId, main_good_app_id));
            Assert.assertEquals(gdCombineTemplate.getId(), Long.valueOf(combine_template_id), "gd_combine_template id 错误");
            Assert.assertEquals(gdCombineTemplate.getTemplateType(), "fixed", "gd_combine_template template_type 错误");
            Assert.assertEquals(gdCombineTemplate.getVersion(), request.getVersion(), "gd_combine_template version 错误");
            Assert.assertEquals(gdCombineTemplate.getPrice(), request.getPrice(), "gd_combine_template price 错误");
            Assert.assertEquals(gdCombineTemplate.getName(), request.getSkuName(), "gd_combine_template name 错误");
            Assert.assertEquals(gdCombineTemplate.getDescInfo(), request.getDescInfo(), "gd_combine_template desc_info 错误");
            Assert.assertEquals(gdCombineTemplate.getIsPackageSale(), Byte.valueOf("1"), "gd_combine_template is_package_sale 错误");
            Assert.assertEquals(gdCombineTemplate.getState(), request.getShelfState(), "gd_combine_template state 错误");

            // gd_combine_template_content
            List<GdCombineTemplateContent> gdCombineTemplateContentList = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>().lambda().eq(GdCombineTemplateContent::getCombineTemplateId, combine_template_id));
            Assert.assertEquals(gdCombineTemplateContentList.size(), 3, "gd_combine_template_content size 错误");
            for (GdCombineTemplateContent gdCombineTemplateContent : gdCombineTemplateContentList) {
                if (gdCombineTemplateContent.getItemId().equals(year_atom_sku)) {
                    //原子 年SKU为主商品
                    Assert.assertEquals(gdCombineTemplateContent.getIsLeader(), Byte.valueOf("1"), "gd_combine_template_content is_leader 主商品错误");
                    log.info("组合套餐SKU主商品绑定成功");
                }
                if (gdCombineTemplateContent.getItemId().equals(request.getSkuItemList().get(1).getSkuId())) {
                    log.info("组合套餐SKU插件atom_sku_point_store_year绑定成功");
                }
                if (gdCombineTemplateContent.getItemId().equals(request.getSkuItemList().get(2).getSkuId())) {
                    log.info("组合套餐SKU插件atom_sku_groupon_year绑定成功");
                }
            }
            //gd_order_way_config
            int sizeWayConfig = gdOrderWayConfigMapper.selectList(new QueryWrapper<GdOrderWayConfigEntity>().lambda().eq(GdOrderWayConfigEntity::getSpuId, main_good_app_id)).size();
            Assert.assertEquals(sizeWayConfig, 9, "订购方式错误");
            //gd_sku_content
            List<GdSkuContentEntity> gdSkuContentEntityList = gdSkuContentMapper.selectList(new QueryWrapper<GdSkuContentEntity>().lambda().eq(GdSkuContentEntity::getSkuId, combine_item_id));
            Assert.assertEquals(gdSkuContentEntityList.size(), 3, "gd_combine_template_content size 错误");
            for (GdSkuContentEntity gdSkuContentEntity : gdSkuContentEntityList) {
                if (gdSkuContentEntity.getRelSkuId().equals(year_atom_sku)) {
                    //原子 年SKU为主商品
                    Assert.assertEquals(gdSkuContentEntity.getIsLeader(), Byte.valueOf("1"), "gd_sku_content is_leader 主商品错误");
                    log.info("组合套餐SKU主商品绑定成功");
                }
                if (gdSkuContentEntity.getRelSkuId().equals(request.getSkuItemList().get(1).getSkuId())) {
                    log.info("组合套餐SKU插件atom_sku_point_store_year绑定成功");
                }
                if (gdSkuContentEntity.getRelSkuId().equals(request.getSkuItemList().get(2).getSkuId())) {
                    log.info("组合套餐SKU插件atom_sku_groupon_year绑定成功");
                }
            }
            // open_application_item
            int size_open_app_item = openApplicationItemMapper.selectList(new QueryWrapper<OpenApplicationItemEntity>().lambda().eq(OpenApplicationItemEntity::getAppid, app_id)).size();
            Assert.assertEquals(size_open_app_item, 3, "open_application_item错误");

            // open_application_item_shop_relation
            int size_open_application_item_shop_relation = openApplicationItemShopRelationMapper.selectList(new QueryWrapper<OpenApplicationItemShopRelationEntity>().lambda().eq(OpenApplicationItemShopRelationEntity::getAppId, app_id)).size();
            Assert.assertEquals(size_open_application_item_shop_relation, 5, "open_application_item_shop_relation错误");

            // open_application_agreement_relation
            int size_open_application_agreement_relation = openApplicationAgreementRelationMapper.selectList(new QueryWrapper<OpenApplicationAgreementRelationEntity>().lambda().eq(OpenApplicationAgreementRelationEntity::getAppId, app_id)).size();
            Assert.assertEquals(size_open_application_agreement_relation, 1, "open_application_agreement_relation错误");

        }
        return result;
    }

    /**
     * 权益校验
     */
    public void rightDBCheck(Long rightId, SaveRightsRequest saveRightsRequest, String state) {
        //落库-YCM库 gd_sku 查询记录=3
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdRightsMapper.selectList(new QueryWrapper<GdRightsEntity>().lambda().eq(GdRightsEntity::getId, rightId)).size() == 1);

        //落库校验
        GdRightsEntity gdRightsEntity = gdRightsMapper.selectOne(new QueryWrapper<GdRightsEntity>().lambda().eq(GdRightsEntity::getId, rightId));
        log.info(gdRightsEntity.toString());
        Assert.assertEquals(gdRightsEntity.getName(), saveRightsRequest.getName());
        Assert.assertEquals(gdRightsEntity.getDescInfo(), saveRightsRequest.getDescInfo());
        Assert.assertEquals(gdRightsEntity.getCategory(), saveRightsRequest.getCategory());
        Assert.assertEquals(gdRightsEntity.getAppId(), saveRightsRequest.getAppId());
        Assert.assertEquals(gdRightsEntity.getChannel(), "YOUZAN");
        Assert.assertEquals(gdRightsEntity.getState(), state);
        Assert.assertEquals(gdRightsEntity.getIsShow(), Boolean.TRUE);
        //gd_goods_rights_relation 表无数据
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(() -> gdGoodsRightsRelationMapper.selectList(new QueryWrapper<GdGoodsRightsRelationEntity>().lambda().eq(GdGoodsRightsRelationEntity::getRightsId, rightId)).size() == 0);

    }

    /**
     * 权益-删除
     */
    public void rightDBDelete(Long rightId) {
        //删除
        gdRightsMapper.delete(new QueryWrapper<GdRightsEntity>().lambda().eq(GdRightsEntity::getId, rightId));
    }


    /**
     * 有赞云：加油包，套餐包 落库校验
     *
     * @param combine_app_id  combine_spu_youzanyun_basic_package or combine_spu_youzanyun_plus_package
     * @param combine_item_id 自定义的itemid
     * @param request         创建请求
     */
    public void newYZYPlusBasicPackageCheck(String combine_app_id, String combine_item_id, UpdateCombineGoodsSkuRequest request) {
        // 1-gd_combine_basic 表全检验
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> gdCombineBasicMapper.selectList(new QueryWrapper<GdCombineBasic>().lambda().eq(GdCombineBasic::getCombineAppId, combine_app_id)).size() == 1);
        GdCombineBasic gdCombineBasic = gdCombineBasicMapper.selectOne(new QueryWrapper<GdCombineBasic>().lambda().eq(GdCombineBasic::getCombineAppId, combine_app_id));

        // 2-gd_combine_item 表全检验
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> gdCombineItemMapper.selectList(new QueryWrapper<GdCombineItem>().lambda().eq(GdCombineItem::getCombineAppId, combine_app_id).eq(GdCombineItem::getCombineItemId, combine_item_id)).size() == 1);

        GdCombineItem gdCombineItem = gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>().lambda().eq(GdCombineItem::getCombineAppId, combine_app_id).eq(GdCombineItem::getCombineItemId, combine_item_id));

        Long combine_template_id = gdCombineItem.getCombineTemplateId();

        // 3-gd_combine_template 表全检验
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> gdCombineTemplateMapper.selectList(new QueryWrapper<GdCombineTemplate>().lambda().eq(GdCombineTemplate::getId, combine_template_id)).size() == 1);

        GdCombineTemplate gdCombineTemplate = gdCombineTemplateMapper.selectOne(new QueryWrapper<GdCombineTemplate>().lambda().eq(GdCombineTemplate::getId, combine_template_id));

        // 4-gd_combine_template_content 表全检验
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>().lambda().eq(GdCombineTemplateContent::getCombineTemplateId, combine_template_id)).size() == 3);

        List<GdCombineTemplateContent> gdCombineTemplateContentList = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>().lambda().eq(GdCombineTemplateContent::getCombineTemplateId, combine_template_id));

        // 4表校验
        if (gdCombineItem != null) {
            log.info("创建有赞云加油包SKU成功:" + combine_item_id + ",开始落库校验");
            //gdCombineBasic
            Assert.assertEquals(gdCombineBasic.getCombineAppId(), combine_app_id, "gdCombineBasic表落库错误");
            Assert.assertEquals(gdCombineBasic.getState(), "on_shelf", "gdCombineBasic表落库错误");
            Assert.assertEquals(gdCombineBasic.getSnapshotNo(), Long.valueOf(1), "gdCombineBasic表落库错误");
            Assert.assertEquals(gdCombineBasic.getIsSupportYzb(), Byte.valueOf("0"), "gdCombineBasic表落库错误");
            Assert.assertEquals(gdCombineBasic.getOwnerType(), "YZYUN", "gdCombineBasic表落库错误");
            Assert.assertEquals(gdCombineBasic.getAtomAgreementFlag(), Byte.valueOf("1"), "gdCombineBasic表落库错误");

            //gdCombineItem
            Assert.assertEquals(gdCombineItem.getItemId(), "-1", "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getName(), request.getCommonItemInfoDTO().getName(), "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getEdition(), "normal", "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getSnapshotNo(), Long.valueOf(1), "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getTemplateType(), "fixed", "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getIsShow(), Byte.valueOf("0"), "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getPerformType(), "period", "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getSpecPeriod(), "1", "gdCombineItem表落库错误");
            Assert.assertEquals(gdCombineItem.getSpecPeriodUnit(), "year", "gdCombineItem表落库错误");

            //gdCombineTemplate
            Assert.assertEquals(gdCombineTemplate.getName(), request.getCommonItemInfoDTO().getName(), "gdCombineTemplate表落库错误");
            Assert.assertEquals(gdCombineTemplate.getCombineAppId(), combine_app_id, "gdCombineTemplate表落库错误");
            Assert.assertEquals(gdCombineTemplate.getTemplateType(), "fixed", "gdCombineTemplate表落库错误");
            Assert.assertEquals(gdCombineTemplate.getVersion(), "basic", "gdCombineTemplate表落库错误");
            Assert.assertEquals(gdCombineTemplate.getTemplateSnapshotNo(), Long.valueOf(1), "gdCombineTemplate表落库错误");
            Assert.assertEquals(gdCombineTemplate.getIsPackageSale(), Byte.valueOf("1"), "gdCombineTemplate表落库错误");
            Assert.assertEquals(gdCombineTemplate.getState(), "on_shelf", "gdCombineTemplate表落库错误");

            // 资源包与加油包的区别部分
            if (combine_app_id.equals("combine_spu_youzanyun_plus_package")) {
                Assert.assertEquals(gdCombineBasic.getAppId(), "477772", "gdCombineBasic表落库错误");
                Assert.assertEquals(gdCombineBasic.getName(), "有赞云-资源加油包", "gdCombineBasic表落库错误");
                Assert.assertEquals(gdCombineBasic.getCategory(), "refueling_package", "gdCombineBasic表落库错误");

                Assert.assertEquals(gdCombineItem.getAppId(), "477772", "gdCombineItem表落库错误");

                Assert.assertEquals(gdCombineTemplate.getPrice(), Long.valueOf(20000), "gdCombineTemplate表落库错误");

            } else if (combine_app_id.equals("combine_spu_youzanyun_basic_package")) {
                Assert.assertEquals(gdCombineBasic.getAppId(), "-1", "gdCombineBasic表落库错误");
                Assert.assertEquals(gdCombineBasic.getName(), "有赞云-资源套餐包", "gdCombineBasic表落库错误");
                Assert.assertEquals(gdCombineBasic.getCategory(), "meal_package", "gdCombineBasic表落库错误");

                Assert.assertEquals(gdCombineItem.getAppId(), "-1", "gdCombineItem表落库错误");

                Assert.assertEquals(gdCombineTemplate.getPrice(), Long.valueOf(0), "gdCombineTemplate表落库错误");
            }
            //GdCombineTemplateContent
            for (GdCombineTemplateContent gdCombineTemplateContent : gdCombineTemplateContentList) {
                Assert.assertEquals(gdCombineTemplateContent.getItemType(), "atom", "GdCombineTemplateContent");
                Assert.assertEquals(gdCombineTemplateContent.getIsLeader(), Byte.valueOf("0"), "GdCombineTemplateContent");
                Assert.assertEquals(gdCombineTemplateContent.getItemSnapshotNo(), Long.valueOf(1), "GdCombineTemplateContent");

                if (gdCombineTemplateContent.getItemId().equals("atom_sku_youzanyun_api")) {
                    Assert.assertEquals(gdCombineTemplateContent.getTemplateQuantity(), Long.valueOf(2), "GdCombineTemplateContent");
                }
                if (gdCombineTemplateContent.getItemId().equals("atom_sku_youzanyun_container")) {
                    Assert.assertEquals(gdCombineTemplateContent.getTemplateQuantity(), Long.valueOf(200), "GdCombineTemplateContent");
                }
                if (gdCombineTemplateContent.getItemId().equals("atom_sku_youzanyun_message")) {
                    Assert.assertEquals(gdCombineTemplateContent.getTemplateQuantity(), Long.valueOf(2), "GdCombineTemplateContent");
                }
            }
        }

    }

    /**
     * 删除有赞云加油包
     */
    public void deleteYZYPlusBasicPackageCheck(String combine_app_id, String combine_item_id) {
        if (StringUtils.isNotEmpty(combine_app_id) && StringUtils.isNotEmpty(combine_item_id)) {
            GdCombineItem gdCombineItem = gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>().lambda().eq(GdCombineItem::getCombineAppId, combine_app_id).eq(GdCombineItem::getCombineItemId, combine_item_id));
            Long combine_template_id = gdCombineItem.getCombineTemplateId();
            if (combine_template_id != null) {
                gdCombineItemMapper.delete(new QueryWrapper<GdCombineItem>().lambda().eq(GdCombineItem::getCombineAppId, combine_app_id).eq(GdCombineItem::getCombineItemId, combine_item_id).last("limit 1"));
                gdCombineTemplateMapper.delete(new QueryWrapper<GdCombineTemplate>().lambda().eq(GdCombineTemplate::getId, combine_template_id).eq(GdCombineTemplate::getCombineAppId, combine_app_id).last("limit 1"));
                gdCombineTemplateContentMapper.delete(new QueryWrapper<GdCombineTemplateContent>().lambda().eq(GdCombineTemplateContent::getCombineTemplateId, combine_template_id).last("limit 3"));
            }

        }
    }
    /**
     * 权益商品
     */
}
