package com.youzan.test.checkDebugTest.CreateOrderRisk;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.BasicQueryRemoteServiceV2;
import com.youzan.yop.api.entity.order.CalOrderPriceApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.basic.PurchasableServiceFetchForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.form.order.RiskCheckForm;
import com.youzan.yop.api.response.ItemPreferentialInfoResultApi;
import com.youzan.yop.api.response.ItemRiskResultApi;
import com.youzan.yop.api.response.PurchasableSoftwareApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/1/22 2:19 PM
 */
public class CreateOrderRiskTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(CreateOrderRiskTest.class);
    @Dubbo
    public BasicQueryRemoteServiceV2 basicQueryRemoteServiceV2;

    public Long kdtIdForCheck = 58828407L;
    public String kdtNameForCheck = "CI-接口自动化-下单校验测试";

    public Long kdtIdFor3Years = 58831110L;
    public String kdtNameFor3Years = "CI-接口自动化-下单校验（3年服务期限制）";

    public Long kdtIdForHighToLow = 58831129L;
    public String kdtNameForHighToLow = "CI-接口自动化-高续低";

    public Long kdtIdForWaitReviewOrder = 58833676L;
    public String kdtNameForWaitReviewOrder = "CI-接口自动化-有待审核订单";

    public Long jyKdtId = 59102436L;
    public String jyKdtName = "CI-自动化测试-教育单店";

    public Long lsKdtId = 59200319L;
    public String lsKdtName = "CI-自动化测试-零售下单校验";


    public Long baoDanKdtId = 59200601L;
    public String baoDanKdtName = "下单校验-爆单计划";
    public int giftCard = 6350;
    public int giftCardChain =20106;
    public int jyBasicItemId = 8310;
    public int jyProItemId = 8311;
    public int baoDanPlan = 73357;

    public Long wscAppId = 873L;
    public Long jyAppId = 39748L;

    /**
     * 有待支付订单创建订单测试（执行前保证有待支付订单和待审核订单）
     * @param kdtId
     * @param kdtName
     */
    @Test(dataProvider = "riskCheck-twoParam")
    public void createOrderHasWaitPayOrder(Long kdtId,String kdtName) {
        //closeWaitPayOrder(kdtId);
        PlainResult<String>  result = compareServiceImp.invoke(()->createNormalOrder(kdtId,kdtName,basicWechatItemId,1,0L));
        //ListResult<PoolDTO> result = compareServiceImp.invoke(()->poolQueryService.queryAssociatedUserPoolByDeptPoolId(81836L),compareConfig1);
        //PlainResult<String>  resultAgain = createNormalOrder(kdtId,kdtName,basicWechatItemId,1,0L);

        //logger.info("有待支付订单再次创建订单的返回结果：{}", JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),130033);
    }


    /**
     * 有待审核订单创建订单测试
     */
    @Test
    public void createOrderHasWaitReviewOrder() {
        PlainResult<String>  result = compareServiceImp.invoke(()->createNormalOrder(kdtIdForWaitReviewOrder,kdtNameForWaitReviewOrder,basicWechatItemId,1,0L));
        //ListResult<PoolDTO> result = compareServiceImp.invoke(()->poolQueryService.queryAssociatedUserPoolByDeptPoolId(81836L),compareConfig1);
        //PlainResult<String>  resultAgain = createNormalOrder(kdtIdForWaitReviewOrder,kdtNameForWaitReviewOrder,basicWechatItemId,1,0L);

        //logger.info("有待支付订单再次创建订单的返回结果：{}", JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),130033);
    }

    /**
     * 3年服务期限制
     */
    @Test(dataProvider = "for3Years")
    public void createOrderFor3YearsLimit(Long kdtId,String kdtName,Long appId,int one,int two,int three,int code) {
        PlainResult<String> result = compareServiceImp.invoke(()->yearsLimit(kdtId,kdtName,appId,one, two, three, code));
    }


    /**
     * 高续低--创建订单(createNormalOrder)（目前错误返回码与线上不一致，线上是130608，实际是130033）
     */
    @Test
    public void highToLowLow() {
        initShopByKdtId(kdtIdForHighToLow);
        rechargeShopBalance(String.valueOf(kdtIdForHighToLow), cny);

        PlainResult<String>  result = createNormalOrder(kdtIdForHighToLow,kdtNameForHighToLow,professionItemId,1,0L);

        Assert.assertEquals(result.getCode(),200,result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, kdtIdForHighToLow);
        }
        waitForPerform(kdtIdForHighToLow,873L,Long.valueOf(result.getData()));

        //尝试创建一笔低版本订单
        PlainResult<String> renewResult = createNormalOrder(kdtIdForHighToLow,kdtNameForHighToLow,basicWechatItemId,1,0L);

        Assert.assertEquals(renewResult.getCode(),130033,renewResult.getMessage());
        Assert.assertEquals(renewResult.getMessage(),"你现在使用的有赞微商城为高版本，无法购买低版本");

    }

    /**
     * 高续低-90天内可以高续低(已购服务剩余天数 = 89，实际包括当天还有90天)-createNormalOrder
     */
    @Test
    public void highToLowLowIn90Days() {
        initShopByKdtId(kdtIdForHighToLow);
        rechargeShopBalance(String.valueOf(kdtIdForHighToLow), cny);

        PlainResult<String>  result = createNormalOrder(kdtIdForHighToLow,kdtNameForHighToLow,professionItemId,1,0L);

        Assert.assertEquals(result.getCode(),200,result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, kdtIdForHighToLow);
        }
        waitForPerform(kdtIdForHighToLow,873L,Long.valueOf(result.getData()));

        movePerformStatusByAppId(kdtIdForHighToLow,873L,-275);

        //尝试创建一笔低版本订单
        PlainResult<String> renewResult = createNormalOrder(kdtIdForHighToLow,kdtNameForHighToLow,basicWechatItemId,1,0L);

        Assert.assertEquals(renewResult.getCode(),200,renewResult.getMessage());
        Assert.assertEquals(renewResult.getMessage(),"successful");

    }

    @Test(dataProvider = "highToLow")
    public void threeYearsLimitInServiceInfo(Long kdtId) {
        //PlainResult<PurchasableSoftwareApi> fetchPurchasableServiceList = fetchPurchasableServiceList(kdtId,873);

        PlainResult<PurchasableSoftwareApi> fetchPurchasableServiceList = compareServiceImp.invoke(()->fetchPurchasableServiceList(kdtId,873));

    }



    @Test(dataProvider = "riskCheck-oneParam")
    public void hasWaitToPayOrderInServiceInfo(Long kdtId) {
        //initShopByKdtId(kdtIdForCheck);
        //PlainResult<String>  result = createNormalOrder(kdtIdForCheck,kdtNameForCheck,basicWechatItemId,1,0L);
        //if (result.isSuccess()) {
            PlainResult<PurchasableSoftwareApi> fetchPurchasableServiceList = compareServiceImp.invoke(()->fetchPurchasableServiceList(kdtId,873));
            Assert.assertEquals(fetchPurchasableServiceList.getData().getItemList().get(0).isCanOperate(),true);
        //}else {
            //throw new BusinessException("创建订单失败，请确定创建订单失败的原因后重新跑用例" + JSON.toJSONString(result));
        //}
    }

    @Test
    public void calOrderPriceHasWaitPayOrder() {
        PlainResult<CalOrderPriceApi>  resultAgain = compareServiceImp.invoke(()->calOrderPrice(kdtIdForCheck,kdtNameForCheck,basicWechatItemId,1));

        logger.info("有待支付订单再次创建订单的返回结果：{}",JSON.toJSONString(resultAgain));
        Assert.assertEquals(resultAgain.getCode(),200);
    }

    /**
     * 提交订单处待支付订单和待审核订单弹窗，是根据  "reason":"wait_pay","reason":"wait_pay", 来判断是弹哪个窗口
     * 执行前先保证店铺有待支付订单
     * @param kdtId
     */
    @Test(dataProvider = "riskCheck-oneParam")
    public void checkRiskForItemTest(Long kdtId) {
        RiskCheckForm riskCheckForm = new RiskCheckForm();
        List<OrderItemForm> orderItemList = new ArrayList<>();
        OrderItemForm orderItemForm = new OrderItemForm();
        orderItemForm.setItemId(basicWechatItemId);
        orderItemForm.setDuration(1);
        orderItemForm.setQuantity(1);
        orderItemList.add(orderItemForm);

        riskCheckForm.setItemList(orderItemList);
        riskCheckForm.setKdtId(kdtId);
        riskCheckForm.setAppId(873);
        riskCheckForm.setV2(true);
        logger.info("提交订单按钮风控参数：{}",JSON.toJSONString(riskCheckForm));
        //createNormalOrder(kdtId,"店铺名称",)

        PlainResult<List<ItemRiskResultApi>> riskResult
                = compareServiceImp.invoke(()->orderRemoteService.checkRiskForItemList(riskCheckForm));

        logger.info("风控检查结果：{}",JSON.toJSONString(riskResult));

    }

    /**
     * 验证新账号才能订购爆单计划
     * @param kdtId
     * @param kdtName
     */
    @Test(dataProvider = "baoDan")
    public void createBaoDan(Long kdtId,String kdtName) {
        closeWaitPayOrder(kdtId);
        PlainResult<String> result = compareServiceImp.invoke(()->createBaoDanPlan
                (kdtId,kdtName));
        //logger.info("创建订单返回：{}",result);
        //Assert.assertEquals(result.getCode(),200,result.getMessage());
       // Assert.assertEquals(result.getMessage(),"successful");

    }

    public PlainResult<String> createBaoDanPlan(Long kdtId,String kdtName) {
        closeWaitPayOrder(kdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (kdtId,kdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId,baoDanPlan),1,0L);
        logger.info("创建订单返回：{}",result);
        return result;
    }


    public PlainResult<PurchasableSoftwareApi> fetchPurchasableServiceList(Long kdtId,Integer appId) {
        PurchasableServiceFetchForm purchasableServiceFetchForm = new PurchasableServiceFetchForm();
        purchasableServiceFetchForm.setAppId(appId);
        purchasableServiceFetchForm.setKdtId(kdtId);

        logger.info("购买服务信息参数：{}",JSON.toJSONString(purchasableServiceFetchForm));
        PlainResult<PurchasableSoftwareApi> fetchPurchasableServiceList = basicQueryRemoteServiceV2.fetchPurchasableServiceList(purchasableServiceFetchForm);
        logger.info("购买服务信息结果：{}",JSON.toJSONString(fetchPurchasableServiceList));
        return fetchPurchasableServiceList;
    }

    public PlainResult<String> yearsLimit(Long kdtId,String kdtName,Long appId,int one,int two,int three,int code) {
        initShopByKdtId(kdtId);
        rechargeShopBalance(String.valueOf(kdtId), cny);

        PlainResult<String>  result = createNormalOrder(kdtId,kdtName,one,1,0L);

        Assert.assertEquals(result.getCode(),200,result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, kdtId);
        }
        waitForPerform(kdtId,appId,Long.valueOf(result.getData()));

        //创建一笔2年的订单
        PlainResult<String> renewResult = createNormalOrder(kdtId,kdtName,two,2,0L);

        Assert.assertEquals(renewResult.getCode(),200,renewResult.getMessage());
        if (renewResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, kdtId);
        }

        waitForPerform(kdtId,appId,Long.valueOf(renewResult.getData()));

        //继续续费
        PlainResult<String>  renewResultAgain = createNormalOrder(kdtId,kdtName,three,1,0L);

        return renewResultAgain;
    }



    @DataProvider(name = "riskCheck-twoParam")
    public Object[][] riskCheck() {
        return new Object[][] {
                {kdtIdForCheck,kdtNameForCheck},
                {kdtIdForWaitReviewOrder,kdtNameForWaitReviewOrder}
        };
    }

    @DataProvider(name = "riskCheck-oneParam")
    public Object[][] riskCheck2() {
        return new Object[][] {
                {kdtIdForCheck},
                {kdtIdForWaitReviewOrder}
        };
    }

    @DataProvider(name = "for3Years")
    public Object[][] for3Years() {
        return new Object[][] {
                {kdtIdFor3Years,kdtNameFor3Years,873L,basicWechatItemId,basicWechatItemId,basicWechatItemId,130603},
                {kdtIdFor3Years,kdtNameFor3Years,873L,basicWechatItemId,basicWechatItemId,professionItemId,200},
                {kdtIdFor3Years,kdtNameFor3Years,873L,basicWechatItemId,basicWechatItemId,ultimateItemId_2021,200},
                {kdtIdFor3Years,kdtNameFor3Years,873L,professionItemId,professionItemId,professionItemId,130603},
                {kdtIdFor3Years,kdtNameFor3Years,873L,ultimateItemId_2021,ultimateItemId_2021,ultimateItemId_2021,130603},
                {kdtIdFor3Years,kdtNameFor3Years,873L,professionItemId,professionItemId,ultimateItemId_2021,200},
                {jyKdtId,jyKdtName,jyAppId,jyBasicItemId,jyBasicItemId,jyBasicItemId,130603},
                {jyKdtId,jyKdtName,jyAppId,jyBasicItemId,jyBasicItemId,jyProItemId,200},
        };
    }

    @DataProvider(name = "highToLow")
    public Object[][] threeYears() {
        return new Object[][] {
                {kdtIdFor3Years}
        };
    }



    public Object[][] highToLow() {
        return new Object[][] {
                {kdtIdForHighToLow}
        };
    }

    @DataProvider(name = "baoDan")
    public Object[][] BaoDan() {
        return new Object[][] {
                {baoDanKdtId,baoDanKdtName},
                {wscKdtId,wscKdtName}
        };
    }


    @Test
    public void batchCreateOrder() {
        Long kdtIdForBatch = 59530159L;
        String kdtNameForBatch = "关闭的订单大于500";
        rechargeShopBalance(String.valueOf(kdtIdForBatch), cny);


        for(int i = 0;i<550; i++) {
            initShopByKdtId(kdtIdForBatch);

            PlainResult<String> result = createNormalOrder(kdtIdForBatch, kdtNameForBatch, basicWechatItemId, 1, 0L);

            Assert.assertEquals(result.getCode(), 200, result.getMessage());
//        if (result.getCode() == 200) {
//            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
//            cashierPay(preparePayApiPlainResult, account, kdtIdForBatch);
//        }
//        waitForPerform(kdtIdForBatch,873L,Long.valueOf(result.getData()));
            try {
                Thread.sleep(2000);
            }catch (InterruptedException e) {
                e.printStackTrace();
            }

        }

    }





    @Override
    public PlainResult<String> createNormalOrder(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        //获取商品的优惠
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(kdtId,1,itemId,quantity,1);

        logger.info("优惠信息：{}",itemPreferentialInfoResult);

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        logger.info("创建订单参数：{}",JSON.toJSONString(createOrderForm));
        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);
        logger.info("创建订单结果：{}",JSON.toJSONString(resultCreateNormalOrder));

        return resultCreateNormalOrder;
    }

    @Override
    public PlainResult<Long> createOrder(Long kdtId, String kdtName, int itemId, int quantity,Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        //微商城订单创建参数
        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList, yzb);
        logger.info("创建订单的参数：" + JSON.toJSON(createOrderForm));

        PlainResult<Long> orderCreateApiPlainResult = orderRemoteService.createOrder(createOrderForm);
        logger.info("创建订单结果：" + JSON.toJSON(createOrderForm));

        return orderCreateApiPlainResult;
    }
}