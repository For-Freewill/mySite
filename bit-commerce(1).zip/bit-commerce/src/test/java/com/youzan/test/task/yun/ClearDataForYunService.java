package com.youzan.test.task.yun;

import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import java.util.List;

/**
 * Created by baoyan on 2021-02-01.
 */
public class ClearDataForYunService extends YunBaseTest {

    @JSONData("/dataResource/clearData/clearKdtIdForYunService.json")
    private List<Long> kdtIds;

    @Test
    public void ClearDataForKdt() {
        List<Long> failedClearKdtIds = Lists.newArrayList();
        try {
//            for (Long kdtId : kdtIds) {
//                logger.info("开始店铺 {} 订单退款", kdtId);
//                refundOrderByKdtId(kdtId);
//                logger.info("店铺 {} 退款完成", kdtId);
//                concurrentStatus(kdtId);
//            }
        } finally {
            //开始清理数据
            for (Long kdtId : kdtIds) {
                try {
                    logger.info("开始店铺 {} 清理数据", kdtId);
                    godBlessU(kdtId);
                    logger.info("店铺 {} 清理完成", kdtId);
                    concurrentStatus(kdtId);
                } catch (Exception e) {
                    failedClearKdtIds.add(kdtId);
                    logger.info("店铺 {} 清理数据异常: {}", kdtId, e.getMessage());
                }
            }
        }
    }
}
