package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.StartTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.promotion.crm.OpenAppCrmPromotionApi;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-03-24 13:50
 **/
public class GetValidPromotionKdtJoinTest extends StartTest {

    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void getValidPromotionKdtJoinTest() {
        Long kdtId = 58711819L;
        Long preferentialId = 8406L;
        PlainResult<Boolean> getValidPromotionKdtJoinResult = promotionRemoteService.getValidPromotionKdtJoin(kdtId, preferentialId);
        Assert.assertEquals(getValidPromotionKdtJoinResult.getCode(), 200);
    }

    /**
     * 异常用例
     */
    @Test
    public void getValidPromotionKdtJoinKdtIdNullTest() {
        Long kdtId = null;
        Long preferentialId = 8406L;
        PlainResult<Boolean> getValidPromotionKdtJoinResult = promotionRemoteService.getValidPromotionKdtJoin(kdtId, preferentialId);
        Assert.assertEquals(getValidPromotionKdtJoinResult.getCode(), 200);
    }

    /**
     * 异常用例
     */
    @Test
    public void getValidPromotionKdtJoinPreferentialIdNullTest() {
        Long kdtId = 58711819L;
        Long preferentialId = null;
        PlainResult<Boolean> getValidPromotionKdtJoinResult = promotionRemoteService.getValidPromotionKdtJoin(kdtId, preferentialId);
        Assert.assertEquals(getValidPromotionKdtJoinResult.getCode(), 200);
    }
}
