package com.youzan.test.apicase.yop.ycmRefactorRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.apicase.yop.YopBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.YcmRefactorRemoteService;
import com.youzan.yop.api.entity.OrderSummaryInfoApi;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author tianning
 * @date 2020/9/25 8:19 下午
 * 批量获取交易订单下的子订单信息
 * TODO 为啥返回的是200 但是信息确是：系统错误，查询失败
 * @线上
 */
public class GetOrderInfoListTest extends YopBaseTest {
    @Dubbo
    public YcmRefactorRemoteService ycmRefactorRemoteService;

    /**
     * 批量获取交易订单下的子订单信息
     * 正常用例
     */
    @Test
    public void listCrmOrderByCrmApprovalNosNormalTest() {
        List<Long> orderIds = new ArrayList<>();
        orderIds.add(311582017539001L);
        orderIds.add(311582017539002L);
        orderIds.add(311582017539003L);
        orderIds.add(311582017539004L);
        orderIds.add(311582017539005L);
        orderIds.add(311582017539006L);
        Long tradeOrderId = 6633980113646125056L;
        PlainResult<List<OrderSummaryInfoApi>> getOrderInfoListResult = ycmRefactorRemoteService.getOrderInfoList(orderIds, tradeOrderId);
        Assert.assertEquals(getOrderInfoListResult.getCode(), 200);
        Assert.assertEquals(getOrderInfoListResult.getMessage(), "系统错误，查询失败！");
    }

    /**
     * 异常用例--入参为空
     */
    @Test
    public void listCrmOrderByCrmApprovalNosParameterNullTest() {
        PlainResult<List<OrderSummaryInfoApi>> getOrderInfoListResult = ycmRefactorRemoteService.getOrderInfoList(null, null);
        Assert.assertEquals(getOrderInfoListResult.getCode(), 200);
        Assert.assertEquals(getOrderInfoListResult.getMessage(), "系统错误，查询失败！");
    }

    /**
     * 异常用例--入参非法
     */
    @Test
    public void listCrmOrderByCrmApprovalNosParameterInvalidTest() {
        List<Long> orderIds = new ArrayList<>();
        Long tradeOrderId = 0L;
        PlainResult<List<OrderSummaryInfoApi>> getOrderInfoListResult = ycmRefactorRemoteService.getOrderInfoList(orderIds, tradeOrderId);
        Assert.assertEquals(getOrderInfoListResult.getCode(), 200);
        Assert.assertEquals(getOrderInfoListResult.getMessage(), "系统错误，查询失败！");
    }
}
