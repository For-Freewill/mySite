package com.youzan.test.basecase.yunServiceFee.baseCase;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.OrderQuota.OrderProtocolInfoApi;
import com.youzan.yop.api.form.orderQuota.OrderForm;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by baoyan on 2020-07-26.
 */
public class GetQuotaProtocolInfoTest extends YunBaseTest {

    /**
     * 场景一：
     * 订单前后均没有礼包服务期
     */
    @Test
    public void testNoGift() {
        OrderForm orderForm = new OrderForm();
        PlainResult<OrderProtocolInfoApi> result = new PlainResult<OrderProtocolInfoApi>();
        orderForm.setOrderId(311583304339650l);
        result = orderQuotaRemoteService.getQuotaProtocolInfo(orderForm);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getOrderId().longValue(), 311583304339650l);
        Assert.assertEquals(result.getData().getBeginTime().toString(), "Tue Apr 02 13:55:23 CST 2030");
        Assert.assertEquals(result.getData().getEndTime().toString(), "Wed Apr 02 13:55:23 CST 2031");
    }

    /**
     * 场景二：
     * 订单后有礼包服务期
     */
    @Test
    public void testGiftBehind() {
        OrderForm orderForm = new OrderForm();
        PlainResult<OrderProtocolInfoApi> result = new PlainResult<OrderProtocolInfoApi>();
        orderForm.setOrderId(311596004990402l);
        result = orderQuotaRemoteService.getQuotaProtocolInfo(orderForm);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getOrderId().longValue(), 311596004990402l);
        Assert.assertEquals(result.getData().getBeginTime().toString(), "Wed Jul 29 14:43:11 CST 2020");
        Assert.assertEquals(result.getData().getEndTime().toString(), "Sat Sep 04 14:43:11 CST 2021");
    }

    /**
     * 场景三：
     * 订单前有礼包服务期
     */
    @Test
    public void testGiftBefore() {
        OrderForm orderForm = new OrderForm();
        PlainResult<OrderProtocolInfoApi> result = new PlainResult<OrderProtocolInfoApi>();
        orderForm.setOrderId(311583832844803l);
        result = orderQuotaRemoteService.getQuotaProtocolInfo(orderForm);
        Assert.assertEquals(result.getCode(), 200);
    }

    /**
     * 场景四：
     * 订单前后均有礼包服务期
     */
    @Test
    public void testGiftBeforeAndBehind() {
        OrderForm orderForm = new OrderForm();
        PlainResult<OrderProtocolInfoApi> result = new PlainResult<OrderProtocolInfoApi>();
        orderForm.setOrderId(311596004990402l);
        result = orderQuotaRemoteService.getQuotaProtocolInfo(orderForm);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getOrderId().longValue(), 311596004990402l);
        Assert.assertEquals(result.getData().getBeginTime().toString(), "Wed Jul 29 14:43:11 CST 2020");
        Assert.assertEquals(result.getData().getEndTime().toString(), "Sat Sep 04 14:43:11 CST 2021");
    }

    /**
     * 场景五：
     * 订单前后有订单，续费场景
     */
    @Test
    public void testOrderBeforeAndBehind() {
        OrderForm orderForm = new OrderForm();
        PlainResult<OrderProtocolInfoApi> result = new PlainResult<OrderProtocolInfoApi>();
        orderForm.setOrderId(311596004990402l);
        result = orderQuotaRemoteService.getQuotaProtocolInfo(orderForm);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getOrderId().longValue(), 311596004990402l);
        Assert.assertEquals(result.getData().getBeginTime().toString(), "Wed Jul 29 14:43:11 CST 2020");
        Assert.assertEquals(result.getData().getEndTime().toString(), "Sat Sep 04 14:43:11 CST 2021");
    }

}
