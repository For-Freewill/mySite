package com.youzan.test.offlineTrade.basecase;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.entity.dataobject.ycmJob.JbcJob;
import com.youzan.commerce.test.entity.dataobject.ycmJob.JbcTask;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.commerce.test.mapper.ycmJob.JbcJobMapper;
import com.youzan.commerce.test.mapper.ycmJob.JbcTaskMapper;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.request.BatchOfflineOrderRequest;
import com.youzan.yop.api.request.BatchOfflineOrderSearchRequest;
import com.youzan.yop.api.response.BatchOfflineOrderResponse;
import com.youzan.yop.api.response.BatchOfflineOrderSearchResponse;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @program: bit-commerce
 * @description 查询线下批量落单完成情况
 * @author: tianning
 * @create: 2021-04-14 17:20
 **/

public class SearchTest extends TnBaseTest {

    @JSONData(value = "dataResource/apicase/yop/CreateBatchOfflineOrderRequestData.json", key = "batchOfflineOrderWithLSRequest")
    private BatchOfflineOrderRequest batchOfflineOrderWithLSRequest;

    @JSONData(value = "dataResource/apicase/yop/CreateBatchOfflineOrderRequestData.json", key = "batchOfflineOrderWithWSCRequest")
    private BatchOfflineOrderRequest batchOfflineOrderWithWSCRequest;

    @Dubbo
    public OrderRemoteService orderRemoteService;

    @Autowired(required = false)
    public TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    public JbcJobMapper jbcJobMapper;
    @Autowired(required = false)
    public JbcTaskMapper jbcTaskMapper;

    public static Long WSCSUBKDTID = 59614753L;

    List<JbcTask> jbcTaskActivateList = null;
    List<JbcJob> jbcJobActivateList = null;
    List<TdOrder> tdOrderRecords = null;

    String jobNo = "";
    String bizNo = "";

    /**
     * 1、线下批量续费网店+店铺员工
     *    先生成线下落单数据（假定总部方案已经生成，网店方案已经生成并激活）
     *    biz后台线下批量续费：WSC连锁-网店（D）：订购网店个数为2个，续费店铺为1个,店铺员工续费为2个
     *    账号：15558185312
     *    总部：预落单微商城连锁总部1 59601915
     *    子店：预落单微商城连锁网店 59614753
     * 2、续费后查询结果
     */
    @Test(enabled = false)
    //场景已下，先忽略
    public void searchTest() {
        try {
            BatchOfflineOrderSearchRequest batchOfflineOrderSearchRequest = new BatchOfflineOrderSearchRequest();

            bizNo = createOffLineOrderWithWSCWithStaff();

            batchOfflineOrderSearchRequest.setBizNo(bizNo);

            PlainResult<BatchOfflineOrderSearchResponse> searchResult = orderRemoteService.search(batchOfflineOrderSearchRequest);
            Assert.assertEquals(searchResult.getCode(), 200);
            Assert.assertTrue(searchResult.getData().getFinished());
            Assert.assertEquals(searchResult.getData().getPercentage(), null);
        } finally {
            //查询tdOrder表数据
            tdOrderRecords =
                    tdOrderMapper.selectList(
                            new QueryWrapper<TdOrder>().lambda().eq(TdOrder::getOutBizNo, bizNo).orderByDesc(TdOrder::getCreatedAt));
            //查询主任务
            jbcJobActivateList =
                    jbcJobMapper.selectList(
                            new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getBizNo, bizNo).orderByDesc(JbcJob::getCreatedAt));
            for (int i = 0; i < jbcJobActivateList.size(); i++) {
                jobNo = jbcJobActivateList.get(i).getJobNo();
                deleteJob(jobNo);
            }
        }
    }

    /**
     * 先生成线下落单数据
     * biz后台线下批量续费：WSC连锁-网店（D）：订购网店个数为2个，续费店铺为1个,店铺员工续费为2个
     * 账号：15558185312
     * 总部：预落单微商城连锁总部1 59601915
     * 子店：预落单微商城连锁网店 59614753
     */
    public String createOffLineOrderWithWSCWithStaff() {
        rechargeShopBalance(WSCSUBKDTID.toString(), 99999999);
        closeWaitPayOrder(WSCSUBKDTID);
        refundOrderByKdtId(WSCSUBKDTID);

        PlainResult<BatchOfflineOrderResponse> createBatchOfflineOrderResult = orderRemoteService.createBatchOfflineOrder(batchOfflineOrderWithWSCRequest);
        Assert.assertEquals(createBatchOfflineOrderResult.getCode(), 200);

        try {
            sleep(15000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        //查询tdOrder表数据
        List<TdOrder> tdOrderRecords =
                tdOrderMapper.selectList(
                        new QueryWrapper<TdOrder>().lambda().eq(TdOrder::getOutBizNo, createBatchOfflineOrderResult.getData().getBatchCreateNo()).orderByDesc(TdOrder::getCreatedAt));

        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        Assert.assertTrue(CollectionUtils.isNotEmpty(tdOrderRecords));
        Assert.assertEquals(tdOrderRecords.get(0).getState(), "PAID");

        try {
            sleep(10000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        //查询pfOrder的子店的表数据,校验子店数据
        List<PfOrder> pfOrdferRecords =
                pfOrderMapper.selectList(
                        new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBizOrderId, tdOrderRecords.get(0).getTdNo()).eq(PfOrder::getAppCategory, "software_meal").eq(PfOrder::getPerformState, "performed").orderByDesc(PfOrder::getCreatedAt));
        pfOrdferRecords.forEach(item -> {
            if (item.getApplyKdtId().isEmpty()) {
                Assert.assertEquals(item.getTradeState(), "paid_success");
                Assert.assertEquals(item.getPerformState(), "wait_perform");
                Assert.assertEquals(item.getAppCategory(), "software_meal");
                Assert.assertEquals(item.getAppId(), "combine_spu_wsc_chain_bu_basic_for_retail");
                Assert.assertEquals(item.getBuyType(), "new_sign");
                Assert.assertTrue(item.getIsLeaf());
            } else if (!(item.getApplyKdtId().isEmpty()) && item.getAppCategory().equals("app_category")) {
                Assert.assertEquals(item.getTradeState(), "paid_success");
                Assert.assertEquals(item.getPerformState(), "performed");
                Assert.assertEquals(item.getAppId(), "atom_spu_shop_staff");
                Assert.assertEquals(item.getBuyType(), "renew_sign");
                Assert.assertTrue(item.getIsLeaf());
            } else {
                Assert.assertEquals(item.getTradeState(), "paid_success");
                Assert.assertEquals(item.getPerformState(), "performed");
                Assert.assertEquals(item.getAppId(), "combine_spu_wsc_chain_bu_basic_for_retail");
                Assert.assertEquals(item.getBuyType(), "renew_sign");
                Assert.assertTrue(item.getIsLeaf());
            }
        });

        //查询主任务
        jbcJobActivateList =
                jbcJobMapper.selectList(
                        new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getBizNo, createBatchOfflineOrderResult.getData().getBatchCreateNo()).orderByDesc(JbcJob::getCreatedAt));
        Assert.assertTrue(com.baomidou.mybatisplus.core.toolkit.CollectionUtils.isNotEmpty(jbcJobActivateList));

        for (int i = 0; i < jbcJobActivateList.size(); i++) {
            Assert.assertEquals(jbcJobActivateList.get(i).getState(), "DONE");

            //查询子任务
            jbcTaskActivateList =
                    jbcTaskMapper.selectList(
                            new QueryWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, jbcJobActivateList.get(i).getJobNo()).orderByDesc(JbcTask::getCreatedAt));
            for (int k = 0; k < jbcTaskActivateList.size(); k++) {
                Assert.assertTrue(com.baomidou.mybatisplus.core.toolkit.CollectionUtils.isNotEmpty(jbcTaskActivateList));
                Assert.assertEquals(jbcTaskActivateList.get(k).getState(), "DONE");
            }
        }
        return createBatchOfflineOrderResult.getData().getBatchCreateNo();
    }


    /**
     * 删除任务
     */
    public void deleteJob(String jobNo) {
        List<JbcJob> jbcJobList =
                jbcJobMapper.selectList(
                        new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getJobNo, jobNo).orderByDesc(JbcJob::getCreatedAt));
        if (CollectionUtils.isNotEmpty(jbcJobList)) {
            jbcJobList.forEach(item -> {
                jbcTaskMapper.delete(new UpdateWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, item.getJobNo()));
            });
        }
        jbcJobMapper.delete(new UpdateWrapper<JbcJob>().lambda().eq(JbcJob::getJobNo, jobNo));
    }
}

