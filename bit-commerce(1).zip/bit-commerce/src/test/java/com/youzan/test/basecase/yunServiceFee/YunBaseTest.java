package com.youzan.test.basecase.yunServiceFee;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.goods.*;
import com.youzan.commerce.test.entity.dataobject.market.MkJoinRecord;
import com.youzan.commerce.test.entity.dataobject.market.SendNsqMessageDO;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAssetGoods;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageDO;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageLogDO;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeYopProtocolDTO;
import com.youzan.commerce.test.entity.dataobject.perform.*;
import com.youzan.commerce.test.entity.dataobject.trade.*;
import com.youzan.commerce.test.entity.dataobject.yop.CrmOrder;
import com.youzan.commerce.test.entity.dataobject.yop.OrderItemRefundOrder;
import com.youzan.commerce.test.mapper.goods.*;
import com.youzan.commerce.test.mapper.market.*;
import com.youzan.commerce.test.mapper.market.collocation.ActivityMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.PresentRecordMapper;
import com.youzan.commerce.test.mapper.market.yunfee.FeeResourcePackageLogMapper;
import com.youzan.commerce.test.mapper.market.yunfee.FeeResourcePackageMapper;
import com.youzan.commerce.test.mapper.market.yunfee.FeeYopProtocolMapper;
import com.youzan.commerce.test.mapper.perform.*;
import com.youzan.commerce.test.mapper.trade.*;
import com.youzan.commerce.test.mapper.yop.CrmOrderMapper;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.commerce.test.utils.CompareSCUtil;
import com.youzan.commerce.test.utils.DateUtil;
import com.youzan.finance.fee.api.request.FeeYopQueryRequest;
import com.youzan.finance.fee.api.request.FeeYopRefundRequest;
import com.youzan.finance.fee.api.request.FeeYopSingleQueryRequest;
import com.youzan.finance.fee.api.response.FeeYopResourceDTO;
import com.youzan.finance.fee.api.service.FeeStatQueryService;
import com.youzan.finance.fee.api.service.FeeYopService;
import com.youzan.pay.acctrans.api.acctrans.AcctransRechargeService;
import com.youzan.pay.acctrans.api.acctrans.dto.AcctransAccountingDTO;
import com.youzan.pay.acctrans.api.acctrans.request.AcctransRechargeRequest;
import com.youzan.pay.acctrans.common.model.enums.AccountType;
import com.youzan.pay.acctrans.common.model.enums.SubTransCodeEnum;
import com.youzan.pay.acctrans.common.model.enums.TransCodeEnum;
import com.youzan.pay.acctrans.common.model.model.AccountInfo;
import com.youzan.pay.core.api.model.response.DataResult;
import com.youzan.pay.core.common.model.enums.CurrencyCode;
import com.youzan.pay.core.common.model.enums.bizcode.ChannelType;
import com.youzan.pay.core.exception.BusinessException;
import com.youzan.pay.core.utils.KeyUtils;
import com.youzan.pay.customer.api.ops.UserInfoService;
import com.youzan.pay.unified.cashier.api.request.v3.request.PreOrderPayRequest;
import com.youzan.pay.unified.cashier.api.request.v3.result.PreOrderPayResult;
import com.youzan.pay.unified.cashier.api.v3.PreOrderPayService;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.ycm.goods.api.ApplicationSceneRemoteService;
import com.youzan.ycm.goods.api.GoodsCacheRemoteService;
import com.youzan.ycm.goods.request.cache.ClearRelatedCacheRequest;
import com.youzan.ycm.goods.response.cache.ClearRelatedCacheResponse;
import com.youzan.ycm.perform.api.AdvanceRemoteService;
import com.youzan.ycm.perform.api.PfAppStatusRemoteService;
import com.youzan.ycm.perform.api.PfRefundRemoteService;
import com.youzan.ycm.perform.api.TaskScheduleRemoteService;
import com.youzan.ycm.perform.dto.YcmIdDTO;
import com.youzan.ycm.perform.request.advance.AdvanceOrderQuotaRequest;
import com.youzan.ycm.perform.request.advance.CanAdvanceOrderQuotaRequest;
import com.youzan.ycm.perform.request.refund.RefundOrderQuotaRequest;
import com.youzan.ycm.perform.response.advance.CanAdvanceOrderQuotaResponse;
import com.youzan.ycm.trade.api.request.PreparePayRequest;
import com.youzan.ycm.trade.api.result.PreparePayResponse;
import com.youzan.ycm.trade.api.service.PreparePayRemoteService;
import com.youzan.yop.api.*;
import com.youzan.yop.api.entity.BatchOfflineOrderForm;
import com.youzan.yop.api.entity.OfflineOrderForm;
import com.youzan.yop.api.entity.OfflineOrderFormV2;
import com.youzan.yop.api.entity.OrderQuota.OrderProtocolInfoApi;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.item.ItemApi;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.entity.promotion.ycm.OrderPromotionMutexApi;
import com.youzan.yop.api.form.basic.PurchasablePluginFetchForm;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.form.order.OrderItemFormV2;
import com.youzan.yop.api.form.orderQuota.OrderForm;
import com.youzan.yop.api.request.RefundNonConsumeRequest;
import com.youzan.yop.api.request.SearchOrderForRefundRequest;
import com.youzan.yop.api.response.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import java.text.SimpleDateFormat;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.alibaba.dubbo.common.compiler.support.ClassUtils.isNotEmpty;
import static com.youzan.commerce.test.utils.DateUtil.durations;
import static java.lang.Thread.sleep;
import static org.awaitility.Awaitility.with;

/**
 * Created by baoyan on 2020-07-29.
 */
@Slf4j
public class YunBaseTest extends BaseTest {
    public static Long yunKdtId1 = 58112297L;
    public static String yunKdtName1 = "云服务费接口自动化9店";
    public static Long yunKdtId2 = 58112118L;
    public static String yunKdtName2 = "云服务费接口自动化10店";
    public static Long yunKdtId3 = 59525967L;
    public static String yunKdtName3 = "云服务费接口自动化11店";
    public static Long yunKdtId4 = 59543926L;
    public static String yunKdtName4 = "云服务费接口自动化12店";
    public static Long yunKdtId5 = 58112303L;
    public static String yunKdtName5 = "云服务费接口自动化13店";
    public static Long yunKdtId6 = 59544515L;
    public static String yunKdtName6 = "云服务费接口自动化14店";
    public static Long yunKdtId7 = 58112141L;
    public static String yunKdtName7 = "云服务费接口自动化16店";
    public static Long kdtIdForPreparePay1 = 58502876l;
    public static Long kdtIdForPreparePay2 = 58502885l;
    public static Long kdtIdForPreparePay3 = 58502976l;
    public static Long kdtIdForPreparePay4 = 58502886l;
    public static Long kdtIdForClose1 = 58506835l;
    public static Long kdtIdForClose2 = 58509258l;
    public static Long kdtIdForClose3 = 58509259l;
    public static Long kdtIdForClose4 = 58526933l;
    public static Long kdtIdForClose5 = 58526860l;
    public static Long kdtIdForClose6 = 58526861l;
/*    public static Long kdtIdForClose7 = 58705194l;
    public static Long kdtIdForClose8 = 58705195l;*/
    public static Long kdtIdForClose9 = 58705278l;
    // 58727887,预支测试店铺1
    public static Long kdtIdForAdvance1 = 59514505l;
    public static String nameForAdvance1 = "预支测试店铺1";
    public static Long kdtIdForAdvance2 = 58728555l;
    public static String nameForAdvance2 = "预支测试店铺2";
    public static Long kdtIdForAdvance3 = 59136318l;
    public static String nameForAdvance3 = "预支测试店铺3";
    public static Long kdtIdForAdvance4 = 59136315l;
    public static String nameForAdvance4 = "预支测试店铺4";
    public static Long kdtIdForAdvance5 = 59136413l;
    public static String nameForAdvance5 = "预支测试店铺5";
    public static Long kdtIdForAdvance6 =  59136416l;
    public static String nameForAdvance6 = "预支测试店铺6";
    public static Long kdtIdForAdvance7 = 59136320l;
    public static String nameForAdvance7 = "预支测试店铺7";
    public static Long kdtIdForRefund1 = 58729700l;
    public static Long kdtIdForRefund2 = 58729803l;
    public static Long kdtIdForRefund3 = 58729804l;
    public static Long kdtIdForRefund4 = 58729705l;
    public static Long kdtIdForQuery = 58742576l;

    //  2021相关商品信息
    //  微商城2021 itemId
    public int wscWXItemId_2021 = 8530;
    public int wscBDItemId_2021 = 8531;
    public int wscProfessionItemId_2021 = 8532;
    public int wscUltimateItemId_2021 = 8533;
    public int wscFuwuPackageItemId = 73454;
    //  零售相关
    public int lsWXItemId_2021 = 8271;
    public int lsBDItemId_2021 = 8272;
    public int lsZFBItemId_2021 = 8273;
    public int professionItemId_2021 = 8274;
    public int lsFuwuPackageItemId = 73455;
    // 教育
    public int edu_basic_2021 = 74217;
    public int edu_pro_2020 = 74219;



    @Dubbo
    public PreOrderPayService preOrderPayService;
    @Dubbo
    public PfAppStatusRemoteService pfAppStatusRemoteService;
    @Dubbo
    public RefundRemoteService refundRemoteService;
    @Dubbo
    public TaskScheduleRemoteService taskScheduleRemoteService;
    @Dubbo
    public OrderRemoteService orderRemoteService;
    @Dubbo
    public AdvanceRemoteService advanceRemoteService;
    @Dubbo
    public PfRefundRemoteService pfRefundRemoteService;
    @Dubbo
    public FeeYopService feeYopService;
    @Dubbo
    public OrderQuotaRemoteService orderQuotaRemoteService;
    @Dubbo
    public FeeStatQueryService feeStatQueryService;
    @Dubbo
    public RightRemoteService rightRemoteService;
    @Dubbo
    public MarketRemoteService marketRemoteService;
    @Dubbo
    public GoodsCacheRemoteService goodsCacheRemoteService;
    @Dubbo
    public UserInfoService userInfoService;
    @Dubbo
    BasicQueryRemoteServiceV2 basicQueryRemoteServiceV2;


    @Dubbo
    public AcctransRechargeService acctransRechargeService;
    @Autowired(required = false)
    public TdOrderItemMapper tdOrderItemMapper;
    @Autowired(required = false)
    public TdPayOrderMapper tdPayOrderMapper;
    @Autowired(required = false)
    public PfOrderDetailActiveRecordMapper pfOrderDetailActiveRecordMapper;
    @Autowired(required = false)
    public TdSettleOrderMapper tdSettleOrderMapper;
    @Autowired(required = false)
    public PayRefundOrderMapper payRefundOrderMapper;
    @Autowired(required = false)
    public OrderItemRefundOrderMapper orderItemRefundOrderMapper;
    @Autowired(required = false)
    public PromotionResultDetailMapper promotionResultDetailMapper;
    @Autowired(required = false)
    public PresentRecordMapper presentRecordMapper;
    @Autowired(required = false)
    public DeductionResultCompositionMapper deductionResultCompositionMapper;
    @Autowired(required = false)
    public DeductionResultDetailMapper deductionResultDetailMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gfAssetGoodsMapper;
    @Autowired(required = false)
    public JoinRecordMapper joinRecordMapper;
    @Autowired(required = false)
    public PfAssetDeductionMapper pfAssetDeductionMapper;
    @Autowired(required = false)
    public PfRightsStatusMapper pfRightsStatusMapper;
    @Autowired(required = false)
    public PfStockMapper pfStockMapper;
    @Autowired(required = false)
    public PfOrderStockMapper pfOrderStockMapper;
    @Autowired(required = false)
    public PfSchemeMapper pfSchemeMapper;
    @Autowired(required = false)
    public TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    public PfSchemeOrderRelationMapper pfSchemeOrderRelationMapper;
    @Autowired(required = false)
    public PfRechargeConfigMapper pfRechargeConfigMapper;
    @Autowired(required = false)
    public PfDebtRepayRecordMapper pfDebtRepayRecordMapper;
    @Autowired(required = false)
    public PfOrderDetailAdvanceRecordMapper pfOrderDetailAdvanceRecordMapper;
    @Autowired(required = false)
    public PfOrderDetailDebtRecordMapper pfOrderDetailDebtRecordMapper;
    // 计费侧2表
    @Autowired(required = false)
    public FeeResourcePackageMapper feeResourcePackageMapper;
    @Autowired(required = false)
    public FeeYopProtocolMapper feeYopProtocolMapper;
    @Autowired(required = false)
    public FeeResourcePackageLogMapper feeResourcePackageLogMapper;
    @Autowired(required = false)
    public SendNsqMessageMapper sendNsqMessageMapper;
    @Autowired(required = false)
    public PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    public PfOrderDetailMapper pfOrderDetailMapper;
    @Autowired(required = false)
    public PfOrderStatusMapper pfOrderStatusMapper;
    @Autowired(required = false)
    public ActivityMapper activityMapper;
    @Autowired(required = false)
    public PfAssetMapper pfAssetMapper;
    @Dubbo
    PreparePayRemoteService preparePayRemoteService;
    @Autowired(required = false)
    GdAtomItemMapper gdAtomItemMapper;
    @Autowired(required = false)
    GdAtomBasicMapper gdAtomBasicMapper;
    @Autowired(required = false)
    GdAtomItemPropertyRelationMapper gdAtomItemPropertyRelationMapper;
    @Autowired(required = false)
    GdCombineBasicMapper gdCombineBasicMapper;
    @Autowired(required = false)
    GdCombineItemMapper gdCombineItemMapper;
    @Autowired(required = false)
    GdCombineTemplateContentMapper gdCombineTemplateContentMapper;
    @Autowired(required = false)
    GdCombineTemplateMapper gdCombineTemplateMapper;
    @Autowired(required = false)
    public PfFeeResourcePackageMapper pfFeeResourcePackageMapper;
    @Autowired(required = false)
    CrmOrderMapper crmOrderMapper;
    @Autowired(required = false)
    public PfProtectionPeriodMapper pfProtectionPeriodMapper;

    /**
     * @param kdtId
     * @param preparePayResult
     * @desc 收银台扣款动作
     */
    public void payOrder(String kdtId, PlainResult<PreparePayApi> preparePayResult) {
        PreOrderPayRequest request = new PreOrderPayRequest();
        request.setAccount("18099999997");
        request.setBizScene("MERCHANT");
        request.setKdtId(kdtId);
        request.setCashierSign(preparePayResult.getData().getResponse().getCashierSign());
        request.setCashierSalt(preparePayResult.getData().getResponse().getCashierSalt());
        request.setPartnerId(preparePayResult.getData().getResponse().getPartnerId());
        request.setPrepayId(preparePayResult.getData().getResponse().getPrepayId());
        request.setPayTool("BALANCE");
        request.setAcceptPrice(0);
        request.setNewPrice(0);
//        PlainResult<PreOrderPayResult> result = preOrderPayService.preOrderPay(request);
        PlainResult<PreOrderPayResult> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<PreOrderPayResult>>() {

                    @Override
                    public  PlainResult<PreOrderPayResult>  doExecute() {
                        CompareSCUtil.resetSC();
                        return preOrderPayService.preOrderPay(request);
                    }

                    @Override
                    public boolean handleResult(PlainResult<PreOrderPayResult> plainResult) {
                        if(plainResult.getCode() ==200 || plainResult.getCode() ==117700200 ){
                            log.info("payOrder 支付订单成功");
                            return true;
                        }
                        log.info("payOrder 支付订单失败，开始关单");
                        closeWaitPayOrder(Long.valueOf(kdtId));
                        return false;
                    }
                }, 5, 100);

        logger.info(JSON.toJSONString(plainResult));
//        Assert.assertTrue(plainResult.isSuccess()); //异常场景忽略断言，实际无问题
    }

    /**
     * @param kdtId
     * @param n
     * @desc 查询yop侧是否有待激活记录你
     */
    public void queryWaitPerformRecord(long kdtId, int n) {
        List<PfOrderDetailActiveRecord> queryResult =
                pfOrderDetailActiveRecordMapper.selectList(
                        new QueryWrapper<PfOrderDetailActiveRecord>().eq("buy_kdt_id", String.valueOf(kdtId)));
        List<PfOrderDetailActiveRecord> waitPerformList =
                queryResult.stream()
                        .filter(
                                PfOrderDetailActiveRecord ->
                                        "wait_perform".equals(PfOrderDetailActiveRecord.getPerformState()))
                        .collect(Collectors.toList());
        logger.info(JSON.toJSONString(waitPerformList));
        Assert.assertTrue(waitPerformList.size() == n);
    }

    /**
     * @param tdOrderId
     * @desc 修改服务期和operable_time；修改到当前时间前一年
     */
    public void updateEffectAndExpiretime(long tdOrderId) {
        TdOrder tradeOrderDO = tdOrderMapper.selectById(tdOrderId);
        List<PfOrder> pfOrderDOs = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tradeOrderDO.getTdNo()));
        List<Long> pfOrderIds = pfOrderDOs.stream().filter(pfOrder -> "combine_spu_wsc".equals(pfOrder.getAppId())).map(PfOrder::getId).collect(Collectors.toList());
        if (pfOrderIds.size() > 0) {
            for (long orderId : pfOrderIds) {
                PfOrderStatus pfOrderStatus = new PfOrderStatus();
                Calendar calendar1 = Calendar.getInstance();
                Calendar calendar2 = Calendar.getInstance();
                Calendar calendar3 = Calendar.getInstance();
                PfOrderStatus status =
                        pfOrderStatusMapper.selectOne(
                                new QueryWrapper<PfOrderStatus>()
                                        .eq("pf_order_id", orderId)
                                        .eq("app_id", "atom_spu_wsc")
                                        .eq("group_type", "product_with_paid"));
                PfOrderDetailActiveRecord record =
                        pfOrderDetailActiveRecordMapper.selectOne(
                                new UpdateWrapper<PfOrderDetailActiveRecord>()
                                        .eq("pf_order_id", orderId)
                                        .eq("app_id", "atom_spu_order_limit")
                                        .eq("perform_state", "wait_perform"));
                calendar1.setTime(status.getEffectTime());
                calendar1.add(Calendar.YEAR, -1);
                Date effectTime = calendar1.getTime();
                calendar2.setTime(status.getExpireTime());
                calendar2.add(Calendar.DAY_OF_MONTH, -11);
                Date expireTime = calendar2.getTime();
                pfOrderStatus.setEffectTime(effectTime);
                pfOrderStatus.setExpireTime(expireTime);
                pfOrderStatusMapper.update(
                        pfOrderStatus,
                        new UpdateWrapper<PfOrderStatus>()
                                .eq("pf_order_id", orderId)
                                .eq("app_id", "atom_spu_wsc")
                                .eq("group_type", "product_with_paid"));
                PfOrderDetailActiveRecord pfOrderDetailActiveRecord = new PfOrderDetailActiveRecord();
                Date operableTime = calendar3.getTime();
                calendar3.setTime(record.getOperableTime());
                calendar3.add(Calendar.DAY_OF_MONTH, -11);
                pfOrderDetailActiveRecord.setOperableTime(operableTime);
                pfOrderDetailActiveRecordMapper.update(
                        pfOrderDetailActiveRecord,
                        new UpdateWrapper<PfOrderDetailActiveRecord>()
                                .eq("pf_order_id", orderId)
                                .eq("app_id", "atom_spu_order_limit")
                                .eq("perform_state", "wait_perform"));
            }
        }
    }

    /**
     * @param payOrderId
     * @desc 发放额度
     */
    public void activeWaitPerformRecord(long payOrderId) {
        SearchOrderForRefundRequest refundRequest = new SearchOrderForRefundRequest();
        refundRequest.setPayOrderId(String.valueOf(payOrderId));
        PlainResult<PageApi<RefundQueryOrderResponse>> searchRefundResult =
                refundRemoteService.searchOrderForRefund(refundRequest);
        List<RefundQueryOrderResponse> refundQueryOrderResponse =
                searchRefundResult.getData().getContent();
        List<String> orderIdList =
                refundQueryOrderResponse.stream()
                        .map(RefundQueryOrderResponse::getOrderId)
                        .collect(Collectors.toList());
        if (orderIdList.size() > 0) {
            for (String orderId : orderIdList) {
                boolean result = taskScheduleRemoteService.activeRecordByOrderId(Long.valueOf(orderId));
                if (result) {
                    logger.info("发放成功");
                } else {
                    logger.error("发放失败");
                }
            }
        }
    }

    /**
     * @param kdtId
     * @param kdtName
     * @param itemId
     * @param quantity
     * @return
     * @desc 购买订单,老接口，暂时用不上了
     */
  public PlainResult<Long> testCreateOrderV1(
            Long kdtId, String kdtName, int itemId, int quantity) {
        try {
            Thread.sleep(1000);
            moreMoney(kdtId);
            logger.info(kdtId + "充值成功，金额");
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            // 清理缓存
            clearCache(kdtId.toString());

            OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
            List<OrderItemForm> orderItemFormList = new ArrayList<>();
            orderItemFormList.add(orderItemForm);

            ConfirmOrderForm confirmOrderForm =
                    ConstructionParam.getConfirmOrderForm(kdtId, kdtName, orderItemFormList);
            PlainResult<OrderConfirmApi> confirmApiPlainResult =
                    orderRemoteService.confirmOrder(confirmOrderForm);
            Assert.assertTrue(confirmApiPlainResult.getData() != null);
            //Assert.assertTrue(confirmApiPlainResult.getData().getYzbQuota() > 0);
            CreateOrderForm createOrderForm =
                    ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList, 0L);

            //订单级别优惠参数
            Long promotionId = getFullReduce(kdtId, kdtName, itemId, quantity);
            List<PreferentialDescApi> orderPromotionList = ConstructionParam.getOrderPromotionList(kdtId, kdtName, itemId, promotionId, quantity);
            createOrderForm.setOrderPromotionList(orderPromotionList);

            PlainResult<Long> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<Long>>() {

                        @Override
                        public PlainResult<Long> doExecute() {
                            return orderRemoteService.createOrder(createOrderForm);
                        }

                        @Override
                        public boolean handleResult(PlainResult<Long> plainResult) {
                            return plainResult.getCode() == 200;
                        }
                    }, 5, 100);

            Assert.assertEquals(plainResult.getCode(), 200);

            logger.info(JSON.toJSONString(plainResult));
            Assert.assertEquals(plainResult.getCode(), 200);
            Assert.assertEquals(plainResult.getMessage(), "successful");
            if (plainResult.getCode() == 200) {
                PlainResult<PreparePayApi> preparePayApiPlainResult =
                        preparePay(plainResult.getData(), (byte) 4);
                logger.info(JSON.toJSONString(preparePayApiPlainResult));
                payOrder(String.valueOf(kdtId), preparePayApiPlainResult);
                return plainResult;
            }

        } catch (AssertionError e) {
            e.printStackTrace();
        }
        return null;
    }

    public PlainResult<OrderCreateApi> testCreateOrder(Long kdtId, String kdtName, int itemId, int quantity) {
        PlainResult<OrderCreateApi> orderCreateApi = new PlainResult<OrderCreateApi>();
        try {
            Thread.sleep(1000);
            moreMoney(kdtId);
            log.info(kdtId + "充值成功，金额");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 清理缓存
        clearCache(kdtId.toString());
        PurchasablePluginFetchForm fetchForm = new PurchasablePluginFetchForm();
        PlainResult<ItemApi> appIdResult = marketRemoteService.getItemByItemId(itemId);
        if(appIdResult.getCode() == 200){
            fetchForm.setAppId(appIdResult.getData().getAppid());
            fetchForm.setKdtId(kdtId);
            fetchForm.setItemId(itemId);
        }
        else {
            log.info("获取商品信息失败");
        }
        PlainResult<PurchasablePluginApi> queryResult = basicQueryRemoteServiceV2.fetchPurchasablePluginList(fetchForm);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        orderItemFormList.add(orderItemForm);

        if (queryResult.getCode() == 200 && queryResult.getData().getRightsPackageList().size()>0) {
            List<ItemApi> items = queryResult.getData().getRightsPackageList().stream().map(PurchasablePluginItemApi::getItem).collect(Collectors.toList());
            List<Integer>itemIds = items.stream().map(ItemApi::getId).collect(Collectors.toList());
            //构造item参数
            for (Integer itemId1 : itemIds) {
                OrderItemForm orderItemForm1 = ConstructionParam.getOrderItemForm(itemId1, 1);
                orderItemFormList.add(orderItemForm1);
            }

        }else{
            log.info("无权益商品推荐");
        }

//        //获取商品的优惠
//        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(kdtId,1,itemId,quantity,1);
//
//        log.info("优惠信息：{}",itemPreferentialInfoResult);
//        //将获取到的商品级优惠传入参数
//        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();
//        if(itemPreferentialInfoResult.getData().size()>0) {
//            //做非null判断
//            if(itemPreferentialInfoResult.getData().get(0).getPresentList() != null) {
//                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPresentList());
//            }
//            if(itemPreferentialInfoResult.getData().get(0).getPromotionList() != null) {
//                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPromotionList());
//            }
//            //将商品级优惠放入orderItemFormList
//            orderItemForm.setItemPromotionList(itemPromotionList);
//        }

        //获取订单级别的优惠
//        CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(kdtId, kdtName, orderItemFormList);
//        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
////        log.info("确认订单-订单计算返回数据：{}",JSON.toJSON(calOrderPriceApiPlainResult));
//
//        //将订单级别优惠传入参数
//        //满减优惠,并过滤掉selected = false的优惠
//        List<PreferentialDescApi> orderPromotionList = new ArrayList<>();
//
//        for(int OrderPromotionNum = 0;OrderPromotionNum < calOrderPriceApiPlainResult.getData().getOrderPromotionList().size();OrderPromotionNum++) {
//            List<PreferentialDescApi> getFullReduceList = calOrderPriceApiPlainResult.getData().getOrderPromotionList().get(OrderPromotionNum).getOrderPromotionMutexList().
//                    stream().filter(v -> v.getSelected()!=false).collect(Collectors.toList());
//            orderPromotionList.addAll(getFullReduceList);
//        }

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,0l);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

   /*     PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);*/

        PlainResult<String> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                    @Override
                    public  PlainResult<String>  doExecute() {
                        CompareSCUtil.resetSC();
                        return orderRemoteService.createNormalOrder(createOrderForm);
                    }

                    @Override
                    public boolean handleResult(PlainResult<String> plainResult) {
                        if(plainResult.getCode() == 200){
                            log.info("testCreatOrder 创建订单成功");
                            return true;
                        }
                        log.info("testCreatOrder 创建订单失败，开始关单");
                        closeWaitPayOrder(kdtId);
                        return false;
                    }
                }, 5, 100);

        Assert.assertEquals(plainResult.getCode(), 200);

        logger.info(JSON.toJSONString(plainResult));
        Assert.assertEquals(plainResult.getCode(), 200);
        Assert.assertEquals(plainResult.getMessage(), "successful");
        if (plainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult =
                    preparePay(Long.parseLong(plainResult.getData()),(byte) 4);
            logger.info(JSON.toJSONString(preparePayApiPlainResult));
            payOrder(String.valueOf(kdtId), preparePayApiPlainResult);
            OrderCreateApi orderCreateApi1 = new OrderCreateApi();
            orderCreateApi1.setPayOrderId(Long.parseLong(plainResult.getData()));
            orderCreateApi.setData(orderCreateApi1);
            return orderCreateApi ;
        }
        return null;
}



    public Long getFullReduce(Long kdtId, String kdtName, int itemId, int quantity) {
        OrderItemForm confirmOrderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(confirmOrderItemForm);

        ConfirmOrderForm confirmOrderForm = ConstructionParam.getConfirmOrderForm(kdtId, kdtName, orderItemFormList);
        PlainResult<OrderConfirmApi> confirmApiPlainResult = orderRemoteService.confirmOrder(confirmOrderForm);
        logger.info(String.valueOf(confirmApiPlainResult));
        List<OrderPromotionMutexApi> getOrderPromotionList = confirmApiPlainResult.getData().getOrderPromotionList();
        if (getOrderPromotionList.size() > 0) {
            Long promotionId = confirmApiPlainResult.getData().getOrderPromotionList().get(0).getOrderPromotionMutexList().get(0).getPromotionId();
            return promotionId;
        } else {
            return null;
        }
    }

    /**
     * @param kdt_id
     * @param canAdvance 是否可以预支
     * @author wulei
     * @desc 判断是否可以预支
     */
    public PlainResult<CanAdvanceOrderQuotaResponse> testCanAdvanceOrderQuota(
            String kdt_id, boolean canAdvance) {

        CanAdvanceOrderQuotaRequest request = new CanAdvanceOrderQuotaRequest();
        YcmIdDTO ycmIdDTO = new YcmIdDTO();
        ycmIdDTO.setId(kdt_id);
        ycmIdDTO.setType("KDT_ID");
        request.setYcmIdDTO(ycmIdDTO);

        // 等待计费侧数据
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> advanceRemoteService.canAdvanceOrderQuota(request).getData().getCanAdvance() == canAdvance);

        return advanceRemoteService.canAdvanceOrderQuota(request);
    }

    /**
     * @param kdt_id
     * @param orderId  pf_order_detail_active_record 表 pf_order_id
     * @param sequence pf_order_detail_active_record 表 sequence
     * @desc 预支额度 advanceOrderQuota
     * @author wulei 2020-8-13
     */
    public PlainResult<Boolean> testAdvanceOrderQuota(Long kdt_id, String orderId, int sequence) {
        // 先sleep 3秒，防止过快预支，数据落库延迟
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        AdvanceOrderQuotaRequest request = new AdvanceOrderQuotaRequest();

        YcmIdDTO ycmIdDTO = new YcmIdDTO();
        ycmIdDTO.setId(String.valueOf(kdt_id));
        ycmIdDTO.setType("KDT_ID");

        request.setYcmIdDTO(ycmIdDTO);
        request.setAppId("atom_spu_order_limit");
        request.setSequence(sequence);
        request.setOrderId(orderId);

        PlainResult<Boolean> result = new PlainResult<>();
        result = advanceRemoteService.advanceOrderQuota(request);
        Assert.assertTrue(result != null);
        // Assert.assertEquals(result.getCode(), 200);
        if (!String.valueOf(result.getCode()).equals("200")
                || !String.valueOf(result.getCode()).equals("400001")) {
            Assert.assertFalse(Boolean.FALSE);
        }
        return result;
    }

    /**
     * @param kdtId
     * @desc 删除一个店铺的所有数据，危险操作，可能会影响上下游，暂时只用于云服务费
     */
   /* public void deleteTestDataYcmByKdtId(Long kdtId) {
        //  交易信息
        List<TdOrder> tradeOrderDOs = tdOrderMapper.selectList(new QueryWrapper<TdOrder>().eq("buyer_id", kdtId.toString()));
        List<String> tdNoList = tradeOrderDOs.stream().filter(tradeOrderDO -> "YOUZAN".equals(tradeOrderDO.getChannel())).map(TdOrder::getTdNo).collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(tdNoList)) {
            for (String tdNo : tdNoList) {
                //  正向
                tdOrderMapper.delete(new QueryWrapper<TdOrder>().eq("td_no", tdNo));
                tdSettleOrderMapper.delete(new QueryWrapper<TdSettleOrder>().eq("td_no", tdNo));
                //            pfOrderMapper.delete(new QueryWrapper<PfOrder>().eq("biz_order_id", tdNo));
                tdPayOrderMapper.delete(new QueryWrapper<TdPayOrder>().eq("td_no", tdNo));
                tdOrderItemMapper.delete(new QueryWrapper<TdOrderItem>().eq("td_no", tdNo));
                //  逆向
                payRefundOrderMapper.delete(new QueryWrapper<PayRefundOrder>().eq("td_no", tdNo));
                orderItemRefundOrderMapper.delete(
                        new QueryWrapper<OrderItemRefundOrder>().eq("td_no", tdNo));
                // 营销参与记录
                promotionResultDetailMapper.delete(
                        new QueryWrapper<PromotionResultDetail>().eq("td_no", tdNo));
                presentRecordMapper.delete(new QueryWrapper<PresentRecord>().eq("td_no", tdNo));
                // 抵扣升级
                deductionResultDetailMapper.delete(
                        new QueryWrapper<DeductionResultDetail>().eq("td_no", tdNo));
                deductionResultCompositionMapper.delete(
                        new QueryWrapper<DeductionResultComposition>().eq("trade_no", tdNo));
            }
        }

        //  营销信息
        List<GiftAsset> gfAssetDOs =
                gfAssetMapper.selectList(new QueryWrapper<GiftAsset>().eq("owner_ycmid", kdtId.toString()));
        List<Long> gfAssetIdList =
                gfAssetDOs.stream().map(GiftAsset::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(gfAssetIdList)) {
            gfAssetMapper.deleteBatchIds(gfAssetIdList);
            for (long gfAssetId : gfAssetIdList) {
                gfAssetGoodsMapper.delete(new QueryWrapper<GiftAssetGoods>().eq("asset_id", gfAssetId));
            }
        }
        if (CollectionUtils.isNotEmpty(tdNoList)) {
            for (String tdNo : tdNoList) {
                joinRecordMapper.delete(new QueryWrapper<MkJoinRecord>().eq("biz_order_id", tdNo));
            }
        }

        //  履约信息
        List<PfOrder> pfOrderDOs =
                pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("buy_kdt_id", kdtId.toString()));
        List<Long> pfOrderIdList = pfOrderDOs.stream().map(PfOrder::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(pfOrderIdList)) {
            pfOrderMapper.deleteBatchIds(pfOrderIdList);
            List<Long> totalPfAssetIds = new LinkedList<>();
            for (Long pfOrderId : pfOrderIdList) {
                List<PfAsset> pfAssetDOList =
                        pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("pf_order_id", pfOrderId));
                totalPfAssetIds.addAll(
                        pfAssetDOList.stream().map(PfAsset::getId).collect(Collectors.toList()));
            }
            if (CollectionUtils.isNotEmpty(totalPfAssetIds)) {
                pfAssetMapper.deleteBatchIds(totalPfAssetIds);
                for (long pfAssertId : totalPfAssetIds) {
                    pfAssetDeductionMapper.delete(
                            new QueryWrapper<PfAssetDeduction>().eq("pf_asset_id", pfAssertId));
                }
            }
            // 服务期和库存
            for (Long pfOrderId : pfOrderIdList) {
                pfOrderDetailMapper.delete(new QueryWrapper<PfOrderDetail>().eq("pf_order_id", pfOrderId));
            }
            pfOrderStatusMapper.delete(
                    new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", kdtId.toString()));
            pfStockMapper.delete(new QueryWrapper<PfStock>().eq("apply_kdt_id", kdtId));
            pfOrderStockMapper.delete(
                    new QueryWrapper<PfOrderStock>().eq("buy_kdt_id", kdtId.toString()));
            // 延期激活记录表
            pfOrderDetailActiveRecordMapper.delete(
                    new QueryWrapper<PfOrderDetailActiveRecord>().eq("buy_kdt_id", kdtId.toString()));
            // 库存自动充值
            pfRechargeConfigMapper.delete(
                    new QueryWrapper<PfRechargeConfig>().eq("apply_kdt_id", kdtId.toString()));
            // 方案
            pfSchemeMapper.delete(new QueryWrapper<PfScheme>().eq("owner_id", kdtId.toString()));
            for (Long pfOrderId : pfOrderIdList) {
                pfSchemeOrderRelationMapper.delete(
                        new QueryWrapper<PfSchemeOrderRelation>().eq("order_id", pfOrderId));
            }
        }

        logger.info("测试数据清理完毕");
    }*/

    /**
     * #desc 订单退款
     *
     * @param payOrderId
     * @param date
     * @param refundCnyAmt
     * @param refundYzbAmt
     * @param refundMode
     */
    public void refundOrderNew(
            Long payOrderId, Date date, Long refundCnyAmt, Long refundYzbAmt, String refundMode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(date);
        SearchOrderForRefundRequest refundRequest = new SearchOrderForRefundRequest();
        refundRequest.setPayOrderId(String.valueOf(payOrderId));
        PlainResult<PageApi<RefundQueryOrderResponse>> searchRefundResult =
                refundRemoteService.searchOrderForRefund(refundRequest);
        //       searchRefundResult.getData().setPageSize(100);
        List<RefundQueryOrderResponse> refundQueryOrderResponse =
                searchRefundResult.getData().getContent();
        List<String> orderIdList =
                refundQueryOrderResponse.stream()
                        .map(RefundQueryOrderResponse::getOrderId)
                        .collect(Collectors.toList());
        for (String orderId : orderIdList) {
            RefundNonConsumeRequest refundNonConsumeRequest = new RefundNonConsumeRequest();
            refundNonConsumeRequest.setMemo("");
            refundNonConsumeRequest.setOperatorId("2135");
            refundNonConsumeRequest.setOrderId(orderId);
            refundNonConsumeRequest.setRefundCalculateTime(refundTime);
            refundNonConsumeRequest.setRefundMode(refundMode);
            refundNonConsumeRequest.setRefundYzbAmt(refundYzbAmt);
            refundNonConsumeRequest.setRefundCnyAmt(refundCnyAmt);
            refundNonConsumeRequest.setRefundWay("ORIG");
            PlainResult<Boolean> refundResult =
                    refundRemoteService.refundNonConsume(refundNonConsumeRequest);
            logger.info(JSON.toJSONString(refundResult));
            Assert.assertEquals(refundResult.getMessage(), "successful");
            Assert.assertEquals(refundResult.getCode(), 200);
            Assert.assertTrue(refundResult.getData());
        }
    }

    /**
     * @param payOrderId
     * @desc 订单额度退款后回收
     */
    public void refundOrderQuota(Long payOrderId) {
        SearchOrderForRefundRequest refundRequest = new SearchOrderForRefundRequest();
        refundRequest.setPayOrderId(String.valueOf(payOrderId));
        PlainResult<PageApi<RefundQueryOrderResponse>> searchRefundResult =
                refundRemoteService.searchOrderForRefund(refundRequest);
        //       searchRefundResult.getData().setPageSize(100);
        List<RefundQueryOrderResponse> refundQueryOrderResponse =
                searchRefundResult.getData().getContent();
        List<String> orderIdList =
                refundQueryOrderResponse.stream()
                        .map(RefundQueryOrderResponse::getOrderId)
                        .collect(Collectors.toList());
        for (String orderId : orderIdList) {
            RefundOrderQuotaRequest refundOrderQuotaRequest = new RefundOrderQuotaRequest();
            refundOrderQuotaRequest.setMemo("");
            refundOrderQuotaRequest.setOperatorId("2135");
            refundOrderQuotaRequest.setPfOrderId(Long.valueOf(orderId));
            refundOrderQuotaRequest.setRefundWay("ORIG");
            PlainResult<Boolean> refundResult =
                    pfRefundRemoteService.refundOrderQuota(refundOrderQuotaRequest);
            logger.info(JSON.toJSONString(refundResult));
            Assert.assertEquals(refundResult.getMessage(), "");
            Assert.assertEquals(refundResult.getCode(), 200);
            Assert.assertTrue(refundResult.getData());
        }
    }

    /**
     * @param kdt_id
     * @param expect_total
     * @desc 校验预支记录表总数
     * @author wulei 2020-8-14
     */
    public void queryAdvanceRecord(Long kdt_id, int expect_total) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 总可用记录数：根据kdt_id
        List<PfOrderDetailAdvanceRecordDO> allAdvanceRecords =
                pfOrderDetailAdvanceRecordMapper.selectList(
                        new QueryWrapper<PfOrderDetailAdvanceRecordDO>().eq("apply_ycm_id", kdt_id));

        // 生效记录数：pf_order_detail_advance_record：kdt_id，state=1，可用记录
        logger.info(
                String.format(
                        "pf_order_detail_advance_record 预支记录表 kdtid=%s,总记录数%s",
                        kdt_id, allAdvanceRecords.size()));

        Assert.assertEquals(allAdvanceRecords.size(), expect_total);
    }

    /**
     * @param kdt_id
     * @desc 删除预支记录表记录：pf_order_detail_advance_record
     * @author wulei 2020-8-14
     */
    public void deleteAdvanceRecord(Long kdt_id) {
        // 总可用记录数：根据kdt_id
        List<PfOrderDetailAdvanceRecordDO> allAdvanceRecords =
                pfOrderDetailAdvanceRecordMapper.selectList(
                        new QueryWrapper<PfOrderDetailAdvanceRecordDO>().eq("apply_ycm_id", kdt_id));

        // 生效记录数：pf_order_detail_advance_record：kdt_id，state=1，可用记录

        logger.info(
                String.format(
                        "pf_order_detail_advance_record 预支记录表 kdtid=%s,总记录数%s",
                        kdt_id, allAdvanceRecords.size()));

        List<Long> allOrderDetailIds =
                allAdvanceRecords.stream()
                        .map(PfOrderDetailAdvanceRecordDO::getAdvancePfOrderDetailId)
                        .collect(Collectors.toList());

        // 清空表记录
        for (Long AdvancePfOrderDetailId : allOrderDetailIds) {
            for (PfOrderDetailAdvanceRecordDO pfOrderDetailAdvanceRecordDO : allAdvanceRecords) {
                if (AdvancePfOrderDetailId == pfOrderDetailAdvanceRecordDO.getAdvancePfOrderDetailId()) {
                    pfOrderDetailAdvanceRecordMapper.delete(
                            new UpdateWrapper<PfOrderDetailAdvanceRecordDO>()
                                    .eq("advance_pf_order_detail_id", AdvancePfOrderDetailId));
                }
            }
        }
        logger.info(String.format("pf_order_detail_advance_record 预支记录表 %s 记录数据清理完成", kdt_id));

    }

    /**
     * @param kdt_id
     * @param expect_total
     * @desc 校验 回收记录 表记录数 pf_order_detail_debt_record
     * @author wulei 2020-8-14
     */
    public void queryDebtRecord(Long kdt_id, int expect_total) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 总可用记录数：根据kdt_id
        List<PfOrderDetailDebtRecordDO> alldebtRecords =
                pfOrderDetailDebtRecordMapper.selectList(
                        new QueryWrapper<PfOrderDetailDebtRecordDO>().eq("apply_ycm_id", kdt_id));

        // 生效记录数：pf_order_detail_debt_record：kdt_id，state=1，可用记录
        logger.info(
                String.format(
                        "pf_order_detail_debt_record 回收记录表 kdtid=%s,总记录数%s", kdt_id, alldebtRecords.size()));

        Assert.assertEquals(alldebtRecords.size(), expect_total);
    }

    /**
     * @param kdt_id
     * @desc 删除回收记录表：pf_order_detail_debt_record
     * @author wulei 2020-8-14
     */
    public void deleteDebtRecord(Long kdt_id) {
        // 总可用记录数：根据kdt_id

        List<PfOrderDetailDebtRecordDO> alldebtRecords =
                pfOrderDetailDebtRecordMapper.selectList(
                        new QueryWrapper<PfOrderDetailDebtRecordDO>().eq("apply_ycm_id", kdt_id));

        // 生效记录数：pf_order_detail_advance_record：kdt_id，state=1，可用记录

        logger.info(
                String.format(
                        "pf_order_detail_debt_record 回收记录表 kdtid=%s,总记录数%s", kdt_id, alldebtRecords.size()));
        logger.info(String.valueOf(alldebtRecords));

        List<Long> allOrderDetailIds =
                alldebtRecords.stream()
                        .map(PfOrderDetailDebtRecordDO::getOwePfOrderDetailId)
                        .collect(Collectors.toList());

        // 清空表记录
        for (Long PfOrderDetailId : allOrderDetailIds) {
            for (PfOrderDetailDebtRecordDO pfOrderDetailDebtRecordDO : alldebtRecords) {
                if (PfOrderDetailId == pfOrderDetailDebtRecordDO.getOwePfOrderDetailId()) {
                    pfOrderDetailDebtRecordMapper.delete(
                            new UpdateWrapper<PfOrderDetailDebtRecordDO>()
                                    .eq("owe_pf_order_detail_id", PfOrderDetailId));
                }
            }
        }
        logger.info(String.format("pf_order_detail_debt_record 回收记录表 %s 记录数据清理完成", kdt_id));

    }

    /**
     * @param kdt_id
     * @param expect_total
     * @desc 校验 回扣记录 表记录数 pf_debt_repay_record
     * @author wulei 2020-8-14
     */
    public void queryRepayRecord(Long kdt_id, int expect_total) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 总可用记录数：根据kdt_id
        List<PfDebtRepayRecordDO> allRepayRecords =
                pfDebtRepayRecordMapper.selectList(
                        new QueryWrapper<PfDebtRepayRecordDO>().eq("apply_ycm_id", kdt_id));

        // 生效记录数：pf_debt_repay_record：kdt_id，state=1，可用记录
        logger.info(
                String.format(
                        "pf_debt_repay_record 回扣记录表 kdtid=%s,总记录数%s", kdt_id, allRepayRecords.size()));

        Assert.assertEquals(allRepayRecords.size(), expect_total);
    }

    /**
     * @param kdt_id
     * @desc 删除 回扣记录表：pf_debt_repay_record
     * @author wulei 2020-8-14
     */
    public void deleteRepayRecord(Long kdt_id) {
        // 总可用记录数：根据kdt_id
        List<PfDebtRepayRecordDO> allRepayRecords =
                pfDebtRepayRecordMapper.selectList(
                        new QueryWrapper<PfDebtRepayRecordDO>().eq("apply_ycm_id", kdt_id));

        // 生效记录数：pf_debt_repay_record：kdt_id，state=1，可用记录
        logger.info(
                String.format(
                        "pf_debt_repay_record 回扣记录表 kdtid=%s,总记录数%s", kdt_id, allRepayRecords.size()));
        logger.info(String.valueOf(allRepayRecords));

        List<Long> allOrderDetailIds =
                allRepayRecords.stream()
                        .map(PfDebtRepayRecordDO::getRepayPfOrderDetailId)
                        .collect(Collectors.toList());

        // 清空表记录
        for (Long PfOrderDetailId : allOrderDetailIds) {
            for (PfDebtRepayRecordDO pfOrderDetailDebtRecordDO : allRepayRecords) {
                if (PfOrderDetailId == pfOrderDetailDebtRecordDO.getRepayPfOrderDetailId()) {
                    pfDebtRepayRecordMapper.delete(
                            new UpdateWrapper<PfDebtRepayRecordDO>()
                                    .eq("repay_pf_order_detail_id", PfOrderDetailId));
                }
            }
        }
        logger.info(String.format("pf_debt_repay_record 回收记录表 %s 记录数据清理完成", kdt_id));

    }

    /**
     * @param kdt_id
     * @desc 慎用！ 清理一个kdt_id下 商业化，计费 关于云服务费的全部表数据
     */
    public void godBlessU(Long kdt_id) {
        //  商业化相关表
        deleteTestDataYcmByKdtId(kdt_id);

        //  pf_order_detail_advance_record 预支记录表
        deleteAdvanceRecord(kdt_id);

        //  pf_order_detail_debt_record 回收表
        deleteDebtRecord(kdt_id);

        //  pf_debt_repay_record 回扣表
        deleteRepayRecord(kdt_id);

        // fc_fee_yop_protocol 计费表
        deleteYopProtocol(kdt_id);

        // fc_fee_resource_package 计费表
        updateFeeResourcePackage(kdt_id, Boolean.TRUE, Boolean.TRUE);

        // 清理服务期缓存
        clearCacheWithAppId(kdt_id.toString(),"atom_spu_wsc");
        clearCacheWithAppId(kdt_id.toString(),"atom_spu_retail_single");
        clearCacheWithAppId(kdt_id.toString(),"atom_spu_software_2021030911105980");

    }

    /**
     * @param kdt_id
     * @desc 店铺订单额度相关计算
     */
    public Map<String, Integer> calcDebtRecord(Long kdt_id) {
        // 总可用记录数：根据kdt_id,is_delte=0
        List<PfOrderDetailDebtRecordDO> alldebtRecords =
                pfOrderDetailDebtRecordMapper.selectList(
                        new QueryWrapper<PfOrderDetailDebtRecordDO>()
                                .eq("apply_ycm_id", kdt_id)
                                .eq("is_delete", 0));

        // 生效记录数：pf_order_detail_advance_record：kdt_id，state=1，可用记录
        logger.info(
                String.format(
                        "pf_order_detail_debt_record 回收记录表 kdtid=%s,总记录数%s", kdt_id, alldebtRecords.size()));
        logger.info(String.valueOf(alldebtRecords));

        //      优化解决
        int oweQuotaSum = alldebtRecords.stream().mapToInt(t -> Math.toIntExact(t.getOweQuota())).sum();
        int oweQuotaSnapshotSum =
                alldebtRecords.stream().mapToInt(t -> Math.toIntExact(t.getOweQuotaSnapshot())).sum();
        int recoveryQuotaSum =
                alldebtRecords.stream().mapToInt(t -> Math.toIntExact(t.getRecoveryQuota())).sum();

        Map<String, Integer> result = new HashMap<String, Integer>();
        // 应回收额度总额=owe_quota_snapshot +recovery_quota
        result.put("shouldReocvery", oweQuotaSnapshotSum + recoveryQuotaSum);
        // 当前欠额=owe_quota
        result.put("owe", oweQuotaSum);
        // 实际回收总额=recovery_quota
        result.put("recover", recoveryQuotaSum);
        // 超支：owe_quota_snapshot
        result.put("overspend", oweQuotaSnapshotSum);
        logger.info(String.format("当前店铺【%s】的回收情况如下：", kdt_id));
        logger.info(String.format("当前欠额owe=%d", oweQuotaSum));
        logger.info(String.format("实际回收额度recover=%d", recoveryQuotaSum));
        logger.info(String.format("超支overspend=%d", oweQuotaSnapshotSum));
        logger.info(String.format("应回收总额度shouldReocvery=%d", oweQuotaSnapshotSum + recoveryQuotaSum));

        return result;
    }

    ////////////////////////////////////// 计费侧操作

    /**
     * @param kdtId
     * @param orderId
     * @param orderDetailId
     * @param n
     * @desc 查询计费侧额度方法1
     */
    public void testGetYopQuota(long kdtId, long orderId, long orderDetailId, int n) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        FeeYopSingleQueryRequest request = new FeeYopSingleQueryRequest();
        request.setKdtId(kdtId);
        request.setOrderId(orderId);
        request.setOrderDetailId(orderDetailId);
        PlainResult<FeeYopResourceDTO> getResult = feeYopService.getYopQuota(request);
        Assert.assertEquals(getResult.getCode(), 200);
        Assert.assertEquals(getResult.getData().getQuota().intValue(), n);
    }

    /**
     * @param kdtId
     * @param sourceType
     * @param excludeInvalid
     * @param n
     * @desc 查询计费侧额度方法2
     */
    public void testQueryQuota(long kdtId, int sourceType, boolean excludeInvalid, int n) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        FeeYopQueryRequest request = new FeeYopQueryRequest();
        request.setKdtId(kdtId);
        List sourceTypes = new ArrayList();
        sourceTypes.add(sourceType);
        request.setSourceTypes(sourceTypes);
        request.setExcludeInvalid(excludeInvalid);
        PlainResult<List<FeeYopResourceDTO>> queryResult = new PlainResult<List<FeeYopResourceDTO>>();
        queryResult = feeYopService.queryYopQuota(request);
        logger.info(JSON.toJSONString(queryResult));
        Assert.assertEquals(queryResult.getCode(), 200, "额度查询异常");
        Assert.assertTrue(queryResult.getData().size() > 0, "额度信息异常");
        Assert.assertEquals(queryResult.getData().get(0).getQuota().intValue(), n, "额度发放或回收异常");
    }

    /**
     * @param kdtId
     * @param expect_total 预期总可额度值
     * @desc 查询计费侧：总额度
     */
    public void testQueryTotalQuota(long kdtId, int expect_total) {
        logger.info("testQueryTotalQuota");
        logger.info(JSON.toJSONString(feeStatQueryService.queryQuotaAndStatBillInfo(kdtId)));
        Assert.assertEquals(feeStatQueryService.queryQuotaAndStatBillInfo(kdtId).getCode(), 200);
        // 等待计费侧数据
        with().atMost(60, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeStatQueryService.queryQuotaAndStatBillInfo(kdtId).getData().getQuota() == expect_total);
        Assert.assertEquals(feeStatQueryService.queryQuotaAndStatBillInfo(kdtId).getData().getQuota(), expect_total);
    }

    /**
     * @param kdtId
     * @param expect_remain 预期总可用额度值
     * @desc 查询计费侧：总可用额度
     */
    public void testQueryAvailableQuota(long kdtId, int expect_remain) {
        Assert.assertEquals(feeStatQueryService.queryQuotaAndStatBillInfo(kdtId).getCode(), 200);
        // 等待计费侧数据
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeStatQueryService.queryQuotaAndStatBillInfo(kdtId).getData().getRemain() == expect_remain);
        Assert.assertEquals(feeStatQueryService.queryQuotaAndStatBillInfo(kdtId).getData().getRemain(), expect_remain);
    }

    /**
     * @param kdtId
     * @param a
     * @param excludeInvalid
     * @desc 查询计费侧额度回收是否完成
     */
    public void testQueryQuotaRecycle(long kdtId, int a, boolean excludeInvalid) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        FeeYopQueryRequest request = new FeeYopQueryRequest();
        request.setKdtId(kdtId);
        List sourceTypes = new ArrayList();
        sourceTypes.add(a);
        request.setSourceTypes(sourceTypes);
        request.setExcludeInvalid(excludeInvalid);
        PlainResult<List<FeeYopResourceDTO>> queryResult = new PlainResult<List<FeeYopResourceDTO>>();
        queryResult = feeYopService.queryYopQuota(request);
        logger.info(JSON.toJSONString(queryResult));
        Assert.assertEquals(queryResult.getCode(), 200, "额度查询异常");
        Assert.assertTrue(queryResult.getData().size() == 0);
    }

    /**
     * @param kdtId
     * @param orderId
     * @param orderDetailId
     * @desc 手动回收计费侧额度（计费退款接口）
     */
    public void testQuotaByRefund(long kdtId, Long orderId, Long orderDetailId) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        FeeYopRefundRequest request = new FeeYopRefundRequest();
        request.setKdtId(kdtId);
        request.setOrderId(orderId);
        request.setOrderDetailId(orderDetailId);
        PlainResult<Long> result = new PlainResult<Long>();
        result = feeYopService.refund(request);
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(), 200, "额度回收异常");
        Assert.assertTrue(result.getData() != -1, "额度回收异常");
    }

    /**
     * @param kdt_id
     * @param quotaToZero ：所有可用额度设置为0（设置used=total）
     * @param deleteAll   ：删除fc_fee_resource_package表记录，慎用
     * @desc 更新计费fc_fee_resource_package表：可以设置可用额度为0，或者删除全部记录
     * @author wulei
     */
    public void updateFeeResourcePackage(Long kdt_id, Boolean quotaToZero, Boolean deleteAll) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 总可用记录数：根据kdt_id
        List<FeeResourcePackageDO> allFeeResourcePpackageDOs =
                feeResourcePackageMapper.selectList(
                        new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()));

        // 生效记录数：查询fc_fee_resource_package表：kdt_id，state=1，total>0的可用记录
        List<FeeResourcePackageDO> availableFeeResourcePpackageDOs =
                feeResourcePackageMapper.selectList(
                        new QueryWrapper<FeeResourcePackageDO>()
                                .eq("kdt_id", kdt_id.toString())
                                .eq("state", 1)
                                .ge("total", 0));

        logger.info(
                String.format(
                        "fc_fee_resource_packag表 kdtid=%s,总记录数%s,生效记录数%s",
                        kdt_id, allFeeResourcePpackageDOs.size(), availableFeeResourcePpackageDOs.size()));

        List<String> availablerelatedNos =
                availableFeeResourcePpackageDOs.stream()
                        .map(FeeResourcePackageDO::getRelatedNo)
                        .collect(Collectors.toList());
        List<String> allrelatedNos =
                allFeeResourcePpackageDOs.stream()
                        .map(FeeResourcePackageDO::getRelatedNo)
                        .collect(Collectors.toList());

        // 如果quotaToZero（额度设置为0）为true，把state=1的额度used设置为total
        if (quotaToZero == Boolean.TRUE) {
            LambdaUpdateWrapper<FeeResourcePackageDO> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.set(FeeResourcePackageDO::getUsed, 20000).eq(FeeResourcePackageDO::getKdtId, kdt_id.toString())
                    .eq(FeeResourcePackageDO::getState, 1);
            feeResourcePackageMapper.update(null, updateWrapper);
        }

        // 如果deleteall 为真，删除所有记录：kdt_id 纬度
        if (deleteAll == Boolean.TRUE) {
            for (String relatedNo : allrelatedNos) {
                for (FeeResourcePackageDO feeResourcePackageDO : allFeeResourcePpackageDOs) {
                    if (relatedNo == feeResourcePackageDO.getRelatedNo()) {
                        feeResourcePackageMapper.delete(
                                new UpdateWrapper<FeeResourcePackageDO>().eq("related_no", relatedNo));
                    }
                }
            }
        }

    }

    public void updateFeeResource(Long kdt_id) {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        LambdaUpdateWrapper<FeeResourcePackageDO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(FeeResourcePackageDO::getUsed, 20000).eq(FeeResourcePackageDO::getKdtId, kdt_id.toString())
                .eq(FeeResourcePackageDO::getState, 1);
        feeResourcePackageMapper.update(null, updateWrapper);
    }

    /**
     * @param kdt_id
     * @desc 清空fc_fee_yop_protocol表制定kdt_id记录
     * @author wulei
     */
    public void deleteYopProtocol(Long kdt_id) {
        // 总可用记录数：根据kdt_id

        List<FeeYopProtocolDTO> allfeeYopProtocolDTOs =
                feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id));

        // 生效记录数：fc_fee_yop_protocol：kdt_id，state=1，可用记录
        List<FeeYopProtocolDTO> availablefeeYopProtocols =
                feeYopProtocolMapper.selectList(
                        new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).eq("state", 1));

        logger.info(
                String.format(
                        "fc_fee_yop_protocol kdtid=%s,总记录数%s,state=1 生效记录数%s",
                        kdt_id, allfeeYopProtocolDTOs.size(), availablefeeYopProtocols.size()));

        List<String> allOrdes =
                allfeeYopProtocolDTOs.stream()
                        .map(FeeYopProtocolDTO::getOrderId)
                        .collect(Collectors.toList());

        for (String relatedNo : allOrdes) {
            for (FeeYopProtocolDTO feeResourcePackageDO : allfeeYopProtocolDTOs) {
                if (relatedNo == feeResourcePackageDO.getOrderId()) {
                    feeYopProtocolMapper.delete(
                            new UpdateWrapper<FeeYopProtocolDTO>().eq("order_id", relatedNo));
                }
            }
        }

    }

    /**
     * @param kdtId
     * @param kdtName
     * @param itemId
     * @param quantity
     * @desc 线下落单-for test
     */
    public void offlineOrder(
            Long kdtId, String kdtName, Integer itemId, Integer quantity, Integer realPrice) {

        clearCache(String.valueOf(kdtId));
        OfflineOrderForm offlineOrderForm = new OfflineOrderForm();
        offlineOrderForm.setKdtId(kdtId);
        offlineOrderForm.setKdtName(kdtName);
        offlineOrderForm.setNeedAdminSign((byte) 0);
        offlineOrderForm.setOperatorId(3046l);
        offlineOrderForm.setRealPrice(realPrice);
        offlineOrderForm.setType(0);
        List<OrderItemForm> items = new ArrayList<>();
        OrderItemForm orderItemForm = new OrderItemForm();
        orderItemForm.setItemId(itemId);
        orderItemForm.setQuantity(quantity);
        orderItemForm.setBuyType((byte) 1);
        orderItemForm.setApplyKdtId(kdtId);
        orderItemForm.setNewMigration(null);
        items.add(orderItemForm);
        offlineOrderForm.setItems(items);
        PlainResult<Long> result = marketRemoteService.createOfflineOrderReform(offlineOrderForm);
        logger.info("线下订单创建结果：");
        logger.info(JSON.toJSONString(result));
    }

    /**
     * @param kdtId
     * @param itemId
     * @param quantity
     * @param realPrice
     * @desc biz_console系统真实线下落单接口
     * @author wulei 202020825
     */
    public PlainResult<List<Long>> bizOfflineOrder(
            Long kdtId, Integer itemId, Integer quantity, Integer realPrice) {
        try {
//            moreMoney(kdtId);
            clearCache(String.valueOf(kdtId));
            BatchOfflineOrderForm offlineOrderForm = new BatchOfflineOrderForm();
            List<Long> kdtIds = new ArrayList<>();
            kdtIds.add(kdtId);
            offlineOrderForm.setKdtIds(kdtIds);
            offlineOrderForm.setNeedAdminSign((byte) 0);
            offlineOrderForm.setOperatorId(3046l);
            offlineOrderForm.setRealPrice(realPrice);
            offlineOrderForm.setType(0);
            offlineOrderForm.setDiscountAmount(0L);
            offlineOrderForm.setOriginPrice(0L);
            List<OrderItemForm> items = new ArrayList<>();
            OrderItemForm orderItemForm = new OrderItemForm();
            orderItemForm.setItemId(itemId);
            orderItemForm.setQuantity(quantity);
            orderItemForm.setBuyType((byte) 1);
            orderItemForm.setApplyKdtId(kdtId);
            orderItemForm.setNewMigration(null);
            items.add(orderItemForm);
            offlineOrderForm.setItems(items);
            PlainResult<List<Long>> result =
                    marketRemoteService.batchCreateOfflineOrderReform(offlineOrderForm);
            logger.info("线下订单创建结果：");
            logger.info(JSON.toJSONString(result));
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            godBlessU(kdtId);
        }
        return null;
    }


    /**
     * @param kdtId
     * @param itemId
     * @param quantity
     * @param realPrice
     * @desc biz_console系统真实线下落单接口V2-最新版
     * @author wulei 202020825
     */
    public PlainResult<CreateOfflineOrderResponse> createOfflineOrderV2(
            Long kdtId, Integer itemId, Integer quantity, Integer realPrice) {
        try {
            clearCache(String.valueOf(kdtId));
            OfflineOrderFormV2 offlineOrderFormV2 = new OfflineOrderFormV2();

            offlineOrderFormV2.setKdtId(kdtId.toString());
            offlineOrderFormV2.setNeedAdminSign((byte) 0);
            offlineOrderFormV2.setOperatorId(3046l);
            offlineOrderFormV2.setRealPrice(realPrice);
            offlineOrderFormV2.setType(0);
            offlineOrderFormV2.setDiscountAmount(0L);
            offlineOrderFormV2.setOriginPrice(0L);
            offlineOrderFormV2.setUserId(123L);

            List<OrderItemFormV2> items = new ArrayList<>();
            OrderItemFormV2 orderItemForm = new OrderItemFormV2();
            orderItemForm.setItemId(itemId);
            orderItemForm.setQuantity(quantity);
            orderItemForm.setBuyType((byte) 1);
            orderItemForm.setApplyKdtId(kdtId.toString());
            orderItemForm.setNewMigration(null);
            items.add(orderItemForm);

            offlineOrderFormV2.setItems(items);
            logger.info("request=",offlineOrderFormV2.toString());

            PlainResult<CreateOfflineOrderResponse> result = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<CreateOfflineOrderResponse>>() {
                        @Override
                        public  PlainResult<CreateOfflineOrderResponse>  doExecute() {
                            CompareSCUtil.resetSC();
                            return marketRemoteService.createOfflineOrderV2(offlineOrderFormV2);
                        }

                        @Override
                        public boolean handleResult(PlainResult<CreateOfflineOrderResponse> plainResult) {
                            if(plainResult.getCode() == 200){
                                log.info("createOfflineOrderV2 创建订单成功");
                                return true;
                            }
                            if(plainResult.getCode() == 141038){
                                // 兼容重复订购爆单计划的场景
                                log.info("createOfflineOrderV2爆单计划单店重复订购");
                                return true;
                            }
                            log.info("createOfflineOrderV2 创建订单失败，开始关单");
                            godBlessU(kdtId);
                            return false;
                        }
                    }, 5, 100);

            logger.info("createOfflineOrderV2线下订单创建结果：");
            logger.info(JSON.toJSONString(result));
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            godBlessU(kdtId);
        }
        return null;
    }

    /**
     * @param kdt_id
     * @param topic
     * @param appid
     * @param pf_order_id
     * @desc 查询NSQ消息表
     * @author wulei 202020827
     */
    public List<SendNsqMessageDO> querySendNsq(
            String kdt_id, String topic, String appid, String pf_order_id) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 查询最近100条数据
        List<SendNsqMessageDO> allfeeYopProtocolDTOs =
                sendNsqMessageMapper.selectList(
                        new QueryWrapper<SendNsqMessageDO>()
                                .eq("topic", topic)
                                .inSql(
                                        "id",
                                        "select t.id from (select * from send_nsq_message  order by  created_at desc limit 100) as t"));

        List<SendNsqMessageDO> allrelatedNos =
                allfeeYopProtocolDTOs.stream()
                        .filter(
                                content ->
                                        content.getContent().indexOf(kdt_id) != -1
                                                && content.getContent().indexOf(appid) != -1
                                                && content.getContent().indexOf(pf_order_id) != -1)
                        .collect(Collectors.toList());
        return allrelatedNos;
    }

    /**
     * @param kdt_id
     * @param item_id
     * @return
     * @desc 查询pf_order表，并返回
     * @author wulei 202020827
     */
    public List<PfOrder> queryPfOrder(String kdt_id, String item_id) {
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 查询最近100条数据
        List<PfOrder> allPfOrders =
                pfOrderMapper.selectList(
                        new QueryWrapper<PfOrder>().eq("buy_kdt_id", kdt_id).eq("item_id", item_id));
        return allPfOrders;
    }

    /**
     * @param gdId：item_id
     * @desc 清理 ycm_goods 缓存
     * @author wulei 20200827
     * *
     */
    public void clearPfGoodsCache(String gdId) {
        try {
            logger.info("开始清理 商品 缓存");
            ClearRelatedCacheRequest clearRelatedCacheRequest1 = new ClearRelatedCacheRequest();
            clearRelatedCacheRequest1.setGdId(gdId);
            clearRelatedCacheRequest1.setGdType("sku");

            ClearRelatedCacheRequest clearRelatedCacheRequest2 = new ClearRelatedCacheRequest();
            clearRelatedCacheRequest2.setGdId(gdId);
            clearRelatedCacheRequest2.setGdType("spu");

            PlainResult<ClearRelatedCacheResponse> result1 = goodsCacheRemoteService.clearRelatedCache(clearRelatedCacheRequest1);
            PlainResult<ClearRelatedCacheResponse> result2 = goodsCacheRemoteService.clearRelatedCache(clearRelatedCacheRequest2);
            logger.info(JSON.toJSONString(result1));
            logger.info(JSON.toJSONString(result2));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param str
     * @return
     */
    public List<Integer> strToList(String str) {
        List<Integer> result = new ArrayList<Integer>();
        if (str != "") {
            for (String s : str.split(",")) {
                result.add(Integer.valueOf(s));
            }
        }
        return result;
    }

    // 商品相关库表删除操作
    public void deleteAtomItemInfoByAppId(String appId) {
        //  gd_atom_item_property_relation
        List<String> itemIds = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().eq("atom_app_id", appId))
                .stream().map(GdAtomItem::getAtomItemId).distinct().collect(Collectors.toList());
        if (itemIds.size() != 0) {
            for (String itemId : itemIds) {
                List<Long> gdAtomItemPropertyRelationIdList = gdAtomItemPropertyRelationMapper.selectList(new QueryWrapper<GdAtomItemPropertyRelation>().eq("atom_item_id", itemId)).stream()
                        .map(GdAtomItemPropertyRelation::getId).collect(Collectors.toList());
                gdAtomItemPropertyRelationMapper.deleteBatchIds(gdAtomItemPropertyRelationIdList);
            }
        }
        //  gd_atom_item
        List<GdAtomItem> gdAtomItemDO = gdAtomItemMapper.selectList(new QueryWrapper<GdAtomItem>().eq("atom_app_id", appId));
        if (gdAtomItemDO.size() != 0) {
            List<Long> gdAtomItemIdList = gdAtomItemDO.stream().map(GdAtomItem::getId).collect(Collectors.toList());
            gdAtomItemMapper.deleteBatchIds(gdAtomItemIdList);
        }
        //  gd_atom_basic
        List<GdAtomBasic> gdAtomBasicDO = gdAtomBasicMapper.selectList(new QueryWrapper<GdAtomBasic>().eq("atom_app_id", appId));
        if (gdAtomBasicDO.size() != 0) {
            List<Long> gdAtomBasicIdList = gdAtomBasicDO.stream().map(GdAtomBasic::getId).collect(Collectors.toList());
            gdAtomBasicMapper.deleteBatchIds(gdAtomBasicIdList);
        }
        logger.info("删除原子商品数据成功");

    }

    public void deleteCombineItemInfoByAppId(String appId) {
        //  gd_combine_basic
        List<Long> gdCombineBasicIdList = gdCombineBasicMapper.selectList(new QueryWrapper<GdCombineBasic>()
                .eq("combine_app_id", appId)).stream().map(GdCombineBasic::getId).collect(Collectors.toList());
        if (gdCombineBasicIdList.size() != 0) {
            gdCombineBasicMapper.deleteBatchIds(gdCombineBasicIdList);
        }

        //  gd_combine_item
        List<Long> gdCombineItemIdList = gdCombineItemMapper.selectList(new QueryWrapper<GdCombineItem>()
                .eq("combine_app_id", appId)).stream().map(GdCombineItem::getId).collect(Collectors.toList());
        if (gdCombineItemIdList.size() != 0) {
            gdCombineItemMapper.deleteBatchIds(gdCombineItemIdList);
        }

        //  gd_combine_template
        List<Long> gdCombineTemplateIdList = gdCombineTemplateMapper.selectList(new QueryWrapper<GdCombineTemplate>()
                .eq("combine_app_id", appId)).stream().map(GdCombineTemplate::getId).collect(Collectors.toList());
        if (gdCombineTemplateIdList.size() != 0) {
            gdCombineTemplateMapper.deleteBatchIds(gdCombineItemIdList);
            //  gd_combine_template_content
            for (Long templateId : gdCombineTemplateIdList) {
                List<Long> gdCombineTemplateContentIdList = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>()
                        .eq("combine_template_id", templateId)).stream()
                        .map(GdCombineTemplateContent::getId).collect(Collectors.toList());
                gdCombineTemplateContentMapper.deleteBatchIds(gdCombineTemplateContentIdList);
            }
        }
        logger.info("删除组合商品数据成功");

    }


    /**
     * 店铺余额充值，单位（元）
     *
     * @param kdtId
     */

    public void moreMoney(Long kdtId) {
        String userNo = kdtId.toString();
        int money = 50000 * 100;
        int inputType = 0;
        //根据kdtId 获取userNo
        PlainResult<String> result = new PlainResult<>();
        try {
            result = userInfoService.queryUserNoByKdtId(Integer.parseInt(String.valueOf(kdtId)));
            if (!result.isSuccess() || result.getData() == null) {
                logger.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
                throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
            }
        } catch (Exception e) {
            logger.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
            throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
        }
        userNo = result.getData();

        String waterNo = String.valueOf(KeyUtils.generateWaterNumber());
        AcctransRechargeRequest rechargeRequest = new AcctransRechargeRequest();
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setUserNo(String.valueOf(userNo));
        accountInfo.setAccountType(AccountType.BASE_ACCT.getType());
        rechargeRequest.setAccountInfo(accountInfo);
        rechargeRequest.setAppName("biz-commerce");
        rechargeRequest.setClientId(waterNo);
        rechargeRequest.setAcquireNo(waterNo);
        rechargeRequest.setAmount(money);
        rechargeRequest.setChannelCode(ChannelType.BALANCE.getCode());
        rechargeRequest.setCurrencyCode(CurrencyCode.CNY.getNum());
        rechargeRequest.setOperator("ci-test");
        rechargeRequest.setOrderNo(waterNo);
        rechargeRequest.setParternerBizType("301001");
        rechargeRequest.setParternerId("301001");
        rechargeRequest.setRemark("接口测试调用");
        rechargeRequest.setSubTransCode(SubTransCodeEnum.RECHARGE_RECHARGESETTLE.getCode());
        rechargeRequest.setTransCode(TransCodeEnum.RECHARGE.getCode());
        rechargeRequest.setRequestTime("test");
        DataResult<AcctransAccountingDTO> rechargeResult = acctransRechargeService.recharge(rechargeRequest);

        if (!rechargeResult.isSuccess()) {
            logger.error("AcctransService 充值接口调用失败,waterNo=" + rechargeResult.getRequestId() + "! ");
            throw new BusinessException("AcctransService 充值接口调用失败！返回结果为：" + JSON.toJSONString(rechargeResult));
        }

    }

    public PlainResult<PreparePayResponse> prePayOrder(
            String env, Long kdtId, String url, String kdtName, int itemId, int quantity, int flag) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            // 清理缓存
            clearCache(kdtId.toString());

            OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
            List<OrderItemForm> orderItemFormList = new ArrayList<>();
            orderItemFormList.add(orderItemForm);

            ConfirmOrderForm confirmOrderForm =
                    ConstructionParam.getConfirmOrderForm(kdtId, kdtName, orderItemFormList);
            PlainResult<OrderConfirmApi> confirmApiPlainResult =
                    orderRemoteService.confirmOrder(confirmOrderForm);
            Assert.assertTrue(confirmApiPlainResult.getData() != null);
            //Assert.assertTrue(confirmApiPlainResult.getData().getYzbQuota() > 0);
            CreateOrderForm createOrderForm =
                    ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList, 0L);

            //订单级别优惠参数
            Long promotionId = getFullReduce(kdtId, kdtName, itemId, quantity);
            List<PreferentialDescApi> orderPromotionList = ConstructionParam.getOrderPromotionList(kdtId, kdtName, itemId, promotionId, quantity);
            createOrderForm.setOrderPromotionList(orderPromotionList);

            PlainResult<OrderCreateApi> orderCreateApiPlainResult =
                    orderRemoteService.createOrderV2(createOrderForm);
            logger.info("orderCreateApiPlainResult:{}", JSON.toJSONString(orderCreateApiPlainResult));
            Assert.assertEquals(orderCreateApiPlainResult.getCode(), 200);
            Assert.assertEquals(orderCreateApiPlainResult.getMessage(), "successful");
            if (orderCreateApiPlainResult.getCode() == 200) {
                PreparePayRequest preparePayForm = new PreparePayRequest();
                preparePayForm.setPayEnv(env);
                if (orderCreateApiPlainResult.getData().getPayOrderId() != null && flag == 1) {
                    TdOrder tdOrder =
                            tdOrderMapper.selectById(orderCreateApiPlainResult.getData().getPayOrderId());
                    String tdNo = tdOrder.getTdNo();
                    preparePayForm.setTradeNo(tdNo);
                }
                ;
                preparePayForm.setReturnUrl(url);
                PlainResult<PreparePayResponse> preparePayResult = preparePayRemoteService.preparePay(preparePayForm);
                logger.info(JSON.toJSONString(preparePayResult));
                return preparePayResult;
            }

        } catch (AssertionError e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 初始化店铺：关单、退款、回收礼包,清理缓存
     *
     * @param kdtId
     */
    public void godCannotHelpU(Long kdtId) {
        closeWaitPayOrder(kdtId);
        refundOrderByKdtId(kdtId);
        recycleGiftAssetByKdtId(kdtId);
        // 清理服务期缓存
        clearCache(String.valueOf(kdtId));
    }

    /**
     * 查询订单额度服务期
     */
    public void getQuotaProtocolInfoCheck(Long kdt_id,String app_id)  {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // pf_order_status.pf_order_id
        PfOrderStatus pfOrderStatus = pfOrderStatusMapper.selectOne(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getAppId,app_id).eq(PfOrderStatus::getApplyKdtId,kdt_id.toString()));
        Long pf_order_id = pfOrderStatus.getPfOrderId();
        log.info("pf_order_id="+pf_order_id);
        // fc_fee_yop_protocol.expire_time
        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);
        Date fc_fee_yop_protocol_expire_time = feeYopProtocolDTO.getExpireTime();
        log.info("DB=fc_fee_yop_protocol.expire_time="+fc_fee_yop_protocol_expire_time);

        OrderForm orderForm = new OrderForm();
        orderForm.setOrderId(pf_order_id);
        PlainResult<OrderProtocolInfoApi> result = orderQuotaRemoteService.getQuotaProtocolInfo(orderForm);
        Assert.assertEquals(result.getCode(), 200);
        log.info("Response=expire_time="+result.getData().getEndTime());
        if(app_id.equals("atom_spu_order_limit")){
            Assert.assertEquals(result.getData().getEndTime(), null);
        }else {
            Assert.assertEquals(result.getData().getEndTime(), fc_fee_yop_protocol_expire_time);
        }
    }

    /**
     * 线下订单-爆单计划：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceBaodan(Long kdt_id) {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "15000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(3));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"plugin_meal");

        Date pfFeeResourcePackageEntity_effect_time = pfFeeResourcePackageEntity.getEffectTime();
        Date pfFeeResourcePackageEntity_expire_time = pfFeeResourcePackageEntity.getExpireTime();

        Period period3 = Period.between(pfFeeResourcePackageEntity_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), pfFeeResourcePackageEntity_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period3.getYears(), 1);

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "15000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(9),"计费侧数据resource_mode=9失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));

        Date fc_fee_resource_package_effect_time = fc_fee_resource_package.getEffectTime();
        Date fc_fee_resource_package_expire_time = fc_fee_resource_package.getExpireTime();

        Period period2 = Period.between(fc_fee_resource_package_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), fc_fee_resource_package_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period2.getYears(), 1);

        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "15000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(3));

        //时间差：1年
        Date feeYopProtocolDTO_effect_time = feeYopProtocolDTO.getEffectTime();
        Date feeYopProtocolDTO_expire_time = feeYopProtocolDTO.getExpireTime();

        Long duration = durations(feeYopProtocolDTO_effect_time,feeYopProtocolDTO_expire_time, ChronoUnit.YEARS);

//        Period period3 = Period.between(feeYopProtocolDTO_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), feeYopProtocolDTO_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(duration, Long.valueOf(1));
        //查询服务期
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_trade_support_plan");
        logger.info("计费侧，线下订单-爆单计划，校验成功");
    }


    /**
     * 线下订单-订单额度，1000额度，500元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceNotZeroOrder(Long kdt_id) {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "1000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"plugin");
        Assert.assertEquals(pfFeeResourcePackageEntity.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(pfFeeResourcePackageEntity.getExpireTime().toString(),"Sat Jan 01 00:00:00 CST 2039");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "1000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(5),"计费侧数据resource_mode=5失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(fc_fee_resource_package.getExpireTime().toString(),"Sat Jan 01 00:00:00 CST 2039");

        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "1000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(1));

        //时间差：100年
        Date feeYopProtocolDTO_effect_time = feeYopProtocolDTO.getEffectTime();
        Date feeYopProtocolDTO_expire_time = feeYopProtocolDTO.getExpireTime();

        Long duration = durations(feeYopProtocolDTO_effect_time,feeYopProtocolDTO_expire_time, ChronoUnit.YEARS);

//        Period period3 = Period.between(feeYopProtocolDTO_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), feeYopProtocolDTO_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(duration, Long.valueOf(100));
        logger.info("计费侧，线下订单-订单额度，1000额度，500元，校验成功");
    }

    /**
     * 线下订单-订单额度，1000额度，0元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceZeroOrder(Long kdt_id) {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "1000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(2));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"plugin");

        //时间差：1年
        Date package_effect_time = pfFeeResourcePackageEntity.getEffectTime();
        Date package_expire_time = pfFeeResourcePackageEntity.getExpireTime();

        Period period = Period.between(package_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), package_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period.getYears(), 1);

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);


        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "1000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(1),"计费侧数据resource_mode=1失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));

        //时间差：1年
        Date fc_fee_resource_package_effect_time = fc_fee_resource_package.getEffectTime();
        Date fc_fee_resource_package_expire_time = fc_fee_resource_package.getExpireTime();

        Period period2 = Period.between(fc_fee_resource_package_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), fc_fee_resource_package_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period2.getYears(), 1);

        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "1000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(2));

        //时间差：1年
        Date feeYopProtocolDTO_effect_time = feeYopProtocolDTO.getEffectTime();
        Date feeYopProtocolDTO_expire_time = feeYopProtocolDTO.getExpireTime();

        Long duration = durations(feeYopProtocolDTO_effect_time,feeYopProtocolDTO_expire_time, ChronoUnit.YEARS);

//        Period period3 = Period.between(feeYopProtocolDTO_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), feeYopProtocolDTO_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(duration, Long.valueOf(1));
        logger.info("计费侧，线下订单-订单额度，1000额度，0元，校验成功");
    }

    /**
     * 线下订单-授信额度-周期性，包含2000额度，1000元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceShouXinPeriod(Long kdt_id) {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "2000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(10));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"rights_v2");

        //时间差：1年
        Date package_effect_time = pfFeeResourcePackageEntity.getEffectTime();
        Date package_expire_time = pfFeeResourcePackageEntity.getExpireTime();

        Period period = Period.between(package_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), package_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period.getYears(), 1);

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "2000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(8),"计费侧数据resource_mode=8失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));

        //时间差：1年
        Date fc_fee_resource_package_effect_time = fc_fee_resource_package.getEffectTime();
        Date fc_fee_resource_package_expire_time = fc_fee_resource_package.getExpireTime();

        Period period2 = Period.between(fc_fee_resource_package_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), fc_fee_resource_package_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period2.getYears(), 1);

        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "2000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(10));

        //时间差：1年
        Date feeYopProtocolDTO_effect_time = feeYopProtocolDTO.getEffectTime();
        Date feeYopProtocolDTO_expire_time = feeYopProtocolDTO.getExpireTime();

        Long duration = durations(feeYopProtocolDTO_effect_time,feeYopProtocolDTO_expire_time, ChronoUnit.YEARS);

//        Period period3 = Period.between(feeYopProtocolDTO_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), feeYopProtocolDTO_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(duration, Long.valueOf(1));
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_youzan_rights_1581440");
        logger.info("计费侧，线下订购-授信订单额度-周期型，校验成功");
    }

    /**
     * 线下订单-授信额度-库存性，包含2000额度，1000元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceShouXinStock(Long kdt_id) {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "2000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(10));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"rights_v2");
        Assert.assertEquals(pfFeeResourcePackageEntity.getExpireTime().toString(),"Thu Jan 01 00:00:00 CST 2099");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "2000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(8),"计费侧数据resource_mode=8失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getExpireTime().toString(),"Thu Jan 01 00:00:00 CST 2099");


        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "2000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(10));
        Assert.assertEquals(feeYopProtocolDTO.getExpireTime().toString(),"Thu Jan 01 00:00:00 CST 2099");
        logger.info("计费侧，线下订购-授信订单额度-库存型，校验成功");
    }


    /**
     * 线上购买-微商城1年基础班，10000额度，6800元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceWSCBasicOneYearOrder(Long kdt_id)  {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "10000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(2));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"software_meal");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "10000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(1),"计费侧数据resource_mode=1失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");


        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "10000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(2));

        // 3各表的expire_time
        Date fee_resource_packageExpireTime = fc_fee_resource_package.getExpireTime();//
        Date fc_fee_yop_protocol = feeYopProtocolDTO.getExpireTime();//
        Date pf_fee_expire = pfFeeResourcePackageEntity.getExpireTime();//

        // fee_resource.expire_time = pf_fee.expire_time
        Assert.assertEquals(fee_resource_packageExpireTime, pf_fee_expire);

        Long duration = durations(fc_fee_yop_protocol,fee_resource_packageExpireTime, ChronoUnit.DAYS);

        if(duration==Long.valueOf("7")){
            // 7天保护期
            log.info("7天保护期正常");
        }else {
            //自定义的保护期
            PfProtectionPeriodEntity pfProtectionPeriodEntity = pfProtectionPeriodMapper.selectOne(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdt_id.toString()));
            Assert.assertEquals(duration, Long.valueOf(pfProtectionPeriodEntity.getProtectionPeriod()));
            log.info(pfProtectionPeriodEntity.getProtectionPeriod()+"天保护期正常");
        }
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_wsc");

        logger.info("计费侧，购买微商城1年基础版本，校验成功");
    }

    /**
     * 线上购买-教育1年基础班，10000额度，6800元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceEDUBasicOneYearOrder(Long kdt_id)  {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "10000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(2));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"software_meal");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "10000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(1),"计费侧数据resource_mode=1失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");


        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "10000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(2));

        // 3各表的expire_time
        Date fee_resource_packageExpireTime = fc_fee_resource_package.getExpireTime();//
        Date fc_fee_yop_protocol = feeYopProtocolDTO.getExpireTime();//
        Date pf_fee_expire = pfFeeResourcePackageEntity.getExpireTime();//

        // fee_resource.expire_time = pf_fee.expire_time
        Assert.assertEquals(fee_resource_packageExpireTime, pf_fee_expire);

        Long duration = durations(fc_fee_yop_protocol,fee_resource_packageExpireTime, ChronoUnit.DAYS);

        if(duration==Long.valueOf("15")){
            // 15天保护期
            log.info("教育15天保护期正常");
        }else {
            //自定义的保护期
            PfProtectionPeriodEntity pfProtectionPeriodEntity = pfProtectionPeriodMapper.selectOne(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdt_id.toString()));
            Assert.assertEquals(duration, Long.valueOf(pfProtectionPeriodEntity.getProtectionPeriod()));
            log.info(pfProtectionPeriodEntity.getProtectionPeriod()+"天保护期正常");
        }
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_edu_single");

        logger.info("计费侧，购买教育1年基础版本，校验成功");
    }

    /**
     * 线上购买-零售1年专业版，10000额度，6800元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceLSProfessionalOneYearOrder(Long kdt_id)  {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "20000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(2));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"software_meal");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "20000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(1),"计费侧数据resource_mode=1失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");


        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "20000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(2));

        // 3各表的expire_time
        Date fee_resource_packageExpireTime = fc_fee_resource_package.getExpireTime();//
        Date fc_fee_yop_protocol = feeYopProtocolDTO.getExpireTime();//
        Date pf_fee_expire = pfFeeResourcePackageEntity.getExpireTime();//

        // fee_resource.expire_time = pf_fee.expire_time
        Assert.assertEquals(fee_resource_packageExpireTime, pf_fee_expire);

        Long duration = durations(fc_fee_yop_protocol,fee_resource_packageExpireTime, ChronoUnit.DAYS);
        if(duration==Long.valueOf("30")){
            // 30天保护期
            log.info("30天保护期正常");
        }else {
            //自定义的保护期
            PfProtectionPeriodEntity pfProtectionPeriodEntity = pfProtectionPeriodMapper.selectOne(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdt_id.toString()));
            Assert.assertEquals(duration, Long.valueOf(pfProtectionPeriodEntity.getProtectionPeriod()));
            log.info(pfProtectionPeriodEntity.getProtectionPeriod()+"天保护期正常");
        }
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_retail_single");
        logger.info("计费侧，购买零售1年专业版，校验成功");
    }

    /**
     * 线上购买-微商城1年专业版班，20000额度，6800元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceWSCProfessional(Long kdt_id) {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "20000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(2));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"software_meal");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "20000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(1),"计费侧数据resource_mode=1失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");


        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "20000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(2));

        // 3各表的expire_time
        Date fee_resource_packageExpireTime = fc_fee_resource_package.getExpireTime();//
        Date fc_fee_yop_protocol = feeYopProtocolDTO.getExpireTime();//
        Date pf_fee_expire = pfFeeResourcePackageEntity.getExpireTime();//

        // fee_resource.expire_time = pf_fee.expire_time
        Assert.assertEquals(fee_resource_packageExpireTime, pf_fee_expire);

        // 7天保护期 fc_fee_yop_protocol
        Long duration = durations(fc_fee_yop_protocol,fee_resource_packageExpireTime, ChronoUnit.DAYS);
        if(duration==Long.valueOf("7")){
            // 7天保护期
            log.info("7天保护期正常");
        }else {
            //自定义的保护期
            PfProtectionPeriodEntity pfProtectionPeriodEntity = pfProtectionPeriodMapper.selectOne(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdt_id.toString()));
            Assert.assertEquals(duration, Long.valueOf(pfProtectionPeriodEntity.getProtectionPeriod()));
            log.info(pfProtectionPeriodEntity.getProtectionPeriod()+"天保护期正常");
        }
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_wsc");

        logger.info("计费侧，购买微商城1年专业版，校验成功");
    }

    /**
     * 线上购买-微商城1年旗舰版，40000额度，26800元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceWSCUltimate(Long kdt_id)  {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "40000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(2));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"software_meal");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "40000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(1),"计费侧数据resource_mode=1失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");


        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "40000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(2));

        // 3各表的expire_time
        Date fee_resource_packageExpireTime = fc_fee_resource_package.getExpireTime();//
        Date fc_fee_yop_protocol = feeYopProtocolDTO.getExpireTime();//
        Date pf_fee_expire = pfFeeResourcePackageEntity.getExpireTime();//

        // fee_resource.expire_time = pf_fee.expire_time
        Assert.assertEquals(fee_resource_packageExpireTime, pf_fee_expire);
        // 7天保护期fc_fee_yop_protocol
        Long duration = durations(fc_fee_yop_protocol,fee_resource_packageExpireTime, ChronoUnit.DAYS);
        if(duration==Long.valueOf("7")){
            // 7天保护期
            log.info("7天保护期正常");
        }else {
            //自定义的保护期
            PfProtectionPeriodEntity pfProtectionPeriodEntity = pfProtectionPeriodMapper.selectOne(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdt_id.toString()));
            Assert.assertEquals(duration, Long.valueOf(pfProtectionPeriodEntity.getProtectionPeriod()));
            log.info(pfProtectionPeriodEntity.getProtectionPeriod()+"天保护期正常");
        }
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_wsc");

        logger.info("计费侧，购买微商城1年旗舰版，校验成功");
    }

    /**
     * 线下落单：无限额度
     * @param kdt_id
     */
    public void feeResourceNoLimitOrder(Long kdt_id)  {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "-1");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(11));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"rights_v2");

        //时间差：1年
        Date package_effect_time = pfFeeResourcePackageEntity.getEffectTime();
        Date package_expire_time = pfFeeResourcePackageEntity.getExpireTime();

        Period period = Period.between(package_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), package_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period.getYears(), 1);

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);


        Assert.assertEquals(fc_fee_resource_package.getTotal(), "-1");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(6),"计费侧数据resource_mode=6失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));

        //时间差：1年
        Date fc_fee_resource_package_effect_time = fc_fee_resource_package.getEffectTime();
        Date fc_fee_resource_package_expire_time = fc_fee_resource_package.getExpireTime();

        Long duration = durations(fc_fee_resource_package_effect_time,fc_fee_resource_package_expire_time, ChronoUnit.YEARS);
        Assert.assertEquals(duration, Long.valueOf(1));

        Period period2 = Period.between(fc_fee_resource_package_effect_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), fc_fee_resource_package_expire_time.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Assert.assertEquals(period2.getYears(), 1);

        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "-1");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(11));

        //时间差：1年
        Date feeYopProtocolDTO_effect_time = feeYopProtocolDTO.getEffectTime();
        Date feeYopProtocolDTO_expire_time = feeYopProtocolDTO.getExpireTime();

        Long duration2 = durations(feeYopProtocolDTO_effect_time,feeYopProtocolDTO_expire_time, ChronoUnit.YEARS);

        Assert.assertEquals(duration2, Long.valueOf(1));
        getQuotaProtocolInfoCheck(kdt_id,"atom_spu_order_limit");

        logger.info("计费侧，无限额度，校验成功");
    }

    /**
     * 计费侧：fc_fee_resource_package 表数据校验
     * @param kdtId
     * @param total
     * @param used
     * @param state
     * @param diffDate //开始结束时间的年差值
     * @param diffExpireToNow // 结束时间和当前时间的年差值
     * @param resourceMode
     */
    public void fcFeeResourcePackageCheck(Long kdtId,String total,String used,Integer state,Integer diffExpireToNow,Integer diffDate,Integer resourceMode){
        // 根据kdtId至少查询1条记录
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdtId.toString())).size() >= 1L);
        // 等待状态变为1
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdtId.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == state);


        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdtId.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        // 1-校验 total
        Assert.assertEquals(fc_fee_resource_package.getTotal(),total);
        // 2-校验 used
        Assert.assertEquals(fc_fee_resource_package.getUsed(),used);
        // 3-校验 state
        Assert.assertEquals(fc_fee_resource_package.getState(),state);
        // 4-校验结束时间与当前时间的差值
        Assert.assertEquals(Integer.valueOf(diff(localDateToDate(LocalDateTime.now()),fc_fee_resource_package.getExpireTime()).getYears()), diffExpireToNow);
        // 5-校验开始/结束时间的差值
        Assert.assertEquals(Integer.valueOf(diff(fc_fee_resource_package.getEffectTime(),fc_fee_resource_package.getExpireTime()).getYears()), diffDate);
        // 6-校验 resourceMode
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),resourceMode);
        // 7-校验 feetype=1
        Assert.assertEquals(fc_fee_resource_package.getFeeType(),Integer.valueOf("1"));
    }

    /**
     * 计费侧：fc_fee_resource_package_log 表数据校验
     * @param kdtId
     * @param amount
     * @param remain
     * @param type
     */
    public void fcFeeResourcePackageLogCheck(Long kdtId,Long amount,Long remain,Integer type){
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageLogMapper.selectList(new QueryWrapper<FeeResourcePackageLogDO>().eq("kdt_id", kdtId.toString()).eq("type",type)).size() >= 1);

        FeeResourcePackageLogDO feeResourcePackageLogDO = feeResourcePackageLogMapper.selectOne(new QueryWrapper<FeeResourcePackageLogDO>().eq("kdt_id", kdtId.toString()).eq("type",type));

        // 1-校验 amount
        Assert.assertEquals(feeResourcePackageLogDO.getAmount(),amount.toString());
        // 2-校验 remain
        Assert.assertEquals(feeResourcePackageLogDO.getRemain(),remain.toString());
    }

    /**
     * 计费侧：fc_fee_yop_protocol 表数据校验
     * @param kdtId
     * @param quota
     * @param state
     * @param diffDate // 开始结束时间的差值
     * @param diffExpireToNow //校验结束时间与当前的差值(年)
     * @param quotaType
     */
    public void fcFeeYopProtocolCheck(Long kdtId,String quota,Integer state,Integer diffExpireToNow,Integer diffDate,Integer quotaType){
        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdtId.toString()).orderByDesc("created_at").last("limit 1")).get(0).getState() == 1);

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdtId.toString()).orderByDesc("created_at").last("limit 1")).get(0);

        // 1-校验 quota
        Assert.assertEquals(feeYopProtocolDTO.getQuota(),quota);
        // 2-校验 state
        Assert.assertEquals(feeYopProtocolDTO.getState(),state);
        // 3-校验结束时间与当前时间的差值
        Assert.assertEquals(Integer.valueOf(diff(localDateToDate(LocalDateTime.now()),feeYopProtocolDTO.getExpireTime()).getYears()), diffExpireToNow);
        // 4-校验开始/结束时间的差值
        Assert.assertEquals(Integer.valueOf(diff(feeYopProtocolDTO.getEffectTime(),feeYopProtocolDTO.getExpireTime()).getYears()), diffDate);
        // 5-校验 quotaType
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(),quotaType);

    }

    /**
     * 日期时间比较
     * @param source
     * @param target
     * @return
     */
    public Period diff(Date source,Date target){
        logger.info("现在时间="+source);
        logger.info("过期时间="+target);
        return Period.between(source.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), target.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
    }

    private static Period diffw(Date source,Date target){
        logger.info("现在时间="+source);
        logger.info("过期时间="+target);
        Period be = Period.between(source.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), target.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        return be;
    }

    public static void main(String[] args) {
        diffw(new Date("Thu Jan 01 00:00:00 CST 1970"),new Date("Mon Mar 20 07:01:13 CST 2023"));
    }
    /**
     * LocalDateTime-->Date 转换
     * @param source
     * @return
     */
    public Date localDateToDate(LocalDateTime source){
        ZoneId zone = ZoneId.systemDefault();
        Instant instant = source.atZone(zone).toInstant();
        Date date = Date.from(instant);
        return date;
    }

    /**
     * 商业化侧：pf_fee_resource_package 表数据校验
     * @param apply_ycm_id
     * @param grantQuota
     * @param state
     * @param diffDate // 开始结束时间的差值
     * @param diffExpireToNow //校验结束时间与当前的差值(年)
     * @param quotaType
     * @param appCategory
     */
    public void pfFeeResourcePackageCheck(Long apply_ycm_id,String grantQuota,Integer state,Integer diffExpireToNow,Integer diffDate,Integer quotaType,String appCategory) {
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", apply_ycm_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity  = pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().lambda().eq(PfFeeResourcePackageEntity::getApplyYcmId, apply_ycm_id.toString())
                .orderByDesc(PfFeeResourcePackageEntity::getCreatedAt).last("limit 1")).get(0);

        // 1-校验 grantQuota
        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota(),grantQuota);
        // 2-校验 state
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(),state);
        // 3-校验结束时间与当前时间的差值
        Assert.assertEquals(Integer.valueOf(diff(localDateToDate(LocalDateTime.now()),pfFeeResourcePackageEntity.getExpireTime()).getYears()), diffExpireToNow);
        // 4-校验开始/结束时间的差值
        Assert.assertEquals(Integer.valueOf(diff(pfFeeResourcePackageEntity.getEffectTime(),pfFeeResourcePackageEntity.getExpireTime()).getYears()), diffDate);
        // 5-校验 quotaType
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),quotaType);
        // 6-校验 appCategory
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),appCategory);
    }


    /**
     * 校验退款，云服务费相关表的state都为0
     * @param apply_ycm_id
     */
    public void yunFeeRefundStateCheck(Long apply_ycm_id){
        //pf_fee_resource_package表记录确保数据存在
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", apply_ycm_id.toString())).size() >= 1L);


        List<PfFeeResourcePackageEntity> pfFeeResourcePackageEntities= pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().lambda().eq(PfFeeResourcePackageEntity::getApplyYcmId, apply_ycm_id.toString())
                .eq(PfFeeResourcePackageEntity::getState,1));

        List<FeeYopProtocolDTO> feeYopProtocolDTOS = feeYopProtocolMapper.selectList(new QueryWrapper<FeeYopProtocolDTO>().lambda().eq(FeeYopProtocolDTO::getKdtId, apply_ycm_id.toString()).eq(FeeYopProtocolDTO::getState,1));

        List<FeeResourcePackageDO> feeResourcePackageDOS = feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().lambda().eq(FeeResourcePackageDO::getKdtId, apply_ycm_id.toString()).eq(FeeResourcePackageDO::getState,1));


        // 校验其他三表的状态都为0:状态为1的记录为0
        Assert.assertEquals(pfFeeResourcePackageEntities.size(),0);
        Assert.assertEquals(feeYopProtocolDTOS.size(),0);
        Assert.assertEquals(feeResourcePackageDOS.size(),0);
    }

    /**
     * 根据订单号，返回订单额度的pf_order，pr_order_detial ID
     * @param tdOrderId
     * @return
     */
    public Map<String,String> yunFeeOrderQuotaWithTdOrder(String tdOrderId){
        return null;
    }

//  获取某个店铺某个应用的最大过期时间
    public Date getMaxExpiredTime(Long kdtId, String appId) {
        List<String> bizOrderIds = tdOrderMapper.selectList(new QueryWrapper<TdOrder>().eq("buyer_id", kdtId.toString())).stream()
                .map(TdOrder::getTdNo).collect(Collectors.toList());
        List<Date> expiredTimes = new ArrayList<>();
        if (bizOrderIds.size() > 0) {
            for (String bizOrderId : bizOrderIds) {
                List<Long> pfOrderIds = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", bizOrderId))
                        .stream().map(PfOrder::getId).collect(Collectors.toList());
                if (pfOrderIds.size() > 0) {
                    for (long pfOrderId : pfOrderIds) {
                        Wrapper<PfOrderStatus> queryWrapper = new QueryWrapper<PfOrderStatus>()
                                .eq("pf_order_id", pfOrderId)
                                .eq("apply_ycm_id", kdtId)
                                .eq("apply_ycm_type", "KDT_ID")
                                .eq("app_id", appId)
                                .eq("group_type", "product_with_paid");
                        List<Date> expiredTime1 = pfOrderStatusMapper.selectList(queryWrapper).stream()
                                .map(PfOrderStatus::getExpireTime).collect(Collectors.toList());
                        expiredTimes.addAll(expiredTime1);
                    }
                }
            }
        }
        Date maxExpiredTime = new Date();
        if (CollectionUtils.isNotEmpty(expiredTimes)) {
            maxExpiredTime = Collections.max(expiredTimes);
        }
        if (CollectionUtils.isEmpty(expiredTimes)) {
            maxExpiredTime = null;
        }
        return maxExpiredTime;
    }


//  审批流数据校验
    public void  queryCrmOrderByCrmApprovalNo(String crmApprovalNo,boolean t,String state,List<String> appIds,String tradeState,int flag){
        //  审批流数据校验
        try {
            sleep(15000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        List<CrmOrder> crmOrders = crmOrderMapper .selectList(new QueryWrapper<CrmOrder>().eq("crm_approval_no", crmApprovalNo))
                .stream().collect(Collectors.toList());
        boolean isCrmOrder  = (crmOrders.size() == 0);
        Assert.assertEquals(isCrmOrder, t);
        List<TdOrder> tdOrders = tdOrderMapper .selectList(new QueryWrapper<TdOrder>().eq("crm_approval_no", crmApprovalNo))
                .stream().collect(Collectors.toList());
        List<String> tdNoList = tdOrders.stream().filter(tradeOrderDO -> "YOUZAN".equals(tradeOrderDO.getChannel())).map(TdOrder::getTdNo).collect(Collectors.toList());
        for(String tdNo:tdNoList) {
            Assert.assertEquals(tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("td_no", tdNo)).getState(), state);
            List<PfOrder> pfOrderDOs =
                    pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdNo));
            List<String> pfOrderAppIdList = pfOrderDOs.stream().map(PfOrder::getAppId).collect(Collectors.toList());
            Assert.assertTrue(pfOrderAppIdList.containsAll(appIds));
            for(PfOrder pfOrder:pfOrderDOs) {
                Assert.assertEquals(pfOrder.getTradeState(), tradeState);
            }
            List<PfOrder> pfOrderPerformeds = pfOrderDOs.stream().filter(pfOrder -> "performed".equals(pfOrder.getPerformState())).collect(Collectors.toList());
            //  是否是延期激活，1为延期激活
            if(flag ==1){
                Assert.assertTrue(pfOrderPerformeds.size()==0);
            }else{
                Assert.assertTrue(pfOrderPerformeds.size()>0);
            }

            for(PfOrder pfOrder:pfOrderPerformeds) {
                int m = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().eq("pf_order_id",pfOrder.getId())).stream().collect(Collectors.toList()).size();
                Assert.assertTrue(m >0);

            }
        }

    }


//   删除审批流下的全部数据
    /**
     * @param crmApprovalNo
     * @desc 删除一个审批流下的全部数据
     */
    public void deleteTestDataYcmByCrmApprovalNo(String crmApprovalNo) {
        //  交易信息
        List<TdOrder> tradeOrderDOs = tdOrderMapper.selectList(new QueryWrapper<TdOrder>().eq("crm_approval_no", crmApprovalNo));
        List<String> tdNoList = tradeOrderDOs.stream().filter(tradeOrderDO -> "YOUZAN".equals(tradeOrderDO.getChannel())).map(TdOrder::getTdNo).collect(Collectors.toList());
        List<String> kdtIds = tradeOrderDOs.stream().map(TdOrder::getBuyerId).collect(Collectors.toList());
        List<TdOrderItem> tradeOrderItemList = new ArrayList<>();
        if (isNotEmpty(tdNoList)) {
            for (String tdNo : tdNoList) {
                //  正向
                tdOrderMapper.delete(new QueryWrapper<TdOrder>().eq("td_no", tdNo));
                tdSettleOrderMapper.delete(new QueryWrapper<TdSettleOrder>().eq("td_no", tdNo));
                //            pfOrderMapper.delete(new QueryWrapper<PfOrder>().eq("biz_order_id", tdNo));
                tdPayOrderMapper.delete(new QueryWrapper<TdPayOrder>().eq("td_no", tdNo));
                //  解决td_order_item删不干净的问题==
                do{
                    tdOrderItemMapper.delete(new QueryWrapper<TdOrderItem>().eq("td_no", tdNo));
                    tradeOrderItemList = tdOrderItemMapper.selectList(new QueryWrapper<TdOrderItem>().eq("td_no", tdNo));
                }while(tradeOrderItemList.size()>0);
                //  逆向
                payRefundOrderMapper.delete(new QueryWrapper<PayRefundOrder>().eq("td_no", tdNo));
                orderItemRefundOrderMapper.delete(
                        new QueryWrapper<OrderItemRefundOrder>().eq("td_no", tdNo));
                // 营销参与记录
                promotionResultDetailMapper.delete(
                        new QueryWrapper<PromotionResultDetail>().eq("td_no", tdNo));
                presentRecordMapper.delete(new QueryWrapper<PresentRecord>().eq("td_no", tdNo));
                // 抵扣升级
                deductionResultDetailMapper.delete(
                        new QueryWrapper<DeductionResultDetail>().eq("td_no", tdNo));
                deductionResultCompositionMapper.delete(
                        new QueryWrapper<DeductionResultComposition>().eq("trade_no", tdNo));
                joinRecordMapper.delete(new QueryWrapper<MkJoinRecord>().eq("biz_order_id", tdNo));
            }
        }
            if (isNotEmpty(kdtIds)) {
                for (String kdtId : kdtIds) {
                    //  营销信息
                    List<GiftAsset> gfAssetDOs =
                            gfAssetMapper.selectList(new QueryWrapper<GiftAsset>().eq("owner_ycmid", String.valueOf(kdtId)));
                    List<Long> gfAssetIdList =
                            gfAssetDOs.stream().map(GiftAsset::getId).collect(Collectors.toList());
                    if (org.apache.commons.collections.CollectionUtils.isNotEmpty(gfAssetIdList)) {
                        gfAssetMapper.deleteBatchIds(gfAssetIdList);
                        for (long gfAssetId : gfAssetIdList) {
                            gfAssetGoodsMapper.delete(new QueryWrapper<GiftAssetGoods>().eq("asset_id", gfAssetId));
                        }
                    }

                    //  履约信息
                    List<PfOrder> pfOrderDOs =
                            pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("buy_kdt_id",String.valueOf(kdtId)));
                    List<Long> pfOrderIdList = pfOrderDOs.stream().map(PfOrder::getId).collect(Collectors.toList());
                    if (org.apache.commons.collections.CollectionUtils.isNotEmpty(pfOrderIdList)) {
                        pfOrderMapper.deleteBatchIds(pfOrderIdList);
                        List<Long> totalPfAssetIds = new LinkedList<>();
                        for (Long pfOrderId : pfOrderIdList) {
                            List<PfAsset> pfAssetDOList =
                                    pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("pf_order_id", pfOrderId));
                            totalPfAssetIds.addAll(
                                    pfAssetDOList.stream().map(PfAsset::getId).collect(Collectors.toList()));
                        }
                        if (org.apache.commons.collections.CollectionUtils.isNotEmpty(totalPfAssetIds)) {
                            pfAssetMapper.deleteBatchIds(totalPfAssetIds);
                            for (long pfAssertId : totalPfAssetIds) {
                                pfAssetDeductionMapper.delete(
                                        new QueryWrapper<PfAssetDeduction>().eq("pf_asset_id", pfAssertId));
                            }
                        }
                        // 服务期和库存
                        for (Long pfOrderId : pfOrderIdList) {
                            pfOrderDetailMapper.delete(new QueryWrapper<PfOrderDetail>().eq("pf_order_id", pfOrderId));
                        }
                        pfOrderStatusMapper.delete(
                                new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", String.valueOf(kdtId)));
                        pfStockMapper.delete(new QueryWrapper<PfStock>().eq("apply_kdt_id", kdtId));
                        pfOrderStockMapper.delete(
                                new QueryWrapper<PfOrderStock>().eq("buy_kdt_id", String.valueOf(kdtId)));
                        // 延期激活记录表
                        pfOrderDetailActiveRecordMapper.delete(
                                new QueryWrapper<PfOrderDetailActiveRecord>().eq("buy_kdt_id", String.valueOf(kdtId)));
                        // 库存自动充值
                        pfRechargeConfigMapper.delete(
                                new QueryWrapper<PfRechargeConfig>().eq("apply_kdt_id",String.valueOf(kdtId)));
                        // 方案
                        pfSchemeMapper.delete(new QueryWrapper<PfScheme>().eq("owner_id", String.valueOf(kdtId)));
                        for (Long pfOrderId : pfOrderIdList) {
                            pfSchemeOrderRelationMapper.delete(
                                    new QueryWrapper<PfSchemeOrderRelation>().eq("order_id", pfOrderId));
                        }
                        //pf_fee_resource_package表
                        pfFeeResourcePackageMapper.delete(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", String.valueOf(kdtId)));
                        //feeResourcePackageLogMapper
                        feeResourcePackageLogMapper.delete(new QueryWrapper<FeeResourcePackageLogDO>().lambda().eq(FeeResourcePackageLogDO::getKdtId, kdtId));
                    }
                    //pf_fee_resource_package表
                    pfFeeResourcePackageMapper.delete(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", String.valueOf(kdtId)));
                    //feeResourcePackageLogMapper
                    feeResourcePackageLogMapper.delete(new QueryWrapper<FeeResourcePackageLogDO>().lambda().eq(FeeResourcePackageLogDO::getKdtId, kdtId));
                    //cd_redeem_code_apply_record
                    cdRedeemCodeApplyRecordMapper.delete(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getApplyYcmId, kdtId));
                    //td_activation_code_apply_record
                    tdActivationCodeApplyRecordMapper.delete(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getApplyYcmId, kdtId));
                    logger.info("该审批流有kdtid,测试数据清理完毕");
                }
            }else{
                logger.info("该审批流无kdtid,测试数据清理完毕");
            }
        //  删除crm_order 数据
        crmOrderMapper.delete(new QueryWrapper<CrmOrder>().eq("crm_approval_no",crmApprovalNo));
        //  删除td_order 数据
        tdOrderMapper.delete(new QueryWrapper<TdOrder>().eq("crm_approval_no",crmApprovalNo));
        //  删除pf_order 数据
        pfOrderMapper.delete(new QueryWrapper<PfOrder>().eq("crm_approval_no",crmApprovalNo));

    }

}