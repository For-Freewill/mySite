package com.youzan.test.basecase.msgPush;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.platform.courier.common.MsgChannel;
import com.youzan.platform.push.api.pushMsg.PushMsgService;
import com.youzan.platform.push.api.stock.MsgSmsStockService;
import com.youzan.platform.push.api.stock.dto.StockDecResultDTO;
import com.youzan.platform.push.api.stock.dto.StockDecreaseDTO;
import com.youzan.platform.push.api.stock.dto.StockInfoDTO;
import com.youzan.platform.push.api.stock.dto.StockQueryDTO;
import com.youzan.platform.push.domain.Recipient;
import com.youzan.platform.push.domain.push.SmsTaskType;
import com.youzan.platform.push.domain.pushMsg.MessageContext;
import com.youzan.platform.push.domain.pushMsg.PushParams;
import com.youzan.platform.push.domain.pushMsg.SmsParams;
import com.youzan.platform.push.request.pushMsg.PushMsgRequest;
import com.youzan.test.basecase.SimpleToolBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.StockRemoteService;
import com.youzan.yop.api.entity.ChangeStockParam;
import com.youzan.yop.api.entity.dto.Item;
import com.youzan.yop.api.form.order.AutoBuyMsgOrderForm;
import com.youzan.yop.api.response.AutoBuyMsgResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.*;

/**
 * @author leifeiyun
 * @date 2021/2/19
 **/
public class MsgPushTest extends SimpleToolBaseTest {
    @Dubbo
    PushMsgService pushMsgService;
    @Dubbo
    MsgSmsStockService msgSmsStockService;
    @Dubbo
    StockRemoteService stockRemoteService;

    @Autowired(required = false)
    TdOrderMapper tdOrderMapper;

    Long kdtId=58802092L;
    @Test(enabled = false)
    public void test(){
        PushMsgRequest pushMsgRequest = new PushMsgRequest();
        List<Recipient> recipients = new ArrayList<>();
        MessageContext messageContext = new MessageContext();
        PushParams pushParams = new PushParams();
        SmsParams smsParams = new SmsParams();

        messageContext.setTemplateName("umpLuckyMoneyEnd");
        Map<String, String> param = new HashMap<>();
        param.put("link", "1111");
        messageContext.setTemplateParamMap(param);

        recipients.add(Recipient.builder().receiver("15988140519").msgChannel(MsgChannel.sms).build());

        smsParams.setSmsTaskType(SmsTaskType.marketing);

        pushParams.setSmsParams(smsParams);
        pushParams.setKdtId(kdtId);
        pushParams.setIsFree(false);
        pushParams.setIsStatistic(false);
        pushParams.setBusinessName("test");

        pushMsgRequest.setMessageContext(messageContext);
        pushMsgRequest.setRecipientList(recipients);
        pushMsgRequest.setPushParams(pushParams);
        pushMsgService.sendMessage(pushMsgRequest);
    }

    /**
     * 业务方短信扣减并触发自动充值(业务方维护，本次仅做接口测试)
     */
    @Test(enabled = false)
    public void testDecreaseStockPushMsg(){
        List<Long> kdtIds = Arrays.asList(59502872L);
        for(Long kdtId : kdtIds){
            StockDecreaseDTO stockDecreaseDTO = new StockDecreaseDTO();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            stockDecreaseDTO.setSerialNo(generate23Sequence());
            stockDecreaseDTO.setDecReason("lfy_test");
            stockDecreaseDTO.setKdtId(kdtId);
            stockDecreaseDTO.setStock(5960L);
            PlainResult<StockDecResultDTO> decreaseResult = msgSmsStockService.decrease(stockDecreaseDTO);
            decreaseResult.getData();
            StockQueryDTO stockQueryDTO = new StockQueryDTO();
            stockQueryDTO.setKdtId(kdtId);
            PlainResult<StockInfoDTO>  result = msgSmsStockService.getStock(stockQueryDTO);
        }


    }

    /**
     * 商业化短信扣减并触发自动充值,迁移之后，不再有流量进来
     */
    @Test(enabled = false)
    public void testDecreaseStockYop(){
        List<Long> kdtIds = Arrays.asList(58821434L);
        for(Long kdtId : kdtIds){
            ChangeStockParam changeStockParam = new ChangeStockParam();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            changeStockParam.setKdtId(kdtId);
            changeStockParam.setNum(1);
            changeStockParam.setBizNo(generate23Sequence());
            changeStockParam.setBizName("yop");
            changeStockParam.setAppId(9638);
            changeStockParam.setChangeStockType("tradeSend");
            PlainResult<Boolean> result1= stockRemoteService.decreaseStock(changeStockParam);
            logger.info(""+result1);
            StockQueryDTO stockQueryDTO = new StockQueryDTO();
            stockQueryDTO.setKdtId(kdtId);
            PlainResult<StockInfoDTO>  result = msgSmsStockService.getStock(stockQueryDTO);
        }


    }


}
