package com.youzan.test.apicase.yop.stockRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.StockRemoteService;
import com.youzan.yop.api.enums.StockApp;
import com.youzan.yop.api.request.StockApi;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by baoyan on 2021-01-05.
 */
public class GetStockTest extends YunBaseTest {
    @Dubbo
    StockRemoteService stockRemoteService;

    @Test
    public void getStockNormalTest(){
        StockApi stockApi = new StockApi();
        stockApi.setKdtId(kdtIdForQuery);
        stockApi.setAppId(9638);
        stockApi.setStockApp(StockApp.MESSAGE_APP);
        PlainResult<Integer> result = stockRemoteService.getStock(stockApi);
        logger.info(result.toString());
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getData().intValue(),1000);
    }

    @Test
    public void getStockWithOutKdtIdTest(){
        StockApi stockApi = new StockApi();
        stockApi.setKdtId(null);
        stockApi.setAppId(9638);
        stockApi.setStockApp(StockApp.MESSAGE_APP);
        PlainResult<Integer> result = stockRemoteService.getStock(stockApi);
        logger.info(result.toString());
        Assert.assertEquals(result.getCode(),130102);
    }

    @Test
    public void getStockWithOutAppIdTest(){
        StockApi stockApi = new StockApi();
        stockApi.setKdtId(kdtIdForQuery);
        stockApi.setAppId(null);
        stockApi.setStockApp(StockApp.MESSAGE_APP);
        PlainResult<Integer> result = stockRemoteService.getStock(stockApi);
        logger.info(result.toString());
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getData().intValue(),1000);
    }

    @Test
    public void getStockWithOutStockAppTest(){
        StockApi stockApi = new StockApi();
        stockApi.setKdtId(kdtIdForQuery);
        stockApi.setAppId(9638);
        stockApi.setStockApp(null);
        PlainResult<Integer> result = stockRemoteService.getStock(stockApi);
        logger.info(result.toString());
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getData().intValue(),1000);
    }
}
