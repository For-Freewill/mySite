package com.youzan.test.concurrent;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.enums.market.coupon.CouponAssetStateEnum;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.CouponAssetRemoteService;
import com.youzan.ycm.market.constant.YcmIDTypeConstant;
import com.youzan.ycm.market.request.couponasset.ReceiveCouponAssetRequest;
import com.youzan.ycm.market.request.couponasset.SaveCouponAssetRequest;
import com.youzan.ycm.market.response.couponasset.ReceiveCouponAssetResponse;
import com.youzan.ycm.market.response.couponasset.SaveCouponAssetResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * 并发领取券资产
 *
 * @author leifeiyun
 * @date 2021/1/6
 **/
public class TestReceiveCouponAssetConcurrent extends ConcurrentBaseTest {

    @Dubbo
    CouponAssetRemoteService couponAssetRemoteService;


    @DataProvider(parallel = true,name="saveCouponAssetData")
    public Object[][] datas() {
       Object[][] objects = new Object[][]{
               {"58112202","170023"}
       };
       return objects;
    }

    @Test(threadPoolSize=5, invocationCount=10,dataProvider = "saveCouponAssetData")
    public void testReceiveCouponAssetConcurrent(String kdtId,String couponId){

        ReceiveCouponAssetRequest request = new ReceiveCouponAssetRequest();
        request.setCouponAssetId(couponId);
        request.setKdtId(kdtId);

        PlainResult<ReceiveCouponAssetResponse> result =  couponAssetRemoteService.receiveCouponAsset(request);
        logger.info("ReceiveCouponAssetResponse --》：" + JSON.toJSONString(result));

    }
}
