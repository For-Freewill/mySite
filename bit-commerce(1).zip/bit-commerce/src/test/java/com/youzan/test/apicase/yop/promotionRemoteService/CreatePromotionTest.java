package com.youzan.test.apicase.yop.promotionRemoteService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.form.PromotionForm;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-01-13 14:54
 * 创建优惠活动
 **/

public class CreatePromotionTest extends TnBaseTest {

    @JSONData(value = "dataResource/apicase/yop/CreatePromotionRequestData.json", key = "createPromotion")
    private PromotionForm createPromotion;

    @JSONData(value = "dataResource/apicase/yop/CreatePromotionRequestData.json", key = "createPromotionException")
    private PromotionForm createPromotionException;


    @BeforeMethod
    public void beforeMethod() {
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        deletePresentActivityData();
    }

    /**
     * 正常用例
     * 买赠礼包  微商城2021基础版  多选一  礼包  全网生效
     */
    @Test
    public void createPromotionNormalTest() {
        try {
            PlainResult<Long> createPromotionResult = promotionRemoteService.createPromotion(createPromotion);

            try {
                sleep(3000);
            } catch (Throwable e) {
                e.getMessage();
            }

            Assert.assertEquals(createPromotionResult.getCode(), 200);

            //查数据库
            List<MkActivity> mkActivityList =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, "买赠活动田宁专用-勿动"));
            Assert.assertTrue(mkActivityList.size() > 0);
            mkActivityList.forEach(item->{
                Assert.assertEquals(item.getState(), "AUDITED_PASS");
                Assert.assertEquals(item.getActivityType(), "G_PRESENT");
                Assert.assertEquals(item.getIs_delete(),0);
            });

        } finally {
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }

    /**
     * 异常用例--入参为null
     */
    @Test
    public void createPromotionRequestNullTest() {
        try {
            PlainResult<Long> createPromotionResult = promotionRemoteService.createPromotion(null);
            Assert.assertEquals(createPromotionResult.getCode(), 130501);
        } finally {
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }

    /**
     * 异常用例--appid为null
     */
    @Test
    public void createPromotionappidNullTest() {
        try {
            PlainResult<Long> createPromotionResult = promotionRemoteService.createPromotion(createPromotionException);
            Assert.assertEquals(createPromotionResult.getCode(), 130501);
            Assert.assertEquals(createPromotionResult.getMessage(), "系统错误");
        } finally {
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }
}

