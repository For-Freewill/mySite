package com.youzan.test.apicase.ycmJob.JobService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.apicase.ycmJob.JobBaseTest;
import com.youzan.ycm.job.request.JobStatisticQueryByBizRequest;
import com.youzan.ycm.job.response.JobStatisticQueryByBizResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @program: bit-commerce
 * @description 任务进度查询
 * @author: tianning
 * @create: 2021-04-14 16:52
 **/

public class QueryJobStatisticByBizTest extends JobBaseForQueryJobTest {

    /**
     * 任务进度查询
     */
    @Test
    public void queryJobStatisticByBizTest() {
        try {
            deleteJob();
            JobStatisticQueryByBizRequest jobRegisterRequest = new JobStatisticQueryByBizRequest();
            jobRegisterRequest.setJobName(jobName);
            jobRegisterRequest.setApplicationName(applicationName);

            String bizNo = registerJobForQueryJobTest();
            jobRegisterRequest.setBizNo(bizNo);

            PlainResult<JobStatisticQueryByBizResponse> queryJobStatisticByBizResult = jobService.queryJobStatisticByBiz(jobRegisterRequest);
            Assert.assertEquals(queryJobStatisticByBizResult.getCode(), 200);
            Assert.assertTrue(com.baomidou.mybatisplus.core.toolkit.CollectionUtils.isNotEmpty(queryJobStatisticByBizResult.getData().getJobStatisticDTOS()));
            Assert.assertEquals(queryJobStatisticByBizResult.getData().getJobStatisticDTOS().get(0).getJobState(), "DOING");
            Assert.assertEquals(queryJobStatisticByBizResult.getData().getJobStatisticDTOS().get(0).getTaskFailCnt(), Long.valueOf(0));
        } finally {
            deleteJob();
        }
    }

    /**
     * 任务进度查询--异常场景-bizNo为null
     */
    @Test
    public void queryJobStatisticByBizBizNoNullTest() {
        try {
            deleteJob();
            JobStatisticQueryByBizRequest jobRegisterRequest = new JobStatisticQueryByBizRequest();
            jobRegisterRequest.setJobName(jobName);
            jobRegisterRequest.setApplicationName(applicationName);

            PlainResult<JobStatisticQueryByBizResponse> queryJobStatisticByBizResult = jobService.queryJobStatisticByBiz(jobRegisterRequest);
            Assert.assertEquals(queryJobStatisticByBizResult.getCode(), 1011);
            Assert.assertEquals(queryJobStatisticByBizResult.getMessage(),"bizNo不允许为空");
        } finally {
            deleteJob();
        }
    }


/**
     * 任务进度查询--异常场景-JobName为null
     */

    @Test
    public void queryJobStatisticByBizJobNameNullTest() {
        try {
            deleteJob();
            JobStatisticQueryByBizRequest jobRegisterRequest = new JobStatisticQueryByBizRequest();
            jobRegisterRequest.setJobName(null);
            jobRegisterRequest.setApplicationName(applicationName);


            String bizNo = registerJobForQueryJobTest();
            jobRegisterRequest.setBizNo(bizNo);

            PlainResult<JobStatisticQueryByBizResponse> queryJobStatisticByBizResult = jobService.queryJobStatisticByBiz(jobRegisterRequest);
            Assert.assertEquals(queryJobStatisticByBizResult.getCode(), 200);
            Assert.assertTrue(com.baomidou.mybatisplus.core.toolkit.CollectionUtils.isNotEmpty(queryJobStatisticByBizResult.getData().getJobStatisticDTOS()));
            Assert.assertEquals(queryJobStatisticByBizResult.getData().getJobStatisticDTOS().get(0).getJobState(), "DOING");
            Assert.assertEquals(queryJobStatisticByBizResult.getData().getJobStatisticDTOS().get(0).getTaskFailCnt(), Long.valueOf(0));
        } finally {
            deleteJob();
        }
    }

/**
     * 任务进度查询--异常场景-ApplicationName为null
     */

    @Test
    public void queryJobStatisticByBizApplicationNameNullTest() {
        try {
            deleteJob();
            JobStatisticQueryByBizRequest jobRegisterRequest = new JobStatisticQueryByBizRequest();
            jobRegisterRequest.setJobName(jobName);
            jobRegisterRequest.setApplicationName(null);


            String bizNo = registerJobForQueryJobTest();
            jobRegisterRequest.setBizNo(bizNo);

            PlainResult<JobStatisticQueryByBizResponse> queryJobStatisticByBizResult = jobService.queryJobStatisticByBiz(jobRegisterRequest);
            Assert.assertEquals(queryJobStatisticByBizResult.getCode(), 1011);
            Assert.assertEquals(queryJobStatisticByBizResult.getMessage(),"applicationName不允许为空");
        } finally {
            deleteJob();
        }
    }
}
