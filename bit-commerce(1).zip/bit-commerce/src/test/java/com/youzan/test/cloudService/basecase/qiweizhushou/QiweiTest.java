package com.youzan.test.cloudService.basecase.qiweizhushou;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.BasicQueryRemoteServiceV2;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.form.basic.PurchasablePluginFetchForm;
import com.youzan.yop.api.response.CreateOfflineOrderResponse;
import com.youzan.yop.api.response.PurchasablePluginApi;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;

/**
 * @author wulei
 * @date 2021-05-17
 */
public class QiweiTest extends YunBaseTest {
     //企微助手-系列case：线上订购使用的是老接口：com.youzan.yop.api.OrderRemoteService#createOrder
    @Dubbo
    public BasicQueryRemoteServiceV2 basicQueryRemoteServiceV2;

    //吴磊的企微助手测试8-BY:线下订购-员工账号-1年人
    @Test
    public void A1OffLineYuanGongAccountTest() {
        Long kdt = 59506216L;
        QiWeiOfflineOrderAccountScene(kdt,73730,1L);
    }

    //吴磊的企微助手测试7-七步:线下订购-企微助手-基础版
    @Test
    public void A2OffLineQiWeiBasicTest() {
        Long kdt = 59500113L;
        QiWeiOfflineOrderScene(kdt,73687,2L);
    }

    //吴磊的企微助手测试5-9526:线下订购-企微助手-专业版
    @Test
    public void A3OffLineQiWeiProTest() {
        Long kdt = 59500106L;
        QiWeiOfflineOrderScene(kdt,73688,2L);
    }

    //吴磊的企微助手测试4-行川手机:线上订购-企微助手-基础版
    @Test
    public void A4OnLineQiWeiBasicTest() {
        Long kdt = 59500100L;
        QiWeiOnlineOrderScene(kdt,73687,1,2L);
    }

    //吴磊的企微助手测试4-行川手机:线上订购-企微助手-专业版
    @Test
    public void A5OnLineQiQeiProTest() {
        Long kdt = 59500100L;
        QiWeiOnlineOrderScene(kdt,73688,1,2L);
    }

    //吴磊的企微助手测试4-行川手机:线上订购-企微助手-员工账号（1年）
    @Test
    public void A6OnLineAccountTest() {
        Long kdt = 59500100L;
        QiWeiOnlineOrderScene(kdt,73730,1,1L);
    }

    //吴磊的企业微信测试3-1513:线上订购-企微助手-4年基础
    @Test
    public void A7OnLineAccountTest() {
        Long kdt = 59500100L;
        godBlessU(kdt);
        // 1年基础
        PlainResult<Long> result = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",73687, 1);
        Assert.assertEquals(200, result.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() >=4L );
        // 2年基础
        PlainResult<Long> result2 = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",73687, 1);
        Assert.assertEquals(200, result2.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() >=6L );

        // 3年基础
        PlainResult<Long> result3 = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",73687, 1);
        Assert.assertEquals(200, result3.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() >=8L );

        // 4年基础
        PlainResult<Long> result4 = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",73687, 1);
        Assert.assertEquals(200, result4.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() >=10L );
    }

    //吴磊的企微助手测试4-行川手机:推荐插件
    @Test
    public void A8OnLineFetchTest() {
        Long kdt = 59500100L;
        godBlessU(kdt);
        PurchasablePluginFetchForm purchasablePluginFetchForm = new PurchasablePluginFetchForm();
        purchasablePluginFetchForm.setKdtId(kdt);
        purchasablePluginFetchForm.setAppId(445207);
        purchasablePluginFetchForm.setItemId(73688);
        PlainResult<PurchasablePluginApi> result = basicQueryRemoteServiceV2.fetchPurchasablePluginList(purchasablePluginFetchForm);
        Assert.assertEquals(200, result.getCode());

        PlainResult<OrderCreateApi> result3 = testCreateOrder(kdt, "企微助手CI自动化-线上订购",73687, 1);
        Assert.assertEquals(200, result3.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() ==2L );

        PlainResult<PurchasablePluginApi> result2 = basicQueryRemoteServiceV2.fetchPurchasablePluginList(purchasablePluginFetchForm);
        Assert.assertEquals(200, result2.getCode());
    }

    //吴磊企业微信测试2-2736:线上订购-企微助手-1年基础，1年专业，抵扣升级
    @Test
    public void A9OnLineAccountTest() {
        Long kdt = 59500100L;
        godBlessU(kdt);
        // 1年基础
        PlainResult<Long> result = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",73687, 1);
        Assert.assertEquals(200, result.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() >=4L );

        // 1年专业
        PlainResult<Long> result5 = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",73688, 1);
        Assert.assertEquals(200, result5.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString()).eq(PfOrderStatus::getState,"valid").eq(PfOrderStatus::getGroupType,"convert_product_with_present").eq(PfOrderStatus::getLevel,"profession")).size() ==2L );
    }

    //吴磊企业微信测试2-2736:线下订购-企微助手-1年基础，1年专业，高版本先生效
    @Test
    public void A10OnLineProFirstTest() {
        Long kdt = 59441204L;
        // 1年基础
        QiWeiOfflineOrderScene(kdt,73687,2L);
        // 1年专业
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 73688, 1, 50000);
        Assert.assertEquals(200, result1.getCode());
        with().atMost(60, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() ==6L );
        // 校验专业版
        Map<String,String> allMap = new HashMap<>();
        allMap.put("buy_ycm_id",kdt.toString());
        allMap.put("app_name","企业微信助手");

        with().atMost(60, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().allEq(allMap).lambda().orderByDesc(PfOrderStatus::getEffectTime)).size() ==3L );

        pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().allEq(allMap).lambda().orderByDesc(PfOrderStatus::getEffectTime)).get(2).getLevel().equals("basic");
  }

    //吴磊的企业微信测试:线上订购-企微助手-专业版，基础版，高续低
    @Test
    public void A11OnLineProWithBasicTest() {
        Long kdt = 59430437L;
        // 1年专业
        QiWeiOnlineOrderScene(kdt,73688,1,2L);
        // 1年基础
        PlainResult<Long> result4 = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",73687, 1);
        Assert.assertEquals(200, result4.getCode());

        // 校验专业版
        Map<String,String> allMap = new HashMap<>();
        allMap.put("buy_ycm_id",kdt.toString());
        allMap.put("app_name","企业微信助手");

        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().allEq(allMap).lambda().orderByDesc(PfOrderStatus::getEffectTime)).size() ==3L );

        pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().allEq(allMap).lambda().orderByDesc(PfOrderStatus::getEffectTime)).get(0).getLevel().equals("profession");

    }

    /**
     * 企微助手-线下订购
     */
    private void QiWeiOfflineOrderScene(Long kdt,int itemId,Long size){
        godBlessU(kdt);
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, itemId, 1, 50000);
        Assert.assertEquals(200, result1.getCode());
        with().atMost(60, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() ==size );
    }

    /**
     * 企微助手-线下订购-员工账号
     */
    private void QiWeiOfflineOrderAccountScene(Long kdt,int itemId,Long size){
        godBlessU(kdt);
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, itemId, 1, 50000);
        Assert.assertEquals(200, result1.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> tdOrderMapper.selectList(new QueryWrapper<TdOrder>().lambda().eq(TdOrder::getBuyerId, kdt.toString())).size() ==size );
    }


    /**
     * 企微助手-线上订购
     */
    private void QiWeiOnlineOrderScene(Long kdt,int itemId,int quantity,Long size){
        godBlessU(kdt);
        PlainResult<Long> result4 = testCreateOrderV1(kdt, "企微助手CI自动化-线上订购",itemId, quantity);
        Assert.assertEquals(200, result4.getCode());
        with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getApplyKdtId, kdt.toString())).size() >=size );
    }
}
