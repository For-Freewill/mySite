package com.youzan.test.market.basecase.gift;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplate;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.gift.request.CreatePresentAssetRequest;
import com.youzan.ycm.gift.request.ReceiveGiftAssetRequest;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.CreatePresentGiftAssetResponse;
import com.youzan.ycm.gift.response.ReceiveGiftAssetResponse;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import com.youzan.ycm.perform.api.PfRefundRemoteService;
import com.youzan.ycm.perform.request.refund.RecycleGiftAssetWithOrderRequest;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2021/4/25 3:19 下午
 * 礼包四部曲：
 * biz后台礼包发放买赠礼包接口
 * 1、创建礼包模板：com.youzan.ycm.gift.api.GiftTemplateRemoteService#saveGiftTemplate
 * 2、发放礼包：com.youzan.ycm.gift.api.GiftAssetRemoteService#createPresentGiftAsset* 3、领取礼包：com.youzan.ycm.gift.api.GiftAssetRemoteService#receiveGiftAsset(发放礼包是手动领取的情况下)
 * 3、领取礼包：com.youzan.ycm.gift.api.GiftAssetRemoteService#receiveGiftAsset(发放礼包是手动领取的情况下)
 * 4、回收礼包：com.youzan.ycm.perform.api.PfRefundRemoteService#recycleGiftAssetWithOrder  （biz后台退款页面回收接口）
 */

public class RecycleGiftByHandTest extends TnBaseTest {

    @Dubbo
    public PfRefundRemoteService pfRefundRemoteService;

    @JSONData(value = "dataResource/basecase.gift/CreatePresentGiftRequestData.json", key = "createPresentGiftTemplateRequest")
    private SaveGiftTemplateRequest createPresentGiftTemplateRequest;

    /**
     * 创建买赠礼包  发放买赠礼包  不领取的情况下biz后台退款页面直接回收买赠礼包
     */
    @Test(enabled = false)
    public void presentGiftWithOutReceiveTest() {
        Long template_id = null;

        try {
            PlainResult<SaveGiftTemplateResponse> createGiftAssetResult = createGiftTemplete(createPresentGiftTemplateRequest);

            Assert.assertEquals(createGiftAssetResult.getCode(), 200);

            String name = "创建买赠礼包模板";

            List<GiftTemplate> giftTemplateList =
                    gfTemplateMapper.selectList(
                            new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, name).orderByDesc(GiftTemplate::getCreated_at));
            Assert.assertTrue(giftTemplateList.size() > 0);
            Assert.assertEquals(giftTemplateList.get(0).getName(), "创建买赠礼包模板");
            Assert.assertEquals(giftTemplateList.get(0).getType(), "PRESENT_GIFT");

            template_id = createGiftAssetResult.getData().getGiftTemplateDTO().getTemplateId();

            CreatePresentAssetRequest createPresentAssetRequest = new CreatePresentAssetRequest();
            List<Long> giftTemplateId = new ArrayList<>();
            giftTemplateId.add(0, template_id);
            createPresentAssetRequest.setGiftTemplateIds(giftTemplateId);

            List<String> giftTemplateIdStr = new ArrayList<>();
            giftTemplateIdStr.add(0, template_id.toString());
            createPresentAssetRequest.setGiftTemplateIdsStr(giftTemplateIdStr);
            createPresentAssetRequest.setDays(365);
            createPresentAssetRequest.setOperator("tianning");
            createPresentAssetRequest.setReason("买赠礼包发放测试");
            createPresentAssetRequest.setReceiveGiftType("By_HAND");

            //发放礼包的条件：一定是软件才可以给发礼包：pf_order表中：biz_order_type='trade_order' perform_state = 'performed' app_category='software'
            List<PfOrder> pfOrder =
                    pfOrderMapper.selectList(
                            new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBuyKdtId, PRESENTKDTID).eq(PfOrder::getBizOrderType, "trade_order").eq(PfOrder::getPerformState, "performed").eq(PfOrder::getAppCategory, "software_meal").orderByDesc(PfOrder::getCreatedAt));
            List<String> pfOrderIdList = new ArrayList<>();
            Assert.assertTrue(pfOrder.size() > 0);

            Long pfOrderId = pfOrder.get(0).getId();

            pfOrderIdList.add(pfOrderId.toString());
            createPresentAssetRequest.setPfOrderIds(pfOrderIdList);

            PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<CreatePresentGiftAssetResponse>>() {

                        @Override
                        public PlainResult<CreatePresentGiftAssetResponse> doExecute() {
                            return giftAssetRemoteService.createPresentGiftAsset(createPresentAssetRequest);
                        }

                        @Override
                        public boolean handleResult(PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult) {
                            return presentGiftAssetResult.getCode() == 200;
                        }
                    }, 5, 100);

            Long giftAssetId = presentGiftAssetResult.getData().getGiftAssetIds().get(0);

            Assert.assertEquals(presentGiftAssetResult.getCode(), 200);

            List<GiftAsset> giftAssetList =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getId, giftAssetId));

            //此时礼包的状态是待领取
            Assert.assertEquals(giftAssetList.get(0).getState(), "WAIT_RECEIVE");

            //领取买赠礼包
            ReceiveGiftAssetRequest receiveGiftAssetRequest = new ReceiveGiftAssetRequest();

            receiveGiftAssetRequest.setGiftAssetId(giftAssetId);
            receiveGiftAssetRequest.setGiftAssetIdStr(giftAssetId.toString());
            PlainResult<ReceiveGiftAssetResponse> receiveGiftAssetResponsePlainResult = giftAssetRemoteService.receiveGiftAsset(receiveGiftAssetRequest);
            Assert.assertEquals(receiveGiftAssetResponsePlainResult.getCode(), 200);

            List<GiftAsset> giftAssetListReceived =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getId, giftAssetId));
            //此时礼包的状态是已领取
            Assert.assertEquals(giftAssetListReceived.get(0).getState(), "RECEIVED");

            try {
                sleep(6000);
            } catch (Throwable e) {
                e.getMessage();
            }

            //biz后台退款页面回收礼包
            RecycleGiftAssetWithOrderRequest recycleGiftAssetWithOrderRequest = new RecycleGiftAssetWithOrderRequest();
            recycleGiftAssetWithOrderRequest.setPfOrderId(pfOrderId);
            recycleGiftAssetWithOrderRequest.setGiftAssetId(giftAssetListReceived.get(0).getId());

            PlainResult<Boolean> recycleGiftAssetWithOrderResult = pfRefundRemoteService.recycleGiftAssetWithOrder(recycleGiftAssetWithOrderRequest);

            try {
                sleep(4000);
            } catch (Throwable e) {
                e.getMessage();
            }

            Assert.assertTrue(recycleGiftAssetWithOrderResult.getData());

            List<GiftAsset> giftAssetListRecycled =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().eq("id", giftAssetId));
            //此时礼包的状态是已回收
            Assert.assertEquals(giftAssetListRecycled.get(0).getState(), "RECYCLED");
        } finally {
            //数据清理  来无影去无踪
            deleteTemplateData();
        }
    }
}
