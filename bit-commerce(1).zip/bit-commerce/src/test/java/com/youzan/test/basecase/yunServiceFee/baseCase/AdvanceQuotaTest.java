package com.youzan.test.basecase.yunServiceFee.baseCase;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.ycm.perform.response.advance.CanAdvanceOrderQuotaResponse;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2020-10-19
 * 订单额度，预支
 */
public class AdvanceQuotaTest extends YunBaseTest {
// 18831860185
    public static String yunKdtName9 = "zidonghua2";

    @Test // 买1续1，预支第2年
    public void testRenewCanAdvance() {
        Long kdt = newWscKdtId();
        // 下单1年基础版本
        PlainResult<OrderCreateApi> result = testCreateOrder(kdt, yunKdtName9, wscWXItemId_2021, 1);
        // 预期：不能预支
        testCanAdvanceOrderQuota(kdt.toString(), Boolean.FALSE);
        // 续费1年基础版本
        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, yunKdtName9, wscWXItemId_2021, 1);
        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支第二年
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 0);
        Assert.assertEquals(String.valueOf(advanceResult.getCode()), "200");
        godCannotHelpU(kdt);
    }

    @Test // 幂等预支
    public void testIdempotentAdvance() throws InterruptedException {
        Long kdt = newWscKdtId();
        // 下单1年基础版本
        PlainResult<OrderCreateApi> result = testCreateOrder(kdt, yunKdtName9, wscWXItemId_2021, 1);
        // 预期：不能预支
        testCanAdvanceOrderQuota(kdt.toString(), Boolean.FALSE);
        // 续费1年基础版本
        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, yunKdtName9, wscWXItemId_2021, 1);
        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支第二年
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 0);
        Thread.sleep(3000);
        // 幂等 预支第二年
        PlainResult<Boolean> advanceResult2 = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 0);
        Thread.sleep(3000);
        PlainResult<Boolean> advanceResult3 = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 0);
        Assert.assertEquals(String.valueOf(advanceResult.getCode()), "200");
        Assert.assertEquals(String.valueOf(advanceResult2.getCode()), "200");
        Assert.assertEquals(String.valueOf(advanceResult3.getCode()), "200");
        godCannotHelpU(kdt);
    }

    @Test // 买1续2，直接预支第3年，预支失败
    public void testSkipAdvance() {
        Long kdt = newWscKdtId();
        // 下单1年基础版本
        PlainResult<OrderCreateApi> result = testCreateOrder(kdt, yunKdtName9, wscWXItemId_2021, 1);
        // 预期：不能预支
        testCanAdvanceOrderQuota(kdt.toString(), Boolean.FALSE);
        // 续费2年基础版本
        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, yunKdtName9, wscWXItemId_2021, 2);
        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支第3年
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 1);
        Assert.assertEquals(advanceResult.getMessage(), "预支失败，没有可预支额度");
        Assert.assertEquals(String.valueOf(advanceResult.getCode()), "400001");
        Assert.assertEquals(String.valueOf(advanceResult.isSuccess()), "false");
        godCannotHelpU(kdt);

    }

    @Test // 买2，预支
    public void testTwoYearAdvance() {
        Long kdt = newWscKdtId();
        // 购买2年基础版本
        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, yunKdtName9, ItemInfo.WSC_JY_12800.getItemId(), 2);
        // 预期可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdt.toString(), Boolean.TRUE);
        // 预支第2年
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdt, canAdvanceResult.getData().getOrderId().toString(), 1);
        Assert.assertEquals(advanceResult.getMessage(), "successful");
        Assert.assertEquals(String.valueOf(advanceResult.getCode()), "200");
        Assert.assertEquals(String.valueOf(advanceResult.isSuccess()), "true");
        // 查询预支记录表是否有预支记录
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 预支后可用额度校验
        testQueryAvailableQuota(kdt, 40000);
        godCannotHelpU(kdt);
    }
}
