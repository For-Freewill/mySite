package com.youzan.test.market.basecase.gift;

import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateMapper;
import com.youzan.shopcenter.shop.service.ShopCreateService;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.market.api.PresentRemoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * @author tianning
 * @date 2021/3/26 5:19 下午
 * 礼包四部曲：
 * 针对有赞后台crm销售发放礼包调用的对应接口
 * 发放并领取买赠礼包资产:com.youzan.ycm.market.api.PresentRemoteService#sendPresentGift
 * 回收礼包资产:com.youzan.ycm.gift.api.GiftAssetRemoteService#recycleByBackstage
 */

public class PresentGiftForCRMTest extends TnBaseTest {
    @Dubbo
    PresentRemoteService presentRemoteService;
    @Dubbo
    ShopCreateService shopCreateService;

    @Autowired(required = false)
    public GfTemplateGoodsMapper gfTemplateGoodsMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gAssetGoodsMapper;

    @JSONData(value = "dataResource/basecase.gift/CreatePresentGiftRequestData.json", key = "createPresentGiftTemplateRequest")
    private SaveGiftTemplateRequest createPresentGiftTemplateRequest;
    
    /**
     * 创建礼包模板
     * 发放并领取买赠礼包或试用期礼包资产（有个中间状态，先create 然后再commit）
     * 回收礼包资产
     */
    @Test(enabled = false)
    public void presentGiftTest() {

    }
}
