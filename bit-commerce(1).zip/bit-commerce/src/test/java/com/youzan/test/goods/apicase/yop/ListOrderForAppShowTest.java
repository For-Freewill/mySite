package com.youzan.test.goods.apicase.yop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.order.OrderListApi;
import com.youzan.yop.api.form.order.SearchOrderListForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2020/11/16 16:05
 * @goods
 */
public class ListOrderForAppShowTest extends YunBaseTest {
    final static public Logger logger = LoggerFactory.getLogger(ListOrderForAppShowTest.class);

    public static Long ORDER_REMOTE_KDT_ID = 58517716L;
    public static Long ORDER_REMOTE_USER_ID = 8107339288L;
    public String ORDER_REMOTE_SHOP_NAME = "CI二期自动化店铺-勿动";

    @Dubbo
    public OrderRemoteService orderRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void listOrderNormalTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        searchOrderListForm.setKdtId(ORDER_REMOTE_KDT_ID);
        searchOrderListForm.setUserId(ORDER_REMOTE_USER_ID);
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        Assert.assertEquals(orderResult.getCode(), 200);
    }

    /**
     * 异常用例：no_kdt_id
     */
    @Test
    public void listOrderNoKdtIdTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        Assert.assertEquals(orderResult.getCode(), 40200);

    }

    /**
     * 异常用例：no_user_id
     */
    @Test
    public void listOrderNoUserIdTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        searchOrderListForm.setKdtId(ORDER_REMOTE_KDT_ID);
        Assert.assertEquals(orderResult.getCode(), 40200);
    }


    /**
     * 异常用例：微商城连锁店
     */
    @Test
    public void listOrderWscChainTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        searchOrderListForm.setKdtId(54438597L);
        searchOrderListForm.setUserId(ORDER_REMOTE_USER_ID);
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        Assert.assertEquals(orderResult.getCode(), 200);
    }

    /**
     * 异常用例：零售连锁店
     */
    @Test
    public void listOrderRetailChainTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        searchOrderListForm.setKdtId(56413363L);
        searchOrderListForm.setUserId(ORDER_REMOTE_USER_ID);
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        Assert.assertEquals(orderResult.getCode(), 200);
    }

    /**
     * 异常用例：教育单店
     */
    @Test
    public void listOrderEduTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        searchOrderListForm.setKdtId(56414436L);
        searchOrderListForm.setUserId(ORDER_REMOTE_USER_ID);
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        Assert.assertEquals(orderResult.getCode(), 200);
    }

    /**
     * 异常用例：美业单店
     */
    @Test
    public void listOrderMeiYeTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        searchOrderListForm.setKdtId(56419674L);
        searchOrderListForm.setUserId(ORDER_REMOTE_USER_ID);
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        Assert.assertEquals(orderResult.getCode(), 200);
    }

    /**
     * 异常用例：分页
     */
    @Test
    public void listOrderPageTest() {
        SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
        searchOrderListForm.setKdtId(56419674L);
        searchOrderListForm.setUserId(ORDER_REMOTE_USER_ID);
        searchOrderListForm.setPageNo(2);
        PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrderForAppShow(searchOrderListForm);
        Assert.assertEquals(orderResult.getCode(), 200);
    }
}
