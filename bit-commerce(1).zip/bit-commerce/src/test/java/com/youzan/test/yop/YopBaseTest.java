package com.youzan.test.yop;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.goods.GdGoodsIdMapping;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.yop.*;
import com.youzan.commerce.test.mapper.goods.GdGoodsIdMappingMapper;
import com.youzan.commerce.test.mapper.perform.PfOrderStatusMapper;
import com.youzan.commerce.test.mapper.yop.*;
import com.youzan.commerce.test.utils.DateUtil;
import com.youzan.pay.unified.cashier.api.request.v3.request.PreOrderPayRequest;
import com.youzan.pay.unified.cashier.api.request.v3.result.PreOrderPayResult;
import com.youzan.pay.unified.cashier.api.v3.PreOrderPayService;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import com.youzan.ycm.perform.api.PfAppStatusRemoteService;
import com.youzan.ycm.perform.request.status.FlushAppStatusRequest;
import com.youzan.yop.api.*;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.order.OrderListApi;
import com.youzan.yop.api.entity.order.PayOrderDetailApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.status.AppStatusInfoApi;
import com.youzan.yop.api.entity.status.OpenAppOrderStatusApi;
import com.youzan.yop.api.enums.AppStatusState;
import com.youzan.yop.api.form.pay.PreparePayForm;
import com.youzan.yop.api.request.RefundCalculateNonConsumeRequest;
import com.youzan.yop.api.request.RefundNonConsumeRequest;
import com.youzan.yop.api.request.SearchOrderForRefundRequest;
import com.youzan.yop.api.response.RefundCalculateNonConsumeResponse;
import com.youzan.yop.api.response.RefundQueryOrderResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;
import static org.hamcrest.Matchers.equalTo;

/**
 * created by leifeiyun on 2019/7/29
 **/
public class YopBaseTest extends BaseTest {


    /**
     * 支付账户号，就是登陆账号，可根据自己的场景，传局部变量
     */
    public static String account = "17413462002";
    public static Long giftKdtId = 52905456L;
    public static String giftKdtName = "自动化店铺-礼包验证";
    public static Long userId = 690258785L;
    public static Long wscKdtId = 54405928L;
    public static String wscKdtName = "微商城自动化店铺-白-1";
    public static Long wscChainKdtId = 54346215L;
    public static String wscChianKdtName = "自动化-微商城连锁-1";
    public static Long wscChainStoreKdtId = 54346216L;
    public static String wscChainStoreKdtName = "自动化-微商城连锁-网店-1";
    public static Long eduKdtId = 51926411L;
    public static String eduKdtName = "自动化-edu-1";
    @Dubbo
    public PaymentRemoteService paymentRemoteService;
    @Dubbo
    public AppStatusRemoteService appStatusRemoteService;
    @Dubbo
    public RefundRemoteService refundRemoteService;
    @Dubbo
    public OrderRemoteService orderRemoteService;
    @Http("cashier")
    public HttpUtil cashierHttp;
    @Autowired(required = false)
    OpenApplicationGiftMapper openApplicationGiftMapper;
    @Autowired(required = false)
    OpenApplicationOrderMapper openApplicationOrderMapper;
    @Autowired(required = false)
    OpenApplicationOrderStatusMapper openApplicationOrderStatusMapper;
    @Autowired(required = false)
    OpenApplicationPayOrderMapper openApplicationPayOrderMapper;
    @Autowired(required = false)
    OpenApplicationPreferentialRecordMapper openApplicationPreferentialRecordMapper;
    @Autowired(required = false)
    OpenApplicationRightStatusMapper openApplicationRightStatusMapper;
    @Autowired(required = false)
    OpenApplicationStatusLogMapper openApplicationStatusLogMapper;
    @Autowired(required = false)
    OpenApplicationStatusMapper openApplicationStatusMapper;
    @Autowired(required = false)
    OpenApplicationPreferentialMapper openApplicationPreferentialMapper;
    @Autowired(required = false)
    PfOrderStatusMapper pfOrderStatusMapper;
    @Autowired(required = false)
    GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @Dubbo
    PfAppStatusRemoteService pfAppStatusRemoteService;
    @Dubbo
    PreOrderPayService preOrderPayService;
    @Dubbo
    MarketRemoteService marketRemoteService;

    public void deleteGiftOrderInfo(Long kdtId, Integer giftId, List appIds) {
        //删除本次用例产生是的所有数据
        openApplicationGiftMapper.delete(new QueryWrapper<Gift>().eq("kdt_id", kdtId).eq("preferential_id", giftId));
        openApplicationOrderStatusMapper.delete(new QueryWrapper<OrderStatus>().eq("kdt_id", kdtId).eq("preferential_id", giftId));
        openApplicationStatusLogMapper.delete(new QueryWrapper<StatusLog>().eq("kdt_id", kdtId).in("app_id", appIds));
        openApplicationPreferentialRecordMapper.delete(new QueryWrapper<PreferentialRecord>().eq("kdt_id", kdtId).eq("preferential_id", giftId));
        openApplicationPreferentialMapper.delete(new QueryWrapper<Preferential>().eq("id", giftId));

    }

    public Integer getCycleStockCount(Long kdtId, int appid) {
        List<OrderStatus> orderStatusList = openApplicationOrderStatusMapper.selectList(new QueryWrapper<OrderStatus>()
                .eq("kdt_id", kdtId)
                .eq("app_id", appid)
                .last("and effect_time<now() and expire_time > now()"));
        return orderStatusList.stream().mapToInt(t -> t.getNum()).sum();

    }

    /**
     * 预支付
     *
     * @param orderId
     * @param env
     */
    public PlainResult<PreparePayApi> preparePay(Long orderId, Byte env) {
        PreparePayForm preparePayForm = new PreparePayForm();
        preparePayForm.setEnv(env);
        preparePayForm.setOrderId(orderId);
        preparePayForm.setReturnUrl("https://cashier.youzan.com/pay/merchant_cashier?after_pay=true");
        PlainResult<PreparePayApi> preparePayResult = paymentRemoteService.preparePay(preparePayForm);

        return preparePayResult;
    }

    //收银台扣款动作
    public void cashierPay(PlainResult<PreparePayApi> preparePayResult, String account, Long kdtId) {
        // 从预支付接口返回值中获取收银台必填信息
        String partnerId = preparePayResult.getData().getResponse().getPartnerId();
        String prepayId = preparePayResult.getData().getResponse().getPrepayId();
        String cashierSalt = preparePayResult.getData().getResponse().getCashierSalt();
        String cashierSign = preparePayResult.getData().getResponse().getCashierSign();
        long mchId = preparePayResult.getData().getResponse().getMchId();
        // 提交收银台扣款
        //由于收银台http接口登录态一直验证不过，就直接调用支付的接口

        PreOrderPayRequest preOrderPayRequest = new PreOrderPayRequest();
        //写死，只在B端支付使用
        preOrderPayRequest.setBizScene("MERCHANT");
        //写死，包含账户余额支付
        preOrderPayRequest.setPayTool("BALANCE");
        preOrderPayRequest.setAccount(account);
        preOrderPayRequest.setKdtId(String.valueOf(kdtId));
        preOrderPayRequest.setCashierSign(cashierSign);
        preOrderPayRequest.setCashierSalt(cashierSalt);
        preOrderPayRequest.setPrepayId(partnerId);
        preOrderPayRequest.setPrepayId(prepayId);

        PlainResult<PreOrderPayResult> payResultPlainResult = preOrderPayService.preOrderPay(preOrderPayRequest);
        Assert.assertEquals(payResultPlainResult.getCode(), 117700200, "调用支付失败！");
    }

    /**
     * 验证预支付接口
     *
     * @param preparePayResult
     */
    public void checkPreparePayResult(PlainResult<PreparePayApi> preparePayResult, Boolean useAccountRemain, Byte payEnv) {
        Assert.assertEquals(preparePayResult.getCode(), 200);
        Assert.assertEquals(preparePayResult.getMessage(), "successful");
        /**
         * 使用账户余额支付，则调用到了新支付
         */
        if (useAccountRemain) {
            Assert.assertTrue(preparePayResult.getData().getNeedPreparePay() == true);
            switch (payEnv) {
                case 0:
                    Assert.assertEquals(String.valueOf(preparePayResult.getData().getResponse().getMchId()), "200000923501");
                    break;
                case 1:
                    Assert.assertEquals(String.valueOf(preparePayResult.getData().getResponse().getMchId()), "200000923502");
                    break;
                //  统一商户号，不再区分产品线
                case 4:
                    Assert.assertEquals(String.valueOf(preparePayResult.getData().getResponse().getMchId()), "200628182528000000");
                    break;
            }
        } else {
            Assert.assertTrue(preparePayResult.getData().getNeedPreparePay() == false);
        }

    }

    /**
     * 对于订购应用，验证该应用服务期往后推一定的时间，可用这个方法进行校验
     *
     * @param kdtId
     * @param appStatusState
     */
    public void checkAppStatus(Long kdtId, AppStatusState appStatusState, Integer calendarType, Integer count) {
        PlainResult<PageApi<OpenAppOrderStatusApi>> orderStateResult = appStatusRemoteService.listOrderStateByStateAndPage(ConstructionParam.getSearchParam(kdtId, appStatusState));
        Assert.assertNotNull(orderStateResult.getData().getContent());
        for (int i = 0; i < orderStateResult.getData().getContent().size(); i++) {
            PlainResult<PageApi<OpenAppOrderStatusApi>> finalOrderStateResult = orderStateResult;
            int finalI = i;

            with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                    () -> finalOrderStateResult.getData().getContent().get(finalI).getState() == appStatusState);

            //验证服务期往后推一定的时间，按照指定格式 参考calendarType以及value
            with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                    new Callable<Boolean>() {
                        @Override
                        public Boolean call() {
                            return DateUtil.compareDate(/*finalOrderStateResult.getData().getContent().get(finalI).getEffectTime()*/new Date(),
                                    finalOrderStateResult.getData().getContent().get(finalI).getExpireTime(),
                                    calendarType, count);
                        }
                    }, equalTo(true));
        }
        Assert.assertEquals(orderStateResult.getCode(), 200);
        Assert.assertEquals(orderStateResult.getMessage(), "successful");
    }

    /**
     * 对于订购应用，验证该应用服务期往后推一定的时间，可用这个方法进行校验，具体到appId维度
     *
     * @param kdtId
     * @param calendarType
     * @param count
     * @param appIds
     */
    public void checkAppStatusWithAppIs(Long kdtId, Integer calendarType, Integer count, List<Integer> appIds) {
        PlainResult<List<AppStatusInfoApi>> appStatusListInfo = appStatusRemoteService.getAppStatusListInfo(ConstructionParam.getQueryAppStatusListForm(kdtId, appIds));
        Assert.assertNotNull(appStatusListInfo.getData());
        for (int i = 0; i < appStatusListInfo.getData().size(); i++) {
            PlainResult<List<AppStatusInfoApi>> finalOrderStateResult = appStatusListInfo;
            int finalI = i;

            //验证服务期往后推一定的时间，按照指定格式 参考calendarType以及value
            with().pollInterval(100, TimeUnit.MICROSECONDS).and().with().pollDelay(1, TimeUnit.MICROSECONDS).until(
                    new Callable<Boolean>() {
                        @Override
                        public Boolean call() {
                            return DateUtil.compareDate(/*finalOrderStateResult.getData().getContent().get(finalI).getEffectTime()*/new Date(),
                                    finalOrderStateResult.getData().get(finalI).getExpireTime(),
                                    calendarType, count);
                        }
                    }, equalTo(true));
        }
        Assert.assertEquals(appStatusListInfo.getCode(), 200);
        Assert.assertEquals(appStatusListInfo.getMessage(), "successful");
    }

    /**
     * 单笔订单退款，通过子订单退款
     *
     * @param orderId
     * @param date
     * @param refundCnyAmt
     * @param refundYzbAmt
     * @param refundMode
     */
    public void refundOrder(String orderId, Date date, Long refundCnyAmt, Long refundYzbAmt, String refundMode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(date);

        RefundNonConsumeRequest refundNonConsumeRequest = new RefundNonConsumeRequest();
        refundNonConsumeRequest.setMemo("");
        refundNonConsumeRequest.setOperatorId("2135");
        refundNonConsumeRequest.setOrderId(orderId);
        refundNonConsumeRequest.setRefundCalculateTime(refundTime);
        refundNonConsumeRequest.setRefundMode(refundMode);
        refundNonConsumeRequest.setRefundYzbAmt(refundYzbAmt);
        refundNonConsumeRequest.setRefundCnyAmt(refundCnyAmt);
        refundNonConsumeRequest.setRefundWay("ORIG");
        PlainResult<Boolean> refundResult = refundRemoteService.refundNonConsume(refundNonConsumeRequest);
        Assert.assertEquals(refundResult.getMessage(), "successful");
        Assert.assertEquals(refundResult.getCode(), 200);
        Assert.assertTrue(refundResult.getData());

    }

    /**
     * 批量退款
     *
     * @param kdtId      店铺id
     * @param payOrderId 父订单号
     * @param refundMode 退款方式【全额，手动，部分】
     */
    public void refundOrderBatch(Long kdtId, String payOrderId, String refundMode, Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(date);
        SearchOrderForRefundRequest searchOrderForRefundRequest = new SearchOrderForRefundRequest();
        searchOrderForRefundRequest.setKdtId(kdtId);
        searchOrderForRefundRequest.setOrderState((byte) 1);
        searchOrderForRefundRequest.setPayOrderId(payOrderId);
        PlainResult<PageApi<RefundQueryOrderResponse>> searchwscResult = refundRemoteService.searchOrderForRefund(searchOrderForRefundRequest);

        for (int i = 0; i < searchwscResult.getData().getContent().size(); i++) {
            RefundCalculateNonConsumeRequest calculateNonConsumeRequest = new RefundCalculateNonConsumeRequest();
            calculateNonConsumeRequest.setOrderId(searchwscResult.getData().getContent().get(i).getOrderId());
            calculateNonConsumeRequest.setRefundMode(refundMode);
            calculateNonConsumeRequest.setRefundCalculateTime(refundTime);

            PlainResult<RefundCalculateNonConsumeResponse> calculateResult = refundRemoteService.calculateNonConsume(calculateNonConsumeRequest);

            refundOrder(searchwscResult.getData().getContent().get(i).getOrderId(),
                    new Date(), calculateResult.getData().getRefundTotalCnyAmt(), calculateResult.getData().getRefundTotalYzbAmt(), refundMode);
        }

    }

    /**
     * 存在待付款订单，则关闭订单
     */
    public void closeWaitPayOrder(Long kdtId) {
        PlainResult<PageApi<OrderListApi>> resultList = orderRemoteService.listOrder(ConstructionParam.getSearchOrderListForm(kdtId, (byte) 0));
        if (resultList.getData().getContent().size() > 0) {
            //关闭订单
            orderRemoteService.closeOrder(ConstructionParam.getOrderDetailForm(kdtId, resultList.getData().getContent().get(0).getId()));
        }
    }

    /**
     * 验证订单详情
     * 订单详情，查询被抵扣的订单,用的是"测试4800续费升级价格",父订单号
     */
    public void getOrderDetailInfo(Long kdtId, Long orderId, Integer orderType) {

        PlainResult<PayOrderDetailApi> queryOrderResult = orderRemoteService.queryOrder(ConstructionParam.getOrderDetailForm(kdtId, orderId));
        Assert.assertEquals(queryOrderResult.getData().getId(), orderId);
        Assert.assertEquals(queryOrderResult.getCode(), 200);
        Assert.assertEquals(queryOrderResult.getMessage(), "successful");
        //  邀请码已下线
        //    assertData(queryOrderResult.getData().getInviteCode(), inviteCode);
        Assert.assertEquals(queryOrderResult.getData().getUserMobile(), "+86 13522399582");
        Assert.assertEquals(queryOrderResult.getData().getKdtId(), kdtId);
        //第一笔为被抵扣，第二笔为升级，升级订单的抵扣信息不为空，true为被抵扣
        int count = 5;
        while (count >= 0) {
            try {
                switch (orderType) {
                    //被升级订单
                    case 1:
                        Assert.assertEquals((int) queryOrderResult.getData().getState(), 3);
                        break;
                    //升级后订单
                    case 2:
                        Assert.assertEquals((int) queryOrderResult.getData().getState(), 1);
                        Assert.assertNotNull(queryOrderResult.getData().getDeducation());
                        break;
                    //普通订购单
                    case 3:
                        Assert.assertEquals((int) queryOrderResult.getData().getState(), 1);
                        break;
                }
                break;
            } catch (Throwable e1) {
                try {
                    Thread.sleep(100);
                    count--;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }

    }

    /**
     * appId维度，做一个服务期平移操作
     *
     * @param applyKdtId
     * @param appId
     * @param days
     */
    public void moveAppStatus(Long applyKdtId, String appId, Integer days) {
        pfOrderStatusMapper.update(new PfOrderStatus(), new UpdateWrapper<PfOrderStatus>()
                .setSql("effect_time = date_sub(effect_time,interval'" + days + "' day),expire_time = date_sub(expire_time,interval'" + days + "' day)")
                .eq("app_id", appId)
                .eq("apply_kdt_Id", applyKdtId)
                .eq("state", "valid")
        );

        //刷新缓存，detail数据
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        flushAppStatusRequest.setKdtId(String.valueOf(applyKdtId));
        flushAppStatusRequest.setAppId(appId);
        pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        //同步（实际不需要同步），但是规范起见以及避免脏数据
        GdGoodsIdMapping gdGoodsIdMapping = gdGoodsIdMappingMapper.selectOne(new QueryWrapper<GdGoodsIdMapping>().eq("ycm_id", appId));
        marketRemoteService.concurrentStatus(applyKdtId, Integer.valueOf(gdGoodsIdMapping.getYopId()));
    }

    public enum ItemInfo {
        SMS_1000("短信充值1000条", 9638, 613, 5000, 1000, null, null),
        WSC_JC_6800("微商城（2020）基础版-微信小程序", 873, 8157, 680000, 1, 57520, null),
        JFSC_12("积分商城12个月", 2, 4, 128800, 1, null, null),
        WSC_JY_12800("微商城(2020)专业版", 873, 8159, 1280000, 1, 57522, null),
        RETAIL_CHAIN_UINON("大网店总部开通费", 38607, 7227, 1000000, 1, null, null),
        RETAIL_CHAIN_STORE_MANAGE("零售连锁门店管理费", 38391, 7221, 100000, 1, null, null),
        YUN_POS("云pos", 34082, 7179, 200000, 1, null, null),
        RETAIL_CHAIN_MEDIUM("多网店总部开通费", 38687, 7231, 1000000, 1, 2845, null),
        RETAIL_CHAIN_STORE_MANAGE_MALL("零售连锁门店商城", 38610, 7229, 200000, 1, null, null),
        RETAIL_CHAIN_UNION_MALL_JC("总部商城基础版", 38408, 7222, 680000, 1, 2849, null),
        RETAIL_CHAIN_CHAIN_VERSION("零售连锁-连锁版", 42514, 7279, 1000000, 1, null, null),
        RETAIL_CHAIN_STORE_AREA_MALL("区域商城", 42397, 7277, 1280000, 1, 2984, null),
        RETAIL_CHAIN_STORE_STORE_MALL("门店商城", 42395, 7278, 200000, 1, 2983, null),
        EDU_BASE("有赞教育基础版一年期", 39748, 7252, 598800, 1, null, null),
        WSC_EXTEND_PACKAGE("微商城扩展包", 39745, 7251, 258000, 1, null, null),
        FRIEND_PATITION_TICKET("好友瓜分券", 18748, 769, 128800, 1, null, null),
        DISCOUNT_PACKAGE("优惠套餐", 706, 29, 68800, 1, null, null),
        STAFF_YEARS("店铺员工1年期", 31458, 7166, 36500, 1, null, null),
        RETAIL_DD_12800("有赞零售单店专业版一年期", 6075, 7182, 1280000, 1, 2188, null);

        private String name;
        private Integer appId;
        private Integer itemId;
        private Integer money;
        private Integer quantity;
        private Integer preferentialId;
        /**
         * 扩展字段，激活码id
         */
        private Integer extend;

        ItemInfo(String name, Integer appId, Integer itemId, Integer money, Integer quantity, Integer preferentialId, Integer extend) {
            this.name = name;
            this.appId = appId;
            this.itemId = itemId;
            this.money = money;
            this.quantity = quantity;
            this.preferentialId = preferentialId;
            this.extend = extend;
        }

        public String getName() {
            return name;
        }

        public Integer getAppId() {
            return appId;
        }

        public Integer getItemId() {
            return itemId;
        }

        public Integer getMoney() {
            return money;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public Integer getPreferentialId() {
            return preferentialId;
        }

        public Integer getExtend() {
            return extend;
        }

        public void setExtend(Integer extend) {
            this.extend = extend;
        }


    }

}
