package com.youzan.test.protocol.apicase.yop;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageDO;
import com.youzan.commerce.test.entity.dataobject.yop.OpenApplicationAgreementEntity;
import com.youzan.commerce.test.entity.dataobject.yop.Protocols;
import com.youzan.commerce.test.mapper.market.yunfee.FeeResourcePackageMapper;
import com.youzan.commerce.test.mapper.market.yunfee.FeeYopProtocolMapper;
import com.youzan.test.BaseTest;
import com.youzan.test.cloudService.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.trade.toc.api.entity.DelayTaskMessage;
import com.youzan.ycm.perform.response.advance.CanAdvanceOrderQuotaResponse;
import com.youzan.yop.api.AgreementAdminRemoteService;
import com.youzan.yop.api.ProtocolsRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.agreement.AgreementExtApi;
import com.youzan.yop.api.entity.agreement.AgreementTypeTreeStructureApi;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.form.agreement.AgreementRequestForm;
import com.youzan.yop.api.form.agreement.ProtocolContextRequestForm;
import com.youzan.yop.api.request.BatchInvalidProtocolsRequest;
import com.youzan.yop.api.request.BatchSignProtocolsRequest;
import com.youzan.yop.api.response.BatchInvalidProtocolsResponse;
import com.youzan.yop.api.response.BatchSignProtocolsResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;

/**
 * @author wulei
 * @date 2021/11/26 11:24
 */
@Slf4j
public class AgreementAdminRemoteServiceTest extends YunBaseTest {
    @Dubbo
    private AgreementAdminRemoteService agreementAdminRemoteService;

    @Dubbo
    private ProtocolsRemoteService protocolsRemoteService;

    //BIZ后台协议创建流程：创建，编辑，打印，发布
    @Test
    public void bizAgreementTest() {
        //创建
        String agreement = "{\"pageNumber\":1,\"page\":1,\"pageSize\":10,\"id\":null,\"name\":\"《协议CI测试WL》\",\"isPublish\":null,\"beginTime\":null,\"endTime\":null,\"url\":\"http://www.baidu.com\",\"showContext\":\"<p><span>#10DisplayNo#</span></p><p><span>吼！！！！！</span></p><p><span>这个东西，也不知道建出来是咋样的</span></p><p><span> #01PartyATag#</span></p><p><span>#02TeamNameTag#</span></p><p><span>#03AmountTag#</span></p><p><span>#04TimeTag#</span></p><p><span>#05TypeTag#</span></p><p><span>#07YzCoinDeduction#</span></p><p><span>#08TotalRealPrice#</span></p><p><span>#09ServiceDeduction#</span></p>\",\"context\":null,\"operatorName\":null,\"types\":[\"YOUZAN_GOODS_AGREEMENT\"],\"channel\":null}";
        AgreementRequestForm request = JSON.parseObject(agreement, AgreementRequestForm.class);
        PlainResult<Long> result = agreementAdminRemoteService.saveProtocolContext(request);
        Assert.assertEquals(result.getCode(), 200);
        Long agreementId = result.getData().longValue();
        log.info("agreement_id="+agreementId);
        try {
            //创建校验
            checkProtocolsDB(agreementId, request, 0);
            //编辑
            request.setId(agreementId);
            request.setName("《协议CI测试WL-1》");
            PlainResult<Boolean> edit = agreementAdminRemoteService.editProtocolContext(request);
            Assert.assertEquals(edit.getCode(), 200);
            Assert.assertEquals(edit.getData(), Boolean.TRUE);

            //编辑校验
            checkProtocolsDB(agreementId, request, 0);
            //发布
            ProtocolContextRequestForm publish = new ProtocolContextRequestForm();
            publish.setAgreementId(agreementId);
            publish.setUserName("wulei_wl");
            publish.setAllNetUpdate(Byte.valueOf("1"));
            publish.setPublishMode("instant");
            publish.setPublishTime(new Date());

            agreementAdminRemoteService.publishProtocolContext(publish);
            //发布校验
            checkProtocolsDB(agreementId, request, 1);
            //查询
            PlainResult<AgreementExtApi> detail = agreementAdminRemoteService.getDetail(agreementId);
            Assert.assertEquals(detail.getCode(), 200);
            Assert.assertEquals(detail.getData().getName(), "《协议CI测试WL-1》");

            //签署协议
            String sign = "{\"agreementIds\":[237],\"ownerYcmId\":\"66543815\",\"ownerYcmType\":\"KDT_ID\",\"placeholderDTO\":{\"name\":null,\"signDate\":1639123273149,\"applicationId\":null,\"partyA\":null},\"businessType\":\"SHOP\",\"signer\":\"8233948427\",\"isVisible\":false,\"shopProtocolExt\":{\"from_scene\":\"create_shop\",\"client_info\":\"{\\\"hardwareDeviceType\\\":\\\"pc\\\"}\",\"page_resource_info\":\"{\\\"provider\\\":\\\"wsc-pc-shop\\\"}\"}}";
            BatchSignProtocolsRequest sign_request = JSON.parseObject(sign, BatchSignProtocolsRequest.class);
            sign_request.setAgreementIds(Arrays.asList(237L));
            sign_request.setOwnerYcmId("57313379");
            sign_request.getPlaceholderDTO().setSignDate(new Date());
            PlainResult<BatchSignProtocolsResponse> sign_result = protocolsRemoteService.signProtocols(sign_request);
            Assert.assertEquals(sign_result.getCode(), 200);

            //失效协议
            BatchInvalidProtocolsRequest invalid = new BatchInvalidProtocolsRequest();
            invalid.setProtocolIds(Arrays.asList(agreementId));
            invalid.setReason("应用删除");
            PlainResult<BatchInvalidProtocolsResponse> invalid_result = protocolsRemoteService.invalidProtocolsByProtocolIds(invalid);
            Assert.assertEquals(invalid_result.getCode(), 200);
        }catch (Exception e){
            log.info("协议流程异常"+e);
        }finally {
            delProtocolsDB(agreementId);
        }

    }

    @Test // 买1年微商城，查看协议表
    public void WSCProtocolsTest() {
        Long kdt = newWscKdtId();

        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdt, "yunKdtName11", wscWXItemId_2021, 1);
        Assert.assertEquals(result1.getCode(), 200);
        with().atMost(60, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> protocolsMapper.selectList(new QueryWrapper<Protocols>().lambda().eq(Protocols::getKdtId,kdt)).size()>=1);

        List<Protocols> protocolsList = protocolsMapper.selectList(new QueryWrapper<Protocols>().lambda().eq(Protocols::getKdtId,kdt).eq(Protocols::getAppId,873));
        Assert.assertEquals(protocolsList.size(), 1);
    }

    @Test // 买1年自定义原子商品（appId=1000451313，itemid=100094707）关联协议366，查看协议表
    public void AtomGoodsWithProtocolsTest() {
        Long kdt = newWscKdtId();

        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdt, "yunKdtName11", 100094707, 1);
        Assert.assertEquals(result1.getCode(), 200);
        with().atMost(60, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> protocolsMapper.selectList(new QueryWrapper<Protocols>().lambda().eq(Protocols::getKdtId,kdt)).size()>=1);

        List<Protocols> protocolsList = protocolsMapper.selectList(new QueryWrapper<Protocols>().lambda().eq(Protocols::getKdtId,kdt).eq(Protocols::getAppId,1000451313));
        Assert.assertEquals(protocolsList.size(), 1);
    }

    @Test // 买1年自定义原子商品（appId=1000451314，itemid=100094708）未关联协议，查看协议表
    public void AtomGoodsNoProtocolsTest() throws InterruptedException {
        Long kdt = newWscKdtId();

        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdt, "yunKdtName11", 100094708, 1);
        Assert.assertEquals(result1.getCode(), 200);

        Thread.sleep(3000);

        List<Protocols> protocolsList = protocolsMapper.selectList(new QueryWrapper<Protocols>().lambda().eq(Protocols::getKdtId,kdt).eq(Protocols::getAppId,1000451314));
        Assert.assertEquals(protocolsList.size(), 0);
    }

    @Test
    public void listAgreementTest() {
        AgreementRequestForm request = new AgreementRequestForm();
        request.setId(365L);
        PlainResult<PageApi<AgreementExtApi>>  result = agreementAdminRemoteService.listAgreement(request);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getContent().size()==1, true);
    }

    @Test
    public void getDetailTest() {
        PlainResult<AgreementExtApi>  result = agreementAdminRemoteService.getDetail(365L);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getId(), Long.valueOf(365));
    }

    @Test
    public void getAgreementListsByNameTest() {
        PlainResult<List<AgreementExtApi>>  result = agreementAdminRemoteService.getAgreementListsByName("微商城");
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().size()>=10, true);
    }

    @Test
    public void getAgreementTypeTreeStructureTest() {
        PlainResult<AgreementTypeTreeStructureApi>  result = agreementAdminRemoteService.getAgreementTypeTreeStructure();
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getAgreementTypeHierarchyApis().size()==2, true);
    }

}
