package com.youzan.test.yop.finance;

import com.google.common.collect.Lists;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.GiftValueAmortizeRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.amortize.ValueAmortizeApi;
import com.youzan.yop.api.form.amortize.SearchGiftByTimeForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;


/**
 * Create by wuwu on 2019/12/9
 **/

public class GiftValueAmortizeRemoteServiceTest {
    Logger logger = LoggerFactory.getLogger(GiftValueAmortizeRemoteServiceTest.class);

    @Dubbo
    GiftValueAmortizeRemoteService giftValueAmortizeRemoteService;

    @Test(enabled = false)
    public void getReceiveAmortizeGiftList_byQueryTime_Test() {
        SearchGiftByTimeForm searchGiftByTimeForm = new SearchGiftByTimeForm();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        try {
            searchGiftByTimeForm.setBeginTime(sdf.parse("2019-12-07 10:53:02"));
            searchGiftByTimeForm.setEndTime(sdf.parse("2019-12-09 18:53:02"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        searchGiftByTimeForm.setPageSize(500);

        PlainResult<PageApi<ValueAmortizeApi>> receiveAmortizeGiftList = giftValueAmortizeRemoteService.getReceiveAmortizeGiftList(searchGiftByTimeForm);

        System.out.println(receiveAmortizeGiftList.getMessage());
        System.out.println(receiveAmortizeGiftList.getData().getContent());

    }

    @Test(enabled = false)
    public void getReceiveAmortizeGiftList_byGiftIds_Test() {
        SearchGiftByTimeForm searchGiftByTimeForm = new SearchGiftByTimeForm();
        searchGiftByTimeForm.setGiftIds(Lists.newArrayList(918691L));
        searchGiftByTimeForm.setPageSize(500);

        PlainResult<PageApi<ValueAmortizeApi>> receiveAmortizeGiftList = giftValueAmortizeRemoteService.getReceiveAmortizeGiftList(searchGiftByTimeForm);
        System.out.println(receiveAmortizeGiftList.getMessage());
        System.out.println(receiveAmortizeGiftList.getData());

    }


    @Test(enabled = false)
    public void getRecycleAmortizeGiftList_byQueryTime_Test() {
        SearchGiftByTimeForm searchGiftByTimeForm = new SearchGiftByTimeForm();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        try {
            searchGiftByTimeForm.setBeginTime(sdf.parse("2019-12-07 10:53:02"));
            searchGiftByTimeForm.setEndTime(sdf.parse("2019-12-09 18:53:02"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        searchGiftByTimeForm.setPageSize(500);

        PlainResult<PageApi<ValueAmortizeApi>> recycleAmortizeGiftList = giftValueAmortizeRemoteService.getRecycleAmortizeGiftList(searchGiftByTimeForm);
        System.out.println(recycleAmortizeGiftList.getMessage());
        System.out.println(recycleAmortizeGiftList.getData().getContent());

    }

    @Test(enabled = false)
    public void getRecycleAmortizeGiftList_byGiftIds_Test() {
        SearchGiftByTimeForm searchGiftByTimeForm = new SearchGiftByTimeForm();
        searchGiftByTimeForm.setGiftIds(Lists.newArrayList(918691L));
        searchGiftByTimeForm.setPageSize(500);

        PlainResult<PageApi<ValueAmortizeApi>> receiveAmortizeGiftList = giftValueAmortizeRemoteService.getRecycleAmortizeGiftList(searchGiftByTimeForm);
        System.out.println(receiveAmortizeGiftList.getMessage());
        System.out.println(receiveAmortizeGiftList.getData());

    }
}
