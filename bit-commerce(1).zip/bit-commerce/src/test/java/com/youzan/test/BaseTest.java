package com.youzan.test;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.StartTest;
import com.youzan.commerce.test.entity.dataobject.goods.CdRedeemCodeApplyRecordEntity;
import com.youzan.commerce.test.entity.dataobject.goods.GdGoodsIdMapping;
import com.youzan.commerce.test.entity.dataobject.market.MkJoinRecord;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponAsset;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAssetGoods;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageLogDO;
import com.youzan.commerce.test.entity.dataobject.perform.*;
import com.youzan.commerce.test.entity.dataobject.trade.*;
import com.youzan.commerce.test.entity.dataobject.yop.OrderItemRefundOrder;
import com.youzan.commerce.test.entity.dataobject.yop.Protocols;
import com.youzan.commerce.test.kv.KvdsConstants;
import com.youzan.commerce.test.mapper.goods.GdGoodsIdMappingMapper;
import com.youzan.commerce.test.mapper.market.DeductionResultCompositionMapper;
import com.youzan.commerce.test.mapper.market.DeductionResultDetailMapper;
import com.youzan.commerce.test.mapper.market.JoinRecordMapper;
import com.youzan.commerce.test.mapper.market.PromotionResultDetailMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityMapper;
import com.youzan.commerce.test.mapper.market.coupon.CouponAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.PresentRecordMapper;
import com.youzan.commerce.test.mapper.market.yunfee.FeeResourcePackageLogMapper;
import com.youzan.commerce.test.mapper.perform.*;
import com.youzan.commerce.test.mapper.trade.*;
import com.youzan.commerce.test.mapper.yop.ProtocolsMapper;
import com.youzan.framework.redis.RedisClient;
import com.youzan.pay.acctrans.api.acctrans.AcctransRechargeService;
import com.youzan.pay.acctrans.api.acctrans.dto.AcctransAccountingDTO;
import com.youzan.pay.acctrans.api.acctrans.request.AcctransRechargeRequest;
import com.youzan.pay.acctrans.common.model.enums.AccountType;
import com.youzan.pay.acctrans.common.model.enums.SubTransCodeEnum;
import com.youzan.pay.acctrans.common.model.enums.TransCodeEnum;
import com.youzan.pay.acctrans.common.model.model.AccountInfo;
import com.youzan.pay.core.api.model.response.DataResult;
import com.youzan.pay.core.common.model.enums.CurrencyCode;
import com.youzan.pay.core.common.model.enums.bizcode.ChannelType;
import com.youzan.pay.core.exception.BusinessException;
import com.youzan.pay.core.utils.KeyUtils;
import com.youzan.pay.customer.api.ops.UserInfoService;
import com.youzan.pay.unified.cashier.api.request.v3.request.PreOrderPayRequest;
import com.youzan.pay.unified.cashier.api.request.v3.result.PreOrderPayResult;
import com.youzan.pay.unified.cashier.api.v3.PreOrderPayService;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.utils.DubboUtil;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.ycm.gift.api.GiftAssetRemoteService;
import com.youzan.ycm.gift.request.RecycleGiftAssetRequestBiz;
import com.youzan.ycm.gift.response.RecycleGiftAssetResponse;
import com.youzan.ycm.goods.api.GoodsRemoteService;
import com.youzan.ycm.goods.request.GoodsSPUListRequest;
import com.youzan.ycm.goods.response.GoodsSPUResponse;
import com.youzan.ycm.goods.response.PageResponse;
import com.youzan.ycm.perform.api.PfAppStatusRemoteService;
import com.youzan.ycm.perform.api.PfRefundRemoteService;
import com.youzan.ycm.perform.request.refund.RefundConsumeRequest;
import com.youzan.ycm.perform.request.refund.RefundOrderQuotaRequest;
import com.youzan.ycm.perform.request.status.FlushAppStatusRequest;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableNewKdtIdResponse;
import com.youzan.ycm.qa.enable.platform.api.service.enable.EnableNewShopPoolService;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableNewKdtIdResponse;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.PaymentRemoteService;
import com.youzan.yop.api.RefundRemoteService;
import com.youzan.yop.api.entity.OfflineOrderFormV2;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.order.CalOrderPriceApi;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.entity.order.OrderListApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.*;
import com.youzan.yop.api.form.pay.PreparePayForm;
import com.youzan.yop.api.request.RefundCalculateNonConsumeRequest;
import com.youzan.yop.api.request.RefundNonConsumeRequest;
import com.youzan.yop.api.request.SearchOrderForRefundRequest;
import com.youzan.yop.api.response.CreateOfflineOrderResponse;
import com.youzan.yop.api.response.ItemPreferentialInfoResultApi;
import com.youzan.yop.api.response.RefundCalculateNonConsumeResponse;
import com.youzan.yop.api.response.RefundQueryOrderResponse;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

/**
 * @author tianning
 * @date 2020/8/9 11:12 下午
 */
@Listeners({CiStatisticalToolsListener.class})
public class BaseTest extends StartTest {
    final static public Logger logger = LoggerFactory.getLogger(BaseTest.class);

    public static String account = "15558185301";
    public Long wscKdtId = 58101529L;
    public Long yzbPromtionId = 5528L;

    @Dubbo
    public PreOrderPayService preOrderPayService;
    @Dubbo
    public PaymentRemoteService paymentRemoteService;
    @Dubbo
    public RefundRemoteService refundRemoteService;
    @Dubbo
    public OrderRemoteService orderRemoteService;
    @Dubbo
    public PfAppStatusRemoteService pfAppStatusRemoteService;
    @Dubbo
    public UserInfoService userInfoService;
    @Dubbo
    public AcctransRechargeService acctransRechargeService;
    @Dubbo
    public GiftAssetRemoteService giftAssetRemoteService;
    @Dubbo
    public PfRefundRemoteService pfRefundRemoteService;
    @Dubbo
    public MarketRemoteService marketRemoteService;
//    @Dubbo
//    public EnableNewShopPoolService enableNewShopPoolService;
    @Dubbo
    public GoodsRemoteService goodsRemoteService;
    @Resource
    public RedisClient redisClient;

    @Autowired(required = false)
    public TdOrderItemMapper tdOrderItemMapper;
    @Autowired(required = false)
    public TdPayOrderMapper tdPayOrderMapper;
    @Autowired(required = false)
    public PfOrderDetailActiveRecordMapper pfOrderDetailActiveRecordMapper;
    @Autowired(required = false)
    public TdSettleOrderMapper tdSettleOrderMapper;
    @Autowired(required = false)
    public PayRefundOrderMapper payRefundOrderMapper;
    @Autowired(required = false)
    public OrderItemRefundOrderMapper orderItemRefundOrderMapper;
    @Autowired(required = false)
    public PromotionResultDetailMapper promotionResultDetailMapper;
    @Autowired(required = false)
    public PresentRecordMapper presentRecordMapper;
    @Autowired(required = false)
    public DeductionResultCompositionMapper deductionResultCompositionMapper;
    @Autowired(required = false)
    public DeductionResultDetailMapper deductionResultDetailMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gfAssetGoodsMapper;
    @Autowired(required = false)
    public JoinRecordMapper joinRecordMapper;
    @Autowired(required = false)
    public CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    public PfAssetDeductionMapper pfAssetDeductionMapper;
    @Autowired(required = false)
    public PfRightsStatusMapper pfRightsStatusMapper;
    @Autowired(required = false)
    public PfStockMapper pfStockMapper;
    @Autowired(required = false)
    public PfOrderStockMapper pfOrderStockMapper;
    @Autowired(required = false)
    public PfSchemeMapper pfSchemeMapper;
    @Autowired(required = false)
    public TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    public PfSchemeOrderRelationMapper pfSchemeOrderRelationMapper;
    @Autowired(required = false)
    public PfRechargeConfigMapper pfRechargeConfigMapper;
    @Autowired(required = false)
    public PfDebtRepayRecordMapper pfDebtRepayRecordMapper;
    @Autowired(required = false)
    public PfOrderDetailAdvanceRecordMapper pfOrderDetailAdvanceRecordMapper;
    @Autowired(required = false)
    public PfOrderDetailDebtRecordMapper pfOrderDetailDebtRecordMapper;
    @Autowired(required = false)
    public GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @Autowired(required = false)
    public FeeResourcePackageLogMapper feeResourcePackageLogMapper;
    @Autowired(required = false)
    public CdRedeemCodeApplyRecordMapper cdRedeemCodeApplyRecordMapper;
    @Autowired(required = false)
    public TdActivationCodeApplyRecordMapper tdActivationCodeApplyRecordMapper;
    @Autowired(required = false)
    public PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    public PfOrderDetailMapper pfOrderDetailMapper;
    @Autowired(required = false)
    public PfOrderStatusMapper pfOrderStatusMapper;
    @Autowired(required = false)
    public ActivityMapper activityMapper;
    @Autowired(required = false)
    public PfAssetMapper pfAssetMapper;
    @Autowired(required = false)
    PfFeeResourcePackageMapper pfFeeResourcePackageMapper;
    @Autowired(required = false)
    public ProtocolsMapper protocolsMapper;
    @Autowired(required = false)
    public PfProtectionPeriodMapper pfProtectionPeriodMapper;


    /**
     * 获取微商城单店新的kdtid
     * @return
     */
    public Long newWscKdtId(){
        EnableNewKdtIdResponse result =  getKdtId("wsc");
        return result.getKdtId();
    }

    /**
     * 获取零售单店新的kdtid
     * @return
     */
    public Long newRetailKdtId(){
        EnableNewKdtIdResponse result =  getKdtId("retail");
        return result.getKdtId();
    }

    /**
     * 获取教育单店新的kdtid
     * @return
     */
    public Long newEduKdtId(){
        EnableNewKdtIdResponse result =  getKdtId("edu");
        return result.getKdtId();
    }

    /**
     * 获取零售连锁新的kdtid
     * @return
     */
    public Long newRetailChainKdtId(){
        EnableNewKdtIdResponse result =  getKdtId("retailChain");
        return result.getKdtId();
    }

    /**
     * 获取微商城连锁新的kdtid
     * @return
     */
    public Long newWscChainKdtId(){
        EnableNewKdtIdResponse result =  getKdtId("wscChain");
        return result.getKdtId();
    }
    /**
     * 预支付
     *
     * @param orderId
     * @param env
     */
    public PlainResult<PreparePayApi> preparePay(Long orderId, Byte env) {
        PreparePayForm preparePayForm = new PreparePayForm();
        preparePayForm.setEnv(env);
        preparePayForm.setOrderId(orderId);
        preparePayForm.setReturnUrl("https://cashier.youzan.com/pay/merchant_cashier?after_pay=true");
        PlainResult<PreparePayApi> preparePayResult = paymentRemoteService.preparePay(preparePayForm);
        Assert.assertEquals(preparePayResult.getCode(),200,preparePayResult.getMessage());
        return preparePayResult;
    }

    //收银台扣款动作
    public void cashierPay(PlainResult<PreparePayApi> preparePayResult, String account, Long kdtId) {
        // 从预支付接口返回值中获取收银台必填信息
        String partnerId = preparePayResult.getData().getResponse().getPartnerId();
        String prepayId = preparePayResult.getData().getResponse().getPrepayId();
        String cashierSalt = preparePayResult.getData().getResponse().getCashierSalt();
        String cashierSign = preparePayResult.getData().getResponse().getCashierSign();
        long mchId = preparePayResult.getData().getResponse().getMchId();
        //提交收银台扣款
        //由于收银台http接口登录态一直验证不过，就直接调用支付的接口
        PreOrderPayRequest preOrderPayRequest = new PreOrderPayRequest();
        //写死，只在B端支付使用
        preOrderPayRequest.setBizScene("MERCHANT");
        //写死，包含账户余额支付
        preOrderPayRequest.setPayTool("BALANCE");
        preOrderPayRequest.setAccount(account);
        preOrderPayRequest.setKdtId(String.valueOf(kdtId));
        preOrderPayRequest.setCashierSign(cashierSign);
        preOrderPayRequest.setCashierSalt(cashierSalt);
        preOrderPayRequest.setPrepayId(partnerId);
        preOrderPayRequest.setPrepayId(prepayId);
        PlainResult<PreOrderPayResult> payResultPlainResult = preOrderPayService.preOrderPay(preOrderPayRequest);
        Assert.assertEquals(payResultPlainResult.getCode(), 117700200,payResultPlainResult.getMessage());

    }

    /**
     * @param kdtId
     * @param preparePayResult
     * @desc 收银台扣款动作--转账汇款
     */
    public PlainResult<PreOrderPayResult> transferPayOrder(Long kdtId, PlainResult<PreparePayApi> preparePayResult) {
        PreOrderPayRequest request = new PreOrderPayRequest();
        request.setAccount("18099999997");
        request.setBizScene("MERCHANT");
        request.setKdtId(String.valueOf(kdtId));
        request.setCashierSign(preparePayResult.getData().getResponse().getCashierSign());
        request.setCashierSalt(preparePayResult.getData().getResponse().getCashierSalt());
        request.setPartnerId(preparePayResult.getData().getResponse().getPartnerId());
        request.setPrepayId(preparePayResult.getData().getResponse().getPrepayId());
        request.setPayTool("TRANSFER_VOUCHER");
        request.setTransferOutAccount("1110");
        request.setTransferOutAccountName("1111");
        request.setTransferInAccount("571907821710904");
        request.setTransferDate("20210301");
        request.setAcceptPrice(0);
        request.setNewPrice(0);
        PlainResult<PreOrderPayResult> result = preOrderPayService.preOrderPay(request);
        logger.info(JSON.toJSONString(result));
        Assert.assertTrue(result.isSuccess());
        //Assert.assertEquals(result.getCode(),117700200,result.getMessage());

        return result;
    }

    /**
     * 店铺余额充值，单位（元）
     *
     * @param kdtId
     * @param money
     */
    public void rechargeShopBalance(String kdtId, int money) {
        String userNo = kdtId;
        money = money * 100;
        int inputType = 0;
        //根据kdtId 获取userNo
        PlainResult<String> result = new PlainResult<>();
        try {
            result = userInfoService.queryUserNoByKdtId(Integer.parseInt(kdtId));
            if (!result.isSuccess() || result.getData() == null) {
                logger.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
                throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
            }
        } catch (Exception e) {
            logger.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
            throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
        }
        userNo = result.getData();

        String waterNo = String.valueOf(KeyUtils.generateWaterNumber());
        AcctransRechargeRequest rechargeRequest = new AcctransRechargeRequest();
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setUserNo(String.valueOf(userNo));
        accountInfo.setAccountType(AccountType.BASE_ACCT.getType());
        rechargeRequest.setAccountInfo(accountInfo);
        rechargeRequest.setAppName("biz-commerce");
        rechargeRequest.setClientId(waterNo);
        rechargeRequest.setAcquireNo(waterNo);
        rechargeRequest.setAmount(money);
        rechargeRequest.setChannelCode(ChannelType.BALANCE.getCode());
        rechargeRequest.setCurrencyCode(CurrencyCode.CNY.getNum());
        rechargeRequest.setOperator("ci-test");
        rechargeRequest.setOrderNo(waterNo);
        rechargeRequest.setParternerBizType("301001");
        rechargeRequest.setParternerId("301001");
        rechargeRequest.setRemark("接口测试调用");
        rechargeRequest.setSubTransCode(SubTransCodeEnum.RECHARGE_RECHARGESETTLE.getCode());
        rechargeRequest.setTransCode(TransCodeEnum.RECHARGE.getCode());
        rechargeRequest.setRequestTime("test");
        DataResult<AcctransAccountingDTO> rechargeResult = acctransRechargeService.recharge(rechargeRequest);

        if (!rechargeResult.isSuccess()) {
            logger.error("AcctransService 充值接口调用失败,waterNo=" + rechargeResult.getRequestId() + "! ");
            throw new BusinessException("AcctransService 充值接口调用失败！返回结果为：" + JSON.toJSONString(rechargeResult));
        }
    }


    /**
     * @param kdtId
     * @desc 退掉指定店铺和appid下所有的订单
     * @author tn
     */
    public void refundBykdtIdAndAppId(Long kdtId, Long appid) {
        refundOrderBatch(kdtId, appid, "", "BY_VALUE", new Date());
    }

    public void refundOrder(String orderId, Date date, Long refundCnyAmt, Long refundYzbAmt, String refundMode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(date);

        RefundNonConsumeRequest refundNonConsumeRequest = new RefundNonConsumeRequest();
        refundNonConsumeRequest.setMemo("");
        refundNonConsumeRequest.setOperatorId("2135");
        refundNonConsumeRequest.setOrderId(orderId);
        refundNonConsumeRequest.setRefundCalculateTime(refundTime);
        refundNonConsumeRequest.setRefundMode(refundMode);
        refundNonConsumeRequest.setRefundYzbAmt(refundYzbAmt);
        refundNonConsumeRequest.setRefundCnyAmt(refundCnyAmt);
        refundNonConsumeRequest.setRefundWay("MARK");
        PlainResult<Boolean> refundResult = refundRemoteService.refundNonConsume(refundNonConsumeRequest);
        Assert.assertEquals(refundResult.getMessage(), "successful");
        Assert.assertEquals(refundResult.getCode(), 200);
        Assert.assertTrue(refundResult.getData());
    }

    /**
     * 批量退款
     *
     * @param kdtId      店铺id
     * @param payOrderId 父订单号
     * @param refundMode 退款方式【全额，手动，部分】
     */
    public void refundOrderBatch(Long kdtId, Long appId, String payOrderId, String refundMode, Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(date);
        SearchOrderForRefundRequest searchOrderForRefundRequest = new SearchOrderForRefundRequest();
        searchOrderForRefundRequest.setKdtId(kdtId);
        searchOrderForRefundRequest.setOrderState((byte) 1);
        if (!"".equals(payOrderId)) {
            searchOrderForRefundRequest.setPayOrderId(payOrderId);
        }
        if (appId != null) {
            searchOrderForRefundRequest.setAppId(appId);
        }
        PlainResult<PageApi<RefundQueryOrderResponse>> searchwscResult = refundRemoteService.searchOrderForRefund(searchOrderForRefundRequest);

        for (int i = 0; i < searchwscResult.getData().getContent().size(); i++) {
            //如果是订单额度，则走订单额度的退款
            if (getAppIdByPfOrderId(searchwscResult.getData().getContent().get(i).getOrderId()).equals("atom_spu_order_limit")) {
                RefundOrderQuotaRequest refundOrderQuotaRequest = new RefundOrderQuotaRequest();
                refundOrderQuotaRequest.setMemo("");
                refundOrderQuotaRequest.setOperatorId("2135");
                refundOrderQuotaRequest.setPfOrderId(Long.valueOf(searchwscResult.getData().getContent().get(i).getOrderId()));
                refundOrderQuotaRequest.setRefundWay("MARK");
                PlainResult<Boolean> refundResult = pfRefundRemoteService.refundOrderQuota(refundOrderQuotaRequest);
                Assert.assertEquals(refundResult.getCode(), 200, refundResult.getMessage());
            }
            //如果是库存型商品，则走库存商品的退款
            else if (!getAppIdByPfOrderId(searchwscResult.getData().getContent().get(i).getOrderId()).equals("atom_spu_order_limit")
                    && searchwscResult.getData().getContent().get(i).getPerformType().equals("count")) {
                RefundConsumeRequest refundConsumeRequest = new RefundConsumeRequest();
                refundConsumeRequest.setPfOrderId(Long.valueOf(searchwscResult.getData().getContent().get(i).getOrderId()));
                refundConsumeRequest.setOperatorId("2135");
                refundConsumeRequest.setRefundMode("BY_ALL");
                refundConsumeRequest.setRefundWay("MARK");

                logger.info("库存型商品退款入参：{}",refundConsumeRequest);
                PlainResult<Boolean> refundResult =pfRefundRemoteService.refundConsume(refundConsumeRequest);
                Assert.assertEquals(refundResult.getCode(), 200, refundResult.getMessage());

            } else {
                RefundCalculateNonConsumeRequest calculateNonConsumeRequest = new RefundCalculateNonConsumeRequest();

                calculateNonConsumeRequest.setOrderId(searchwscResult.getData().getContent().get(i).getOrderId());
                calculateNonConsumeRequest.setRefundMode(refundMode);
                calculateNonConsumeRequest.setRefundCalculateTime(refundTime);

                PlainResult<RefundCalculateNonConsumeResponse> calculateResult = refundRemoteService.calculateNonConsume(calculateNonConsumeRequest);

                refundOrder(searchwscResult.getData().getContent().get(i).getOrderId(),
                        new Date(), calculateResult.getData().getRefundTotalCnyAmt(), calculateResult.getData().getRefundTotalYzbAmt(), refundMode);
            }
        }

    }

    /**
     * @param kdtid
     * @desc 将kdtid下所有的订购退款
     */
    public void refundOrderByKdtId(Long kdtid) {

        refundOrderBatch(kdtid, null, "", "BY_VALUE", new Date());

    }

    /**
     * 存在待付款订单，则关闭订单
     */
    public void closeWaitPayOrder(Long kdtId) {
        PlainResult<PageApi<OrderListApi>> resultList = orderRemoteService.listOrder(ConstructionParam.getSearchOrderListForm(kdtId, (byte) 0));
        if(resultList.getCode() == 200){
            if (resultList.getData().getContent().size() > 0) {
                //关闭订单
                orderRemoteService.closeOrder(ConstructionParam.getOrderDetailForm(kdtId, resultList.getData().getContent().get(0).getId()));
            }
        }else{
            logger.info("查询订单失败:"+resultList.getMessage());
        }

    }

    /**
     * 存在待付款订单，则调用支付付款
     */
    public void payWaitPayOrder(Long kdtId, Long payOrderId) {
        PlainResult<PageApi<OrderListApi>> resultList = orderRemoteService.listOrder(ConstructionParam.getSearchOrderListForm(kdtId, (byte) 0));
        if (resultList.getData().getContent().size() > 0) {
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(payOrderId, (byte) 4);
            //2.支付订单
            cashierPay(preparePayApiPlainResult, account, wscKdtId);

        }
    }

    /**
     * @param kdtId
     * @desc 删除一个店铺的所有数据，危险操作，可能会影响上下游
     */
    public void deleteTestDataYcmByKdtId(Long kdtId) {
        //  交易信息
        List<TdOrder> tradeOrderDOs = tdOrderMapper.selectList(new QueryWrapper<TdOrder>().eq("buyer_id", kdtId.toString()));
        List<String> tdNoList = tradeOrderDOs.stream().filter(tradeOrderDO -> "YOUZAN".equals(tradeOrderDO.getChannel())).map(TdOrder::getTdNo).collect(Collectors.toList());
        List<TdOrderItem> tradeOrderItemList = new ArrayList<>();

        if (isNotEmpty(tdNoList)) {
            for (String tdNo : tdNoList) {
                //  正向
                tdOrderMapper.delete(new QueryWrapper<TdOrder>().eq("td_no", tdNo));
                tdSettleOrderMapper.delete(new QueryWrapper<TdSettleOrder>().eq("td_no", tdNo));
                //            pfOrderMapper.delete(new QueryWrapper<PfOrder>().eq("biz_order_id", tdNo));
                tdPayOrderMapper.delete(new QueryWrapper<TdPayOrder>().eq("td_no", tdNo));
                //  解决td_order_item删不干净的问题==
                do{
                    tdOrderItemMapper.delete(new QueryWrapper<TdOrderItem>().eq("td_no", tdNo));
                    tradeOrderItemList = tdOrderItemMapper.selectList(new QueryWrapper<TdOrderItem>().eq("td_no", tdNo));
                }while(tradeOrderItemList.size()>0);
                //  逆向
                payRefundOrderMapper.delete(new QueryWrapper<PayRefundOrder>().eq("td_no", tdNo));
                orderItemRefundOrderMapper.delete(
                        new QueryWrapper<OrderItemRefundOrder>().eq("td_no", tdNo));
                // 营销参与记录
                promotionResultDetailMapper.delete(
                        new QueryWrapper<PromotionResultDetail>().eq("td_no", tdNo));
                presentRecordMapper.delete(new QueryWrapper<PresentRecord>().eq("td_no", tdNo));
                // 抵扣升级
                deductionResultDetailMapper.delete(
                        new QueryWrapper<DeductionResultDetail>().eq("td_no", tdNo));
                deductionResultCompositionMapper.delete(
                        new QueryWrapper<DeductionResultComposition>().eq("trade_no", tdNo));
            }
        }

        //  营销信息
        List<GiftAsset> gfAssetDOs =
                gfAssetMapper.selectList(new QueryWrapper<GiftAsset>().eq("owner_ycmid", kdtId.toString()));
        List<Long> gfAssetIdList =
                gfAssetDOs.stream().map(GiftAsset::getId).collect(Collectors.toList());
        if (isNotEmpty(gfAssetIdList)) {
            gfAssetMapper.deleteBatchIds(gfAssetIdList);
            for (long gfAssetId : gfAssetIdList) {
                gfAssetGoodsMapper.delete(new QueryWrapper<GiftAssetGoods>().eq("asset_id", gfAssetId));
            }
        }
        if (isNotEmpty(tdNoList)) {
            for (String tdNo : tdNoList) {
                joinRecordMapper.delete(new QueryWrapper<MkJoinRecord>().eq("biz_order_id", tdNo));
            }
        }
        couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().eq("belongto_yid",kdtId.toString()));

        //  履约信息
        List<PfOrder> pfOrderDOs =
                pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("buy_kdt_id", kdtId.toString()));
        List<Long> pfOrderIdList = pfOrderDOs.stream().map(PfOrder::getId).collect(Collectors.toList());
        if (isNotEmpty(pfOrderIdList)) {
            pfOrderMapper.deleteBatchIds(pfOrderIdList);
            List<Long> totalPfAssetIds = new LinkedList<>();
            for (Long pfOrderId : pfOrderIdList) {
                List<PfAsset> pfAssetDOList =
                        pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("pf_order_id", pfOrderId));
                totalPfAssetIds.addAll(
                        pfAssetDOList.stream().map(PfAsset::getId).collect(Collectors.toList()));
            }
            if (isNotEmpty(totalPfAssetIds)) {
                pfAssetMapper.deleteBatchIds(totalPfAssetIds);
                for (long pfAssertId : totalPfAssetIds) {
                    pfAssetDeductionMapper.delete(
                            new QueryWrapper<PfAssetDeduction>().eq("pf_asset_id", pfAssertId));
                }
            }
            // 服务期和库存
            for (Long pfOrderId : pfOrderIdList) {
                pfOrderDetailMapper.delete(new QueryWrapper<PfOrderDetail>().eq("pf_order_id", pfOrderId));
            }
            pfOrderStatusMapper.delete(
                    new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", kdtId.toString()));
            pfStockMapper.delete(new QueryWrapper<PfStock>().eq("apply_kdt_id", kdtId));
            pfOrderStockMapper.delete(
                    new QueryWrapper<PfOrderStock>().eq("buy_kdt_id", kdtId.toString()));
            // 延期激活记录表
            pfOrderDetailActiveRecordMapper.delete(
                    new QueryWrapper<PfOrderDetailActiveRecord>().eq("buy_kdt_id", kdtId.toString()));
            // 库存自动充值
            pfRechargeConfigMapper.delete(
                    new QueryWrapper<PfRechargeConfig>().eq("apply_kdt_id", kdtId.toString()));
            // 方案
            pfSchemeMapper.delete(new QueryWrapper<PfScheme>().eq("owner_id", kdtId.toString()));
            for (Long pfOrderId : pfOrderIdList) {
                pfSchemeOrderRelationMapper.delete(
                        new QueryWrapper<PfSchemeOrderRelation>().eq("order_id", pfOrderId));
            }
            //pf_fee_resource_package表
            pfFeeResourcePackageMapper.delete(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdtId.toString()));
            //feeResourcePackageLogMapper
            feeResourcePackageLogMapper.delete(new QueryWrapper<FeeResourcePackageLogDO>().lambda().eq(FeeResourcePackageLogDO::getKdtId,kdtId));
        }
        //pf_fee_resource_package表
        pfFeeResourcePackageMapper.delete(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdtId.toString()));
        //  pf_rights_status
        pfRightsStatusMapper.delete(new QueryWrapper<PfRightsStatus>().eq("apply_kdt_id", kdtId.toString()));
        //feeResourcePackageLogMapper
        feeResourcePackageLogMapper.delete(new QueryWrapper<FeeResourcePackageLogDO>().lambda().eq(FeeResourcePackageLogDO::getKdtId,kdtId));
        //cd_redeem_code_apply_record
        cdRedeemCodeApplyRecordMapper.delete(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getApplyYcmId,kdtId));
        //td_activation_code_apply_record
        tdActivationCodeApplyRecordMapper.delete(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getApplyYcmId,kdtId));
        //procols
        protocolsMapper.delete(new QueryWrapper<Protocols>().lambda().eq(Protocols::getKdtId,kdtId));
        //pf_protection_period
        pfProtectionPeriodMapper.delete(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdtId));
        logger.info("测试数据清理完毕");
    }

    /**
     * @param kdtId
     * @desc 清理微商城缓存
     */
    public void clearCache(String kdtId) {
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        flushAppStatusRequest.setKdtId(kdtId);
        flushAppStatusRequest.setAppId("atom_spu_wsc");
        PlainResult<Boolean> result =
                pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        if (result.isSuccess() == true) {
            logger.info("缓存清理成功");
        } else {
            logger.error("缓存清理失败");
        }
    }

    /**
     * @param kdtId
     * @desc 清理某一appid服务期缓存
     */
    public void clearCacheWithAppId(String kdtId, String appId) {
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        flushAppStatusRequest.setKdtId(kdtId);
        flushAppStatusRequest.setAppId(appId);
        PlainResult<Boolean> result =
                pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        if (result.isSuccess() == true) {
            logger.info("缓存清理成功");
        } else {
            logger.error("缓存清理失败");
        }
    }



    /**
     * 回收店铺下所有未回收的礼包，包括已过期的
     */

    public void recycleGiftAssetByKdtId(Long kdtid) {
        //回收礼包参数
        RecycleGiftAssetRequestBiz recycleGiftAssetRequestBiz = new RecycleGiftAssetRequestBiz();
        recycleGiftAssetRequestBiz.setRemark("初始化店铺-回收礼包");


        //查找店铺下所有未回收的礼包
        List<GiftAsset> giftAssetsList = gfAssetMapper.selectList(new QueryWrapper<GiftAsset>()
                .eq("owner_ycmid", kdtid)
                .eq("owner_ycmid_type", "kdt_id")
                .eq("state", "RECEIVED"));

        for (GiftAsset giftAsset : giftAssetsList) {
            recycleGiftAssetRequestBiz.setGiftAssetId(giftAsset.getId());
            logger.info("礼包资产id：{}", giftAsset.getId());
            PlainResult<RecycleGiftAssetResponse> recycleGiftAssetResponseResult = giftAssetRemoteService.recycleByBackstage(recycleGiftAssetRequestBiz);
            Assert.assertEquals(recycleGiftAssetResponseResult.getCode(), 200, recycleGiftAssetResponseResult.getMessage());
        }

    }

    public void recyleForPfOrder(Long kdtId) {
        //查询店铺下所有已退款但未回收服务期的子订单
        List<PfOrder> pfOrderList = pfOrderMapper.selectList(new QueryWrapper<PfOrder>()
                .eq("apply_kdt_id", kdtId)
                .eq("trade_state","refunded")
                .eq("perform_state","performed"));
        //回收服务期
        for(PfOrder pfOrder:pfOrderList) {
            pfRefundRemoteService.recycleForPfOrder(pfOrder.getId());
        }

    }

    /**
     * 初始化店铺：关单、退款、回收礼包
     *
     * @param kdtId
     */
    public void initShopByKdtId(Long kdtId) {
        closeWaitPayOrder(kdtId);
        refundOrderByKdtId(kdtId);
        recycleGiftAssetByKdtId(kdtId);
        //这个是用来回收退款成功但服务期回收失败的
        //recyleForPfOrder(kdtId);
    }

    /**
     * 根据子订单号确定订单对应的appid
     */
    public String getAppIdByPfOrderId(String pfOrderId) {
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("id", Long.valueOf(pfOrderId)));
        String ycmAppId = pfOrder.getAppId();
        return ycmAppId;

    }

    public PlainResult<CalOrderPriceApi> calOrderPrice(Long kdtId, String kdtName, int itemId, int quantity) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(kdtId, kdtName, orderItemFormList);
        logger.info("确认订单-参数：{}",JSON.toJSON(calOrderPriceForm));

        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
        logger.info("确认订单-订单计算返回数据：{}",JSON.toJSON(calOrderPriceApiPlainResult));

        return calOrderPriceApiPlainResult;
    }

    public PlainResult<String> createNormalOrderWithNoPromotion(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        logger.info("创建订单参数：{}",JSON.toJSONString(createOrderForm));
        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);
        logger.info("创建订单结果：{}",JSON.toJSONString(resultCreateNormalOrder));

        return resultCreateNormalOrder;
    }


    public PlainResult<String> createNormalOrder(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        //获取商品的优惠
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(kdtId,1,itemId,quantity,1);

        logger.info("优惠信息：{}",itemPreferentialInfoResult);
        //将获取到的商品级优惠传入参数
        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();
        if(itemPreferentialInfoResult.getData().size()>0) {
            //做非null判断
            if(itemPreferentialInfoResult.getData().get(0).getPresentList() != null) {
                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPresentList());
            }
            if(itemPreferentialInfoResult.getData().get(0).getPromotionList() != null) {
                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPromotionList());
            }
            //如果创建订单的时候使用了有赞币，则续费送有赞币的优惠要排除
            if(yzb>0){
                itemPromotionList = itemPromotionList.stream().filter(v -> v.getType()!=6).collect(Collectors.toList());
            }
            //将商品级优惠放入orderItemFormList
            orderItemForm.setItemPromotionList(itemPromotionList);
        }

        //获取订单级别的优惠
        CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(kdtId, kdtName, orderItemFormList);

        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
        logger.info("确认订单-订单计算返回数据：{}",JSON.toJSON(calOrderPriceApiPlainResult));

        //将订单级别优惠传入参数
        //满减优惠,并过滤掉selected = false的优惠
        List<PreferentialDescApi> orderPromotionList = new ArrayList<>();

        for(int OrderPromotionNum = 0;OrderPromotionNum < calOrderPriceApiPlainResult.getData().getOrderPromotionList().size();OrderPromotionNum++) {
            List<PreferentialDescApi> getFullReduceList = calOrderPriceApiPlainResult.getData().getOrderPromotionList().get(OrderPromotionNum).getOrderPromotionMutexList().
                    stream().filter(v -> v.getSelected()!=false).collect(Collectors.toList());
            orderPromotionList.addAll(getFullReduceList);
        }

        if(calOrderPriceApiPlainResult.getData().getTotalRealPrice() == 0) {
            yzb = 0L;
        }
        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList, orderPromotionList,yzb);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        logger.info("创建订单参数：{}",JSON.toJSONString(createOrderForm));
        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);
        logger.info("创建订单结果：{}",JSON.toJSONString(resultCreateNormalOrder));

        return resultCreateNormalOrder;
    }

    public PlainResult<String> createNormalOrderWithMultiApp(Long kdtId, String kdtName, List<Integer> itemList, int quantity, Long yzb) {
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        List<PreferentialDescApi> orderPromotionList = new ArrayList<>();


        for(int i = 0;i <itemList.size();i++) {
            if(itemList.get(i) == 73454 || itemList.get(i) == 73455){
                quantity = 1;
            }
            //构造item参数
            OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(Integer.valueOf(itemList.get(i)), quantity);
            //获取商品的优惠
            PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(kdtId,1,Integer.valueOf(itemList.get(i)),quantity,1);

            logger.info("优惠信息：{}",JSON.toJSONString(itemPreferentialInfoResult));
            List<PreferentialDescApi> itemPromotionList = new ArrayList<>();
            //将获取到的商品级优惠传入参数
            if(itemPreferentialInfoResult.getData().size()>0) {
                //做非null判断
                if(itemPreferentialInfoResult.getData().get(0).getPresentList() != null) {
                    itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPresentList());
                }
                if(itemPreferentialInfoResult.getData().get(0).getPromotionList() != null) {
                    itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPromotionList());
                }
                //如果创建订单的时候使用了有赞币，则续费送有赞币的优惠要排除,有赞币的营销类型为6
                if(yzb>0){
                    itemPromotionList = itemPromotionList.stream().filter(v -> v.getType()!=6).collect(Collectors.toList());
                }
                //将商品级优惠放入orderItemFormList
                orderItemForm.setItemPromotionList(itemPromotionList);
            }
            orderItemFormList.add(orderItemForm);

            //获取订单级别的优惠
            CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(kdtId, kdtName, orderItemFormList);
            PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
            logger.info("确认订单-订单计算返回数据：{}",JSON.toJSON(calOrderPriceApiPlainResult));

            //将订单级别优惠传入参数
            //满减优惠,并过滤掉selected = false的优惠
            for(int OrderPromotionNum = 0;OrderPromotionNum < calOrderPriceApiPlainResult.getData().getOrderPromotionList().size();OrderPromotionNum++) {
                List<PreferentialDescApi> getFullReduceList = calOrderPriceApiPlainResult.getData().getOrderPromotionList().get(OrderPromotionNum).getOrderPromotionMutexList().
                        stream().filter(v -> v.getSelected()!=false).collect(Collectors.toList());
                orderPromotionList.addAll(getFullReduceList);
            }

        }
        //对orderPromotionList过滤一下（因为不同的插件可能会有相同的订单级别优惠）
        List<PreferentialDescApi> newOrderPromotionList = orderPromotionList.stream().collect(
                Collectors. collectingAndThen(
                        Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PreferentialDescApi::getName))), ArrayList::new));

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList, newOrderPromotionList,yzb);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");
        logger.info("创建订单参数：{}",JSON.toJSONString(createOrderForm));

        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);

        return resultCreateNormalOrder;
    }


    public PlainResult<List<ItemPreferentialInfoResultApi>> fetchItemPreferentialInfoOnline(Long kdtId,Integer period,Integer itemId,Integer quantity,Integer duration) {
        ItemPreferentialInfoFetchForm itemPreferentialInfoFetchForm = new ItemPreferentialInfoFetchForm();
        List<OrderItemForm> itemList = new ArrayList<>();
        OrderItemForm orderItemForm = new OrderItemForm();
        orderItemForm.setItemId(itemId);
        orderItemForm.setQuantity(quantity);
        orderItemForm.setDuration(duration);
        itemList.add(orderItemForm);
        itemPreferentialInfoFetchForm.setPeriod(period);
        itemPreferentialInfoFetchForm.setItemList(itemList);
        itemPreferentialInfoFetchForm.setKdtId(kdtId);

        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = orderRemoteService.fetchItemPreferentialInfoOnline(itemPreferentialInfoFetchForm);

        return itemPreferentialInfoResult;
    }




    public PlainResult<OrderCreateApi> createOrderV2WithMultiApp(Long kdtId, String kdtName, Map<Integer,List<Long>> itemInfo, int quantity, byte buyType, Long yzb) {
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        List<PreferentialDescApi> orderPromotionList = new ArrayList<>();

        for (Map.Entry<Integer, List<Long>> vo : itemInfo.entrySet()) {
            int quantityTmp = quantity;
            if (vo.getKey() == 8168 || vo.getKey() == 8164) {
                quantityTmp = 1;
            }
            if(vo.getValue().size() > 0) {
                for (Long applyKdtId : vo.getValue()) {
                    OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(vo.getKey(), quantityTmp);
                    orderItemForm.setBuyType(buyType);
                    if (buyType == (byte) 2) {
                        orderItemForm.setApplyKdtId(applyKdtId);
                    }
                    orderItemFormList.add(orderItemForm);
                }
            }else {
                OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(vo.getKey(), quantityTmp);
                orderItemForm.setBuyType(buyType);
                orderItemFormList.add(orderItemForm);
            }

        }

        //获取订单级别的优惠
        ConfirmOrderForm confirmOrderForm = ConstructionParam.getConfirmOrderForm(kdtId, kdtName, orderItemFormList);
        PlainResult<OrderConfirmApi> confirmOrderResult = orderRemoteService.confirmOrder(confirmOrderForm);
        logger.info("确认订单-订单计算返回数据：{}",JSON.toJSON(confirmOrderResult));

        //将订单级别优惠传入参数
//        for(int OrderPromotionNum = 0;OrderPromotionNum < confirmOrderResult.getData().getOrderPromotionList().size();OrderPromotionNum++) {
//            List<PreferentialDescApi> getFullReduceList = confirmOrderResult.getData().getOrderPromotionList().get(OrderPromotionNum).getOrderPromotionMutexList().
//                    stream().filter(v -> v.getSelected()!=false).collect(Collectors.toList());
//            orderPromotionList.addAll(getFullReduceList);
//        }

        if(isNotEmpty(confirmOrderResult.getData().getOrderPromotionList())) {
            PreferentialDescApi getFullReduce = confirmOrderResult.getData().getOrderPromotionList().get(0).getOrderPromotionMutexList().get(0);
            orderPromotionList.add(getFullReduce);
        }

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,orderPromotionList,yzb);

        logger.info("创建订单参数：{}", JSON.toJSONString(createOrderForm));

        PlainResult<OrderCreateApi> resultCreateOrderV2 =
                orderRemoteService.createOrderV2(createOrderForm);

        return resultCreateOrderV2;
    }

    public Long getYopAppId(String ycmId) {
        GdGoodsIdMapping gdGoodsIds = gdGoodsIdMappingMapper.selectOne(new QueryWrapper<GdGoodsIdMapping>().eq("ycm_id", ycmId));
        Long yopId = Long.valueOf(gdGoodsIds.getYopId());
        return yopId;
    }

    /**
     * 同步店铺下所有插件+软件的服务期，并刷新缓存（不包括权益商品）
     *
     * @param kdtId
     */
    public void concurrentStatus(Long kdtId) {
        //String ycmAppId = getYcmAppId(appId);

        //根据kdtId查询店铺下所有的插件&软件服务期（权益不包括）
        //查询服务期的sql语句
        List<PfOrderStatus> pfOrderStatusList = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().select("DISTINCT app_id")
                .eq("apply_ycm_id", kdtId)
                .eq("apply_ycm_type", "KDT_ID"));
        List<String> appIds = new ArrayList<>();

        //刷新店铺内所有服务期的缓存,同步服务期
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        //flushAppStatusRequest.setAppId(ycmAppId);
        flushAppStatusRequest.setKdtId(String.valueOf(kdtId));
        pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        for (PfOrderStatus pfOrderStatus : pfOrderStatusList) {
            Long yopId = getYopAppId(pfOrderStatus.getAppId());
            //同步服务期
            marketRemoteService.concurrentStatus(kdtId, yopId.intValue());
        }
    }


    /**
     * 不考虑kdtid下有的服务期，ycm系统所有商品进行缓存删除
     * @param kdtId
     */
    public void clearCache(Long kdtId) {
        List<String> appIds = listAllSPU();
            appIds.forEach(appId -> {
                String key = String.format(KvdsConstants.PF_ORDER_STATUS_KEY, kdtId,"KDT_ID", appId);
                redisClient.opsForKey().del(key);
        });
    }

    /**
     * 获取系统所有商品
     * @return
     */
    public List<String> listAllSPU() {
        GoodsSPUListRequest request = new GoodsSPUListRequest();
        request.setNeedPageable(false);
        PlainResult<PageResponse<GoodsSPUResponse>> result = goodsRemoteService.queryGoodsSPUList(request);
        if (result.isSuccess() && Objects.nonNull(result.getData())) {
            PageResponse<GoodsSPUResponse> response = result.getData();
            List<GoodsSPUResponse> goodsSPUResponses = response.getData();
            if (isNotEmpty(goodsSPUResponses)) {
                return goodsSPUResponses.stream().map(GoodsSPUResponse::getAppId).collect(Collectors.toList());
            }
        }
        return new ArrayList<>();
    }


    /**
     * 获取新店铺方法（不适用连锁店铺）
     * prodCode:微商城单店："wsc",零售单店："retail",教育单店："edu"
     * @return
     */
    public EnableNewKdtIdResponse getKdtId(String prodCode) {
        long id = Thread.currentThread().getId();
        logger.info("开始占用新店铺...");
        EnableNewShopPoolService enableNewShopPoolService = DubboUtil.getReference(EnableNewShopPoolService.class);
        PlainResult<EnableNewKdtIdResponse> result = enableNewShopPoolService.concurrentGetNewKdtId(prodCode);
        if (result.isSuccess() == false) {
            logger.info("获取店铺失败");
            return null;
        }else {
            logger.info("新店铺信息：" +JSON.toJSONString(result));
            return result.getData();
        }
    }

    public PlainResult<CreateOfflineOrderResponse> createOfflineOrderV2(
            Long kdtId, Integer itemId, Integer quantity, Integer realPrice) {
        try {
            clearCache(String.valueOf(kdtId));
            OfflineOrderFormV2 offlineOrderFormV2 = new OfflineOrderFormV2();

            offlineOrderFormV2.setKdtId(kdtId.toString());
            offlineOrderFormV2.setNeedAdminSign((byte) 0);
            offlineOrderFormV2.setOperatorId(3046l);
            offlineOrderFormV2.setRealPrice(realPrice);
            offlineOrderFormV2.setType(0);
            offlineOrderFormV2.setDiscountAmount(0L);
            offlineOrderFormV2.setOriginPrice(0L);
            offlineOrderFormV2.setUserId(123L);

            List<OrderItemFormV2> items = new ArrayList<>();
            OrderItemFormV2 orderItemForm = new OrderItemFormV2();
            orderItemForm.setItemId(itemId);
            orderItemForm.setQuantity(quantity);
            orderItemForm.setBuyType((byte) 1);
            orderItemForm.setApplyKdtId(kdtId.toString());
            orderItemForm.setNewMigration(null);
            items.add(orderItemForm);

            offlineOrderFormV2.setItems(items);
            logger.info("request=",offlineOrderFormV2.toString());

            PlainResult<CreateOfflineOrderResponse> result = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2);
            logger.info("createOfflineOrderV2线下订单创建结果：");
            logger.info(JSON.toJSONString(result));
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }





    public enum ItemInfo {
        WSC_JC_6800("微商城（2020）基础版-微信小程序", 873, 8157, 680000, 1, 57520, null),
        WSC_JC_6800_new("微商城（2020）基础版-微信小程序", 873, 8530, 680000, 1, 57520, null),
        WSC_JY_12800("微商城(2020)专业版", 873, 8532, 1280000, 1, 57522, null),
        WSC_QJ_26800("微商城(2020)旗舰版", 873, 8160, 2680000, 1, 57523, null),
        Professional_Net("专业网店（2019）", 50006, 8112, 1280000, 1, null, null),
        WSC_WX_680000_2021("电商（2021）基础版（微信小程序）", 873, 8530, 680000, 1, null, null),
        WSC_BD_680000_2021("电商（2021）基础版（百度小程序）", 873, 8531, 680000, 1, null, null),
        WSC_PF_1280000_2021("电商（2021）专业版", 873, 8532, 1280000, 1, null, null),
        WSC_QJ_2680000_2021("电商（2021）旗舰版", 873, 8533, 2680000, 1, null, null),
        KANJIA_0_BUY("砍价0元购",24276,781,128800,1,null,null),


        WSC_JC_BD_1("微商城(2020)基础版-百度小程序", 873, 8158, 680000, 1, null, null),
        YUN_POS("云pos", 34082, 7179, 200000, 1, null, null),
        STAFF_YEARS("店铺员工1年期", 31458, 7166, 36500, 1, null, null),
        MULTI_STORE_NUM_YEARS("多网点个数", 27890, 7079, 30000, 1, null, null),

        //教育
        EDU_BASE_ONLINE("有赞教育（2020）基础版", 39748, 74217, 680000, 1, null, null),
        EDU_PROFESSION_ONLINE("有赞教育（2020）专业版", 39748, 74219, 1280000, 1, null, null),

        //零售
        LS_BASE_WX("有赞零售（2020）基础版-微信小程序", 6075, 8281, 880000, 1, null, null),
        LS_BASE_BD("有赞零售（2020）基础版-百度小程序", 6075, 8282, 880000, 1, null, null),
        LS_BASE_OFFLINE("有赞零售（2020）专业版", 6075, 8283, 1480000, 1, null, null),
        LS_ZFB_6800_2021("同城基础版2021-支付宝小程序", 6075, 8273, 680000, 1, null, null),
        LS_BD_680000_2021("同城基础版2021-百度小程序", 6075, 8272, 680000, 1, null, null),
        LS_WX_680000_2021("同城基础版2021-微信小程序", 6075, 8271, 680000, 1, null, null),
        LS_ZY_1280000_2021("同城专业版2021", 6075, 8274, 1280000, 1, null, null),
        SMS_1000("短信充值1000条", 9638, 613, 5000, 1000, null,null),

        //美业
        BEAUTY_JC_6800("美业基础版一年期",6281,8163,380000,1,null,null),
        BEAUTY_STORE("美业门店",11228,8165,300000,1,null,null),
        BEAUTY_POINT_STORE("美业积分商城",36281,7187,68800,1,null,null),
        //零售连锁4.0L总部
        RETAIL_CHAIN_L_4_UNION("零售连锁-总部(旗舰版)",50666,8414,4980000,1,null,null),
        //零售连锁4.0D总部
        RETAIL_CHAIN_D_4_UNION("零售连锁-总部(旗舰版)",50777,8434,4980000,1,null,null);

        /*SMS_1000("短信充值1000条", 9638, 613, 5000, 1000, null,null),
        JFSC_12("积分商城12个月", 2, 4, 128800, 1, null,null),
        WSC_JY_12800("微商城(2020)专业版", 873, 8159, 1280000, 1, 57522,null),
        RETAIL_CHAIN_UINON("大网店总部开通费",38607,7227,1000000,1,null,null),
        RETAIL_CHAIN_STORE_MANAGE("零售连锁门店管理费",38391,7221,100000,1,null,null),
        RETAIL_CHAIN_MEDIUM("多网店总部开通费",38687,7231,1000000,1,2845,null),
        RETAIL_CHAIN_STORE_MANAGE_MALL("零售连锁门店商城",38610,7229,200000,1,null,null),
        RETAIL_CHAIN_UNION_MALL_JC("总部商城基础版",38408,7222,680000,1,2849,null),
        RETAIL_CHAIN_CHAIN_VERSION("零售连锁-连锁版",42514,7279,1000000,1,null,null),
        RETAIL_CHAIN_STORE_AREA_MALL("区域商城",42397,7277,1280000,1,2984,null),
        RETAIL_CHAIN_STORE_STORE_MALL("门店商城",42395,7278,200000,1,2983,null),
        EDU_BASE("有赞教育基础版一年期",39748,7252,598800,1,null,null),
        WSC_EXTEND_PACKAGE("微商城扩展包",39745,7251,258000,1,null,null),
        FRIEND_PATITION_TICKET("好友瓜分券",18748,769,128800,1,null,null),
        DISCOUNT_PACKAGE("优惠套餐",706,29,68800,1,null,null),
        RETAIL_DD_12800("有赞零售单店专业版一年期",6075,7182,1280000,1,2188,null),
        MULTI_STORE_ID("多网点服务",32032,7092,68800,1,null,null);*/

        private String name;
        private Integer appId;
        private Integer itemId;
        private Integer money;
        private Integer quantity;
        private Integer preferentialId;

        /**
         * 扩展字段，激活码id
         */
        private Integer extend;

        ItemInfo(String name, Integer appId, Integer itemId, Integer money, Integer quantity, Integer preferentialId, Integer extend) {
            this.name = name;
            this.appId = appId;
            this.itemId = itemId;
            this.money = money;
            this.quantity = quantity;
            this.preferentialId = preferentialId;
            this.extend = extend;
        }

        public String getName() {
            return name;
        }

        public Integer getAppId() {
            return appId;
        }

        public Integer getItemId() {
            return itemId;
        }

        public Integer getMoney() {
            return money;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public Integer getPreferentialId() {
            return preferentialId;
        }

        public Integer getExtend() {
            return extend;
        }

        public void setExtend(Integer extend) {
            this.extend = extend;
        }
    }
}
