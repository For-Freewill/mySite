package com.youzan.test.market.basecase.activity;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.response.activity.SaveGoodsDiscountActivityResponse;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-03-26 19:06
 **/

public class DiscountActivityWithMoreDiscountRuleTest extends TnBaseTest {

    @JSONData(value = "dataResource/apicase.market/DiscountActivityRequestData.json", key = "orderWithDiscountRequest")
    private CreateOrderForm orderWithDiscountRequest;

    //用来做营销满减 & 打折的订购的微商城的店铺
    public static Long DiscountKDTID = 58802881L;
    public static String DiscountKDTIDNAME = "故障注入测试6";

    /**
     * biz后台创建打折活动，活动名称：打折活动CI田宁专用-勿动
     * 配置：参与方式：WITH_ANY_APPS  次数：不限制
     * 单商品：WSC基础版百度小程序
     * 多规则：个数在【1，2】 打8折；个数在【3，4】打2折
     * 订购WSC
     * 验证：打折活动满足使用条件，可以正常使，且金额按照打折活动计算后正确    预期应该是打8折：6800 * 0.8 = 5440
     */
    @Test
    public void createOrderWithDiscountActivityWithGoodsTest() {

        closeWaitPayOrder(DiscountKDTID);

        refundOrderByKdtId(DiscountKDTID);

        try {
            PlainResult<SaveGoodsDiscountActivityResponse> createDiscountActivityResult = createDiscountActivityWithMoreDiscountRule();
            Assert.assertEquals(createDiscountActivityResult.getCode(), 200);

            //查询DB，确认打折活动OK
            List<MkActivity> mkActivityLists =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().eq("name", discountName).eq("state", "AUDITED_PASS").orderByDesc("created_at"));
            Assert.assertEquals(mkActivityLists.get(0).getId().toString(), createDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId());
            Assert.assertEquals(mkActivityLists.get(0).getState(), "AUDITED_PASS");

            List<OrderItemForm> items = new ArrayList<>();
            OrderItemForm orderItemForm = new OrderItemForm();

            List<PreferentialDescApi> itemPromotionList = new ArrayList<>();
            PreferentialDescApi preferentialDescApi = new PreferentialDescApi();
            preferentialDescApi.setType((byte) 23);
            preferentialDescApi.setName("打折活动CI田宁专用-勿动，打折活动CI田宁专用-勿动");
            preferentialDescApi.setDesc("打折活动CI田宁专用-勿动");
            preferentialDescApi.setSelected(true);
            preferentialDescApi.setReduceAmount(136000L);
            preferentialDescApi.setPromotionId(Long.valueOf(createDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId()));

            itemPromotionList.add(preferentialDescApi);
            orderItemForm.setItemPromotionList(itemPromotionList);

            orderItemForm.setItemId(8531);
            orderItemForm.setQuantity(1);
            orderItemForm.setDuration(1);

            items.add(orderItemForm);

            orderWithDiscountRequest.setItems(items);

            PlainResult<String> createNormalOrderResult = createNormalOrder(orderWithDiscountRequest, DiscountKDTID);
            Assert.assertEquals(createNormalOrderResult.getCode(), 200);

            List<TdOrder> tdOrderList = queryTdOrderByKdtIdAndState(DiscountKDTID);

            //预期 orig_price = 680000  currency_amt = 544000  promotion_amt = currency_amt=136000
            Long orig_price = tdOrderList.get(0).getOrigPrice();
            Long promotion_amt = tdOrderList.get(0).getPromotionAmt();
            Long currency_amt = tdOrderList.get(0).getCurrencyAmt();

            //原始金额=实际金额*0.8
            currency_amt = orig_price - orig_price * 8/10;
            Assert.assertEquals(currency_amt.longValue(), 136000L);

        } finally {
            invalidDiscountActivity();
            deleteDiscountActivity();
        }
    }
}
