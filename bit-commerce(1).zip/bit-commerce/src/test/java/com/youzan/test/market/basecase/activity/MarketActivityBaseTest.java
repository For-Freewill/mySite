package com.youzan.test.market.basecase.activity;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.MkItemResult;
import com.youzan.commerce.test.entity.dataobject.market.MkJoinRecord;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivitySnapshot;
import com.youzan.commerce.test.entity.dataobject.market.coupon.*;
import com.youzan.commerce.test.mapper.market.JoinRecordMapper;
import com.youzan.commerce.test.mapper.market.MkItemResultMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityRuleMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivitySnapchatMapper;
import com.youzan.commerce.test.mapper.market.coupon.*;
import com.youzan.test.basecase.SimpleToolBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.api.*;
import com.youzan.ycm.market.request.activity.UpdateActivityStateRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.request.coupon.UpdateCouponStateRequest;
import com.youzan.ycm.market.request.couponasset.RecycleCouponAssetRequest;
import com.youzan.ycm.market.request.couponsend.SaveSendCouponRequest;
import com.youzan.ycm.market.request.couponsend.SendCouponAssetRequest;
import com.youzan.ycm.market.response.activity.GoodsDiscountActivityResponse;
import com.youzan.ycm.market.response.activity.OrderFullReduceActivityResponse;
import com.youzan.ycm.market.response.coupon.SaveCouponResponse;
import com.youzan.ycm.market.response.coupon.UpdateCouponStateResponse;
import com.youzan.ycm.market.response.couponasset.RecycleCouponAssetResponse;
import com.youzan.ycm.market.response.couponsend.SaveCouponSendRecordResponse;
import com.youzan.ycm.market.response.couponsend.SendCouponResponse;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author leifeiyun
 * @date 2020/11/17
 **/
public class MarketActivityBaseTest extends SimpleToolBaseTest {
    @Dubbo
    CouponRemoteService couponRemoteService;
    @Dubbo
    CouponSendRemoteService couponSendRemoteService;
    @Dubbo
    OrderFullReduceActivityRemoteService orderFullReduceActivityRemoteService;

    @Dubbo
    GoodsDicountActivityuRemoteService goodsDicountActivityuRemoteService;

    @Dubbo
    CouponAssetRemoteService couponAssetRemoteService;
    @Autowired(required = false)
    ActivityRuleMapper activityRuleMapper;
    @Autowired(required = false)
    ActivityMapper activityMapper;

    @Autowired(required = false)
    ActivitySnapchatMapper activitySnapchatMapper;
    @Autowired(required = false)
    JoinRecordMapper joinRecordMapper;
    @Autowired(required = false)
    MkItemResultMapper mkItemResultMapper;

    @Autowired(required = false)
    CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    CouponMapper couponMapper;
    @Autowired(required = false)
    CouponRuleMapper couponRuleMapper;
    @Autowired(required = false)
    CouponSnapshotMapper couponSnapshotMapper;
    @Autowired(required = false)
    CouponSendRecordMapper couponSendRecordMapper;
    @Autowired(required = false)
    CouponSendRecordDetailMapper couponSendRecordDetailMapper;


    @JSONData("dataResource/basecase.activity/couponSendRecord.json")
    private SaveSendCouponRequest saveSendCouponRequest;
    @JSONData("dataResource/basecase.activity/discountCouponForMemberCard.json")
    private SaveCouponRequest saveDiscountCoupon;

    public void deleteActivityConfigData(String activityId) {
        logger.info("开始清理活动数据，活动id---->:" + activityId);
        activityMapper.delete(new QueryWrapper<MkActivity>()
                .eq("id", activityId));
        activityRuleMapper.delete(new QueryWrapper<MkActivityRule>()
                .eq("activity_id", activityId));
        activitySnapchatMapper.delete(new QueryWrapper<MkActivitySnapshot>()
                .eq("activity_id", activityId));
        List<MkJoinRecord> mkJoinRecordList = joinRecordMapper.selectList(new QueryWrapper<MkJoinRecord>()
                .eq("mk_id", activityId));
        if (mkJoinRecordList.size() > 0) {
            mkItemResultMapper.delete(new QueryWrapper<MkItemResult>()
                    .in("join_record_id", mkJoinRecordList.stream().map(MkJoinRecord::getId).collect(Collectors.toList())));
            joinRecordMapper.delete(new QueryWrapper<MkJoinRecord>()
                    .eq("mk_id", activityId));
        }


    }

    public void deleteActivityConfigDataWithoutJoinRecord(String activityId) {
        logger.info("开始清理活动数据，活动id---->:" + activityId);
        activityMapper.delete(new QueryWrapper<MkActivity>()
                .eq("id", activityId));
        activityRuleMapper.delete(new QueryWrapper<MkActivityRule>()
                .eq("activity_id", activityId));
        activitySnapchatMapper.delete(new QueryWrapper<MkActivitySnapshot>()
                .eq("activity_id", activityId));


    }

    /**
     * 清理券数据
     *
     * @param couponId
     */
    public void deleteCouponData(Long couponId) {
        logger.info("-----------开始清理礼包券配置信息----------");
        logger.info("-----------礼包券id+" + couponId + "----------");
        couponMapper.delete(new QueryWrapper<MkCoupon>().eq("id", couponId));
        couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().eq("coupon_id", couponId));
        couponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshot>().eq("coupon_id", couponId));
        couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().eq("coupon_id", couponId));
        List<MkCouponSendRecord> mkCouponSendRecordList = couponSendRecordMapper.selectList(new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId));
        couponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId));

        if (mkCouponSendRecordList != null) {
            for(MkCouponSendRecord mkCouponSendRecord : mkCouponSendRecordList)
            couponSendRecordDetailMapper.delete(new QueryWrapper<MkCouponSendRecordDetail>().eq("send_record_id", mkCouponSendRecord.getId()));
        }
    }

    /**
     * 上架权益
     *
     * @param couponId
     */
    public void updateCouponState(String couponId) {
        UpdateCouponStateRequest updateCouponStateRequest = new UpdateCouponStateRequest();
        updateCouponStateRequest.setOperator("leifeiyun");
        updateCouponStateRequest.setCouponState("ONLINE");
        updateCouponStateRequest.setCouponId(couponId);
        PlainResult<UpdateCouponStateResponse> updateCouponStateResponsePlainResult = couponRemoteService.updateCouponState(updateCouponStateRequest);
        Assert.assertEquals(updateCouponStateResponsePlainResult.getCode(), 200);

    }

    /**
     * 生成发券单并发送优惠券
     *
     * @param couponId
     * @param couponName
     */
    public void generateSendRecordAndSendCoupon(String couponId, String couponName) {
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String sendRecordCouponName = couponName + dateString;
        //组装发券单
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponId(couponId);
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponName(sendRecordCouponName);
        PlainResult<SaveCouponSendRecordResponse> discountCouponSendRecord = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);
        //发放优惠券券
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        sendCouponAssetRequest.setCouponSendRecordId(discountCouponSendRecord.getData().getCouponSendRuleDTO().getCouponSendRecordId());
        sendCouponAssetRequest.setSendOperator("leifeiyun");
        PlainResult<SendCouponResponse> sendResult = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);
        Assert.assertEquals(sendResult.getCode(), 200);
    }

    /**
     * 创建权益券
     *
     * @param couponName
     * @param saveCouponRequest
     * @return
     */
    public String createCoupon(String couponName, SaveCouponRequest saveCouponRequest) {
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String discountCouponName = couponName + dateString;
        saveCouponRequest.getAllCouponDTO().setName(discountCouponName);
        PlainResult<SaveCouponResponse> discountSaveResult = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = discountSaveResult.getData().getAllCouponDTO().getCouponId();
        Assert.assertEquals(discountSaveResult.getCode(), 200);
        return couponId;
    }

    /**
     * 回收券资产
     *
     * @param couponId
     */
    public void recycleCouponAsset(String couponId) {
        RecycleCouponAssetRequest recycleCouponAssetRequest = new RecycleCouponAssetRequest();
        recycleCouponAssetRequest.setCouponAssetId(couponId);
        recycleCouponAssetRequest.setOpScene("BIZ");
        PlainResult<RecycleCouponAssetResponse> recycleCouponAssetResult = couponAssetRemoteService.recycleCouponAsset(recycleCouponAssetRequest);
        Assert.assertNotNull(recycleCouponAssetResult.getData().getCouponAssetDTO());
        Assert.assertEquals(recycleCouponAssetResult.getCode(), 200);
        Assert.assertEquals(recycleCouponAssetResult.getMessage(), "successful");

    }

    /**
     * 失效满减活动
     *
     * @param activityId
     */
    public void expireFullReduceActivity(String activityId) {
        //失效满减活动
        UpdateActivityStateRequest updateActivityStateRequest = new UpdateActivityStateRequest();
        updateActivityStateRequest.setActivityId(activityId);
        updateActivityStateRequest.setActivityState("EXPIRED");
        updateActivityStateRequest.setOperator("leifeiyun");
        PlainResult<OrderFullReduceActivityResponse> stateChangeResult =
                orderFullReduceActivityRemoteService.updateActivityState(updateActivityStateRequest);

        Assert.assertEquals(stateChangeResult.getCode(), 200, stateChangeResult.getMessage());
        Assert.assertEquals(stateChangeResult.getMessage(), "successful");
        Assert.assertEquals(stateChangeResult.getData().getFullReduceActivityDTO().getActivityState(), "EXPIRED");
    }

    /**
     * 失效打折活动
     *
     * @param activityId
     */
    public void expireDiscountActivity(String activityId) {
        //失效满减活动
        UpdateActivityStateRequest updateActivityStateRequest = new UpdateActivityStateRequest();
        updateActivityStateRequest.setActivityId(activityId);
        updateActivityStateRequest.setActivityState("EXPIRED");
        updateActivityStateRequest.setOperator("leifeiyun");
        PlainResult<GoodsDiscountActivityResponse> stateChangeResult =
                goodsDicountActivityuRemoteService.updateActivityState(updateActivityStateRequest);

        Assert.assertEquals(stateChangeResult.getCode(), 200, stateChangeResult.getMessage());
        Assert.assertEquals(stateChangeResult.getMessage(), "successful");
        Assert.assertEquals(stateChangeResult.getData().getGoodsDiscountActivityDTO().getActivityState(), "EXPIRED");
    }

    /**
     * 优惠类型:1:打折，2:赠送，3:打包购买优惠，4:硬件，5:礼包，6:有赞币,8:搭配购,9:插件套餐，21:满减活动，22:券资产，23:打折活动
     *
     * @see -com.youzan.yop.market.enums.PreferentialPackageType
     */
    public PreferentialDescApi generatePreferential(String promotionId, Byte type) {
        PreferentialDescApi preferentialDescApi = new PreferentialDescApi();
        switch (type) {
            case 21:
                MkActivity mkActivity = getMKActivity(promotionId);
                preferentialDescApi.setName(mkActivity.getName());
                break;
            case 22:
                MkCouponAsset mkCouponAsset = getMKCoupon(promotionId);
                preferentialDescApi.setName(mkCouponAsset.getName());
                break;
            case 23:
                mkActivity = getMKActivity(promotionId);
                preferentialDescApi.setName(mkActivity.getName());
                break;
        }
        preferentialDescApi.setPromotionId(Long.valueOf(promotionId));
        preferentialDescApi.setType(type);
        return preferentialDescApi;
    }

    public MkCouponAsset getMKCoupon(String couponAssetId) {
        MkCouponAsset mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("id", couponAssetId));
        return mkCouponAsset;
    }

    public MkActivity getMKActivity(String activityId) {
        MkActivity mkActivity = activityMapper.selectOne(new QueryWrapper<MkActivity>().eq("id", activityId));
        return mkActivity;
    }


    @Test(enabled = false)
    public void testTemp() {
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String sendRecordCouponName = "28317日常test" + dateString;
        //组装发券单
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponId("3503");
        saveSendCouponRequest.getCouponSendRuleDTO().setCouponName(sendRecordCouponName);
        saveSendCouponRequest.getCouponSendRuleDTO().setKdtIdList(Arrays.asList("58112001"));
        PlainResult<SaveCouponSendRecordResponse> discountCouponSendRecord = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);
        //发放优惠券券
        SendCouponAssetRequest sendCouponAssetRequest = new SendCouponAssetRequest();
        sendCouponAssetRequest.setCouponSendRecordId(discountCouponSendRecord.getData().getCouponSendRuleDTO().getCouponSendRecordId());
        sendCouponAssetRequest.setSendOperator("leifeiyun");
        PlainResult<SendCouponResponse> sendResult = couponSendRemoteService.sendCoupon(sendCouponAssetRequest);
        Assert.assertEquals(sendResult.getCode(), 200);
    }

    @Test(enabled = false)
    public void testDeleteCoupon() {
        //需要有事没事就去清理一波数据
        /**
         * select group_concat(id) from mk_coupon where name like '%auto-lfy-打折券%';
         *
         * select * from mk_coupon where name like '%auto-lfy-打折券%';
         */
        List<Integer> integerList = Arrays.asList(14185,14186,14187);
        for (int id : integerList) {
            deleteCouponData(Long.valueOf(id));
        }
    }

    @Test(enabled = false)
    public void testDeleteActivity(){
        /**
         * select * from mk_activity where name like '%auto-lfy-%';
         * select group_concat(id) from mk_activity where name like '%auto-lfy-%';
         */
        List<Integer> integerList = Arrays.asList(6289,6291,6831,7492,7493,7637,7638,7725,7879,7968,8058,8109,8160,8232,8233,8309,8369,8396,8397,8500,8557,8558,8644,8711,8772,8885,8982,9075,9079,9284,9331,9381,9485,9596,9785,9919,10010,11718,11825,11832,11856,12224,12296,12900,12974,13029,13030,13031,13034,13035,13036,13043,13045,13132,13214,13325,13413,13442,13530,13544,13606,13629,13792,13872,13873,13890,13923,14030,14047,14063,14204,14239,14281,14295,14353,14371,14424,14435,14449,14463,14488,14508,14521,14527,14555,14587,14605,14630,14658,14780,14831,14848,14855,14872,14878,14879,14907,14916,14961,14969,14997,15005,15034,15043,15060,15082,15096,15130,16107);
        for (int id : integerList) {
            deleteActivityConfigData(String.valueOf(id));
        }
    }


    public void deleteLfyCouponData(){
        List<MkCoupon> mkCouponList = couponMapper.selectList(new QueryWrapper<MkCoupon>().like("name","auto-lfy"));
        for (MkCoupon mkCoupon : mkCouponList) {
            deleteCouponData(Long.valueOf(mkCoupon.getId()));
        }
    }

    public void deleteLfyActivityData(){
        List<MkActivity> mkActivities = activityMapper.selectList(new QueryWrapper<MkActivity>().like("name","auto-lfy"));
        for (MkActivity mkActivity : mkActivities) {
            deleteCouponData(Long.valueOf(mkActivity.getId()));
        }
    }

    @AfterClass
    public void afterClass(){
        deleteLfyCouponData();
        deleteLfyActivityData();
    }
}
