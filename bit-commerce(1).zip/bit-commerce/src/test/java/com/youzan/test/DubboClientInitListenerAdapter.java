package com.youzan.test;

import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.invoker.DubboInvoker;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import javax.annotation.PostConstruct;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DubboClientInitListenerAdapter extends TestListenerAdapter {
    @Override
    public void onTestStart(ITestResult result) {
        // when test start  spring or dubbo ctx init
        super.onTestStart(result);

        // 为子类实现dubbo invoker 注入
        Arrays.stream(getAllField(this.getClass()))
                .forEach(f -> {
                    if (f.isAnnotationPresent(Dubbo.class)) {
                        DubboInvoker.dubboInvokeAnnotation(f,this);
                    }

                });
    }

    private Field[] getAllField(Class instanceClass){
        List<Field> fieldList = new ArrayList<>();
        while (instanceClass != null){
            fieldList.addAll(new ArrayList<>(Arrays.asList(instanceClass.getDeclaredFields())));
            instanceClass = instanceClass.getSuperclass();
        }
        Field[] fields = new Field[fieldList.size()];
        fieldList.toArray(fields);
        return fields;
    }
}
