package com.youzan.test.refund.basecase;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;
import static org.awaitility.Duration.ONE_HUNDRED_MILLISECONDS;

/**
 * @author wuwu
 * @date 2020/10/21 4:34 PM
 */
public class WscToRetailTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(WscToRetailTest.class);

    @Test(enabled = false)
    public void WscToRetailAndWscRefunded() {
        /**
         * 1. 订购微商城单店软件
         * 2. 订购零售单店软件
         * 3. 检查微商城服务期是否退款
         * 4. 将店铺类型降级回微商城
         **/

        closeWaitPayOrder(wscToRetailKdtId);
        refundOrderByKdtId(wscToRetailKdtId);
        rechargeYzcoin(wscToRetailKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscToRetailKdtId), cny + 1000);
        //保证店铺是一个微商城店铺
        retailToWsc(wscToRetailKdtId);
        concurrentStatus(wscToRetailKdtId);
        concurrentStatus(wscToRetailKdtId);

        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscToRetailKdtId,wscToRetailKdtName,basicWechatItemId,1,0L);
        logger.info("第一笔订单创建返回结果:{}", orderCreateApiPlainResult);
        Assert.assertEquals(orderCreateApiPlainResult.getCode(), 200, "商业化下单失败，失败原因:" + orderCreateApiPlainResult.getMessage());

        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscToRetailKdtId);
        }

        //等待履约
        waitForPerform(wscToRetailKdtId, 873L, Long.valueOf(orderCreateApiPlainResult.getData()));

        //查询有效的订单服务期的sql语句
        Wrapper<PfOrderStatus> queryWrapper = new QueryWrapper<PfOrderStatus>()
                .eq("apply_kdt_id", wscToRetailKdtId)
                .eq("app_id", "atom_spu_wsc")
                .eq("state", "valid")
                .eq("group_type", "product_with_paid");

        //校验微商城服务期生成
        List<PfOrderStatus> pfOrderStatusList = pfOrderStatusMapper.selectList(queryWrapper);
        Assert.assertEquals(pfOrderStatusList.size(), 1, "生成了" + pfOrderStatusList.size() + "订单服务期");

        //等待10s
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        PlainResult<String> retailOrderCreateApiPlainResult =createNormalOrder(wscToRetailKdtId,wscToRetailKdtName,retailBasicWechatItem,1,0L);
        logger.info("创建零售订单返回值：{}", retailOrderCreateApiPlainResult);

        if (retailOrderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(retailOrderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscToRetailKdtId);
        }

        //等到微商城订单服务期失效
        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(3, TimeUnit.SECONDS)
                .await("等待退款...")
                .atMost(60L, TimeUnit.SECONDS)
                .until(() -> getAppStatus(wscToRetailKdtId, 873L, Long.valueOf(orderCreateApiPlainResult.getData())) == false);

        //断言退款是否成功
        //校验微商城服务期被回收
        List<PfOrderStatus> pfOrderStatusList2 = pfOrderStatusMapper.selectList(queryWrapper);
        Assert.assertEquals(pfOrderStatusList2.size(), 0, "退款失败");

        //将零售软件退款
        refundOrderByKdtId(wscToRetailKdtId);

        //等到订单服务期失效
        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(3, TimeUnit.SECONDS)
                .await("等待履约...")
                .atMost(10L, TimeUnit.SECONDS)
                .until(() -> getAppStatus(wscToRetailKdtId, 6075L, Long.valueOf(retailOrderCreateApiPlainResult.getData())) == false);

        //降级
        retailToWsc(wscToRetailKdtId);
    }
}
