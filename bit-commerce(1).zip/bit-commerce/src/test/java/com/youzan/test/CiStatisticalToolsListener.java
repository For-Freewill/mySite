package com.youzan.test;

import com.alibaba.fastjson.JSONObject;
import com.youzan.api.common.response.CommonResultCode;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteFinishProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.request.crm.ci.SuiteStartProcessRequestDTO;
import com.youzan.ycm.qa.enable.platform.api.service.crm.ci.SuiteListenerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;

/**
 * @author hezhulin
 * @date 2021-08-11 18:03
 */
public class CiStatisticalToolsListener extends DubboClientInitListenerAdapter {

    @Dubbo
    protected SuiteListenerService suiteListenerService;

    protected Logger logger = LoggerFactory.getLogger(CiStatisticalToolsListener.class);

    @Override
    public void onTestStart(ITestResult result) {
        //每一个@Test注释的测试方法执行之前
        super.onTestStart(result);
        logger.info("----onTestStart监听开始前置校验处理----");
        logger.info("变量JOB_NAME========" + System.getenv().get("JOB_NAME"));
        logger.info("变量BUILD_URL========" + System.getenv().get("BUILD_URL"));
        logger.info("变量SC========" + System.getenv().get("sc"));
        logger.info("变量suiteName========" + result.getTestContext().getSuite().getName());


        SuiteStartProcessRequestDTO suiteStartProcessRequestDTO = new SuiteStartProcessRequestDTO();
        //非jenkins环境执行的监听器不处理
        if (null == System.getenv().get("JOB_NAME") ||System.getenv().get("JOB_NAME").isEmpty()){
            logger.info("-------onTestStart-------非jenkins环境触发的无需处理");
            return;
//            suiteStartProcessRequestDTO.setJobBuildUrl("https://cd-qa.qima-inc.com/jenkins-18/job/crm-core-ng/job/qaBit-bit-enable/33/");
//            suiteStartProcessRequestDTO.setSc("prj002673");
//            suiteStartProcessRequestDTO.setSuiteName("crm-core-ng");
//            suiteStartProcessRequestDTO.setIsReferJob(false);
        }

        logger.info("-------onTestStart-------开始前置校验通过的后续处理");

        if (null == System.getenv().get("BUILD_URL") || System.getenv().get("BUILD_URL").isEmpty()){
            logger.warn("BUILD_URL不应该为空");
            return;
        }
        suiteStartProcessRequestDTO.setJobBuildUrl(System.getenv().get("BUILD_URL"));
        if (null == System.getenv().get("sc") || System.getenv().get("sc").isEmpty()){
            logger.warn("sc不应该为空");
            return;
        }
        suiteStartProcessRequestDTO.setSc(System.getenv().get("sc"));
        suiteStartProcessRequestDTO.setSuiteName(result.getTestContext().getSuite().getName());

        logger.info("触发重试的原job信息========" + System.getenv().get("type"));
        String sourceJob = System.getenv().get("type");
        if (null == sourceJob || sourceJob.isEmpty()){
            suiteStartProcessRequestDTO.setIsReferJob(false);
        }else if (sourceJob.startsWith("[") && sourceJob.endsWith("]")) {
            suiteStartProcessRequestDTO.setIsReferJob(true);
            suiteStartProcessRequestDTO.setSourceJobs(JSONObject.parseArray(sourceJob,Long.class));
        }else {
            suiteStartProcessRequestDTO.setIsReferJob(false);
        }

        PlainResult<Boolean> suiteStartProcessResult = suiteListenerService.suiteStartProcess(suiteStartProcessRequestDTO);

        try {
            if (suiteStartProcessResult.getCode()== CommonResultCode.SUCCESS.code && suiteStartProcessResult.getData())
                logger.info("-------suiteOnStart-------suiteListenerService.suiteStartProcess触发成功");
            else
                logger.error("-------suiteOnStart-------suiteListenerService.suiteStartProcess触发异常");
        }catch (Exception e){
            logger.error("-------suiteOnStart-------suiteListenerService.suiteStartProcess触发异常");
            logger.error(e.getMessage());
        }


    }

    @Override
    public void onFinish(ITestContext testContext) {
        //suite文件中每一个<test></test>结束后
        logger.info("----onFinish监听开始前置校验处理----");
        logger.info("变量JENKINS_HOME========" + System.getenv().get("JENKINS_HOME"));
        logger.info("变量JOB_URL========" + System.getenv().get("JOB_URL"));
        logger.info("变量BUILD_URL========" + System.getenv().get("BUILD_URL"));
        logger.info("变量SC========" + System.getenv().get("sc"));

        SuiteFinishProcessRequestDTO suiteFinishProcessRequestDTO = new SuiteFinishProcessRequestDTO();
        //非jenkins环境执行的监听器不处理
        if (null == System.getenv().get("JOB_NAME") ||System.getenv().get("JOB_NAME").isEmpty()){
            logger.info("-------suiteOnFinish-------非jenkins环境触发的无需处理");
            return;
//            suiteFinishProcessRequestDTO.setJobBuildUrl("https://cd-qa.qima-inc.com/jenkins-18/job/crm-core-ng/job/qaBit-bit-enable/33/");
//            suiteFinishProcessRequestDTO.setSuiteName("crm-core-ng");
        }

        logger.info("-------onFinish-------开始前置校验通过的后续处理");

        if (null == System.getenv().get("BUILD_URL") || System.getenv().get("BUILD_URL").isEmpty()){
            logger.warn("BUILD_URL不应该为空");
            return;
        }
        suiteFinishProcessRequestDTO.setJobBuildUrl(System.getenv().get("BUILD_URL"));
        suiteFinishProcessRequestDTO.setSuiteName(testContext.getSuite().getName());
        try {
            PlainResult<Boolean> suiteFinishProcessResult = suiteListenerService.suiteFinishProcess(suiteFinishProcessRequestDTO);
            if (suiteFinishProcessResult.getCode()== CommonResultCode.SUCCESS.code && suiteFinishProcessResult.getData())
                logger.info("-------onFinish-------suiteListenerService.suiteFinishProcess触发成功");
            else
                logger.error("-------onFinish-------suiteListenerService.suiteFinishProcess触发异常");
        }catch (Exception e){
            logger.error("-------onFinish-------suiteListenerService.suiteFinishProcess触发异常");
            logger.error(e.getMessage());
        }

    }
}
