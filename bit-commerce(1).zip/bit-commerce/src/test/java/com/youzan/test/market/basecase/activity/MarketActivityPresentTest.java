package com.youzan.test.market.basecase.activity;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponAsset;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponRule;
import com.youzan.commerce.test.mapper.market.coupon.CouponAssetMapper;
import com.youzan.commerce.test.mapper.market.coupon.CouponMapper;
import com.youzan.commerce.test.mapper.market.coupon.CouponRuleMapper;
import com.youzan.commerce.test.mapper.market.coupon.CouponSnapshotMapper;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import com.youzan.ycm.market.api.CouponAssetRemoteService;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.form.PromotionForm;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import com.youzan.yop.api.request.DistributeStockToKdtRequest;
import com.youzan.yop.api.request.GetPromotionV2Request;
import com.youzan.yop.api.response.DistributeStockToKdtResponse;
import com.youzan.yop.api.response.GetPromotionV2Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author leifeiyun
 * @date 2020/10/29
 **/
public class MarketActivityPresentTest extends MarketActivityBaseTest {
    Long wscKdtId = 58300258L;
    @Dubbo
    PromotionRemoteService promotionRemoteService;
    @Dubbo
    OrderRemoteService orderRemoteService;
    @Dubbo
    CouponAssetRemoteService couponAssetRemoteService;
    @Http("yop")
    HttpUtil yopHttpUntil;
    @Autowired(required = false)
    CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    CouponMapper couponMapper;
    @Autowired(required = false)
    CouponRuleMapper couponRuleMapper;
    @Autowired(required = false)
    CouponSnapshotMapper couponSnapshotMapper;
    String createGiftProPath = "src/test/resources/dataResource/basecase.activityPresent/createGiftPro.json";
    String confirmOrderForGiftCouponPath = "src/test/resources/dataResource/basecase.activityPresent/confirmOrderForGiftCoupon.json";

    /**
     * 1.创建礼包券
     * 2.验证礼包券生成数据与传入数据一致
     * 3.分配礼包券
     * 4.检查生成的券资产
     * 5.回收券资产
     * 6.检查回收的券资产
     * 7.清理数据
     */
    @Test
    public void testCreateGiftCouponAndDistributeStock() {
        Long activityId = null;
        try {
            PromotionForm promotionForm = JsonCovertUntil.getObjectFromjson(createGiftProPath, PromotionForm.class);
            //根据时间戳生成序列作为买赠活动名称
            String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
            String giftProName = "auto-lfy-giftProName" + dateString;
            promotionForm.setName(giftProName);
            PlainResult<Long> plainResult = promotionRemoteService.createPresentCoupon(promotionForm);

            activityId = plainResult.getData();

            //验证查询的数据与创建的数据一致
            GetPromotionV2Request getPromotionV2Request = new GetPromotionV2Request();
            getPromotionV2Request.setPromotionId(activityId);
            getPromotionV2Request.setPromotionType("COUPON");
            PlainResult<GetPromotionV2Response> getPromotionV2Result = promotionRemoteService.getPromotionV2(getPromotionV2Request);

            Assert.assertEquals(getPromotionV2Result.getCode(), 200);
            Assert.assertEquals(getPromotionV2Result.getMessage(), "successful");
//            Assert.assertEquals(getPromotionV2Result.getData().getPromotion().getAppId(), promotionForm.getAppId());
//            Assert.assertEquals(getPromotionV2Result.getData().getPromotion().getItemId(), promotionForm.getItemId());
//            Assert.assertEquals(getPromotionV2Result.getData().getPromotion().getBeginTime(), promotionForm.getBeginTime());
//            Assert.assertEquals(getPromotionV2Result.getData().getPromotion().getEndTime(), promotionForm.getEndTime());
//            Assert.assertEquals(getPromotionV2Result.getData().getPromotion().getGiftForDistributeList().get(0).getMaxKdtStock(),
//                    promotionForm.getGiftForDistributeList().get(0).getMaxKdtStock());
//            Assert.assertEquals(getPromotionV2Result.getData().getPromotion().getGiftForDistributeList().get(0).getTotalStock(),
//                    promotionForm.getGiftForDistributeList().get(0).getTotalStock());
//            Assert.assertEquals(getPromotionV2Result.getData().getPromotion().getGiftForDistributeList().get(0).getGiftItemList().get(0).getSkuNum(),
//                    promotionForm.getGiftForDistributeList().get(0).getGiftItemList().get(0).getSkuNum());


            //分配配额
            DistributeStockToKdtRequest distributeStockToKdtRequest = new DistributeStockToKdtRequest();
            distributeStockToKdtRequest.setPromotionId(activityId);
            distributeStockToKdtRequest.setBizNo(generateCrmDistributeStockBizNo(wscKdtId));
            distributeStockToKdtRequest.setBizType("crm_distribute_stock");
            distributeStockToKdtRequest.setPromotionType("COUPON");
            distributeStockToKdtRequest.setDistributeStock(Long.valueOf(1));
            distributeStockToKdtRequest.setKdtId(wscKdtId);


            PlainResult<DistributeStockToKdtResponse> distributeStockResult = promotionRemoteService.distributeStockToKdt(distributeStockToKdtRequest);
            Assert.assertEquals(distributeStockResult.getCode(), 200);
            Assert.assertEquals(distributeStockResult.getMessage(), "successful");
            Assert.assertTrue(distributeStockResult.getData().getDistributeSuccess() == true);


            //检查生成相应的券资产
            MkCouponAsset mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("coupon_id", activityId));
            Assert.assertEquals(activityId, mkCouponAsset.getCouponId());
            Assert.assertEquals(wscKdtId, Long.valueOf(mkCouponAsset.getBelongtoYid()));
            Assert.assertEquals(mkCouponAsset.getState(), "RECEIVED");
            Assert.assertEquals(mkCouponAsset.getCouponType(), "G_PRESENT");

            //回收券资产
            recycleCouponAsset(String.valueOf(mkCouponAsset.getId()));
            //验证券资产状态回收
            mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("coupon_id", activityId));
            Assert.assertEquals(mkCouponAsset.getState(), "RECYCLED");

        } catch (Exception e) {
        } finally {
            deleteCouponData(activityId);
        }

    }


    /**
     * 1.创建礼包券
     * 2.验证礼包券生成数据与传入数据一致
     * 3.分配礼包券
     * 4.检查生成的券资产
     * 5.确认订单，确认生成相应的买赠礼包
     * 6.验证买赠礼包id与生成的礼包券内容中礼包id一致
     * 7.回收券资产
     * 8.检查回收的券资产
     * 9.清理数据
     */
    @Test
    public void testCreateGiftCouponAndDistributeStockAndForShow() {
        Long activityId = null;
        try {
            PromotionForm promotionForm = JsonCovertUntil.getObjectFromjson(createGiftProPath, PromotionForm.class);
            //根据时间戳生成序列作为买赠活动名称
            String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
            String giftProName = "auto-lfy-giftProName" + dateString;
            promotionForm.setName(giftProName);
            PlainResult<Long> plainResult = promotionRemoteService.createPresentCoupon(promotionForm);
            activityId = plainResult.getData();


            //分配配额
            DistributeStockToKdtRequest distributeStockToKdtRequest = new DistributeStockToKdtRequest();
            distributeStockToKdtRequest.setPromotionId(activityId);
            distributeStockToKdtRequest.setBizNo(generateCrmDistributeStockBizNo(wscKdtId));
            distributeStockToKdtRequest.setBizType("crm_distribute_stock");
            distributeStockToKdtRequest.setPromotionType("COUPON");
            distributeStockToKdtRequest.setDistributeStock(Long.valueOf(1));
            distributeStockToKdtRequest.setKdtId(wscKdtId);
            PlainResult<DistributeStockToKdtResponse> distributeStockResult = promotionRemoteService.distributeStockToKdt(distributeStockToKdtRequest);
            Assert.assertEquals(distributeStockResult.getCode(), 200);
            Assert.assertEquals(distributeStockResult.getMessage(), "successful");
            Assert.assertTrue(distributeStockResult.getData().getDistributeSuccess() == true);

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //检查生成相应的券资产
            MkCouponAsset mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("coupon_id", activityId));
            Assert.assertEquals(mkCouponAsset.getCouponType(), "G_PRESENT");
            //确认订单，展示买赠礼包，只要confimrorder的订单优惠中，有这个礼包就行，调用的是confirmOrder
            ConfirmOrderForm confirmOrderForm = JsonCovertUntil.getObjectFromjson(confirmOrderForGiftCouponPath, ConfirmOrderForm.class);
            PlainResult<OrderConfirmApi> confirmApiPlainResult = orderRemoteService.confirmOrder(confirmOrderForm);
            Assert.assertEquals(confirmApiPlainResult.getCode(), 200);
            Assert.assertEquals(confirmApiPlainResult.getMessage(), "successful");
            MkCouponRule mkCouponRule = couponRuleMapper.selectOne(new QueryWrapper<MkCouponRule>().eq("coupon_id", activityId));
            JSONArray jsonArray = JSONArray.parseArray(mkCouponRule.getActions());
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            Long presentId = jsonObject.getLong("presentId");
            String type = jsonObject.getString("type");
            Assert.assertEquals(presentId, confirmApiPlainResult.getData().getItems().get(0).getItemPromotionList().get(0).getPromotionId(), "礼包id不一致");
            Assert.assertEquals(type, "PRESENT");

            //回收券资产
            recycleCouponAsset(String.valueOf(mkCouponAsset.getId()));
            //验证券资产状态回收
            mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("coupon_id", activityId));
            Assert.assertEquals(mkCouponAsset.getState(), "RECYCLED");
            //清理礼包券配置数据
            deleteCouponData(activityId);
        } catch (Exception e) {
        } finally {
            deleteCouponData(activityId);
        }

    }


    @BeforeClass
    public void beforeClass() {
        deleteTestDataYcmByKdtId(wscKdtId);
    }


    @Test(enabled = false)
    public void test() {
        String s = "[{\"enableSalesControl\":false,\"itemSimple\":{\"skuId\":\"atom_sku_paid_promotion_year\",\"spuId\":\"atom_spu_paid_promotion\"},\"presentId\":1067,\"promotionScopeEnum\":\"GOODS\",\"quantity\":1,\"type\":\"PRESENT\"}]";
        JSONArray jsonArray = JSONArray.parseArray(s);
        JSONObject jsonObject = jsonArray.getJSONObject(0);


    }

}
