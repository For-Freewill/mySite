package com.youzan.test.yop.dto;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhouqinghua on 2018/5/21.
 */
public class CashierPayDTO {
    public final static String PARTNER_ID = "partnerId";
    public final static String PREPAY_ID = "prepayId";
    public final static String CASHIER_SALT = "cashierSalt";
    public final static String CASHIER_SIGN = "cashierSign";
    public final static String KDT_ID = "kdtId";
    public final static String MCHID = "mchId";
    public final static String PAY_TOOL = "payTool";
    public final static String BIZ = "biz";
    public final static String PACKAGE_NAME = "packageName";
    public final static String PACKAGE_VERSION = "packageVersion";


    public static Map<String, Object> cashierPayBalance(String partnerId, String prepayId, String cashierSalt, String cashierSing, Long kdtId, long mchId) {
        Map<String, Object> param = new HashMap<>();
        param.put(KDT_ID, kdtId);
        param.put(PAY_TOOL, "BALANCE");
        param.put(BIZ, URLEncoder.encode("B端pc商业化订购"));
        param.put(PACKAGE_NAME, URLEncoder.encode("@youzan/cashier-pc"));
        param.put(PACKAGE_VERSION, URLEncoder.encode("3.1.1"));
        param.put(PARTNER_ID, partnerId);
        param.put(PREPAY_ID, prepayId);
        param.put(CASHIER_SALT, cashierSalt);
        param.put(CASHIER_SIGN, cashierSing);

        param.put(MCHID, mchId);

        return param;
    }
}
