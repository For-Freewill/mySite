package com.youzan.test.market.basecase.activity;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.PromotionForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.apache.commons.collections.CollectionUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-03-25 15:32
 **/
public class PresentActivityProdChannelTest extends TnBaseTest {

    //零售店铺
    public static Long LSKDTID = 59444666L;
    public static String LSKDTIDNAME = "营销买赠CI产品线店铺";

    //WSC店铺
    public static Long WSCKDTID = 59444858L;
    public static String WSCKDTIDNAME = "营销买赠CIWSC使用店铺";

    @JSONData(value = "dataResource/apicase.market/OrderWithPresentActivityRequestData.json", key = "createOrderFormWithLS")
    private CreateOrderForm createOrderFormWithLS;

    @JSONData(value = "dataResource/apicase.market/OrderWithPresentActivityRequestData.json", key = "createOrderFormWithWSC")
    private CreateOrderForm createOrderFormWithWSC;

    @JSONData(value = "dataResource/basecase.activity/CreatePresentRequestData.json", key = "createPresent")
    private PromotionForm promotionForm;

    @BeforeMethod
    public void init() {
        try {
            sleep(1000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * 1、biz后台创建买赠活动，活动名称：营销买赠CI产品线田宁专用-勿动；对应的配置：产品线为微商城单店；新签&续签；全网生效；参与次数不限
     * 2、电商2021百度小程序基础版订购 + 礼包名称：营销买赠CI田宁专用-勿动（礼包内容：积分商城）
     * 验证：微商城可用，零售不可用
     */
    @Test
    public void presentActivityTest() {
        String td_no = "";

        //1、店铺充值
        rechargeShopBalance(LSKDTID.toString(), 99999999);

        //2、如果有未关闭订单，先关闭
        closeWaitPayOrder(LSKDTID);

        //3、退服务期，使得该店铺可以作为新购店铺重新使用
        refundOrderByKdtId(LSKDTID);

        //4、订购 产品线是零售，预期买赠活动不可用
        PlainResult<String> plainResultLS = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                    @Override
                    public PlainResult<String> doExecute() {
                        return orderRemoteService.createNormalOrder(createOrderFormWithLS);
                    }

                    @Override
                    public boolean handleResult(PlainResult<String> plainResultLS) {
                        return plainResultLS.getCode() == 200;
                    }
                }, 5, 100);
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        Assert.assertEquals(plainResultLS.getMessage(), "存在服务在当前店铺不可订购，请联系在线客服");
        Assert.assertEquals(plainResultLS.getCode(), 130033);


        //6、订购  产品线是WSC，预期买赠活动可用
        rechargeShopBalance(WSCKDTID.toString(), 99999999);

        closeWaitPayOrder(WSCKDTID);

        refundOrderByKdtId(WSCKDTID);

        PlainResult<String> plainResultWSC = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                    @Override
                    public PlainResult<String> doExecute() {
                        return orderRemoteService.createNormalOrder(createOrderFormWithWSC);
                    }

                    @Override
                    public boolean handleResult(PlainResult<String> plainResultWSC) {
                        return plainResultWSC.getCode() == 200;
                    }
                }, 5, 100);
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        Assert.assertEquals(plainResultWSC.getCode(), 200);

        if (plainResultWSC.getCode() == 200) {
            //6.预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.parseLong(plainResultWSC.getData()), (byte) 4);
            Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

            //7.余额支付
            cashierPay(preparePayApiPlainResult, account, WSCKDTID);
        }

        //查一下订单表，确认数据确实生成
        List<TdOrder> tdOrderRecords = queryTdOrderByKdtIdAndState(WSCKDTID);
        Assert.assertTrue(CollectionUtils.isNotEmpty(tdOrderRecords));
    }
}
