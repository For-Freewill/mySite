package com.youzan.test.cloudService.apicase.yop;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.status.ServiceListApi;
import com.youzan.yop.api.form.status.SearchAppOrderStatusListFormV2;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * date:2021/09/02
 * @大爷
 */
public class ListOrderStateByStateAndPageV2Test extends YunBaseTest {
    public String state = "EFFECT";
    public String state2 = "EXPIRED";
    public String state3 = "";
    public static Long wsc_jichu = 60334094L;
    public static String wsc_jichu_name = "企业店-3C数码01628161283sys997";

    public static Long wsc_null = 61204750L;
    public static String wsc_null_name = "企业店-手机01631160155sys352";

    public static Long wsc_expired = 60912615L;
    public static String wsc_expired_name = "企业店-3C数码01628576045sys41210817";

    @Dubbo
    public AppStatusRemoteService appStatusRemoteService;

    @Test
    //正向用例：订购微商城专业版-支付宝小程序
    public void listOrderStateByStateAndPageV2Test() {
        PlainResult<PageApi<ServiceListApi>> result = appStatusRemoteService.listOrderStateByStateAndPageV2(formV2(wsc_jichu, state));
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(), 200);
        if (result.getData().getContent() != null) {
            Assert.assertEquals(result.getData().getContent().toString().contains("支付宝小程序"), true);
        }
    }

    @Test
    //正向用例：新开店铺未订购服务
    public void listOrderStateByStateAndPageV2TestNull() {
        PlainResult<PageApi<ServiceListApi>> result = appStatusRemoteService.listOrderStateByStateAndPageV2(formV2(wsc_null, state));
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getTotalPages(), 0);

    }

    @Test
    //正向用例：打烊店铺
    public void listOrderStateByStateAndPageV2TestExpired() {
        PlainResult<PageApi<ServiceListApi>> result = appStatusRemoteService.listOrderStateByStateAndPageV2(formV2(wsc_expired, state2));
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getTotalPages(), 0);
    }

    @Test
    //反向用例：店铺ID为空报错
    public void listOrderStateByStateAndPageV2TestNoKdt() {
        PlainResult<PageApi<ServiceListApi>> result =appStatusRemoteService.listOrderStateByStateAndPageV2(formV2(null,state));
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),130501);
    }
    @Test
    //反向用例 服务期为空返回正常
    public void listOrderStateByStateAndPageV2TestNoState(){
        PlainResult<PageApi<ServiceListApi>> result = appStatusRemoteService.listOrderStateByStateAndPageV2(formV2(wsc_jichu,null));
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);
        if (result.getData().getContent() != null) {
            Assert.assertEquals(result.getData().getContent().toString().contains("支付宝小程序"), true);
        }
    }


    public SearchAppOrderStatusListFormV2 formV2(Long kdtId, String state) {
        SearchAppOrderStatusListFormV2 searchAppOrderStatusListFormV2 = new SearchAppOrderStatusListFormV2();
        searchAppOrderStatusListFormV2.setKdtId(kdtId);
        searchAppOrderStatusListFormV2.setState(state);
        searchAppOrderStatusListFormV2.setPageNumber(1);
        searchAppOrderStatusListFormV2.setPageSize(20);
        return searchAppOrderStatusListFormV2;

    }
}
