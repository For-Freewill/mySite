package com.youzan.test.market.basecase.collection;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.mapper.market.collocation.ActivityMapper;
import com.youzan.commerce.test.mapper.market.collocation.CollocationMapper;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.api.CollocationActivityRemoteService;
import com.youzan.ycm.market.dto.activity.CollocationActivityDTO;
import com.youzan.ycm.market.dto.rule.ItemFixedUnitPriceRuleDTO;
import com.youzan.ycm.market.request.activity.SaveCollocationActivityRequest;
import com.youzan.ycm.market.response.activity.SaveCollocationActivityResponse;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2020/8/31 7:45 下午
 * 一个完整的搭配购订购流程
 */
public class CollocationAllTest extends TnBaseTest {

    public static Long WSCKDTIDCIWRITE = 58112073L;
    public static String WSCKDTCIWRITE = "58112073";
    public static String WSCKDTCIWRITENAME = "WSCCI2";

    @Dubbo
    public CollocationActivityRemoteService collocationActivityRemoteService;
    @Dubbo
    public OrderRemoteService orderRemoteService;

    @Autowired(required = false)
    public CollocationMapper collocationMapper;
    @Autowired(required = false)
    public ActivityMapper activityMapper;

    @JSONData(value = "dataResource/basecase.collocation/CollocationRequestData.json", key = "request")
    private CreateOrderForm createOrderForm;

    @BeforeMethod
    public void init() {
        try {
            sleep(1000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        clearCache(WSCKDTCIWRITE);
    }

    /**
     * 先生成一条搭配购信息
     * 再进行下单订购
     */
    @Test
    public void firstCollocationTest() {
        String activityId = "";
        batchDeleteCollocationByName();
        try {
            //1. 新增一条搭配购
            PlainResult<SaveCollocationActivityResponse> result = collocationCreate();
            Assert.assertNotNull(result.getData().getCollocationActivityDTOs());

            //2.如果有未关闭订单，先关闭
            rechargeShopBalance(WSCKDTCIWRITE, 99999999);
            closeWaitPayOrder(WSCKDTIDCIWRITE);
            refundOrderByKdtId(WSCKDTIDCIWRITE);

            //3. 创建订单
            PlainResult<Long> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<Long>>() {

                        @Override
                        public PlainResult<Long> doExecute() {
                            return orderRemoteService.createOrder(createOrderForm);
                        }

                        @Override
                        public boolean handleResult(PlainResult<Long> plainResult) {
                            return plainResult.getCode() == 200;
                        }
                    }, 5, 100);

            Assert.assertEquals(plainResult.getCode(), 200);

            if (plainResult.getCode() == 200) {
                //4.预支付
                PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(plainResult.getData(), (byte) 4);

                Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

                //5.余额支付
                cashierPay(preparePayApiPlainResult, account, WSCKDTIDCIWRITE);
            }
            activityId = result.getData().getCollocationActivityDTOs().get(0).getActivityId();
        } finally {
            collocationInvalid(activityId);
            deleteCollocationByActivityId(activityId);
        }
    }

    /**
     * 生成搭配购
     */
    public PlainResult<SaveCollocationActivityResponse> collocationCreate() {

        SaveCollocationActivityRequest saveCollocationActivityRequest = new SaveCollocationActivityRequest();
        List<CollocationActivityDTO> collocationActivityDTOs = new ArrayList<>();

        CollocationActivityDTO collocationActivityDTO = new CollocationActivityDTO();
        collocationActivityDTO.setMainAppId("atom_spu_point_store");

        List<String> productChannels = new ArrayList<>();
        productChannels.add("WSC");
        productChannels.add("EDU");
        productChannels.add("RETAIL");
        collocationActivityDTO.setProductChannels(productChannels);

        List<ItemFixedUnitPriceRuleDTO> itemFixedUnitPriceRuleDTOList = new ArrayList<>();
        ItemFixedUnitPriceRuleDTO itemFixedUnitPriceRuleDTOGroupon = new ItemFixedUnitPriceRuleDTO();
        itemFixedUnitPriceRuleDTOGroupon.setAppId("atom_spu_point_store");
        itemFixedUnitPriceRuleDTOGroupon.setFixedUnitPrice(1288L);
        itemFixedUnitPriceRuleDTOGroupon.setItemId("atom_sku_point_store_year");
        itemFixedUnitPriceRuleDTOGroupon.setQuantity(1L);

        ItemFixedUnitPriceRuleDTO itemFixedUnitPriceRuleDTOPoint = new ItemFixedUnitPriceRuleDTO();
        itemFixedUnitPriceRuleDTOPoint.setAppId("atom_spu_heatmap");
        itemFixedUnitPriceRuleDTOPoint.setFixedUnitPrice(2000L);
        itemFixedUnitPriceRuleDTOPoint.setItemId("atom_sku_heatmap_year");
        itemFixedUnitPriceRuleDTOPoint.setQuantity(1L);

        itemFixedUnitPriceRuleDTOList.add(itemFixedUnitPriceRuleDTOGroupon);
        itemFixedUnitPriceRuleDTOList.add(itemFixedUnitPriceRuleDTOPoint);
        collocationActivityDTO.setItemFixedUnitPriceRuleDTOList(itemFixedUnitPriceRuleDTOList);

        List<String> userTags = new ArrayList<>();
        userTags.add("FIRST");
        userTags.add("RENEW");
        userTags.add("SIGN_BACK");
        collocationActivityDTO.setUserTags(userTags);

        collocationActivityDTO.setActivityState("EFFECTING");
        collocationActivityDTO.setName("哈士奇搭配购微商城新增测试");
        collocationActivityDTO.setActivityDesc("哈士奇搭配购微商城新增测试");
        collocationActivityDTO.setEffectTime("2020-08-31 00:00:00");
        collocationActivityDTO.setExpireTime("2040-08-31 00:00:00");
        collocationActivityDTO.setAppName("积分商城");
        collocationActivityDTO.setJoinLimitType("WITH_ALL_APPS");
        collocationActivityDTO.setChannel("YOUZAN");

        collocationActivityDTOs.add(collocationActivityDTO);
        saveCollocationActivityRequest.setCollocationActivityDTOs(collocationActivityDTOs);

        PlainResult<SaveCollocationActivityResponse> saveCollocationResult = collocationActivityRemoteService.saveCollocation(saveCollocationActivityRequest);

        return saveCollocationResult;
    }
}
