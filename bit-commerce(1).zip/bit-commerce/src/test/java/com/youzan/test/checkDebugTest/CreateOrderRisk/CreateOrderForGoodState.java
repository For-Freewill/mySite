package com.youzan.test.checkDebugTest.CreateOrderRisk;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wuwu
 * @date 2021/1/26 5:56 PM
 */
public class CreateOrderForGoodState extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(CreateOrderRiskTest.class);
    public Long kdtIdForCheck = 58828407L;
    public String kdtNameForCheck = "CI-接口自动化-下单校验测试";

    public int itemId = 73840;
    public int itemId2 = 73841;

    public int offlineAppItemId = 73849;

    public int proLineItemId = 73850;

    /**
     * 老的校验：对于商品已经下架、或者sku已经下架，后端都是没做拦截的，都还是可以订购成功的
     * 新的检验：针对下架的商品或sku均会做下架处理
     */
    @Test
    public void createNormalOrderForSkuOffline() {
        //PlainResult<String> result =  compareServiceImp.invoke(()->createNormalOrder(kdtIdForCheck,kdtNameForCheck,itemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,itemId,1,0L);

        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }

    @Test
    public void createOrderForSkuOffline() {
        //PlainResult<Long> result =  compareServiceImp.invoke(()->createOrder(kdtIdForCheck,kdtNameForCheck,itemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,itemId,1,0L);

        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }

    @Test
    public void createNormalOrderForGoodOffline() {
        //PlainResult<String> result =  compareServiceImp.invoke(()->createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L);
        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }

    @Test
    public void createOrderForGoodOffline() {
        //PlainResult<String> result =  compareServiceImp.invoke(()->createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L);

        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }

    /**
     * 销售渠道没有配置--期望结果是不能订购
     */
    @Test
    public void createNormalOrderForProLineTest() {
        //PlainResult<String> result =  compareServiceImp.invoke(()->createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,proLineItemId,1,0L);
        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }

    @Test
    public void createOrderForProLineTest() {
        //PlainResult<String> result =  compareServiceImp.invoke(()->createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,proLineItemId,1,0L);

        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }

    /**
     * 分配渠道没有配置--期望结果是不能订购
     */
    @Test
    public void createNormalOrderForAssignTest() {
        //PlainResult<String> result =  compareServiceImp.invoke(()->createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,proLineItemId,1,0L);
        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }

    @Test
    public void createOrderForAssignTest() {
        //PlainResult<String> result =  compareServiceImp.invoke(()->createNormalOrder(kdtIdForCheck,kdtNameForCheck,offlineAppItemId,1,0L));
        PlainResult<String> result =  createNormalOrder(kdtIdForCheck,kdtNameForCheck,proLineItemId,1,0L);

        Assert.assertEquals(result.getCode(),130033);
        Assert.assertEquals(result.getMessage(),"服务已下架，暂不支持订购。如有疑问，请致电0571-89988848或联系在线客服");
    }


}
