package com.youzan.test.basecase.promoCode;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.gson.JsonObject;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponAsset;
import com.youzan.commerce.test.entity.dataobject.market.redeemCode.MkRedeemCodeConf;
import com.youzan.commerce.test.entity.dataobject.market.redeemCode.MkRedeemCodeContent;
import com.youzan.commerce.test.entity.dataobject.market.redeemCode.MkRedeemCodeRecord;
import com.youzan.commerce.test.mapper.market.coupon.CouponAssetMapper;
import com.youzan.commerce.test.mapper.market.redeem.MkRedeemCodeConfMapper;
import com.youzan.commerce.test.mapper.market.redeem.MkRedeemCodeContentMapper;
import com.youzan.commerce.test.mapper.market.redeem.MkRedeemCodeRecordMapper;
import com.youzan.commerce.test.utils.CompareSCUtil;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.platform.service_chain.context.ServiceChainContext;
import com.youzan.test.basecase.SimpleToolBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.redeemcode.RedeemCodeManagerService;
import com.youzan.ycm.market.api.redeemcode.RedeemCodeRemoteService;
import com.youzan.ycm.market.dto.RedeemCodeRecordDTO;
import com.youzan.ycm.market.request.redeemcode.*;
import com.youzan.ycm.market.response.redeemcode.AcquireRedeemCodeResponse;
import com.youzan.ycm.market.response.redeemcode.AddRedeemCodeConfResponse;
import com.youzan.ycm.market.response.redeemcode.GetRedeemCodeDataResponse;
import com.youzan.ycm.market.response.redeemcode.RecycleRedeemObjResponse;
import org.awaitility.Awaitility;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.awaitility.Awaitility.with;

/**
 * @author leifeiyun
 * @date 2020/10/19
 **/
public class PromoCodeTest extends SimpleToolBaseTest {
    @Dubbo
    RedeemCodeRemoteService redeemCodeRemoteService;
    @Dubbo
    RedeemCodeManagerService redeemCodeManagerService;

    @Autowired(required = false)
    CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    MkRedeemCodeConfMapper mkRedeemCodeConfMapper;
    @Autowired(required = false)
    MkRedeemCodeContentMapper mkRedeemCodeContentMapper;
    @Autowired(required = false)
    MkRedeemCodeRecordMapper mkRedeemCodeRecordMapper;

    String promoCodeCreatePath = "src/test/resources/data/promoCode/createPromoCode.json";
    String codeRedeemPath = "src/test/resources/data/promoCode/codeRedeem.json";
    String codeAcquirePath = "src/test/resources/data/promoCode/codeAcquire.json";

    /**
     * 1.生成优惠券码
     * 2.获取优惠券码
     * 3.分配优惠券码
     * 4.再次分配优惠券码
     * 5.清理数据
     */
    static Map serviceChainMap  = new HashMap();
    static {
        serviceChainMap.put("name", CompareSCUtil.getSC());
    }
    @Test(priority = 0)
    public void testAcquireRedeemCode() {
        AddRedeemCodeConfRequest addRedeemCodeConfRequest = JsonCovertUntil.getObjectFromjson(promoCodeCreatePath, AddRedeemCodeConfRequest.class);
        Long configId = createPromoCode().getData().getId();

        //获取优惠码
        GetRedeemCodeDataRequest getRedeemCodeDataRequest = new GetRedeemCodeDataRequest();
        getRedeemCodeDataRequest.setConfigId(configId);
        PlainResult<List<GetRedeemCodeDataResponse>> listPlainResult = redeemCodeManagerService.getRedeemCodeData(getRedeemCodeDataRequest);
        checkStatusOfRedeem("UNISSUED", configId);
        String redeemCode = "";
        if (listPlainResult.getData() != null) {
            redeemCode = listPlainResult.getData().get(0).getRedeemCode();
        }
        //分配兑换码
        AcquireRedeemCodeRequest acquireRedeemCodeRequest = JsonCovertUntil.getObjectFromjson(codeAcquirePath, AcquireRedeemCodeRequest.class);
        acquireRedeemCodeRequest.setAcquireBizNo(generate23Sequence());
        acquireRedeemCodeRequest.setRedeemCodeId(String.valueOf(configId));
        AtomicReference<PlainResult<AcquireRedeemCodeResponse>> redeemCodeResponsePlainResult = new AtomicReference<>(redeemCodeRemoteService.acquire(acquireRedeemCodeRequest));
        Assert.assertEquals(redeemCodeResponsePlainResult.get().getCode(), 200);
        Assert.assertEquals(redeemCodeResponsePlainResult.get().getMessage(), "successful");
        Assert.assertNotNull(redeemCodeResponsePlainResult.get().getData());
        //验证券码状态已发放
        checkStatusOfRedeem("ISSUED", configId);
        //再次分配优惠券码
        Awaitility.setDefaultTimeout(1, TimeUnit.MINUTES);
        with().pollInterval(10, TimeUnit.SECONDS).and().await("验证再次兑换券码").until(() -> {
            ServiceChainContext.setInvocationServiceChainContext(serviceChainMap);
            acquireRedeemCodeRequest.setAcquireBizNo(generate23Sequence());
            redeemCodeResponsePlainResult.set(redeemCodeRemoteService.acquire(acquireRedeemCodeRequest));
            boolean compareResult = "4103".equals(String.valueOf(redeemCodeResponsePlainResult.get().getCode())) &&
                    "无可分配的兑换码".equals(redeemCodeResponsePlainResult.get().getMessage());
            logger.info("compareResult--->" + compareResult+":"+String.valueOf(redeemCodeResponsePlainResult.get().getCode()+"："+redeemCodeResponsePlainResult.get().getMessage()));
            return compareResult;
        });
        deleteRedeemCodeData(redeemCode);
    }

    /**
     * 1.生成优惠券码
     * 2.获取优惠券码
     * 3.分配优惠券码
     * 4.兑换优惠券券码
     * 5.再次兑换优惠券码
     * 6.检查生成的券资产
     * 7.清理数据
     */
    @Test(priority = 1)
    public void testRedeemCode() {
        AddRedeemCodeConfRequest addRedeemCodeConfRequest = JsonCovertUntil.getObjectFromjson(promoCodeCreatePath, AddRedeemCodeConfRequest.class);
        Long configId = createPromoCode().getData().getId();

        //获取优惠码
        GetRedeemCodeDataRequest getRedeemCodeDataRequest = new GetRedeemCodeDataRequest();
        getRedeemCodeDataRequest.setConfigId(configId);
        PlainResult<List<GetRedeemCodeDataResponse>> listPlainResult = redeemCodeManagerService.getRedeemCodeData(getRedeemCodeDataRequest);
        checkStatusOfRedeem("UNISSUED", configId);
        String redeemCode = "";
        if (listPlainResult.getData() != null) {
            redeemCode = listPlainResult.getData().get(0).getRedeemCode();
        }
        //分配兑换码
        AcquireRedeemCodeRequest acquireRedeemCodeRequest = JsonCovertUntil.getObjectFromjson(codeAcquirePath, AcquireRedeemCodeRequest.class);
        acquireRedeemCodeRequest.setAcquireBizNo(generate23Sequence());
        acquireRedeemCodeRequest.setRedeemCodeId(String.valueOf(configId));
        redeemCodeRemoteService.acquire(acquireRedeemCodeRequest);

        //兑换优惠码
        CodeRedeemRequest codeRedeemRequest = JsonCovertUntil.getObjectFromjson(codeRedeemPath, CodeRedeemRequest.class);
        codeRedeemRequest.setRedeemCode(redeemCode);
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        PlainResult<RedeemCodeRecordDTO> redeemResult = redeemCodeRemoteService.redeem(codeRedeemRequest);
        for (int i = 0; i < 6; i++) {
            if (redeemResult.getCode() == 200) {
                break;
            } else {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                redeemResult = redeemCodeRemoteService.redeem(codeRedeemRequest);
            }
        }
        Assert.assertEquals(redeemResult.getCode(), 200);
        Assert.assertEquals(redeemResult.getMessage(), "successful");
        Assert.assertEquals(redeemResult.getData().getRedeemCode(), redeemCode);
        checkStatusOfRedeem("REDEEMED", configId);

        //再次兑换优惠码
        redeemResult = redeemCodeRemoteService.redeem(codeRedeemRequest);
        Assert.assertEquals(redeemResult.getCode(), 4005);
        Assert.assertEquals(redeemResult.getMessage(), "兑换码已失效，无法兑换");


        //检查生成相应的券资产
        MkRedeemCodeRecord mkRedeemCodeRecord = mkRedeemCodeRecordMapper.selectOne(new QueryWrapper<MkRedeemCodeRecord>().eq("redeem_code", redeemCode));
        MkCouponAsset mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("source_order_id", mkRedeemCodeRecord.getId()).eq("source_order_type", "REDEEM_CODE_RECORD"));
        Assert.assertEquals(addRedeemCodeConfRequest.getRedeemContentList().get(0).getRedeemObjId(), String.valueOf(mkCouponAsset.getCouponId()));
        Assert.assertEquals(codeRedeemRequest.getBelongToId(), mkCouponAsset.getBelongtoYid());
        Assert.assertEquals("RECEIVED", mkCouponAsset.getState());
        //清理数据
        deleteRedeemCodeData(redeemCode);
    }

    /**
     * 1.创建优惠码
     * 2.获取优惠码
     * 3.分配兑换码
     * 4.兑换优惠码
     * 5.检查生成相应的券资产
     * 6.回收券码
     * 7.检查券码已回收
     * 8.检查券资产已回收
     */
    @Test(priority = 2)
    public void testCycleRedeemCode() {
        AddRedeemCodeConfRequest addRedeemCodeConfRequest = JsonCovertUntil.getObjectFromjson(promoCodeCreatePath, AddRedeemCodeConfRequest.class);
        /**
         * -----这边放到jenkin上，经常空指针，不确定是不是调用方法导致数据拿不到，先不调用方法，把逻辑直接加进来---------------
         */
        //创建优惠码
        //根据时间戳生成序列作为优惠券码名称
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String redeemCodeName = "auto-lfy-redeemName" + dateString;
        addRedeemCodeConfRequest.setName(redeemCodeName);
        addRedeemCodeConfRequest.setConfDesc(redeemCodeName);
        PlainResult<AddRedeemCodeConfResponse> addRedeemCodeConfResponsePlainResult = redeemCodeManagerService.addRedeemCodeConf(addRedeemCodeConfRequest);
        Assert.assertEquals(addRedeemCodeConfResponsePlainResult.getCode(), 200);
        Assert.assertEquals(addRedeemCodeConfResponsePlainResult.getMessage(), "successful");
        Assert.assertNotNull(addRedeemCodeConfResponsePlainResult.getData());
        logger.info("生成券码批次id:-->" + addRedeemCodeConfResponsePlainResult.getData().getId());
        /**
         * -----------------------------------------------------
         */

        Long configId = addRedeemCodeConfResponsePlainResult.getData().getId();
        String redeemObjId = addRedeemCodeConfRequest.getRedeemContentList().get(0).getRedeemObjId();
        logger.info("addRedeemCodeConfRequest--->:" + addRedeemCodeConfRequest);
        //获取优惠码
        GetRedeemCodeDataRequest getRedeemCodeDataRequest = new GetRedeemCodeDataRequest();
        getRedeemCodeDataRequest.setConfigId(configId);
        PlainResult<List<GetRedeemCodeDataResponse>> listPlainResult = redeemCodeManagerService.getRedeemCodeData(getRedeemCodeDataRequest);
        checkStatusOfRedeem("UNISSUED", configId);
        String redeemCode = "";
        if (listPlainResult.getData() != null) {
            redeemCode = listPlainResult.getData().get(0).getRedeemCode();
        }
        //分配兑换码
        AcquireRedeemCodeRequest acquireRedeemCodeRequest = JsonCovertUntil.getObjectFromjson(codeAcquirePath, AcquireRedeemCodeRequest.class);
        acquireRedeemCodeRequest.setAcquireBizNo(generate23Sequence());
        acquireRedeemCodeRequest.setRedeemCodeId(String.valueOf(configId));
        redeemCodeRemoteService.acquire(acquireRedeemCodeRequest);

        //兑换优惠码
        CodeRedeemRequest codeRedeemRequest = JsonCovertUntil.getObjectFromjson(codeRedeemPath, CodeRedeemRequest.class);
        codeRedeemRequest.setRedeemCode(redeemCode);
        redeemCodeRemoteService.redeem(codeRedeemRequest);

        //检查生成相应的券资产
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        MkRedeemCodeRecord mkRedeemCodeRecord = mkRedeemCodeRecordMapper.selectOne(new QueryWrapper<MkRedeemCodeRecord>().eq("redeem_code", redeemCode));
        MkCouponAsset mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("source_order_id", mkRedeemCodeRecord.getId()).eq("source_order_type", "REDEEM_CODE_RECORD"));
        Assert.assertEquals(redeemObjId, String.valueOf(mkCouponAsset.getCouponId()));
        Assert.assertEquals(codeRedeemRequest.getBelongToId(), mkCouponAsset.getBelongtoYid());
        Assert.assertEquals("RECEIVED", mkCouponAsset.getState());
        //回收券码
        RecycleRedeemObjRequest recycleRedeemObjRequest = new RecycleRedeemObjRequest();
        recycleRedeemObjRequest.setRedeemCodeRecordId(String.valueOf(mkRedeemCodeRecord.getId()));
        PlainResult<RecycleRedeemObjResponse> redeemObjResponsePlainResult = redeemCodeManagerService.recycleRedeemObj(recycleRedeemObjRequest);
        //检查券码已回收
        checkStatusOfRedeem("REDEEM_OBJ_RECYCLED", configId);
        //检查券资产已回收
        mkCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("source_order_id", mkRedeemCodeRecord.getId()).eq("source_order_type", "REDEEM_CODE_RECORD"));
        Assert.assertEquals("RECYCLED", mkCouponAsset.getState());

        deleteRedeemCodeData(redeemCode);
    }


    /**
     * 优惠券码数据删除操作
     */
    public void deleteRedeemCodeData(String redeemCode) {
        //注意删除数据的顺序
        MkRedeemCodeRecord mkRedeemCodeRecord = mkRedeemCodeRecordMapper.selectOne(new QueryWrapper<MkRedeemCodeRecord>()
                .eq("redeem_code", redeemCode));
        logger.info("-------开始清理券码【" + redeemCode + "】相关的信息------");

        //1.delete asset
        couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>()
                .eq("source_order_id", mkRedeemCodeRecord.getId())
                .eq("source_order_type", "REDEEM_CODE_RECORD"));
        logger.info("券资产信息已清理，source_order_id：-->" + mkRedeemCodeRecord.getId());

        //2.delete content
        mkRedeemCodeContentMapper.delete(new QueryWrapper<MkRedeemCodeContent>()
                .eq("rel_conf_id", mkRedeemCodeRecord.getRelConfId()));
        logger.info("券码内容相关信息已清理，rel_conf_id：--->" + mkRedeemCodeRecord.getRelConfId());
        //3.delete recordbelong_to_id
        mkRedeemCodeRecordMapper.delete(new QueryWrapper<MkRedeemCodeRecord>()
                .eq("rel_conf_id", mkRedeemCodeRecord.getRelConfId()));
        logger.info("券码记录相关信息已清理，rel_conf_id：--->" + mkRedeemCodeRecord.getRelConfId());

        //4.delete conf
        mkRedeemCodeConfMapper.delete(new QueryWrapper<MkRedeemCodeConf>()
                .eq("id", mkRedeemCodeRecord.getRelConfId()));
        logger.info("券码配置相关信息已清理，rel_conf_id：--->" + mkRedeemCodeRecord.getRelConfId());

    }


    /**
     * 验证优惠券码状态
     *
     * @param status
     * @param configId
     */
    public void checkStatusOfRedeem(String status, Long configId) {
        //获取优惠码
        GetRedeemCodeDataRequest getRedeemCodeDataRequest = new GetRedeemCodeDataRequest();
        getRedeemCodeDataRequest.setConfigId(configId);
        PlainResult<List<GetRedeemCodeDataResponse>> listPlainResult = redeemCodeManagerService.getRedeemCodeData(getRedeemCodeDataRequest);
        if (listPlainResult.getData() != null) {
            Assert.assertEquals(listPlainResult.getData().get(0).getState(), status);
        }
    }

    /**
     * 创建并验证优惠券码
     *
     * @return
     */
    public PlainResult<AddRedeemCodeConfResponse> createPromoCode() {
        //创建优惠码
        AddRedeemCodeConfRequest addRedeemCodeConfRequest = JsonCovertUntil.getObjectFromjson(promoCodeCreatePath, AddRedeemCodeConfRequest.class);
        //根据时间戳生成序列作为优惠券码名称
        String dateString = new SimpleDateFormat("mmDDHHmm").format(new Date());
        String redeemCodeName = "auto-lfy-redeemName" + dateString;
        addRedeemCodeConfRequest.setName(redeemCodeName);
        addRedeemCodeConfRequest.setConfDesc(redeemCodeName);
        PlainResult<AddRedeemCodeConfResponse> addRedeemCodeConfResponsePlainResult = redeemCodeManagerService.addRedeemCodeConf(addRedeemCodeConfRequest);
        Assert.assertEquals(addRedeemCodeConfResponsePlainResult.getCode(), 200);
        Assert.assertEquals(addRedeemCodeConfResponsePlainResult.getMessage(), "successful");
        Assert.assertNotNull(addRedeemCodeConfResponsePlainResult.getData());
        logger.info("生成券码批次id:-->" + addRedeemCodeConfResponsePlainResult.getData().getId());

        return addRedeemCodeConfResponsePlainResult;
    }

    @Test(enabled = false)
    public void testHistoryRedeemCode(){
        String s ="{\n" +
                "\t\"data\":\n" +
                "\t[\n" +
                "\t\t{\n" +
                "\t\t\t\"redeem_code\": \"3SGCQQFY\"\n" +
                "\t\t},\n" +
                "\t\t{\n" +
                "\t\t\t\"redeem_code\": \"SQ75D3JF\"\n" +
                "\t\t}\n" +
                "\t]\n" +
                "}";

        JSONObject jsonObject = JSONObject.parseObject(s);
        JSONArray jsonArray = jsonObject.getJSONArray("data");
        for(int i=0;i<jsonArray.size();i++){
            JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
            deleteRedeemCodeData(String.valueOf(jsonObject1.get("redeem_code")));
        }

    }
}
