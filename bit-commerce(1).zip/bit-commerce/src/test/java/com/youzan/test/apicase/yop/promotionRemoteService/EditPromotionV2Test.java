package com.youzan.test.apicase.yop.promotionRemoteService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.request.EditPromotionV2Request;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @program: bit-commerce
 * @description 编辑营销
 * @author: tianning
 * @create: 2021-03-24 12:36
 **/
public class EditPromotionV2Test extends TnBaseTest {

    @JSONData(value = "dataResource/apicase/yop/EditPromotionV2RequestData.json", key = "editPromotionV2Request")
    private EditPromotionV2Request editPromotionV2Request;

    @JSONData(value = "dataResource/apicase/yop/EditPromotionV2RequestData.json", key = "editPromotionV2InvalidRequest")
    private EditPromotionV2Request editPromotionV2InvalidRequest;

    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test(priority = 0)
    public void listBriefPromotionV2Test() {
        PlainResult<Long> createPromotionResult = null;
        try {
            createPromotionResult = createPromotion();
            editPromotionV2Request.setPromotionId(createPromotionResult.getData());
            PlainResult<Boolean> editPromotionV2Result = promotionRemoteService.editPromotionV2(editPromotionV2Request);
            Assert.assertEquals(editPromotionV2Result.getCode(), 200);
            Assert.assertTrue(editPromotionV2Result.getData());
        } finally {
            invalidPresentActivity(createPromotionResult.getData());
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }

    /**
     * 异常用例
     */
    @Test(priority = 2)
    public void listBriefPromotionV2ParamNullTest() {
        PlainResult<Boolean> editPromotionV2Result = promotionRemoteService.editPromotionV2(null);
        Assert.assertEquals(editPromotionV2Result.getCode(), 130501);
    }

    /**
     * 异常用例
     */
    @Test(priority = 3)
    public void listBriefPromotionV2PromotionTypeNullTest() {
        PlainResult<Long> createPromotionResult = null;
        try {
            createPromotionResult = createPromotion();
            editPromotionV2Request.setPromotionId(createPromotionResult.getData());
            editPromotionV2Request.setPromotionType(null);
            PlainResult<Boolean> editPromotionV2Result = promotionRemoteService.editPromotionV2(editPromotionV2Request);
            Assert.assertEquals(editPromotionV2Result.getCode(), 130624);
        } finally {
            invalidPresentActivity(createPromotionResult.getData());
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }

    /**
     * 异常用例
     */
    @Test(priority = 4)
    public void listBriefPromotionV2PromotionIdNullTest() {
        editPromotionV2Request.setPromotionId(null);
        PlainResult<Boolean> editPromotionV2Result = promotionRemoteService.editPromotionV2(editPromotionV2Request);
        Assert.assertEquals(editPromotionV2Result.getCode(), 130501);
    }

    /**
     * 异常用例--编辑已经失效的
     */
    @Test(priority = 1)
    public void listBriefPromotionV2EditInvalidTest() {
        PlainResult<Long> createPromotionResult = null;
        try {
            createPromotionResult = createPromotion();
            invalidPresentActivity(createPromotionResult.getData());

            //查一下数据库
            List<MkActivity> mkActivityList =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, createPromotionResult.getData()));
            Assert.assertEquals(mkActivityList.get(0).getState(), "CANCELED");

            editPromotionV2InvalidRequest.setPromotionId(mkActivityList.get(0).getId());

            PlainResult<Boolean> editPromotionV2Result = promotionRemoteService.editPromotionV2(editPromotionV2InvalidRequest);
            Assert.assertEquals(editPromotionV2Result.getCode(), 130624);
        } finally {
            invalidPresentActivity(createPromotionResult.getData());
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }
}
