package com.youzan.test.concurrent;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.PresentRemoteService;
import com.youzan.ycm.market.constant.PromotionTypeConstant;
import com.youzan.ycm.market.request.present.SendPresentCouponRequest;
import com.youzan.ycm.market.response.present.SendPresentCouponResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


/**
 * @author leifeiyun
 * @date 2021/1/6
 **/
public class TestSendPresentCouponConcurrent extends ConcurrentBaseTest {

    @Dubbo
    PresentRemoteService presentRemoteService;


    @DataProvider(parallel = true,name="saveCouponAssetData")
    public Object[][] datas() {
       Object[][] objects = new Object[][]{
               {"58802859","XXX","lfy0000000980"}
       };
       return objects;
    }

    @Test(threadPoolSize=5, invocationCount=20,dataProvider = "saveCouponAssetData")
    public void testSendPresentCouponConcurrent(String kdtId,String couponId,String bizNO){

        SendPresentCouponRequest request = new SendPresentCouponRequest();
        request.setDistributeStock(1L);
        request.setPromotionType(PromotionTypeConstant.COUPON);
        request.setPromotionId(Long.valueOf(couponId));
        request.setKdtId(Long.valueOf(kdtId));

        request.setBizType("PRESENT_COUPON");
        request.setBizNo(bizNO);

        PlainResult<SendPresentCouponResponse> result =  presentRemoteService.sendPresentCoupon(request);
        logger.info("SendPresentCouponResponse.getData()--》："+result.getData());

    }
}
