package com.youzan.test.basecase;

import com.youzan.commerce.test.dataprepare.driver.SimpleDriverService;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.perform.front.api.PfAbilityStatusBaseQueryService;
import com.youzan.ycm.perform.front.request.status.QueryAbilityStatusRequest;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.junit.Rule;

/**
 * @author shenwu
 * @date 2021/9/13 11:48 下午
 */
public class SwBaseTest extends BaseTest {

    @Rule
    public SimpleDriverService driverService = new SimpleDriverService();

    @Dubbo
    PfAbilityStatusBaseQueryService pfAbilityStatusBaseQueryService;
    @JSONData(value = "dataResource/apicase.perform/QueryStatusByAbilityIdAndApplyYcmIdRequest.json", key = "request")
    private QueryAbilityStatusRequest queryAbilityStatusRequest;

}
