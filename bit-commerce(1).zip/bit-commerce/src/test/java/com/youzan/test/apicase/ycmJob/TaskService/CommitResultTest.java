package com.youzan.test.apicase.ycmJob.TaskService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.ycmJob.JbcJob;
import com.youzan.commerce.test.entity.dataobject.ycmJob.JbcTask;
import com.youzan.test.apicase.ycmJob.JobBaseTest;
import com.youzan.ycm.job.request.TaskSyncStateRequest;
import com.youzan.ycm.job.response.TaskSyncStateResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-04-14 15:52
 **/

public class CommitResultTest extends JobBaseTest {

    /**
     * 子任务同步--result==SU
     */
    @Test
    public void commitResultResultIsSUTest() {
        try {
            deleteJob();

            String bizNo = registerJobTest();

            List<JbcJob> jbcJobList =
                    jbcJobMapper.selectList(
                            new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getBizNo, bizNo).orderByDesc(JbcJob::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcJobList));


            List<JbcTask> jbcTaskList =
                    jbcTaskMapper.selectList(
                            new QueryWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, jbcJobList.get(0).getJobNo()).orderByDesc(JbcTask::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcTaskList));

            TaskSyncStateRequest taskSyncStateRequest = new TaskSyncStateRequest();
            taskSyncStateRequest.setJobNo(jobNo);
            taskSyncStateRequest.setResult("SU");

            jbcTaskList.forEach(item -> {
                taskSyncStateRequest.setTaskNo(item.getTaskNo());
                PlainResult<TaskSyncStateResponse> taskSyncStateResult = taskService.commitResult(taskSyncStateRequest);
                Assert.assertEquals(taskSyncStateResult.getCode(), 200);
                Assert.assertTrue(taskSyncStateResult.getData().getSyncSuccess());
            });
        } finally {
            deleteJob();
        }
    }

    /**
     * 子任务同步--result==FA
     */
    @Test
    public void commitResultResultIsFATest() {
        try {
            deleteJob();

            String bizNo = registerJobTest();

            List<JbcJob> jbcJobList =
                    jbcJobMapper.selectList(
                            new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getBizNo, bizNo).orderByDesc(JbcJob::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcJobList));


            List<JbcTask> jbcTaskList =
                    jbcTaskMapper.selectList(
                            new QueryWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, jbcJobList.get(0).getJobNo()).orderByDesc(JbcTask::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcTaskList));

            TaskSyncStateRequest taskSyncStateRequest = new TaskSyncStateRequest();
            taskSyncStateRequest.setJobNo(jobNo);
            taskSyncStateRequest.setResult("SU");

            jbcTaskList.forEach(item -> {
                taskSyncStateRequest.setTaskNo(item.getTaskNo());
                PlainResult<TaskSyncStateResponse> taskSyncStateResult = taskService.commitResult(taskSyncStateRequest);
                Assert.assertEquals(taskSyncStateResult.getCode(), 200);
                Assert.assertTrue(taskSyncStateResult.getData().getSyncSuccess());
            });
        } finally {
            deleteJob();
        }
    }

    /**
     * 子任务同步--异常场景--jobNo为null
     */
    @Test
    public void commitResultJobNoNullTest() {
        try {
            deleteJob();
            String bizNo = registerJobTest();

            List<JbcJob> jbcJobList =
                    jbcJobMapper.selectList(
                            new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getBizNo, bizNo).orderByDesc(JbcJob::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcJobList));

            List<JbcTask> jbcTaskList =
                    jbcTaskMapper.selectList(
                            new QueryWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, jbcJobList.get(0).getJobNo()).orderByDesc(JbcTask::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcTaskList));

            TaskSyncStateRequest taskSyncStateRequest = new TaskSyncStateRequest();
            taskSyncStateRequest.setJobNo(null);
            taskSyncStateRequest.setResult("SU");

            jbcTaskList.forEach(item -> {
                taskSyncStateRequest.setTaskNo(item.getTaskNo());
                PlainResult<TaskSyncStateResponse> taskSyncStateResult = taskService.commitResult(taskSyncStateRequest);
                Assert.assertEquals(taskSyncStateResult.getCode(), 1011);
            });
        } finally {
            deleteJob();
        }
    }

    /**
     * 子任务同步--异常场景--result为null
     */
    @Test
    public void commitResultResultNullTest() {
        try {
            deleteJob();

            String bizNo = registerJobTest();

            List<JbcJob> jbcJobList =
                    jbcJobMapper.selectList(
                            new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getBizNo, bizNo).orderByDesc(JbcJob::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcJobList));

            List<JbcTask> jbcTaskList =
                    jbcTaskMapper.selectList(
                            new QueryWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, jbcJobList.get(0).getJobNo()).orderByDesc(JbcTask::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(jbcTaskList));

            TaskSyncStateRequest taskSyncStateRequest = new TaskSyncStateRequest();
            taskSyncStateRequest.setJobNo(jobNo);
            taskSyncStateRequest.setResult(null);

            jbcTaskList.forEach(item -> {
                taskSyncStateRequest.setTaskNo(item.getTaskNo());
                PlainResult<TaskSyncStateResponse> taskSyncStateResult = taskService.commitResult(taskSyncStateRequest);
                Assert.assertEquals(taskSyncStateResult.getCode(), 1011);
            });
        } finally {
            deleteJob();
        }
    }
}
