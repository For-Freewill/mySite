package com.youzan.test.refund.basecase;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.request.RefundCalculateNonConsumeRequest;
import com.youzan.yop.api.response.RefundCalculateNonConsumeResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wuwu
 * @date 2020/11/9 7:38 PM
 */
public class WscRefundTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(WscRefundTest.class);
    public Long promotionId = 8649L;
    String refundMode = "BY_VALUE";

    @Test
    public void refundByAllAndOrigWayIn24() {
        /**
         * 1. 订购微商城1年
         * 2. 24小时内退款refund mode = BY_ALL,refund way = ORIG
         * 3. 校验结果：退款金额 = 实付金额，24小时内的原路退回按购买价格退
         */

        closeWaitPayOrder(baseRefundKdtId);
        refundOrderByKdtId(baseRefundKdtId);
        rechargeYzcoin(baseRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(baseRefundKdtId), cny + 1000);
        concurrentStatus(baseRefundKdtId);
        String refundMode = "BY_ALL";

        //创建订单
        PlainResult<String> createOrderResult = createNormalOrder(baseRefundKdtId, baseRefundKdtName, basicBaiduItemId_2021, 1, yzb);
        logger.info("新的创建订单结果是：{}", createOrderResult);
        Assert.assertEquals(createOrderResult.getCode(), 200, createOrderResult.getMessage());

        //预付款和付款
        if (createOrderResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(createOrderResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, baseRefundKdtId);
        }

        String orderId = createOrderResult.getData();
        waitForPerform(baseRefundKdtId, 873L, Long.valueOf(orderId));

        logger.info("履约成功");

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        String pfOrderId = String.valueOf(pfOrder.getId());
        //计算24小时内原路退回-按购买原价退回的退款非库存退款现金和有赞币计算正确

        //构造退款参数
        RefundCalculateNonConsumeRequest calculateNonConsumeRequest = buildCalculateNonConsumeRequest(pfOrderId, refundMode);
        logger.info("计算退款参数：{}", calculateNonConsumeRequest);

        PlainResult<RefundCalculateNonConsumeResponse> calculateResult = refundRemoteService.calculateNonConsume(calculateNonConsumeRequest);
        logger.info("退款订单结果：{}", calculateResult);

        refundOrder(pfOrderId, calculateResult.getData().getRefundTotalCnyAmt(), calculateResult.getData().getRefundTotalYzbAmt(), refundMode);
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(orderId));

        logger.info("服务期回收成功");

    }

    @Test
    public void refundByValueAndOrigWayIn24() {
        /**
         * 1. 订购微商城1年
         * 2. 24小时内退款refund mode = BY_ALL,refund way = ORIG
         * 3. 校验结果：退款金额 = 实付金额，24小时内的原路退回按购买价格退
         */

        closeWaitPayOrder(baseRefundKdtId);
        refundOrderByKdtId(baseRefundKdtId);
        rechargeYzcoin(baseRefundKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(baseRefundKdtId), cny + 1000);
        concurrentStatus(baseRefundKdtId);
        String refundMode = "BY_VALUE";

        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(baseRefundKdtId,baseRefundKdtName,basicBaiduItemId_2021,1,0L);

        Assert.assertEquals(orderCreateApiPlainResult.getCode(), 200, orderCreateApiPlainResult.getMessage());

        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, baseRefundKdtId);
        }

        String orderId = orderCreateApiPlainResult.getData();

        waitForPerform(baseRefundKdtId, 873L, Long.valueOf(orderId));

        logger.info("履约成功");

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        String pfOrderId = String.valueOf(pfOrder.getId());

        //构造退款参数
        RefundCalculateNonConsumeRequest calculateNonConsumeRequest = buildCalculateNonConsumeRequest(pfOrderId, refundMode);
        logger.info("计算退款参数：{}", calculateNonConsumeRequest);

        PlainResult<RefundCalculateNonConsumeResponse> calculateResult = refundRemoteService.calculateNonConsume(calculateNonConsumeRequest);
        logger.info("退款订单结果：{}", calculateResult);

        //按剩余价值退款
        //TODO 计算剩余价值正确性，24小时内等于付款金额
        refundOrder(pfOrderId, calculateResult.getData().getRefundTotalCnyAmt(), calculateResult.getData().getRefundTotalYzbAmt(), refundMode);
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(orderId));

        initShopByKdtId(baseRefundKdtId);
    }

    @Test
    public void refundAndRecycleOrderGift() {
        initShopByKdtId(baseRefundKdtId);
        rechargeShopBalance(String.valueOf(baseRefundKdtId), cny + 1000);

        //下单，带一个礼包
        setActivityValid(promotionId);

        PlainResult<String> result =createNormalOrder(baseRefundKdtId,baseRefundKdtName,basicWechatItemId,1,0L);
        logger.info("创建订单的结果：{}",result);

        setActivityInvalid(promotionId);


        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, baseRefundKdtId);
        }

        waitForPerform(baseRefundKdtId,873L,Long.valueOf(result.getData()));

        //退款
        Long orderId = Long.valueOf(result.getData());

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("app_id", "combine_spu_wsc"));

        String pfOrderId = String.valueOf(pfOrder.getId());
        //计算24小时内原路退回-按购买原价退回的退款非库存退款现金和有赞币计算正确

        //构造退款参数
        RefundCalculateNonConsumeRequest calculateNonConsumeRequest = buildCalculateNonConsumeRequest(pfOrderId, refundMode);
        logger.info("计算退款参数：{}", calculateNonConsumeRequest);

        PlainResult<RefundCalculateNonConsumeResponse> calculateResult = refundRemoteService.calculateNonConsume(calculateNonConsumeRequest);
        logger.info("退款订单结果：{}", calculateResult);

        refundOrder(pfOrderId, calculateResult.getData().getRefundTotalCnyAmt(), calculateResult.getData().getRefundTotalYzbAmt(), refundMode);
        waitForRefund(baseRefundKdtId, 873L, Long.valueOf(result.getData()));

        logger.info("服务期回收成功");

        //校验礼包服务期已经回收
        //查询有效的礼包服务期的sql语句 TODO 后面写一个统一的方法（查询礼包服务期）
        Wrapper<PfOrderStatus> queryWrapper = new QueryWrapper<PfOrderStatus>()
                .eq("pf_order_id", pfOrder.getId())
                .eq("apply_ycm_id", baseRefundKdtId)
                .eq("apply_ycm_type", "KDT_ID")
                .eq("app_id", "atom_spu_wsc")
                .eq("state", "valid")
                .eq("group_type", "product_with_present");

        //校验微商城服务期生成
        List<PfOrderStatus> pfOrderStatusList = pfOrderStatusMapper.selectList(queryWrapper);

        Assert.assertEquals(pfOrderStatusList.size(),0,"礼包服务期未回收成功");
    }


    @Override
    public PlainResult<String> createNormalOrder(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);
        Byte type = 25;

        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();

        if (itemId == basicWechatItemId) {
            PreferentialDescApi itemPromtion = new PreferentialDescApi();
            itemPromtion.setType(type);
            itemPromtion.setSelected(true);
            itemPromtion.setPromotionId(promotionId);

            itemPromotionList.add(itemPromtion);

            orderItemForm.setItemPromotionList(itemPromotionList);
        }

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);
        logger.info("创建订单参数:{}", JSON.toJSONString(createOrderForm));
        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);

        return resultCreateNormalOrder;
    }


}
