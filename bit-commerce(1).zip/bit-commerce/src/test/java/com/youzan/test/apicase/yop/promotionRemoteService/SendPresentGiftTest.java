package com.youzan.test.apicase.yop.promotionRemoteService;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.MkPresent;
import com.youzan.commerce.test.entity.dataobject.market.MkPresentGift;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplate;
import com.youzan.commerce.test.entity.dataobject.perform.PfAsset;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.shopcenter.shop.entity.LongServiceResult;
import com.youzan.shopcenter.shop.entity.request.WscCreateRequest;
import com.youzan.shopcenter.shop.service.ShopCreateService;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.uic.api.user.service.UserRegisterService;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import com.youzan.ycm.qa.enable.platform.api.service.enable.EnableNewShopPoolService;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.request.SendPresentGiftRequest;
import com.youzan.yop.api.response.SendPresentGiftResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2020/11/05 3:59 下午
 * 根据订单号补发买赠礼包（包括买赠礼包以及买赠券）
 * 目前该接口只用于CRM侧补发礼包的业务场景
 */
public class SendPresentGiftTest extends TnBaseTest {

    @JSONData(value = "dataResource/apicase/yop/SendPresentGiftRequestData.json", key = "ACTIVITYRequest")
    private SendPresentGiftRequest ACTIVITYRequest;

    @JSONData(value = "dataResource/apicase/yop/SendPresentGiftRequestData.json", key = "COUPONRequest")
    private SendPresentGiftRequest COUPONRequest;

    @JSONData(value = "dataResource/apicase/yop/SendPresentGiftRequestData.json", key = "request")
    private SendPresentGiftRequest request;

    @JSONData(value = "dataResource/apicase/yop/SendPresentGiftRequestData.json", key = "requestOrderIdInvalid")
    private SendPresentGiftRequest requestOrderIdInvalid;

    @JSONData(value = "dataResource/apicase/yop/SendPresentGiftRequestData.json", key = "requestOrderIDNotExit")
    private SendPresentGiftRequest requestOrderIDNotExit;

    @JSONData(value = "dataResource/apicase/yop/CreateBuyGiftTempleteRequestData.json", key = "createPresenTemplateRequest")
    private SaveGiftTemplateRequest createPresenTemplateRequest;

    //创建订单使用
    @JSONData(value = "dataResource/apicase/yop/SendGiftRequestData.json", key = "createOrderForm")
    private CreateOrderForm createOrderForm;

    @Dubbo
    private EnableNewShopPoolService enableNewShopPoolService;
    @Dubbo
    private ShopCreateService shopCreateService;
    @Dubbo
    private UserRegisterService userRegisterService;

    Long templateId = null;

    //对应的手机号：15558185312
    Long account = 8166237931L;

    String kdtIdName = "CISendGiftKdtId";

    @BeforeMethod
    public void init() {
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * 根据订单号补发买赠礼包
     */
    @Test
    public void sendPresentGiftActivityNormalTest() {
        try {
            //创建一个买赠活动，2021微商城百度小程序，礼包是积分商城1年
            PlainResult<Long> activityId = createPromotion();

            //查询下生成的活动ID对应的礼包模板ID
            List<MkActivity> mkActivityList =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId));

            mkActivityList.forEach(item -> {
                List<MkActivityRule> mkActivityRulesList =
                        activityRuleMapper.selectList(
                                new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, item.getId()));

                //获取mk_present表数据，其中id是 mk_present表的actions大字段里的 presentId
                String presentId = "";
                JSONArray jsonArray = JSONArray.parseArray(mkActivityRulesList.get(0).getActions());
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                presentId = jsonObject.getString("presentId");
                List<MkPresent> mkPresentsList =
                        mkPresentMapper.selectList(
                                new QueryWrapper<MkPresent>().lambda().eq(MkPresent::getId, presentId));

                Assert.assertNotNull(mkPresentsList);

                List<MkPresentGift> mkPresentGiftList =
                        mkPresentGiftMapper.selectList(
                                new QueryWrapper<MkPresentGift>().lambda().eq(MkPresentGift::getPresentId, presentId));
                templateId = mkPresentGiftList.get(0).getGiftTemplateId();

                try {
                    sleep(10000);
                } catch (Throwable e) {
                    e.getMessage();
                }

                //创建WSC单店
                Long kdtId = createWscSingleKdtId().getData();

                rechargeShopBalance(kdtId.toString(), 99999999);

                closeWaitPayOrder(kdtId);

                //创建订单  订购WSC百度小程序
                createOrderForm.setKdtId(kdtId);

                PlainResult<String> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                        new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                            @Override
                            public PlainResult<String> doExecute() {
                                return orderRemoteService.createNormalOrder(createOrderForm);
                            }

                            @Override
                            public boolean handleResult(PlainResult<String> plainResult) {
                                return plainResult.getCode() == 200;
                            }
                        }, 5, 100);

                Assert.assertEquals(plainResult.getCode(), 200);

                if (plainResult.getCode() == 200) {

                    //3.预支付
                    PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.parseLong(plainResult.getData()), (byte) 4);
                    Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

                    //4.余额支付
                    cashierPay(preparePayApiPlainResult, String.valueOf(account), kdtId);

                    try {
                        sleep(3000);
                    } catch (Throwable e) {
                        e.getMessage();
                    }

                    List<PfOrder> orderList = queryPfOrder(kdtId);
                    ACTIVITYRequest.setOrderId(orderList.get(0).getId().toString());

                    ACTIVITYRequest.setPromotionId(activityId.getData().toString());
                    ACTIVITYRequest.setBizNo(orderList.get(0).getBizOrderId());

                    ACTIVITYRequest.setGiftTemplateId(templateId.toString());

                    PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(ACTIVITYRequest);

                    Assert.assertEquals(sendPresentGiftResult.getCode(), 200);
                    Assert.assertEquals(sendPresentGiftResult.getData().getGiftAssetId().length(), 19);

                    List<PfAsset> pfAssetResult = pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("out_biz_no", ACTIVITYRequest.getBizNo()));
                    Assert.assertEquals(pfAssetResult.get(0).getGiftAssetId().longValue(), 19);
                }
            });
        } finally {
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }

    /**
     * 买赠券
     */
    @Test
    public void sendPresentGiftCOUPONNormalTest() {
        try {
            //创建买赠券，要发的券的活动时间必须包含订单的创建时间，因此需要先创建要发的券，券的内容是积分商城，订购的商品是WSC百度小程序
            PlainResult<Long> couponResult = createPresentCoupon();

            //查询下生成的活动ID对应的礼包模板ID
            List<MkActivity> mkActivityList =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, couponResult));

            mkActivityList.forEach(item -> {
                List<MkActivityRule> mkActivityRulesList =
                        activityRuleMapper.selectList(
                                new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, item.getId()));

                //获取mk_present表数据，其中id是 mk_present表的actions大字段里的 presentId
                String presentId = "";
                JSONArray jsonArray = JSONArray.parseArray(mkActivityRulesList.get(0).getActions());
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                presentId = jsonObject.getString("presentId");
                List<MkPresent> mkPresentsList =
                        mkPresentMapper.selectList(
                                new QueryWrapper<MkPresent>().lambda().eq(MkPresent::getId, presentId));

                Assert.assertNotNull(mkPresentsList);

                List<MkPresentGift> mkPresentGiftList =
                        mkPresentGiftMapper.selectList(
                                new QueryWrapper<MkPresentGift>().lambda().eq(MkPresentGift::getPresentId, presentId));
                templateId = mkPresentGiftList.get(0).getGiftTemplateId();

                try {
                    sleep(10000);
                } catch (Throwable e) {
                    e.getMessage();
                }

                Long kdtId = createWscSingleKdtId().getData();

                rechargeShopBalance(kdtId.toString(), 99999999);

                closeWaitPayOrder(kdtId);

                //创建WSC单店
                createOrderForm.setKdtId(kdtId);

                PlainResult<String> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                        new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                            @Override
                            public PlainResult<String> doExecute() {
                                return orderRemoteService.createNormalOrder(createOrderForm);
                            }

                            @Override
                            public boolean handleResult(PlainResult<String> plainResult) {
                                return plainResult.getCode() == 200;
                            }
                        }, 5, 100);

                Assert.assertEquals(plainResult.getCode(), 200);

                if (plainResult.getCode() == 200) {

                    //3.预支付
                    PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.parseLong(plainResult.getData()), (byte) 4);
                    Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

                    //4.余额支付
                    cashierPay(preparePayApiPlainResult, String.valueOf(account), kdtId);

                    try {
                        sleep(3000);
                    } catch (Throwable e) {
                        e.getMessage();
                    }

                    List<PfOrder> orderList = queryPfOrder(kdtId);
                    COUPONRequest.setOrderId(orderList.get(0).getId().toString());
                    COUPONRequest.setBizNo(orderList.get(0).getBizOrderId());

                    COUPONRequest.setPromotionId(couponResult.getData().toString());

                    COUPONRequest.setGiftTemplateId(templateId.toString());

                    PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(COUPONRequest);

                    Assert.assertEquals(sendPresentGiftResult.getCode(), 200);
                    Assert.assertEquals(sendPresentGiftResult.getData().getGiftAssetId().length(), 19);

                    List<PfAsset> pfAssetResult = pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("out_biz_no", COUPONRequest.getBizNo()));
                    Assert.assertEquals(pfAssetResult.get(0).getGiftAssetId().longValue(), 19);
                }
            });
        } finally {
            deletePresentCouponData();
            deleteTemplateDataCoupon();
        }
    }

    /**
     * 异常场景--当前订单已补发该礼包,不可再补发相同礼包
     */
    @Test
    public void sendPresentGiftOrderIdInvalidTest() {
        List<TdOrder> tdOrderList = queryTdOrderByKdtIdAndState(GIFTKDTID1);
        String td_no = tdOrderList.get(0).getTdNo();
        List<PfOrder> pfOrderRecords =
                pfOrderMapper.selectList(
                        new QueryWrapper<PfOrder>().eq("biz_order_id", td_no).eq("app_category", "software_meal").orderByDesc("created_at"));

        requestOrderIdInvalid.setOrderId(pfOrderRecords.get(0).getId().toString());
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(requestOrderIdInvalid);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 1003);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "该订单不满足礼包补发条件，不可补发礼包");
    }

    /**
     * 异常场景 orderId不存在
     */
    @Test
    public void sendPresentGiftOrderIDNotExitTest() {

        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<SendPresentGiftResponse>>() {

                    @Override
                    public PlainResult<SendPresentGiftResponse> doExecute() {
                        return promotionRemoteService.sendPresentGift(requestOrderIDNotExit);
                    }

                    @Override
                    public boolean handleResult(PlainResult<SendPresentGiftResponse> sendPresentGiftResult) {
                        return sendPresentGiftResult.getCode() == 200;
                    }
                }, 5, 100);

        Assert.assertEquals(sendPresentGiftResult.getCode(), 1007);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "不存在的订单");
    }

    /**
     * 异常场景 orderId为null
     */
    @Test
    public void sendPresentGiftOrderIdNullTest() {
        request.setOrderId(null);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 promotionType为null
     */
    @Test
    public void sendPresentGiftpromotionTypeNullTest() {
        request.setPromotionType(null);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 promotionId为null
     */
    @Test
    public void sendPresentGiftpromotionIdNullTest() {
        request.setPromotionId(null);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 giftTemplateId为null
     */
    @Test
    public void sendPresentGiftTemplateIdNullTest() {
        request.setGiftTemplateId(null);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 distributeNum为0
     */
    @Test
    public void sendPresentGiftDistributeNumZeroTest() {
        request.setDistributeNum(0L);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 bizNo为null
     */
    @Test
    public void sendPresentGiftBizNoNullTest() {
        request.setBizNo(null);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 bizType非法--promotionType是ACTIVITY  这里promotionType是券时 才会出现该异常。promotionType是活动时 暂时未做处理  直接抛出999
     */
    @Test
    public void sendPresentGiftACTIVITYBizTypeNullTest() {
        request.setBizType(null);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 bizType非法--promotionType是COUPON
     */
    @Test
    public void sendPresentGiftCOUPONBizTypeNullTest() {
        request.setPromotionType("COUPON");
        request.setBizType(null);
        PlainResult<SendPresentGiftResponse> sendPresentGiftResult = promotionRemoteService.sendPresentGift(request);
        Assert.assertEquals(sendPresentGiftResult.getCode(), 130102);
        Assert.assertEquals(sendPresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 动态创建一个WSC店铺
     */
    public LongServiceResult createWscSingleKdtId() {
        WscCreateRequest request = new WscCreateRequest();

        request.setShopName(kdtIdName);
        request.setBusiness(30);
        request.setProvince("浙江省");
        request.setCity("杭州市");
        request.setArea("华泰创业园");
        request.setCountyId(310000);
        request.setAccountId(account);
        request.setAddress("华泰创业园");

        LongServiceResult result = shopCreateService.createWscShop(request);

        return result;
    }
}

