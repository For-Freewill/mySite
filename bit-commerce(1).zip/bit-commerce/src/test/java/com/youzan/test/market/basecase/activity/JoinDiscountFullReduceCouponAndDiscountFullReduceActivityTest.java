package com.youzan.test.market.basecase.activity;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponAsset;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.dto.activity.ActivityBaseDTO;
import com.youzan.ycm.market.request.activity.PageQueryActivityRequest;
import com.youzan.ycm.market.request.activity.SaveGoodsDiscountActivityRequest;
import com.youzan.ycm.market.request.activity.SaveOrderFullReduceActivityRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.response.PageResponse;
import com.youzan.ycm.market.response.activity.SaveGoodsDiscountActivityResponse;
import com.youzan.ycm.market.response.activity.SaveOrderFullReduceActivityResponse;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * @author leifeiyun
 * @date 2020/11/17
 **/

public class JoinDiscountFullReduceCouponAndDiscountFullReduceActivityTest extends MarketActivityBaseTest {


    @JSONData("dataResource/basecase.activity/fullReduceCouponForMemberCard.json")
    private SaveCouponRequest saveFullReduceCoupon;
    @JSONData("dataResource/basecase.activity/discountCouponForMemberCard.json")
    private SaveCouponRequest saveDiscountCoupon;
    @JSONData("dataResource/basecase.activity/discountActivityForMemberCardCreate.json")
    private SaveGoodsDiscountActivityRequest saveGoodsDiscountActivityRequest;
    @JSONData("dataResource/basecase.activity/fullReducetActivityForMemberCardCreate.json")
    private SaveOrderFullReduceActivityRequest saveOrderFullReduceActivityRequest;
    @JSONData("dataResource/basecase.activity/confirmOrderForMemberCard.json")
    private ConfirmOrderForm confirmOrderForm;


    @Test()
    public void testJoinDiscountFullReduceCouponAndDiscountFullReduceActivity() {
        String discountActivityId = "";
        String fullReduceActivityId = "";
        String discountCouponId = "";
        String fullReduceCouponId = "";

        try {
            //创建打折券
            discountCouponId = createCoupon("auto-lfy-打折券", saveDiscountCoupon);
            //上架打折券
            updateCouponState(discountCouponId);
            //创建满减券
            fullReduceCouponId = createCoupon("auto-lfy-满减券", saveFullReduceCoupon);
            //上架满减券
            updateCouponState(fullReduceCouponId);
            //组装发放打折券
            generateSendRecordAndSendCoupon(discountCouponId, "auto-lfy-打折券-发券单");
            //组装发放满减券
            generateSendRecordAndSendCoupon(fullReduceCouponId, "auto-lfy-满减券-发券单");

            //创建打折活动
            PlainResult<SaveGoodsDiscountActivityResponse> saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveGoodsDiscountActivityRequest);
            if (saveDiscountActivityResult.getCode() == 703) {
                //打折活动已创建，则失效掉
                PageQueryActivityRequest pageQueryActivityRequest = new PageQueryActivityRequest();
                pageQueryActivityRequest.setKeyword("集成测试插件-2");
                PlainResult<PageResponse<ActivityBaseDTO>> queryResult = goodsDicountActivityuRemoteService.pageQueryActivityList(pageQueryActivityRequest);
                for (int i = 0; i < queryResult.getData().getItems().size(); i++) {
                    expireDiscountActivity(queryResult.getData().getItems().get(i).getActivityId());
                }
                saveDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(saveGoodsDiscountActivityRequest);
            }
            discountActivityId = saveDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId();
            //创建满减活动
            PlainResult<SaveOrderFullReduceActivityResponse> saveFullReduceActivityResult = orderFullReduceActivityRemoteService.saveActivity(saveOrderFullReduceActivityRequest);
            Assert.assertEquals(saveFullReduceActivityResult.getCode(), 200, saveFullReduceActivityResult.getMessage());
            fullReduceActivityId = saveFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId();

            MkCouponAsset discountCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("coupon_id", discountCouponId));
            MkCouponAsset fullReduceCouponAsset = couponAssetMapper.selectOne(new QueryWrapper<MkCouponAsset>().eq("coupon_id", fullReduceCouponId));
            String discountAssetId = String.valueOf(discountCouponAsset.getId());
            String fullReduceAssetId = String.valueOf(fullReduceCouponAsset.getId());


            //21:满减活动，22:券资产，23:打折活动
            PreferentialDescApi preferentialDescApi = new PreferentialDescApi();
            //设置打折活动
            confirmOrderForm.getItems().get(0).getItemPromotionList().set(0, generatePreferential(discountActivityId, (byte) 23));
            // 设置打折券
            confirmOrderForm.getItems().get(0).getItemPromotionList().set(1, generatePreferential(discountAssetId, (byte) 22));

            // 设置满减活动
            confirmOrderForm.getOrderPromotionList().set(0, generatePreferential(fullReduceActivityId, (byte) 21));
            // 设置满减券
            confirmOrderForm.getOrderPromotionList().set(1, generatePreferential(fullReduceAssetId, (byte) 22));
            PlainResult<OrderConfirmApi> confirmApiPlainResult = orderRemoteService.confirmOrder(confirmOrderForm);
            Long totalSumPrice = Long.valueOf((long) (68800 * 0.9 * 0.88));
            Long totalPrice = Long.valueOf((long) (68800 * 0.9 * 0.88 - 2000 - 1000));
            Long totalDiscountPrice = Long.valueOf((long) 68800 - (long) (68800 * 0.9 * 0.88 - 2000 - 1000));
            Assert.assertEquals(totalSumPrice, confirmApiPlainResult.getData().getTotalSumPrice(), "营销小计错误");
            Assert.assertEquals(totalPrice, confirmApiPlainResult.getData().getTotalRealPrice(), "营销金额错误");
            Assert.assertEquals(Long.valueOf(68800), Long.valueOf(confirmApiPlainResult.getData().getTotalPrice()));
            Assert.assertEquals(totalDiscountPrice, confirmApiPlainResult.getData().getTotalDiscountPrice(), "总优惠价格计算错误");


            //回收券资产

            recycleCouponAsset(String.valueOf(discountAssetId));
            recycleCouponAsset(String.valueOf(fullReduceAssetId));
            //失效活动
            expireDiscountActivity(discountActivityId);
            expireFullReduceActivity(fullReduceActivityId);

            //确认订单，计算优惠
        } catch (Exception e) {
        } finally {
            //删除配置的优惠券数据
            deleteCouponData(Long.valueOf(discountCouponId));
            deleteCouponData(Long.valueOf(fullReduceCouponId));
            //删除配置的满减活动数据
            deleteActivityConfigData(discountActivityId);
            deleteActivityConfigData(fullReduceActivityId);
        }
    }


    @BeforeClass
    public void beforeClass() {
        deleteTestDataYcmByKdtId(wscKdtId);
    }

    @Test()
    public void test() {
        int t = (int) (68800 * 0.9 * 0.88) - 2000 - 1000;
    }
}