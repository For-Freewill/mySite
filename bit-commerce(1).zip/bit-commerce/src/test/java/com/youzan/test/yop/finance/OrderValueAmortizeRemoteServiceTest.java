package com.youzan.test.yop.finance;

import com.google.common.collect.Lists;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.YopBaseTest;
import com.youzan.yop.api.OrderValueAmortizeRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.amortize.BaseValueAmortizeApi;
import com.youzan.yop.api.entity.amortize.ValueAmortizeApi;
import com.youzan.yop.api.form.amortize.SearchOrderByTimeForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Create by wuwu on 2019/12/6
 **/
public class OrderValueAmortizeRemoteServiceTest extends YopBaseTest {
    Logger logger = LoggerFactory.getLogger(OrderValueAmortizeRemoteServiceTest.class);

    @Dubbo
    OrderValueAmortizeRemoteService orderValueAmortizeRemoteService;

//    @Test(enabled = false)
//    public void getPaidAmortizeOrderList_byOrderIds_Test() {
//        SearchOrderByTimeForm searchOrderByTimeForm = new SearchOrderByTimeForm();
//        searchOrderByTimeForm.setOrderIds(Lists.newArrayList(1575546782849105845L));
//        searchOrderByTimeForm.setPageSize(500);
//
//        PlainResult<PageApi<ValueAmortizeApi>> PaidAmortizeOrderList = orderValueAmortizeRemoteService.getPaidAmortizeOrderList(searchOrderByTimeForm);
//
//        System.out.println(PaidAmortizeOrderList.getData().getContent());
//        System.out.println(PaidAmortizeOrderList.getMessage());
//
//        //Assert.assertEquals(PaidAmortizeOrderList.getCode(),40200);
//    }

//    @Test(enabled = false)
//    public void getPaidAmortizeOrderList_byTimeQuery_Test() {
//        SearchOrderByTimeForm searchOrderByTimeForm = new SearchOrderByTimeForm();
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//        try {
//            searchOrderByTimeForm.setBeginTime(sdf.parse("2019-12-09 10:53:02"));
//            searchOrderByTimeForm.setEndTime(sdf.parse("2019-12-09 12:53:02"));
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        searchOrderByTimeForm.setPageSize(500);
//
//        PlainResult<PageApi<ValueAmortizeApi>> PaidAmortizeOrderList = orderValueAmortizeRemoteService.getPaidAmortizeOrderList(searchOrderByTimeForm);
//
//        System.out.println(PaidAmortizeOrderList.getData().getContent());
//        System.out.println(PaidAmortizeOrderList.getMessage());
//        }

    @Test(enabled = false)
    public void getRefundAmortizeOrderList_byOrderIds_Test() {
        SearchOrderByTimeForm searchOrderByTimeForm = new SearchOrderByTimeForm();
        searchOrderByTimeForm.setOrderIds(Lists.newArrayList(1575546782849105845L));
        searchOrderByTimeForm.setPageSize(500);

        PlainResult<PageApi<ValueAmortizeApi>> PaidAmortizeOrderList = orderValueAmortizeRemoteService.getRefundAmortizeOrderList(searchOrderByTimeForm);

        System.out.println(PaidAmortizeOrderList.getData().getContent());
        System.out.println(PaidAmortizeOrderList.getMessage());

    }

    @Test(enabled = false)
    public void getRefundAmortizeOrderList_byTimeQuery_Test() {
        SearchOrderByTimeForm searchOrderByTimeForm = new SearchOrderByTimeForm();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            searchOrderByTimeForm.setBeginTime(sdf.parse("2019-12-09 10:53:02"));
            searchOrderByTimeForm.setEndTime(sdf.parse("2019-12-09 18:53:02"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        searchOrderByTimeForm.setPageSize(500);

        PlainResult<PageApi<ValueAmortizeApi>> PaidAmortizeOrderList = orderValueAmortizeRemoteService.getRefundAmortizeOrderList(searchOrderByTimeForm);

        System.out.println(PaidAmortizeOrderList.getData().getContent());
        System.out.println(PaidAmortizeOrderList.getMessage());
    }

    @Test(enabled = false)
    public void getAmortizeDetailByOrderIdTest() {
        Long orderId = 1575882718152421713L;
        PlainResult<BaseValueAmortizeApi> pageApiPlainResult = orderValueAmortizeRemoteService.getAmortizeDetailByOrderId(orderId);

        System.out.println(pageApiPlainResult.getData().getGiftValueAmortizeDetailApiList());

        System.out.println(pageApiPlainResult.getMessage());


    }


}
