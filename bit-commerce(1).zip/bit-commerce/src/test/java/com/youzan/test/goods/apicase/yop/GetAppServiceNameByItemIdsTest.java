package com.youzan.test.goods.apicase.yop;

import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.form.appOperationDtos.AppServiceInfoDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wulei
 * @date 2020/11/16 16:14
 * getAppServiceNameByItemIds :open_application_item 表ID
 * @goods
 */
public class GetAppServiceNameByItemIdsTest extends YunBaseTest {
    final static public Logger logger = LoggerFactory.getLogger(GetAppServiceNameByItemIdsTest.class);

    public static Long ORDER_REMOTE_KDT_ID = 58517716L;
    public static Long ORDER_REMOTE_USER_ID = 8107339288L;
    public String ORDER_REMOTE_SHOP_NAME = "CI二期自动化店铺-勿动";


    @Dubbo
    public OrderRemoteService orderRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void listOrderNormalTest() {
        List<Integer> list = new ArrayList();
        list.add(1);
        list.add(589);
        list.add(72651);
        List<AppServiceInfoDto> orderResult = orderRemoteService.getAppServiceNameByItemIds(list);
        Assert.assertEquals(orderResult.size(), 3);
    }

    /**
     * 正常用例：校验数据库返回数据
     * open_application_item.id=8160(微商城(2020)旗舰版)
     */
    @Test
    public void listOrderNormalAssertTest() {
        List<Integer> list = new ArrayList();
        list.add(8160);
        List<AppServiceInfoDto> orderResult = orderRemoteService.getAppServiceNameByItemIds(list);
        Assert.assertEquals(orderResult.size(), 1);
        Assert.assertEquals(Integer.valueOf(orderResult.get(0).getAppId()), Integer.valueOf(873));
        Assert.assertEquals(Integer.valueOf(orderResult.get(0).getItemId()), Integer.valueOf(8160));
        Assert.assertEquals(orderResult.get(0).getAppName(), "有赞微商城_微商城(2020)旗舰版");
        Assert.assertEquals(Byte.valueOf(orderResult.get(0).getAppGroup()), Byte.valueOf("3"));
    }

    /**
     * 异常用例：no list
     */
    @Test
    public void listOrderNoListTest() {
        List<Integer> list = new ArrayList();
        List<AppServiceInfoDto> orderResult = orderRemoteService.getAppServiceNameByItemIds(list);
        Assert.assertEquals(orderResult.size(), 0);
    }


    /**
     * 异常用例：list no exists
     */
    @Test
    public void listOrderNotExistTest() {
        List<Integer> list = new ArrayList();
        list.add(11);
        List<AppServiceInfoDto> orderResult = orderRemoteService.getAppServiceNameByItemIds(list);
        Assert.assertEquals(orderResult.size(), 0);
    }
}
