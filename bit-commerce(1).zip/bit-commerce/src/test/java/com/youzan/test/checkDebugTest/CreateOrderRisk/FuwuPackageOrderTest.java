package com.youzan.test.checkDebugTest.CreateOrderRisk;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;

/**
 * @author wuwu
 * @date 2020/12/24 11:17 AM
 */
public class FuwuPackageOrderTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(FuwuPackageOrderTest.class);

    /**
     * 单独订购服务包
     */
    @Test
    public void createFuwuPackage() {
        closeWaitPayOrder(wscKdtId);
        PlainResult<String> result = createNormalOrder
                (wscKdtId,wscKdtName,fuwuPackageItemId,1,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"新店上线服务（电商版）不允许单独订购",result.getMessage());

    }
    /**
     * 新购基础版 + 服务包
     */
    @Test
    public void createFuwuPackage1() {
        closeWaitPayOrder(wscKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscKdtId,wscKdtName,Arrays.asList(basicWechatItemId_2021,fuwuPackageItemId),1,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 新购基础版 不带服务包
     */
    @Test
    public void createFuwuPackageNewBasic() {
        closeWaitPayOrder(wscKdtId);
        PlainResult<String> result = createNormalOrder
                (wscKdtId,wscKdtName,basicWechatItemId,1,0L);
        logger.info("创建服务包订单：{}",result);
        Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful",result.getMessage());

    }

    /**
     * 新购专业版，不带服务包
     */
    @Test
    public void createFuWuPackage2() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(professionItemId_2021),1,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040);
        Assert.assertEquals(result.getMessage(),"订购专业版，必须同时订购新店上线服务（电商版），请添加商品",result.getMessage());
    }

    /**
     * 新购旗舰版，不带服务包
     */
    @Test
    public void createFuWuPackage3() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(ultimateItemId_2021),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040);
        Assert.assertEquals(result.getMessage(),"订购旗舰版，必须同时订购新店上线服务（电商版），请添加商品",result.getMessage());

    }


    /**
     * 新购专业版+服务包
     */
    @Test
    public void createFuwuPackage4() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful");

    }

    /**
     * 新购旗舰版+服务包
     */
    @Test
    public void createFuwuPackage5() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful",result.getMessage());

    }

    /**
     * 续费基础版不带服务包
     */
    @Test
    public void createFuwuPackageRebewBasic() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,2,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        }

    /**
     * 续费基础版 + 服务包
     */
    @Test
    public void createFuwuPackage6() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,1,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        String tdOrderId = resultBasic.getData();
        //logger.info("tdorderid:{}",tdOrderId);
        //付款
        if (resultBasic.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultBasic.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(basicWechatItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());
    }


    /**
     * 续费专业版 + 服务包
     */
    @Test
    public void createFuwuPackage7() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 续费专业版 不带服务包
     */

    @Test
    public void createFuwuPackageRenewPro() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建专业版版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,professionItemId_2021,2,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());
    }

    /**
     * 续费旗舰版 +服务包
     */

    @Test
    public void createFuwuPackage8() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建专业版版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,ultimateItemId_2021,1,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());

        String tdOrderId = resultCreateOrder.getData();
        //付款
        if (resultCreateOrder.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultCreateOrder.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 续费旗舰版 不带服务包
     */

    @Test
    public void createFuwuPackageRenewUlt() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建专业版版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,ultimateItemId_2021,2,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());
    }


    /**
     * 升级到专业版 + 服务包
     */
    @Test
    public void createFuwuPackage9() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,2,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        //logger.info("tdorderid:{}",tdOrderId);
        //付款
        if (resultBasic.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultBasic.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 升级到旗舰版 +服务包
     */
    @Test
    public void createFuwuPackage10() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,2,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        //logger.info("tdorderid:{}",tdOrderId);
        //付款
        if (resultBasic.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultBasic.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),1,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 降级到专业版+服务包
     */
    @Test
    public void createFuwuPackage11() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建旗舰版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,ultimateItemId_2021,1,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());

        String tdOrderId = resultCreateOrder.getData();
        //付款
        if (resultCreateOrder.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultCreateOrder.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        //移动服务期
        movePerformStatusByAppId(wscAndPackageKdtId,873L,-350);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),1,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

}
