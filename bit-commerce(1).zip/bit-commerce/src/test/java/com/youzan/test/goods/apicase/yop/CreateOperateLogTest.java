package com.youzan.test.goods.apicase.yop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.apicase.yop.YopBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.OperateLogRemoteService;
import com.youzan.yop.api.entity.operate.Category;
import com.youzan.yop.api.entity.operate.OperateType;
import com.youzan.yop.api.form.operate.OperateLogForm;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2020/9/25 3:59 下午
 * 增加操作日志
 * @大爷
 */
public class CreateOperateLogTest extends YopBaseTest {
    @Dubbo
    public OperateLogRemoteService operateLogRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void createOperateLogNormalTest() {
        OperateLogForm operateLogForm = new OperateLogForm();
        operateLogForm.setCategory(Category.ACTIVITY);
        operateLogForm.setOperateType(OperateType.EDIT);
        operateLogForm.setRecordId(108L);
        operateLogForm.setUserName("tianning");
        operateLogForm.setParamDetail(null);
        PlainResult<Integer> result = operateLogRemoteService.createOperateLog(operateLogForm);
        Assert.assertEquals(result.getCode(), 200);
    }

    /**
     * 异常用例--operateLogForm列表为空
     */
    @Test
    public void createOperateLogOperateLogFormListNullTest() {
        OperateLogForm operateLogForm = new OperateLogForm();
        PlainResult<Integer> result = operateLogRemoteService.createOperateLog(operateLogForm);
        Assert.assertEquals(result.getCode(), 130501);
    }

    /**
     * 异常用例--入参为空
     */
    @Test
    public void createOperateLogParameterNullTest() {
        PlainResult<Integer> result = operateLogRemoteService.createOperateLog(null);
        Assert.assertEquals(result.getCode(), 130501);
    }
}
