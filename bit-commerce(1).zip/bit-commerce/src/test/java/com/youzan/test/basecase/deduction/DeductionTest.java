package com.youzan.test.basecase.deduction;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfAsset;
import com.youzan.commerce.test.entity.dataobject.perform.PfAssetDeduction;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.entity.order.CalOrderPriceApi;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/1/14 11:27 AM
 */
public class DeductionTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(DeductionTest.class);
    Long wscKdtId = newWscKdtId();
    @Test
    public void Only24HourLeftStatusToDedution() {
        initShopByKdtId(wscKdtId);
        rechargeYzcoin(wscKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscKdtId), cny);

        //创建第一笔订单（基础版）
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,basicWechatItemId,1,yzb);

        Assert.assertEquals(orderCreateApiPlainResult.getCode(),200,orderCreateApiPlainResult.getMessage());
        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }

        //第一笔订单返回的td order id
        String orderId = orderCreateApiPlainResult.getData();

        //等待履约
        waitForPerform(wscKdtId, 873L, Long.valueOf(orderId));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //移动服务期至小于24小时  TODO 这里的364不准确的，后续要改成自动获取总服务期数
        movePerformStatusByAppId(wscKdtId,873L,-364);

        PfAsset pfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_paid").eq("app_id", "combine_spu_wsc"));


        PlainResult<CalOrderPriceApi> calOrderPricePlainResult =
                calOrderPrice(wscKdtId,wscKdtName,professionItemId,1);
        //int deductionPrice = calOrderPricePlainResult.getData().getDeducation().getDeductionPrice();

        //Long expectDeductionPrice = (pfAssetOrder.getCnyAmt() * (365 - 100 - 1) / 365);

        Assert.assertEquals(calOrderPricePlainResult.getData().getDeducation(),null);

    }


    @Test
    public void deductionAfter24HoursTest() {
        /**
         * 1.清理店铺下的待支付和未退款的订单，充余额、充有赞币
         * 2.创建订单，含礼包
         * 3.预支付
         * 4.支付
         * 5.退款
         * 6.清空账户余额和有赞币
         * 此用例断言的前提条件是摊销用例跑通过
         **/

        initShopByKdtId(wscKdtId);
        rechargeYzcoin(wscKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscKdtId), cny);
        //创建第一笔订单（基础版）
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,basicWechatItemId,1,yzb);

        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }


        //第一笔订单返回的td order id
        String orderId = orderCreateApiPlainResult.getData();

        //等待履约
        waitForPerform(wscKdtId, 873L, Long.valueOf(orderId));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //将服务期往前移动100天
        movePerformStatusByAppId(wscKdtId, deductedAppId, -100);

        PfAsset pfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_paid").eq("app_id", "combine_spu_wsc"));

        PlainResult<CalOrderPriceApi> calOrderPricePlainResult =
                calOrderPrice(wscKdtId,wscKdtName,professionItemId,1);
        int deductionPrice = calOrderPricePlainResult.getData().getDeducation().getDeductionPrice();

        //TODO 这里的365不准确的，后续要改成自动获取总服务期数
        Long expectDeductionPrice = (pfAssetOrder.getCnyAmt() * (365 - 100 - 1) / 365);

        Assert.assertEquals(deductionPrice, expectDeductionPrice.intValue(), "抵扣金额不符合预期");

        //创建抵扣升级订单（专业版）
        PlainResult<String> deductionOrderCreateApiPlainResult = createNormalOrderWithNoPromotion(wscKdtId,wscKdtName,professionItemId,1,yzb);

        logger.info("抵扣升级订单结果:{}", deductionOrderCreateApiPlainResult);
        if (deductionOrderCreateApiPlainResult.getCode() != 200) {
            logger.error("创建订单失败:{}", deductionOrderCreateApiPlainResult.getMessage());
        }
        Assert.assertEquals(deductionOrderCreateApiPlainResult.getCode(), 200, "抵扣升级订单下单失败");


        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(deductionOrderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }

        //等待升级订单履约
        waitForPerform(wscKdtId,873L,Long.valueOf(deductionOrderCreateApiPlainResult.getData()));

        //等待被升级订单状态变为upgrade
        waitForPfOrderStateChanged(Long.valueOf(orderId));

        //将订单退款
        initShopByKdtId(wscKdtId);
        resetShopBalance(wscKdtId.intValue());
        recycleYzcoin(wscKdtId);
    }

    @Test
    public void deductionAndRecycleRewardYzbTest() {

        /**
         * 抵扣升级时按比例把奖励的有赞币回收了
         **/

        initShopByKdtId(wscKdtId);
        rechargeYzcoin(wscKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscKdtId), cny + 1000);

        //新购第一笔订单
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,basicWechatItemId_2021,1,yzb);
        logger.info("第一笔订单创建的返回值" + orderCreateApiPlainResult);
        Assert.assertEquals(orderCreateApiPlainResult.getCode(), 200, "商业化下单失败，失败原因:" + orderCreateApiPlainResult.getMessage());

        if (orderCreateApiPlainResult.getCode() == 200) {
            try {
                PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
                cashierPay(preparePayApiPlainResult, account, wscKdtId);
            } catch (Exception e) {
                logger.error("预支付或支付失败" + e.getMessage());
            }
        }

        String newOrderId = orderCreateApiPlainResult.getData();

        //等待履约
        waitForPerform(wscKdtId, 873L, Long.valueOf(newOrderId));

        //续费订单，不实用有赞币，需要奖励有赞币

        PlainResult<String> renewOrderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,basicWechatItemId_2021,1,0L);
        logger.info("续费订单创建结果：{}", JSON.toJSON(renewOrderCreateApiPlainResult));

        if (renewOrderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewOrderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }

        String renewOrderId = renewOrderCreateApiPlainResult.getData();

        //等待履约
        waitForPerform(wscKdtId, 873L, Long.valueOf(renewOrderId));

        TdOrder tdNewOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", newOrderId));

        TdOrder tdRenewOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewOrderId));


        PfAsset pfAssetNewOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdNewOrder.getTdNo()).eq("source_type", "product_with_paid").eq("app_id", "combine_spu_wsc"));
        PfAsset pfAssetRenewOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdRenewOrder.getTdNo()).eq("source_type", "product_with_paid").eq("app_id", "combine_spu_wsc"));

        OrderItemForm deductOrderItemForm = ConstructionParam.getOrderItemForm(professionItemId, 2);
        List<OrderItemForm> deductOrderItemFormList = new ArrayList<>();
        deductOrderItemFormList.add(deductOrderItemForm);

        //订单级别优惠参数
        Long deductPromotionId = getFullReduce(wscKdtId, wscKdtName, professionItemId, 1);

        List<PreferentialDescApi> deductOrderPromotionList = ConstructionParam.getOrderPromotionList(wscKdtId, wscKdtName, professionItemId, deductPromotionId, 2);
        CreateOrderForm createDeductionOrderForm = ConstructionParam.getCreateOrderWithParam(wscKdtId, wscKdtName, deductOrderItemFormList, deductOrderPromotionList, yzb);
        logger.info("创建抵扣升级订单的参数：{}", JSONObject.toJSON(createDeductionOrderForm));


        ConfirmOrderForm confirmOrderForm =
                ConstructionParam.getConfirmOrderForm(wscKdtId, wscKdtName, deductOrderItemFormList);
        PlainResult<OrderConfirmApi> confirmApiPlainResult =
                orderRemoteService.confirmOrder(confirmOrderForm);
        logger.info("确认订单返回信息:{}", JSONObject.toJSON(confirmApiPlainResult));

        PlainResult<CalOrderPriceApi> calOrderPrice = calOrderPrice(wscKdtId,wscKdtName,professionItemId,2);

        int deductionPrice = confirmApiPlainResult.getData().getDeducation().getDeductionPrice();

        Long expectedDeductionprice = pfAssetNewOrder.getCnyAmt() + pfAssetNewOrder.getYzbAmt() - pfAssetNewOrder.getYzbAwardAmt() + pfAssetRenewOrder.getCnyAmt() + pfAssetRenewOrder.getYzbAmt() - pfAssetRenewOrder.getYzbAwardAmt();

        //当抵扣金额大于升级的版本原价时，则抵扣金额 = 升级版本价格 -（升级软件版本的商品优惠+升级软件版本的订单优惠）


        logger.info("实际抵扣金额:{}", String.valueOf(deductionPrice));
        logger.info("期待抵扣金额:{}", expectedDeductionprice);

        logger.info("第一笔订单的实付:{}", pfAssetNewOrder.getCnyAmt());
        logger.info("第一笔订单的有赞币支付:{}", pfAssetNewOrder.getYzbAmt());
        logger.info("第一笔订单的奖励有赞币:{}", pfAssetNewOrder.getYzbAwardAmt());
        logger.info("第二笔订单的实付:{}", pfAssetRenewOrder.getCnyAmt());
        logger.info("第二笔订单的有赞币支付:{}", pfAssetRenewOrder.getYzbAmt());
        logger.info("第二笔订单的奖励有赞币:{}", pfAssetRenewOrder.getYzbAwardAmt());

        Assert.assertEquals(deductionPrice, expectedDeductionprice.intValue(), "抵扣金额不符合预期");


        //创建抵扣升级订单
        PlainResult<String> deductionOrderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,professionItemId,2,0L);
        if (deductionOrderCreateApiPlainResult.getCode() != 200) {
            logger.error("创建订单失败:{}", deductionOrderCreateApiPlainResult.getMessage());
        } else {
            logger.info("抵扣升级订单创建成功，返回结果:{}", deductionOrderCreateApiPlainResult);

        }
        Assert.assertEquals(deductionOrderCreateApiPlainResult.getCode(), 200, "抵扣升级订单下单失败");

        //将订单退款
        initShopByKdtId(wscKdtId);
        resetShopBalance(wscKdtId.intValue());
        recycleYzcoin(wscKdtId);
    }


    @Test
    public void deductionIn24HoursTest() {

        /**
         * 24小时内发生抵扣升级
         * 预期结果：实付劝退，有赞币全退
         **/

        logger.info("testOnlyCnyPayOrder start test...");

        initShopByKdtId(wscKdtId);
        rechargeYzcoin(wscKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscKdtId), cny + 1000);


        //创建订单
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,basicWechatItemId_2021,1,0L);
        logger.info("第一笔订单创建返回结果:{}", orderCreateApiPlainResult);

        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }

        String orderId = orderCreateApiPlainResult.getData();

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //等待履约
        waitForPerform(wscKdtId, 873L, Long.valueOf(orderId));

        PfAsset pfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_paid").eq("app_id", "combine_spu_wsc"));

        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(professionItemId, 1);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        ConfirmOrderForm confirmOrderForm =
                ConstructionParam.getConfirmOrderForm(wscKdtId, wscKdtName, orderItemFormList);
        PlainResult<OrderConfirmApi> confirmApiPlainResult =
                orderRemoteService.confirmOrder(confirmOrderForm);
        logger.info("确认订单返回信息:{}", JSONObject.toJSON(confirmApiPlainResult));

        int deductionPrice = confirmApiPlainResult.getData().getDeducation().getDeductionPrice();

        logger.info("实际抵扣金额:{}", String.valueOf(deductionPrice));
        logger.info("期待抵扣金额:{}", String.valueOf(pfAssetOrder.getCnyAmt() + pfAssetOrder.getYzbAmt()));

        Assert.assertEquals(pfAssetOrder.getCnyAmt() + pfAssetOrder.getYzbAmt(), deductionPrice, "抵扣金额不符合预期");



        PlainResult<String> deductionOrderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,professionItemId,1,0L);
        logger.info("抵扣升级订单结果:{}", deductionOrderCreateApiPlainResult);
        if (deductionOrderCreateApiPlainResult.getCode() != 200) {
            logger.error("创建订单失败:{}", deductionOrderCreateApiPlainResult.getMessage());
        }
        Assert.assertEquals(deductionOrderCreateApiPlainResult.getCode(), 200, "抵扣升级订单下单失败");


        //将订单退款
        initShopByKdtId(wscKdtId);
        resetShopBalance(wscKdtId.intValue());
        recycleYzcoin(wscKdtId);
    }

    @Test
    public void deductionMoreThenPayTest() {
        initShopByKdtId(wscNoPromtionKdtId);
        rechargeYzcoin(wscNoPromtionKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscNoPromtionKdtId), cny);

        //创建第一笔订单1年（基础版）
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscNoPromtionKdtId,wscNoPromtionKdtName,basicWechatItemId,1,yzb);

        Assert.assertEquals(orderCreateApiPlainResult.getCode(),200,orderCreateApiPlainResult.getMessage());
        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscNoPromtionKdtId);
        }

        //创建第二笔订单2年（基础版）
        PlainResult<String> renewOrderCreateApiPlainResult = createNormalOrder(wscNoPromtionKdtId,wscNoPromtionKdtName,basicWechatItemId,2,yzb);

        Assert.assertEquals(renewOrderCreateApiPlainResult.getCode(),200,renewOrderCreateApiPlainResult.getMessage());
        if (renewOrderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewOrderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscNoPromtionKdtId);
        }

        //第二笔订单返回的td order id
        String orderId = renewOrderCreateApiPlainResult.getData();
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));


        //等待履约
        waitForPerform(wscNoPromtionKdtId, 873L, Long.valueOf(orderId));


        /**
         * 升级到专业版
         * 抵扣金额 = 订购专业版金额 = 专业版原价12800*专业版折扣-满减（为了计算方便，此处会用到一个无营销的店铺）
         * 返还金额 = 基础版剩余价值 - 抵扣金额
         */


        PlainResult<CalOrderPriceApi> deductionCalOrderPricePlainResult =
                calOrderPrice(wscNoPromtionKdtId,wscKdtName,professionItemId,1);

        Assert.assertEquals(deductionCalOrderPricePlainResult.getCode(),200,deductionCalOrderPricePlainResult.getMessage());
        //查看抵扣金额
        Assert.assertEquals(Long.valueOf(deductionCalOrderPricePlainResult.getData().getDeducation().getDeductionPrice()),deductionCalOrderPricePlainResult.getData().getTotalPrice(),"抵扣金额不正确");
        //查看返还金额
        Assert.assertEquals(deductionCalOrderPricePlainResult.getData().getDeducation().getDeductionReturnYzb(),Integer.valueOf(760000),"该返还的yzb金额不正确");
        Assert.assertEquals(deductionCalOrderPricePlainResult.getData().getTotalRealPrice(),Long.valueOf(0),"抵扣完实付金额不正确");

        //创建第三笔笔订单1年（专业版）--此处是一笔抵扣升级订单
        PlainResult<String> deductionOrderCreateApiPlainResult = createNormalOrder(wscNoPromtionKdtId,wscNoPromtionKdtName,professionItemId,1,0L);

        //因为是0元单，无需支付，所以把支付给去调了
        if (deductionOrderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(deductionOrderCreateApiPlainResult.getData()), (byte) 4);
//            cashierPay(preparePayApiPlainResult, account, wscNoPromtionKdtId);
        }

        waitForPfOrderStateChanged(Long.valueOf(orderCreateApiPlainResult.getData()));

        waitForPfOrderStateChanged(Long.valueOf(renewOrderCreateApiPlainResult.getData()));

        //升级订单返回的td order id
        String deductionOrderId = deductionOrderCreateApiPlainResult.getData();
        TdOrder deductionTdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>()
                .eq("id", deductionOrderId));

        waitForPerform(wscNoPromtionKdtId,873L,Long.valueOf(deductionOrderId));

        PfAsset deductionPfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>()
                .eq("out_biz_no", deductionTdOrder.getTdNo())
                .eq("source_type", "product_with_paid")
                .eq("app_id", "combine_spu_wsc"));

        // TODO 只校验ycm的表是否有发放有赞币，实际的发放还要看business_development.yzcoin_account
        List<PfAssetDeduction> pfAssetDeductionForOrderList = pfAssetDeductionMapper.selectList(new QueryWrapper<PfAssetDeduction>()
                .eq("pf_asset_id",deductionPfAssetOrder.getId())
                .eq("is_deleted",0));

        Assert.assertEquals(pfAssetDeductionForOrderList.size(),2,"抵扣关系表返还金额数量不正确");

        Long yzbReturn = 0L;
        for (PfAssetDeduction pfAssetDeduction:pfAssetDeductionForOrderList) {
            yzbReturn += pfAssetDeduction.getDeductedYzbReturn();
        }
        Assert.assertEquals(yzbReturn,Long.valueOf(760000),"返还金额在pfAssetDeduction表里落得不正确");


        //将订单退款
        //initShopByKdtId(wscNoPromtionKdtId);

    }


    @Test
    public void firstDeductionValueAmortizeTest() {
        initShopByKdtId(wscKdtId);
        rechargeYzcoin(wscKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscKdtId), cny);

        //创建第一笔订单（基础版）
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,basicWechatItemId,1,yzb);

        Assert.assertEquals(orderCreateApiPlainResult.getCode(),200,orderCreateApiPlainResult.getMessage());
        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }

        //第一笔订单返回的td order id
        String orderId = orderCreateApiPlainResult.getData();
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //等待履约
        waitForPerform(wscKdtId, 873L, Long.valueOf(orderId));

        PfAsset firstPfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_paid").eq("app_id", "combine_spu_wsc"));

        List<PfAsset> firstPfAssetGiftList = pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_present").eq("app_id", "combine_spu_wsc"));


        //当前礼包剩余价值等额传递

        //创建抵扣升级订单（专业版）
        PlainResult<String> deductionOrderCreateApiPlainResult = createNormalOrder(wscKdtId,wscKdtName,professionItemId,1,yzb);

        Assert.assertEquals(deductionOrderCreateApiPlainResult.getCode(),200,orderCreateApiPlainResult.getMessage());

        logger.info("抵扣升级订单结果:{}", deductionOrderCreateApiPlainResult);
        if (deductionOrderCreateApiPlainResult.getCode() != 200) {
            logger.error("创建订单失败:{}", deductionOrderCreateApiPlainResult.getMessage());
        }

        Assert.assertEquals(deductionOrderCreateApiPlainResult.getCode(), 200, "抵扣升级订单下单失败");


        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(deductionOrderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }

        //抵扣升级订单返回的td order id
        String deductionOrderId = deductionOrderCreateApiPlainResult.getData();

        waitForPerform(wscKdtId,873L,Long.valueOf(deductionOrderId));

        waitForPfOrderStateChanged(Long.valueOf(orderCreateApiPlainResult.getData()));

        TdOrder deductionTdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", deductionOrderId));
        PfAsset deductionPfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>()
                .eq("out_biz_no", deductionTdOrder.getTdNo())
                .eq("source_type", "product_with_paid")
                .eq("app_id", "combine_spu_wsc"));
        List<PfAsset> deductionPfAssetGiftList = pfAssetMapper.selectList(new QueryWrapper<PfAsset>()
                .eq("out_biz_no", deductionTdOrder.getTdNo())
                .eq("source_type", "product_with_present")
                .eq("app_id", "combine_spu_wsc"));

        /**
         * 实付的摊销校验：
         * 礼包实付金额 = pfOrder里的实付金额 * 礼包天数 /（订单天数 + 礼包天数）
         * 礼包实付有赞币 = pfOrder里的实付有赞币 * 礼包天数 /（订单天数 + 礼包天数）
         */
        List<PfAsset> gfAssetItemNumList = new ArrayList<>();
        Long allGiftsNum = 0L;
        Long gfsCnyValue = 0L;
        Long gfsYzbValue = 0L;

        //获取pf_order里订单实付的金额
        PfOrder deductionPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
                .eq("biz_order_id", deductionTdOrder.getTdNo()));

        Long CnyValue = deductionPfOrder.getRealPrice();
        Long YzbValue = deductionPfOrder.getYzbPrice();
        Long giftDeductionAmount = 0L;
        Long giftDeductionYzb = 0L;
        Long gfsItemCnyValue = 0L;
        Long gfsItemYzbValue = 0L;



        /**
         * 抵扣升级订单实付的摊销
         */
        if (deductionPfAssetGiftList.size() > 0) {
            for (PfAsset pfAssetGift : deductionPfAssetGiftList) {
                if (pfAssetGift.getItemId().endsWith("day")) {
                    allGiftsNum += pfAssetGift.getItemNum();
                }
                if (pfAssetGift.getItemId().endsWith("year")) {
                    allGiftsNum = allGiftsNum + pfAssetGift.getItemNum() * 365;

                }
            }
            for (PfAsset pfAssetGift : deductionPfAssetGiftList) {
                //TODO 此处的365后续需要修改成计算订单的时间，后面再说
                if (pfAssetGift.getItemId().endsWith("day")) {
                    gfsItemCnyValue = CnyValue * pfAssetGift.getItemNum() / (365 + allGiftsNum);
                    logger.info("校验抵扣升级订单礼包的实付摊销，实际值：{}，期待值：{}",pfAssetGift.getCnyAmt(),gfsItemCnyValue);
                    Assert.assertEquals(pfAssetGift.getCnyAmt(), gfsItemCnyValue, "礼包实付金额摊销错误");
                    gfsCnyValue += gfsItemCnyValue;


                    gfsItemYzbValue = YzbValue * pfAssetGift.getItemNum() / (365 + allGiftsNum);
                    logger.info("校验抵扣升级订单礼包的有赞币摊销，实际值：{}，期待值：{}",pfAssetGift.getYzbAmt(),gfsItemYzbValue);
                    Assert.assertEquals(pfAssetGift.getYzbAmt(), gfsItemYzbValue, "礼包实付有赞币摊销错误");
                    gfsYzbValue += gfsItemYzbValue;

                    //校验升级订单的买赠礼包摊销抵扣金额正确
                    PfAssetDeduction pfAssetDeductionForOrder = pfAssetDeductionMapper.selectOne(new QueryWrapper<PfAssetDeduction>()
                            .eq("pf_asset_id",pfAssetGift.getId())
                            .eq("is_deleted",0));
                    logger.info("校验抵扣升级订单礼包摊销到的抵扣实付金额，实际值：{}，期待值：{}",pfAssetDeductionForOrder.getDeductedCnyAmount(),firstPfAssetOrder.getCnyAmt()*pfAssetGift.getItemNum()/(allGiftsNum+365));
                    Assert.assertEquals(pfAssetDeductionForOrder.getDeductedCnyAmount(),Long.valueOf(firstPfAssetOrder.getCnyAmt()*pfAssetGift.getItemNum()/(allGiftsNum+365)));
                    giftDeductionAmount+=pfAssetDeductionForOrder.getDeductedCnyAmount();

                    //校验升级订单的买赠礼包摊销抵扣金额的实付有赞币正确
                    logger.info("校验抵扣升级订单礼包摊销到的抵扣有赞币，实际值：{}，期待值：{}",pfAssetDeductionForOrder.getDeductedYzbAmount(),firstPfAssetOrder.getYzbAmt()*pfAssetGift.getItemNum()/(allGiftsNum+365));
                    Assert.assertEquals(pfAssetDeductionForOrder.getDeductedYzbAmount(),Long.valueOf(firstPfAssetOrder.getYzbAmt()*pfAssetGift.getItemNum()/(allGiftsNum+365)));
                    giftDeductionYzb+=pfAssetDeductionForOrder.getDeductedYzbAmount();
                }else {
                    gfsItemCnyValue = CnyValue * pfAssetGift.getItemNum()*365 / (365 + allGiftsNum);
                    logger.info("校验抵扣升级订单礼包的实付摊销，实际值：{}，期待值：{}",pfAssetGift.getCnyAmt(),gfsItemCnyValue);
                    Assert.assertEquals(pfAssetGift.getCnyAmt(), gfsItemCnyValue, "礼包实付金额摊销错误");
                    gfsCnyValue += gfsItemCnyValue;

                    gfsItemYzbValue = YzbValue * pfAssetGift.getItemNum()*365 / (365 + allGiftsNum);
                    logger.info("校验抵扣升级订单礼包的有赞币摊销，实际值：{}，期待值：{}",pfAssetGift.getYzbAmt(),gfsItemYzbValue);
                    Assert.assertEquals(pfAssetGift.getYzbAmt(), gfsItemYzbValue, "礼包实付有赞币摊销错误");
                    gfsYzbValue += gfsItemYzbValue;

                    //校验升级订单的买赠礼包摊销抵扣金额正确
                    PfAssetDeduction pfAssetDeductionForOrder = pfAssetDeductionMapper.selectOne(new QueryWrapper<PfAssetDeduction>()
                            .eq("deducted_pf_asset_id",pfAssetGift.getId())
                            .eq("is_deleted",0));
                    logger.info("校验抵扣升级订单礼包摊销到的抵扣实付金额，实际值：{}，期待值：{}",pfAssetDeductionForOrder.getDeductedCnyAmount(),firstPfAssetOrder.getCnyAmt()*pfAssetGift.getItemNum()/(allGiftsNum+365));
                    Assert.assertEquals(pfAssetDeductionForOrder.getDeductedCnyAmount(),Long.valueOf(firstPfAssetOrder.getCnyAmt()*pfAssetGift.getItemNum()*365/(allGiftsNum+365)));
                    giftDeductionAmount+=pfAssetDeductionForOrder.getDeductedCnyAmount();

                    //校验升级订单的买赠礼包摊销抵扣金额的实付有赞币正确
                    logger.info("校验抵扣升级订单礼包摊销到的抵扣有赞币，实际值：{}，期待值：{}",pfAssetDeductionForOrder.getDeductedYzbAmount(),firstPfAssetOrder.getYzbAmt()*pfAssetGift.getItemNum()/(allGiftsNum+365));
                    Assert.assertEquals(pfAssetDeductionForOrder.getDeductedYzbAmount(),Long.valueOf(firstPfAssetOrder.getYzbAmt()*pfAssetGift.getItemNum()*365/(allGiftsNum+365)));
                    giftDeductionYzb+=pfAssetDeductionForOrder.getDeductedYzbAmount();
                }

            }

            //校验升级订单的摊销抵扣金额的实付正确
            PfAssetDeduction pfAssetDeductionForOrder = pfAssetDeductionMapper.selectOne(new QueryWrapper<PfAssetDeduction>()
                    .eq("pf_asset_id",deductionPfAssetOrder.getId())
                    .eq("is_deleted",0));
            //抵扣里的实付摊销在订单
            logger.info("校验抵扣升级订单摊销到的抵扣实付金额，实际值：{}，期待值：{}",pfAssetDeductionForOrder.getDeductedCnyAmount(),firstPfAssetOrder.getCnyAmt()-giftDeductionAmount);
            Assert.assertEquals(pfAssetDeductionForOrder.getDeductedCnyAmount(),Long.valueOf(firstPfAssetOrder.getCnyAmt()-giftDeductionAmount));
            //抵扣里的有赞币摊销在订单
            logger.info("校验抵扣升级订单摊销到的抵扣实付有赞币金额，实际值：{}，期待值：{}",pfAssetDeductionForOrder.getDeductedYzbAmount(),firstPfAssetOrder.getYzbAmt()-giftDeductionYzb);
            Assert.assertEquals(pfAssetDeductionForOrder.getDeductedYzbAmount(),Long.valueOf(firstPfAssetOrder.getYzbAmt()-giftDeductionYzb));


            Long orderCnyValue = CnyValue - gfsCnyValue;
            Long orderYzbValue = YzbValue - gfsYzbValue;

            //抵扣升级订单本身的摊销校验
            Assert.assertEquals(deductionPfAssetOrder.getCnyAmt(), orderCnyValue, "订单实付金额摊销错误");
            Assert.assertEquals(deductionPfAssetOrder.getYzbAmt(), orderYzbValue, "订单实付有赞币摊销错误");

        } else {
            Assert.assertEquals(deductionPfAssetOrder.getCnyAmt(), CnyValue, "订单实付金额摊销错误");
            Assert.assertEquals(deductionPfAssetOrder.getYzbAmt(), YzbValue, "订单实付金额摊销错误");
        }

        /**
         * 抵扣升级订单抵扣金额的摊销--24小时之内的订单
         * 计算方式：
         * 1. 抵扣前订单和抵扣后订单有一个抵扣关系，抵扣的金额是服务期的剩余价值，超过24小时后有赞币抵扣为0
         * 2. 折算的礼包和折算前的礼包有一个折算关系，折算的价值也是礼包的剩余价值，折算不到一天的礼包不进行折算
         */


        //订单抵扣关系查找：(如果抵扣前有多比订单)
//        List<PfAssetDeduction> pfAssetDeductionForOrderList = pfAssetDeductionMapper.selectList(new QueryWrapper<PfAssetDeduction>()
//                .eq("deducted_pf_asset_id",firstPfAssetOrder.getId()));
        //订单抵扣关系抵扣金额的传递
//        for (PfAsset pfAssetGift:deductionPfAssetGiftList) {
//
//        }

        // 获取礼包资产id
        //List<Long> firstGfAssetIdList = new ArrayList<>();

        if (firstPfAssetGiftList.size() > 0) {
            for (PfAsset pfAssetGift : firstPfAssetGiftList) {
                PfAssetDeduction pfAssetDeductionForGift = pfAssetDeductionMapper.selectOne(new QueryWrapper<PfAssetDeduction>()
                        .eq("deducted_pf_asset_id",pfAssetGift.getId())
                        .eq("is_deleted",0));
                Assert.assertEquals(pfAssetDeductionForGift.getDeductedCnyAmount(),pfAssetGift.getCnyAmt());
                Assert.assertEquals(pfAssetDeductionForGift.getDeductedYzbAmount(),pfAssetGift.getYzbAmt());
            }
        }

        //将订单退款
        initShopByKdtId(wscKdtId);

    }


    @Test
    public void TestOrderValueAmortize() {

        /**
         * 1.清理店铺下的待支付和未退款的订单，充余额、充有赞币
         * 2.创建订单，含礼包
         * 3.预支付
         * 4.支付
         * 5.退款
         * 6.清空账户余额和有赞币
         **/

        //TODO 总感觉少了点try catch，后面再想
        initShopByKdtId(wscNoPromtionKdtId);
        rechargeYzcoin(wscNoPromtionKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(wscNoPromtionKdtId), cny + 1000);

        //创建订单
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(wscNoPromtionKdtId,wscNoPromtionKdtName,basicWechatItemId,1,yzb);

        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscNoPromtionKdtId);
        }

        String orderId = orderCreateApiPlainResult.getData();

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //等待履约
        waitForPerform(wscNoPromtionKdtId, 873L, Long.valueOf(orderId));

        PfAsset pfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_paid"));
        //获取pf_order里订单实付的金额
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));

        Long CnyValue = pfOrder.getRealPrice();
        Long YzbValue = pfOrder.getYzbPrice();

        Assert.assertEquals(pfAssetOrder.getCnyAmt(), CnyValue, "订单实付金额摊销错误");
        Assert.assertEquals(pfAssetOrder.getYzbAmt(), YzbValue, "订单实付金额摊销错误");

        //将订单退款
        initShopByKdtId(wscNoPromtionKdtId);
        //resetShopBalance(wscNoPromtionKdtId.intValue());
        //recycleYzcoin(wscNoPromtionKdtId);
    }

}
