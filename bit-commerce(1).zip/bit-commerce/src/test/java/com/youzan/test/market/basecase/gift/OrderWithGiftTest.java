package com.youzan.test.market.basecase.gift;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateMapper;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.gift.constant.GiftAssetOriginTypeConstant;
import com.youzan.ycm.gift.constant.GiftTypeConstant;
import com.youzan.ycm.gift.dto.GiftAssetDTO;
import com.youzan.ycm.gift.dto.GiftAssetGoodsDTO;
import com.youzan.ycm.gift.request.CreateGiftAssetRequest;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.CreateGiftAssetResponse;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author tianning
 * @date 2021/1/14 5:19 下午
 * 软件订购过程中 进行礼包资产的持久化
 */

public class OrderWithGiftTest extends TnBaseTest {

    @Autowired(required = false)
    public GfTemplateGoodsMapper gfTemplateGoodsMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gAssetGoodsMapper;

    @JSONData(value = "dataResource/basecase.gift/CreatePresentGiftRequestData.json", key = "createPresentGiftTemplateRequest")
    private SaveGiftTemplateRequest createPresentGiftTemplateRequest;

    /**
     * 订购微商城2021基础版，同时附带买赠礼包，校验礼包的持久化正确性
     */
    @Test
    public void orderWithGiftTest() {
        try {
            //创建一个买赠礼包模板
            PlainResult<SaveGiftTemplateResponse> saveGiftTemplatePlainResult = createGiftTemplete(createPresentGiftTemplateRequest);
            Assert.assertEquals(saveGiftTemplatePlainResult.getCode(), 200);

            //2.创建该模板下的买赠礼包
            CreateGiftAssetRequest createGiftAssetRequest = new CreateGiftAssetRequest();
            GiftAssetDTO giftAssetDTO = new GiftAssetDTO();

            giftAssetDTO.setOwnerYcmId(PRESENTKDTID.toString());
            giftAssetDTO.setOriginType(GiftAssetOriginTypeConstant.PRESENT);
            giftAssetDTO.setType(GiftTypeConstant.PRESENT_GIFT);
            giftAssetDTO.setBeginTime("2020-01-01");
            giftAssetDTO.setEndTime("2022-01-01");
            giftAssetDTO.setBizExt(null);
            giftAssetDTO.setBizId("123");
            giftAssetDTO.setBizType("YCM_TRADE_NO");
            giftAssetDTO.setDesc("创建买赠礼包");
            giftAssetDTO.setIcon("Icon");
            giftAssetDTO.setId(1L);
            giftAssetDTO.setIdStr("1");
            giftAssetDTO.setName("创建买赠礼包");
            giftAssetDTO.setOperator("tianning");
            giftAssetDTO.setOwnerYcmIdType("kdt_id");
            giftAssetDTO.setReceiveTime("2020-01-01");
            giftAssetDTO.setRefundTime("2022-01-01");
            giftAssetDTO.setRemark("");
            giftAssetDTO.setSentTime("2020-01-01");
            giftAssetDTO.setState("receive");
            giftAssetDTO.setTemplateId(saveGiftTemplatePlainResult.getData().getGiftTemplateDTO().getTemplateId());
            giftAssetDTO.setValue(100L);
            giftAssetDTO.setOwnerYcmIdName("买赠礼包CI专用");
            giftAssetDTO.setTemplateIdStr(saveGiftTemplatePlainResult.getData().toString());

            List<GiftAssetGoodsDTO> giftAssetGoodsDTOS = new ArrayList<>();
            GiftAssetGoodsDTO giftAssetGoodsDTO = new GiftAssetGoodsDTO();

            giftAssetGoodsDTO.setSkuId("combine_sku_wsc_2021_basic_wechat_year");
            giftAssetGoodsDTO.setSpecQuantity(1L);
            giftAssetGoodsDTO.setSkuNum(1L);
            giftAssetGoodsDTO.setSpuId("combine_spu_wsc");
            giftAssetGoodsDTO.setSpuSnapshot("1");
            giftAssetGoodsDTO.setSkuSnapshot("1");
            giftAssetGoodsDTO.setSpecPeriod(1L);
            giftAssetGoodsDTO.setBizExt(null);

            giftAssetGoodsDTO.setGiftAssetGoodsId(1L);
            giftAssetGoodsDTO.setGiftTemplateGoodsId(saveGiftTemplatePlainResult.getData().getGiftTemplateDTO().getTemplateId());

            giftAssetGoodsDTOS.add(giftAssetGoodsDTO);
            giftAssetDTO.setGiftAssetGoodsDTOS(giftAssetGoodsDTOS);

            createGiftAssetRequest.setGiftAssetDTO(giftAssetDTO);

            PlainResult<CreateGiftAssetResponse> createGiftAssetResponsePlainResult = giftAssetRemoteService.createGiftAsset(createGiftAssetRequest);
            Assert.assertEquals(createGiftAssetResponsePlainResult.getCode(), 200);

            List<GiftAsset> giftAssetList =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getId, createGiftAssetResponsePlainResult.getData().getGiftAssetId()));

            Assert.assertEquals(giftAssetList.get(0).getTemplateId(), saveGiftTemplatePlainResult.getData().getGiftTemplateDTO().getTemplateId());

            Assert.assertNotNull(giftAssetList.get(0).getId());
            Assert.assertEquals(giftAssetList.get(0).getState(), "CREATED");
        } finally {
            deleteTemplateData();
        }
    }
}
