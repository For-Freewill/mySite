package com.youzan.test.cloudService.basecase;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.response.CreateOfflineOrderResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

/**
 * @author wulei
 * @desc 云服务费落计费侧数据校验，详细校验计费侧数据
 * @Date: 2020/10/21 14:31
 * 专用测试手机：17540783535
 */
public class YunFeeCheckResourceTest extends YunBaseTest {
    // 最后一个 LS单店
    private List<Long> yunFeeCheck = Arrays.asList(58820195L, 58820298L, 58820198L, 58820299L, 58820800L, 58820801L, 58820806L, 58820905L, 58820908L, 58820923L, 58823784L, 58749467L, 58749375L);

    // 线下落单：新商家爆单计划 itemid=73357 在计费侧的数据正确性校验：5000，1.5W额度
    @Test
    public void A1feeResourceForbaodan() {
        Long kdt = newWscKdtId();
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 73357, 1, 500000);
        Assert.assertEquals(200, result1.getCode());
        feeResourceBaodan(kdt);
    }

    // 线下落单：非0元，订单额度，itemid=44269，买1000额度，500元
    @Test
    public void A2quotaNotZeroOrder() {
        Long kdt = newWscKdtId();
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 7284, 1000, 50000);
        Assert.assertEquals(200, result1.getCode());
        feeResourceNotZeroOrder(kdt);
    }

    // 线下落单：0元，订单额度，itemid=44269，买1000额度，实付0元
    @Test
    public void A3quotaZeroOrder() {
        Long kdt = newWscKdtId();
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 7284, 1000, 0);
        Assert.assertEquals(200, result1.getCode());
        feeResourceZeroOrder(kdt);
    }

    // 线下落单:授信额度商品-周期型，itemid=73633，包含2000额度，实付1000元
    @Test
    public void A4ShouXinPeriodEdu() {
        Long kdt = newWscKdtId();
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 73633, 1, 100000);
        Assert.assertEquals(200, result1.getCode());
        feeResourceShouXinPeriod(kdt);
    }

    // 线下落单:授信额度商品-库存型，itemid=73646，包含2000额度，实付1000元
    @Test
    public void A4ShouXinStockEdu() {
        Long kdt = newWscKdtId();
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 73646, 1, 100000);
        Assert.assertEquals(200, result1.getCode());
        feeResourceShouXinStock(kdt);
    }

    // 线下落单:无限额度，itemid=73635，无限额度，实付500元
    @Test
    public void A5NoLimitEdu() {
        Long kdt = newWscKdtId();
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 73635, 1, 50000);
        Assert.assertEquals(200, result1.getCode());
        feeResourceNoLimitOrder(kdt);
    }

    // 线上订单：微商城1年基础版本，计费侧校验
    @Test
    public void A6quotaWSCBasicOneYear() {
        Long kdt = newWscKdtId();
        godBlessU(kdt);
        PlainResult<OrderCreateApi> result = testCreateOrder(kdt, "yunKdtName9", wscWXItemId_2021, 1);
        Assert.assertEquals(200, result.getCode());
        feeResourceWSCBasicOneYearOrder(kdt);
    }

    // 线上订单：教育单店1年-15天
    @Test
    public void A6quotaEduBasicOneYear() {
        Long kdt = newEduKdtId();
        godBlessU(kdt);
        PlainResult<OrderCreateApi> result = testCreateOrder(kdt, "yunKdtName9", edu_basic_2021, 1);
        Assert.assertEquals(200, result.getCode());
        feeResourceEDUBasicOneYearOrder(kdt);
    }

    // 线上订单：零售单店1年基础版本，计费侧校验
    @Test
    public void A6quotaLSBasicOneYear() {
//      17540783535
        Long kdtId = newRetailKdtId();
        godBlessU(kdtId);
        PlainResult<OrderCreateApi> result = testCreateOrder(kdtId, "自动化-零售云服务费3", professionItemId_2021, 1);
        Assert.assertEquals(200, result.getCode());
        feeResourceLSProfessionalOneYearOrder(kdtId);
    }

    // 线上订单：微商城1年专业版本，计费侧校验
    @Test
    public void A7quotaWSCProfessionalOneYear() {
        Long kdt = newWscKdtId();
        godBlessU(kdt);
        PlainResult<OrderCreateApi> result = testCreateOrder(kdt, "yunKdtName9", wscProfessionItemId_2021, 1);
        Assert.assertEquals(200, result.getCode());
        feeResourceWSCProfessional(kdt);

    }

    // 线上订单：微商城1年期间版本，计费侧校验
    @Test
    public void A8quotaWSCUltimateOneYear() {
        Long kdt = newWscKdtId();
        godBlessU(kdt);
        PlainResult<OrderCreateApi> result = testCreateOrder(kdt, "yunKdtName9", wscUltimateItemId_2021, 1);
        Assert.assertEquals(200, result.getCode());
        feeResourceWSCUltimate(kdt);
    }

    // 线下订单额度：微商城连锁-总部，计费侧校验：58749467
    @Test
    public void A9quotaWSCChainOneYear() {
        godBlessU(yunFeeCheck.get(11));
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(yunFeeCheck.get(11), 7284, 1000, 50000);
        Assert.assertEquals(200, result1.getCode());
        feeResourceNotZeroOrder(yunFeeCheck.get(11));
    }

    // 线下订单额度：零售连锁-总部，计费侧校验：58749375
    @Test
    public void A10quotaRetailChainOneYear() {
        godBlessU(yunFeeCheck.get(12));
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(yunFeeCheck.get(12), 7284, 1000, 50000);
        Assert.assertEquals(200, result1.getCode());
        feeResourceNotZeroOrder(yunFeeCheck.get(12));
    }

    @Test
    public void baodanOffline() {
        // 场景1：单店可以购买
        Long kdt = newWscKdtId();
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(kdt, 73357, 1, 500000);
        Assert.assertEquals(200, result1.getCode());
        // 场景2：单店再次购买失败
        PlainResult<CreateOfflineOrderResponse> result2 = createOfflineOrderV2(kdt, 73357, 1, 500000);
        Assert.assertEquals(141038, result2.getCode());
    }

    @Test
    public void baodanForChain() {
        godCannotHelpU(57116532L);
        // 场景3：连锁店不能购买
        PlainResult<CreateOfflineOrderResponse> result1 = createOfflineOrderV2(57116532L, 73357, 1, 1000000);
        Assert.assertEquals(141038, result1.getCode());
        Assert.assertEquals("该店铺不支持订购该商品", result1.getMessage());
        godCannotHelpU(57116532L);
    }

    // 线下落单：专业网店（2019）
//    @Test
//    public void zhuanyewangdian() {
//        PlainResult<CreateOfflineOrderResponse>  result1 = createOfflineOrderV2(58805275L, 8112, 1,1280000);
//        Assert.assertEquals(200, result1.getCode());
//    }




}
