package com.youzan.test.checkDebugTest.ActivityTest;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.test.basecase.DeductBaseTest;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author wuwu
 * @date 2021/4/7 7:53 PM
 */
public class ActivityBuyerTagTest extends DeductBaseTest {


    @Test
    public void setPresentActivityBuyerTag() {
        List<String> buyerTags = Arrays.asList("SIGN_BACK");
        Long mkActivityId = 564L;
        Long mkActivityRuleId = 1760L;

        MkActivity mkActivity = new MkActivity();

        MkActivity mkActivity1 = activityMapper.selectOne(new QueryWrapper<MkActivity>()
                .eq("id",mkActivityId));
        JSONArray jsonArrayShowCondition = JSONArray.parseArray(mkActivity1.getShowConditions());
        JSONObject jsonObjectShowCondition = jsonArrayShowCondition.getJSONObject(2);
        jsonObjectShowCondition.put("buyerTagEnumList",buyerTags);
        jsonArrayShowCondition.set(2,jsonObjectShowCondition);

        mkActivity.setShowConditions(jsonArrayShowCondition.toString());


        JSONArray jsonArrayCondition = JSONArray.parseArray(mkActivity1.getConditions());
        JSONObject jsonObjectCondition = jsonArrayCondition.getJSONObject(2);
        jsonObjectCondition.put("buyerTagEnumList",buyerTags);
        jsonArrayCondition.set(2,jsonObjectCondition);

        mkActivity.setShowConditions(jsonArrayCondition.toString());

        activityMapper.update(mkActivity, new UpdateWrapper<MkActivity>()
                .eq("id", mkActivityId));


        MkActivityRule mkActivityRule = new MkActivityRule();


        MkActivityRule mkActivityRule1 = activityRuleMapper.selectOne(new QueryWrapper<MkActivityRule>()
                .eq("id",mkActivityRuleId));

        JSONArray jsonArrayRuleCondition = JSONArray.parseArray(mkActivityRule1.getConditions());
        JSONObject jsonObjectRuleCondition = jsonArrayRuleCondition.getJSONObject(2);
        jsonObjectRuleCondition.put("buyerTagEnumList",buyerTags);
        jsonArrayRuleCondition.set(2,jsonObjectRuleCondition);

        mkActivityRule.setConditions(jsonArrayShowCondition.toString());


        activityRuleMapper.update(mkActivityRule, new UpdateWrapper<MkActivityRule>()
                .eq("id", mkActivityRuleId));
    }

    @Test
    public void setDiscountActivityBuyerTag() {
        //List<String> buyerTags = Arrays.asList("SIGN_BACK");
        String buyerTags = "SIGN_BACK";
        Long mkActivityId = 5455L;
//        Long mkActivityRuleId = 1760L;

        MkActivity mkActivity = new MkActivity();

        MkActivity mkActivity1 = activityMapper.selectOne(new QueryWrapper<MkActivity>()
                .eq("id",mkActivityId));
        JSONArray jsonArrayShowCondition = JSONArray.parseArray(mkActivity1.getShowConditions());
        JSONObject jsonObjectShowCondition = jsonArrayShowCondition.getJSONObject(2);
        jsonObjectShowCondition.put("buyerTagEnum",buyerTags);
        jsonArrayShowCondition.set(2,jsonObjectShowCondition);

        mkActivity.setShowConditions(jsonArrayShowCondition.toString());


        JSONArray jsonArrayCondition = JSONArray.parseArray(mkActivity1.getConditions());
        JSONObject jsonObjectCondition = jsonArrayCondition.getJSONObject(2);
        jsonObjectCondition.put("buyerTagEnum",buyerTags);
        jsonArrayCondition.set(2,jsonObjectCondition);

        mkActivity.setConditions(jsonArrayCondition.toString());

        activityMapper.update(mkActivity, new UpdateWrapper<MkActivity>()
                .eq("id", mkActivityId));

    }



    @Test
    public void getActivityBuyerTag() {
        Set<String> buyerTag = new HashSet<>();
        List<MkActivity> mkActivityList = activityMapper.selectList(new QueryWrapper<MkActivity>()
                .eq("activity_type","G_DISCOUNT")
                .like("conditions","buyerTagEnum"));

        for(MkActivity mkActivity:mkActivityList) {
            buyerTag.add(String.valueOf(mkActivity.getId()));
        }
        System.out.println(buyerTag);
        System.out.println(buyerTag.size());





        Set<String> buyerTagList = new HashSet<>();
        List<MkActivityRule> mkActivityRulesList = activityRuleMapper.selectList(new QueryWrapper<MkActivityRule>()
                .eq("rule_type","G_DISCOUNT")
                .like("conditions","buyerTagEnum"));

        for(MkActivityRule mkActivityRule:mkActivityRulesList) {
            buyerTagList.add(String.valueOf(mkActivityRule.getId()));
        }
        System.out.println(buyerTagList);
        System.out.println(buyerTagList.size());






    }
}
