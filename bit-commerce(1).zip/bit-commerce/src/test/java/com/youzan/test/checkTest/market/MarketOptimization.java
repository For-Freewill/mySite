package com.youzan.test.checkTest.market;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.api.PresentRemoteService;
import com.youzan.ycm.market.api.TradeRemoteService;
import com.youzan.ycm.market.dto.couponsend.CouponSendRuleDTO;
import com.youzan.ycm.market.request.couponasset.BatchSendCouponAssetRequest;
import com.youzan.ycm.market.request.couponsend.SaveSendCouponRequest;
import com.youzan.ycm.market.request.present.GetAvailablePresentGiftRequest;
import com.youzan.ycm.market.request.present.JudgeIsValidOrderRequest;
import com.youzan.ycm.market.request.present.SendPresentGiftRequest;
import com.youzan.ycm.market.request.trade.BatchCalculateRequest;
import com.youzan.ycm.market.response.couponasset.BatchSendCouponAssetResponse;
import com.youzan.ycm.market.response.couponsend.SaveCouponSendRecordResponse;
import com.youzan.ycm.market.response.present.GetAvailablePresentGiftResponse;
import com.youzan.ycm.market.response.present.JudgeIsValidOrderResponse;
import com.youzan.ycm.market.response.present.SendPresentGiftResponse;
import com.youzan.ycm.market.response.trade.BatchCalculateResponse;
import com.youzan.yop.api.response.ItemPreferentialInfoResultApi;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/7/12 8:15 PM
 */
public class MarketOptimization extends DeductBaseTest {
    @Dubbo
    public PresentRemoteService presentRemoteService;
    @Dubbo
    public TradeRemoteService tradeRemoteService;
    @JSONData("dataResource/basecase.activity/saveSendCouponRequest.json")
    public SaveSendCouponRequest saveSendCouponRequest;

    /**
     * 针对不同的产品线的优惠券批量发放
     * 针对不通用户标签的优惠券批量发放
     * @param
     */
    @Test(threadPoolSize = 1, invocationCount = 1,dataProvider = "recordIds",enabled = false)
    public void batchSendCouponAssetTest(String recordId) {
        BatchSendCouponAssetRequest batchSendCouponAssetRequest = new BatchSendCouponAssetRequest();
//        List kdtIdList = Arrays.asList("60048362","60135219","60048348","60133117","60129424","60048354");
//        List kdtIdList = Arrays.asList("60146705");
        //List kdtIdList = Arrays.asList("60146904");
        List kdtIdList = Arrays.asList("60146971","60146739");
//        ,"60146904","60146705"
        batchSendCouponAssetRequest.setCouponSendChannel("CRM_SALE");
        batchSendCouponAssetRequest.setCouponSendRecordId(recordId);
        batchSendCouponAssetRequest.setSendOperator("leifeiyun");
        batchSendCouponAssetRequest.setKdtIdList(kdtIdList);
        logger.info("参数："+JSON.toJSONString(batchSendCouponAssetRequest));
        PlainResult<BatchSendCouponAssetResponse> result = couponAssetRemoteService.batchSendCouponAsset(batchSendCouponAssetRequest);
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200,result.getMessage());
    }


    @DataProvider
    public Object[][] recordIds() {
        return new Object[][]{
                {"28996"},//新签
                {"28997"},//续签
                {"28998"},//回签
                {"28999"},//新+续
                {"29000"},//新+回
                {"29001"},//续+回
                {"29002"},//全部
                {"29051"}


        };
    }

    /**
     * 针对不同的产品线的优惠券批量发放
     * 针对不通用户标签的优惠券批量发放
     * @param
     */
    @Test(threadPoolSize = 1, invocationCount = 1,dataProvider = "prodShop",enabled = false)
    public void batchSendCouponAssetForProdTypeTest(String kdtId) {
        BatchSendCouponAssetRequest batchSendCouponAssetRequest = new BatchSendCouponAssetRequest();
//        List kdtIdList = Arrays.asList("60048362","60135219","60048348","60133117","60129424","60048354");
//        List kdtIdList = Arrays.asList("60146705");
        //List kdtIdList = Arrays.asList("60146904");
        List kdtIdList = Arrays.asList(kdtId);
//        ,"60146904","60146705"
        batchSendCouponAssetRequest.setCouponSendChannel("CRM_SALE");
        batchSendCouponAssetRequest.setCouponSendRecordId("29059");
        batchSendCouponAssetRequest.setSendOperator("leifeiyun");
        batchSendCouponAssetRequest.setKdtIdList(kdtIdList);
        logger.info("参数："+JSON.toJSONString(batchSendCouponAssetRequest));
        PlainResult<BatchSendCouponAssetResponse> result = couponAssetRemoteService.batchSendCouponAsset(batchSendCouponAssetRequest);
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200,result.getMessage());
    }


    @DataProvider
    public Object[][] prodShop() {
        return new Object[][]{
                {"60146971"},//教育连锁
                {"60146739"},//教育单店
                {"60135219"},//微商城单店
                {"60146653"},//美业
                {"60048354"},//零售单店
                {"60146967"},//零售连锁
                {"60147070"},//旺小店
                {"60146660"},//企微助手
                {"60146783"},//微商城单店
        };
    }


    /**
     * CRM店铺订单下可以补发礼包的数据展示
     * 重点测试不同买赠活动条件下，订单下可补发礼包展示
     * @param orderId
     */
    @Test(dataProvider = "orderId",enabled = false)
    public void getAvailablePresentGiftTest(String orderId) {
        GetAvailablePresentGiftRequest getAvailablePresentGiftRequest = new GetAvailablePresentGiftRequest();
        getAvailablePresentGiftRequest.setOrderId(orderId);
        logger.info("参数："+JSON.toJSONString(getAvailablePresentGiftRequest));
        //PlainResult<GetAvailablePresentGiftResponse> result = presentRemoteService.getAvailablePresentGift(getAvailablePresentGiftRequest);
        PlainResult<GetAvailablePresentGiftResponse> result = compareServiceImp.invoke(() -> presentRemoteService.getAvailablePresentGift(getAvailablePresentGiftRequest));
        logger.info(JSON.toJSONString(result));
    }

    @DataProvider
    public Object[][] orderId() {
        return new Object[][]{
//                {"311626338200343"},//周期购
//                {"311626338200344"},//热力图
//                {"311626338200345"},//推广分析
//                {"311626337164300"},//微商城
//                {"311626335264084"},//微商城
//                {"311626664524275"},
//                {"311626666688227"},
//                {"311626677586747"},
//                {"311626662760250"},
//                {"311626682500808"},
//                {"311626666688227"},
//                {"311626683406811"},
                {"311626686116823"},
                {"311626685985822"}

        };
    }


    /**
     * CRM补发买赠礼包全量回归
     * @param
     */
    @Test(enabled = false)
    public void sendPresentGiftTest() {
        SendPresentGiftRequest sendPresentGiftRequest = new SendPresentGiftRequest();
        sendPresentGiftRequest.setOrderId("311626686116823");
        sendPresentGiftRequest.setBizNo("1626666209509_13100_1_311690687524275");
        sendPresentGiftRequest.setBizType("crm_distribute_stock");
        sendPresentGiftRequest.setDistributeNum(1L);
        sendPresentGiftRequest.setGiftTemplateId("35324");
        sendPresentGiftRequest.setPromotionId("33883");
        sendPresentGiftRequest.setPromotionType("COUPON");//券：COUPON，活动：ACTIVITY
        PlainResult<SendPresentGiftResponse> result = presentRemoteService.sendPresentGift(sendPresentGiftRequest);
        logger.info(JSON.toJSONString(result));
    }


    /**
     * CRM补发买赠礼包：判断订单是否符合补发条件
     * @param
     */
    @Test(enabled = false)
    public void judgeOrderIsMeetConditionTest() {
        JudgeIsValidOrderRequest judgeIsValidOrderRequest = new JudgeIsValidOrderRequest();
        List<String> orderIds = Arrays.asList("311626677610748","311626677586747","311626338200343","311626338200343","311626666688227","311626664524275","311626663304261","311626663303260","311626662760249","311626662760250","311626427862263") ;
        judgeIsValidOrderRequest.setOrderIds(orderIds);
        logger.info("参数："+JSON.toJSONString(judgeIsValidOrderRequest));

        PlainResult<JudgeIsValidOrderResponse> result = compareServiceImp.invoke(() ->presentRemoteService.judgeOrderIsMeetCondition(judgeIsValidOrderRequest));
        logger.info(JSON.toJSONString(result));
    }


    @Test(enabled = false)
    public void batchCalculateTest() {
        BatchCalculateRequest batchCalculateRequest = new BatchCalculateRequest();
        PlainResult<BatchCalculateResponse> result = tradeRemoteService.batchCalculate(batchCalculateRequest);
        logger.info(JSON.toJSONString(result));
    }

    /**
     * 新签用户的试用期礼包买赠活动的下单并履约
     * 买激活码送礼包的买赠活动的下单并履约（该活动通过刷数据，并无页面入口, 目前已存活动数据已失效）
     */
    @Test(enabled = false)
    public void calculateV2Test() {
//        CalculateRequest calculateRequest = new CalculateRequest();
//
//        BuyerContextDTO buyerContextDTO = new BuyerContextDTO();
//        buyerContextDTO.setBuyerId();
//        buyerContextDTO.setProdLine();
//        buyerContextDTO.setBuyerType();
//        buyerContextDTO.setYcmBuyer();
//        calculateRequest.setBuyerContextDTO(buyerContextDTO);
//
//        OrderContextDTO orderContextDTO = new OrderContextDTO();
//        orderContextDTO.setPromotionOwner();
//        orderContextDTO.setBizExt();
//        orderContextDTO.setOrderWay();
//        orderContextDTO.setActivationOrderFlag();
//        orderContextDTO.setYzbAmount();
//
//        List<ItemDetailDTO> itemDetailDTOList = new ArrayList<>();
//        ItemDetailDTO itemDetailDTO = new ItemDetailDTO();
//        itemDetailDTO.setSkuId();
//        itemDetailDTO.setSpuId();
//        itemDetailDTO.setSubTotalAmount();
//        itemDetailDTO.setBizExt();
//        itemDetailDTO.setDurationNum();
//        itemDetailDTO.setQuantityNum();
//        orderContextDTO.setItemDetailDTOList(itemDetailDTOList);
//
//        calculateRequest.setOrderContextDTO(orderContextDTO);
//
//        PromotionChoiceDTO promotionChoiceDTO = new PromotionChoiceDTO();
//        promotionChoiceDTO.setBizExt();
//        promotionChoiceDTO.setPromotionChoiceType();
//        promotionChoiceDTO.setPromotionScope();
//        promotionChoiceDTO.setPromotionId();
//        promotionChoiceDTO.setPromotionType();
//        promotionChoiceDTO.setSkuId();
//        promotionChoiceDTO.setSpuId();
//
//        List<PromotionChoiceDTO> promotionChoiceDTOS = new ArrayList<>();
//        calculateRequest.setPromotionChoiceDTOList(promotionChoiceDTOS);
//
//
//        calculateRequest.setTradePhase();
//        calculateRequest.setCalcStrategy();
//        PlainResult<CalculateResponse> result = tradeRemoteService.calculateV2(calculateRequest);
//        logger.info(JSON.toJSONString(result));

    }


    @Test(dataProvider = "itemId",enabled = false)
    public void fetchItemPreferentialInfoOnlineTest(Integer itemId, Integer quantity) {
        PlainResult<List<ItemPreferentialInfoResultApi>> result =
                compareServiceImp.invoke(() -> fetchItemPreferentialInfoOnline(60133117L,1,itemId,quantity,1));
        logger.info(JSON.toJSONString(result));

    }

    @DataProvider
    public Object[][] itemId() {
        return new Object[][]{
                {basicWechatItemId,1},
                {basicWechatItemId,2},
                {basicBaiduItemId_2021,1},
                {basicBaiduItemId_2021,2},
                {professionItemId,1},
                {professionItemId,2},
                {ultimateItemId_2021,1},
                {ultimateItemId_2021,2}
        };
    }

    @Test(dataProvider = "userTagList",enabled = false)
    public void saveCouponSendRecordTest(List userTagList) {
        CouponSendRuleDTO couponSendRuleDTO = saveSendCouponRequest.getCouponSendRuleDTO();
        couponSendRuleDTO.setUserTagList(userTagList);
        saveSendCouponRequest.setCouponSendRuleDTO(couponSendRuleDTO);
        logger.info("参数："+saveSendCouponRequest);
        PlainResult<SaveCouponSendRecordResponse> result = couponSendRemoteService.saveCouponSendRecord(saveSendCouponRequest);
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);

    }


    @DataProvider
    public Object[][] userTagList() {
        List<String> all = Arrays.asList("FIRST","SIGN_BACK","REORDER");
        List<String> first = Arrays.asList("FIRST");
        List<String> renew = Arrays.asList("REORDER");
        List<String> signBack = Arrays.asList("SIGN_BACK");
        List<String> firstAndRenew = Arrays.asList("FIRST","REORDER");
        List<String> firstAndSignBack = Arrays.asList("FIRST","SIGN_BACK");
        List<String> renewAndSignBack = Arrays.asList("SIGN_BACK","REORDER");

        return new Object[][]{
                {all},
                {first},
                {renew},
                {signBack},
                {firstAndRenew},
                {firstAndSignBack},
                {renewAndSignBack},

        };
    }


}
