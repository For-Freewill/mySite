package com.youzan.test.apicase.yop;

import com.youzan.test.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author tianning
 * @date 2020/8/9 11:12 下午
 */
public class YopBaseTest extends BaseTest {
    final static public Logger logger = LoggerFactory.getLogger(YopBaseTest.class);
}
