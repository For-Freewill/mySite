package com.youzan.test.apicase.yop.stockRemoteService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageDO;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.StockRemoteService;
import com.youzan.yop.api.entity.ChangeStockParam;
import com.youzan.yop.api.enums.StockApp;
import com.youzan.yop.api.request.StockApi;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;
import static org.awaitility.Awaitility.with;

/**
 * Created by baoyan on 2021-01-05.
 * 短信业务迁移至业务方，老的集成废弃
 */
/*
public class DecreaseStockTest extends YunBaseTest {
    @Dubbo
    StockRemoteService stockRemoteService;
    private long kdtId1 = 58813044l;
    private long kdtId2 = 58813053l;

*/
/*    @BeforeClass
    public void clean() {

        godBlessU(kdtId1);
        godBlessU(kdtId2);
    }*//*


    //  正常扣减
    @Test
    public void decreaseStockNormalTest() {
        //  下单短信充值,充值成功
        godCannotHelpU(kdtId1);
        PlainResult<List<Long>> result1 = bizOfflineOrder(kdtId1, 613, 1, 50);
        Assert.assertEquals(result1.getCode(),200);
        StockApi stockApi = new StockApi();
        stockApi.setKdtId(kdtId1);
        stockApi.setAppId(9638);
        stockApi.setStockApp(StockApp.MESSAGE_APP);
        // 轮询方式查询库存
        with().atMost(20, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> stockRemoteService.getStock(stockApi).getData().intValue()==1000);
        ChangeStockParam changeStockParam = new ChangeStockParam();
        changeStockParam.setKdtId(kdtId1);
        changeStockParam.setAppId(9638);
        changeStockParam.setChangeStockType("tradeSend");
        changeStockParam.setNum(1);
        changeStockParam.setBizNo(null);
        changeStockParam.setBizName(null);
        PlainResult<Boolean> decreaseResult = stockRemoteService.decreaseStock(changeStockParam);
        logger.info(decreaseResult.toString());
        Assert.assertEquals(decreaseResult.getCode(), 200);
        Assert.assertTrue(decreaseResult.getData());
        //  剩余库存为999
        PlainResult<Integer> resultAfterDecrease = stockRemoteService.getStock(stockApi);
        Assert.assertEquals(resultAfterDecrease.getCode(), 200);
        Assert.assertEquals(resultAfterDecrease.getData().intValue(), 999);
    }

    //  没有库存时无法扣减
    @Test
    public void decreaseStockWithOutStockTest() {
        godCannotHelpU(kdtId2);
        //  下单短信充值,充值成功
        PlainResult<List<Long>> result1 = bizOfflineOrder(kdtId2, 613, 1, 50);
        StockApi stockApi = new StockApi();
        stockApi.setKdtId(kdtId2);
        stockApi.setAppId(9638);
        stockApi.setStockApp(StockApp.MESSAGE_APP);
        // 轮询方式查询库存
        with().atMost(20, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> stockRemoteService.getStock(stockApi).getData().intValue()==1000);
        ChangeStockParam changeStockParam = new ChangeStockParam();
        changeStockParam.setKdtId(kdtId2);
        changeStockParam.setAppId(9638);
        changeStockParam.setChangeStockType("tradeSend");
        changeStockParam.setNum(1000);
        PlainResult<Boolean> decreaseResult = stockRemoteService.decreaseStock(changeStockParam);
        Assert.assertEquals(decreaseResult.getCode(), 200);
        Assert.assertTrue(decreaseResult.getData());
        PlainResult<Integer> resultAfterDecrease = stockRemoteService.getStock(stockApi);
        Assert.assertEquals(resultAfterDecrease.getCode(), 200);
        Assert.assertEquals(resultAfterDecrease.getData().intValue(), 0);
        changeStockParam.setNum(1);
        PlainResult<Boolean> decreaseResult1 = stockRemoteService.decreaseStock(changeStockParam);
        logger.info(decreaseResult1.toString());
        Assert.assertEquals(decreaseResult1.getCode(), 40200);
        Assert.assertFalse(decreaseResult1.getData());
        Assert.assertEquals(decreaseResult1.getMessage(), "库存不足");

    }

    @Test
    public void decreaseStockWithOutKdtIdTest() {
        ChangeStockParam changeStockParam = new ChangeStockParam();
        changeStockParam.setKdtId(null);
        changeStockParam.setAppId(9638);
        changeStockParam.setChangeStockType("tradeSend");
        changeStockParam.setNum(1000);
        PlainResult<Boolean> decreaseResult = stockRemoteService.decreaseStock(changeStockParam);
        logger.info(decreaseResult.toString());
        Assert.assertEquals(decreaseResult.getCode(), 150006);
        Assert.assertFalse(decreaseResult.getData());
    }

    @Test
    public void decreaseStockWithOutAppIdTest() {
        ChangeStockParam changeStockParam = new ChangeStockParam();
        changeStockParam.setKdtId(kdtId1);
        changeStockParam.setAppId(null);
        changeStockParam.setChangeStockType("tradeSend");
        changeStockParam.setNum(1000);
        PlainResult<Boolean> decreaseResult = stockRemoteService.decreaseStock(changeStockParam);
        logger.info(decreaseResult.toString());
        Assert.assertEquals(decreaseResult.getCode(), 130501);
        Assert.assertFalse(decreaseResult.getData());
    }

    @Test
    public void decreaseStockWithOutChangeStockTypeTest() {
        ChangeStockParam changeStockParam = new ChangeStockParam();
        changeStockParam.setKdtId(kdtId1);
        changeStockParam.setAppId(9638);
        changeStockParam.setChangeStockType(null);
        changeStockParam.setNum(1000);
        PlainResult<Boolean> decreaseResult = stockRemoteService.decreaseStock(changeStockParam);
        logger.info(decreaseResult.toString());
        Assert.assertEquals(decreaseResult.getCode(),130501);
        Assert.assertFalse(decreaseResult.getData());
    }

    @Test
    public void decreaseStockWithOutNumTest() {
        ChangeStockParam changeStockParam = new ChangeStockParam();
        changeStockParam.setKdtId(kdtId1);
        changeStockParam.setAppId(9638);
        changeStockParam.setChangeStockType("tradeSend");
        changeStockParam.setNum(null);
        PlainResult<Boolean> decreaseResult = stockRemoteService.decreaseStock(changeStockParam);
        logger.info(decreaseResult.toString());
        Assert.assertEquals(decreaseResult.getCode(),130501);
        Assert.assertFalse(decreaseResult.getData());
    }
}
*/
