package com.youzan.test.market.basecase.activity;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import com.youzan.ycm.market.api.CouponRemoteService;
import com.youzan.ycm.market.dto.coupon.AllCouponDTO;
import com.youzan.ycm.market.request.activity.SaveOrderFullReduceActivityRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.response.activity.SaveOrderFullReduceActivityResponse;
import com.youzan.ycm.market.response.coupon.SaveCouponResponse;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author leifeiyun
 * @date 2020/11/20
 **/
public class ActivityToolTest extends MarketActivityBaseTest {

    //    @JSONData("/dataResource/basecase.activity/fullReduceActivitySaveTemp.json")
//    SaveOrderFullReduceActivityRequest saveOrderFullReduceActivityRequest;

    @Dubbo
    CouponRemoteService couponRemoteService;
    @Http("bizProd")
    public HttpUtil bizProdHttp;
    @Http("ops")
    public HttpUtil opsHttp;


    /**
     * 把线上的满减活动，根据满减活动id，同步到qa，创建一份一模一样的，并且让活动立即生效，注意每次使用，去线上捞一下session
     */
    @Test(enabled = false)
    public void saveOrderFullReduceActivity() {
        //每次使用，传入要复制的线上的活动id,
        List<Integer> stringList = Arrays.asList(765, 766, 767, 768, 768, 769, 770);

        Map header = new HashMap();
        header.put("Content-Type", "application/json;charset=UTF-8");
        String kdtsessionid = "YZ780813492089364480YZHJ3LtpDt";
//        header.put("Cookie", "KDTSESSIONID="+kdtsessionid+";QUDAO_SESSIONID="+kdtsessionid+";sid="+kdtsessionid);
        header.put("Cookie", "KDTSESSIONID=" + kdtsessionid);
        for (Integer s : stringList) {
            String url = "/ycm/v1/activity/fullReduce/" + s;
            String stringResult = bizProdHttp.doGetReturnResponse(url, "page=1&pageSize=10", header);
            JSONObject jsonObject = JSON.parseObject(stringResult);
            SaveOrderFullReduceActivityRequest saveOrderFullReduceActivityRequest = jsonObject.getJSONObject("data").toJavaObject(SaveOrderFullReduceActivityRequest.class);
            saveOrderFullReduceActivityRequest.getFullReduceActivityDTO().setActivityId("");
            saveOrderFullReduceActivityRequest.getFullReduceActivityDTO().setEffectTime("2020-11-24 00:00:00");
            PlainResult<SaveOrderFullReduceActivityResponse> plainResult =
                    orderFullReduceActivityRemoteService.saveActivity(saveOrderFullReduceActivityRequest);

        }
    }


    /**
     * 把线上的满减券，根据满减券id，同步到qa，创建一份一模一样的，并且让券立即上架，注意每次使用，去线上捞一下session
     */
    @Test(enabled = false)
    public void saveOrderFullCoupon() {
        //每次使用，传入要复制的线上的活动id,
        List<Integer> stringList = Arrays.asList(3072, 3074, 3075);

        Map header = new HashMap();
        header.put("Content-Type", "application/json;charset=UTF-8");
        String kdtsessionid = "YZ834455630315208704YZXcoOXSSy";
//        header.put("Cookie", "KDTSESSIONID="+kdtsessionid+";QUDAO_SESSIONID="+kdtsessionid+";sid="+kdtsessionid);
        header.put("Cookie", "KDTSESSIONID=" + kdtsessionid);
        for (Integer s : stringList) {
            String url = "/ycm/v1/coupon/" + s;
            String stringResult = bizProdHttp.doGetReturnResponse(url, "page=1&pageSize=10", header);
            JSONObject jsonObject = JSON.parseObject(stringResult);
            AllCouponDTO allCouponDTO = jsonObject.getJSONObject("data").toJavaObject(AllCouponDTO.class);
            SaveCouponRequest saveCouponRequest = new SaveCouponRequest();
            allCouponDTO.setCouponId("");
            allCouponDTO.setName("线上导下来的-"+allCouponDTO.getName());
            saveCouponRequest.setAllCouponDTO(allCouponDTO);
            PlainResult<SaveCouponResponse> plainResult =
                    couponRemoteService.saveCoupon(saveCouponRequest);
            //上架权益
            updateCouponState(String.valueOf(plainResult.getData().getAllCouponDTO().getCouponId()));

        }
    }


    /**
     * ycm_trade_order_paid ycm-perform 11969
     */
    @Test(enabled = false)
    public void testOpsSkipMsg(){
        Map header = new HashMap();
        header.put("Content-Type", "application/json;charset=UTF-8");
        String kdtsessionid = "YZ804401797901078528YZvcEtNHJe";
//        header.put("Cookie", "KDTSESSIONID="+kdtsessionid+";QUDAO_SESSIONID="+kdtsessionid+";sid="+kdtsessionid);
        header.put("Cookie", "KDTSESSIONID=" + kdtsessionid);
        String url = "/api/v1.0/yuri/api/v1.0/addons/nsq-channels/2719";
        Map paramMap = new HashMap();
        paramMap.put("action","skip");
        JSONObject jsonObject = opsHttp.doPutReturnResponseJson(url,paramMap,header);
        logger.info(""+jsonObject.toJSONString());
    }
}
