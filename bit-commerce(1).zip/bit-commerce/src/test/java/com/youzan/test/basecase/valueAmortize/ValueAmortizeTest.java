package com.youzan.test.basecase.valueAmortize;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfAsset;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.perform.PfAssetMapper;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by wuwu on 2020/8/18
 **/
public class ValueAmortizeTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(ValueAmortizeTest.class);

    @Autowired(required = false)
    PfAssetMapper pfAssetMapper;
    @Autowired(required = false)
    TdOrderMapper tdOrderMapper;

    public Long promotionId = 8649L;

    public Long giftAmorizeKdtId = 59523220L;
    public String giftAmorizeKdtName = "CI-接口自动化-礼包摊销测试";



    @Test
    public void TestGiftAndOrderValueAmortize() {

        /**
         * 1.清理店铺下的待支付和未退款的订单，充余额、充有赞币
         * 2.创建订单，含礼包
         * 3.预支付
         * 4.支付
         * 5.退款
         * 6.清空账户余额和有赞币
         **/

        initShopByKdtId(amortizeKdtId);
        rechargeYzcoin(amortizeKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(amortizeKdtId), cny + 1000);

        setActivityValid(promotionId);

        //创建订单
        PlainResult<String> orderCreateApiPlainResult = createNormalOrder(amortizeKdtId,amortizeKdtName,basicWechatItemId,1,yzb);

        setActivityInvalid(promotionId);

        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(orderCreateApiPlainResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, amortizeKdtId);
        }

        String orderId = orderCreateApiPlainResult.getData();

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //等待履约
        waitForPerform(amortizeKdtId, 873L, Long.valueOf(orderId));

        List<PfAsset> gfAssetItemNumList = new ArrayList<>();
        Long allGiftsNum = 0L;
        Long gfsCnyValue = 0L;
        Long gfsYzbValue = 0L;

        //获取pf_order里订单实付的金额
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));

        Long CnyValue = pfOrder.getRealPrice();
        Long YzbValue = pfOrder.getYzbPrice();

        PfAsset pfAssetOrder = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_paid"));
        List<PfAsset> pfAssetGifts = pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo()).eq("source_type", "product_with_present").eq("app_id", "combine_spu_wsc"));
        if (pfAssetGifts.size() > 0) {
            for (PfAsset pfAssetGift : pfAssetGifts) {
                if (pfAssetGift.getItemId().endsWith("day")) {

                    gfAssetItemNumList.add(pfAssetGift);
                    allGiftsNum += pfAssetGift.getItemNum();
                }
                if (pfAssetGift.getItemId().endsWith("year")) {
                    gfAssetItemNumList.add(pfAssetGift);
                    allGiftsNum = allGiftsNum + pfAssetGift.getItemNum() * 365;

                }
            }
            for (PfAsset pfAssetGift : gfAssetItemNumList) {
                Long gfsItemCnyValue = 0L;
                //TODO 此处的365后续需要修改成计算订单的时间，后面再说
                gfsItemCnyValue = CnyValue * pfAssetGift.getItemNum() / (365 + allGiftsNum);
                Assert.assertEquals(pfAssetGift.getCnyAmt(), gfsItemCnyValue, "礼包实付金额摊销错误");
                gfsCnyValue += gfsItemCnyValue;

                Long gfsItemYzbValue = 0L;
                gfsItemYzbValue = YzbValue * pfAssetGift.getItemNum() / (365 + allGiftsNum);
                Assert.assertEquals(pfAssetGift.getYzbAmt(), gfsItemYzbValue, "礼包实付有赞币摊销错误");
                gfsYzbValue += gfsItemYzbValue;
            }

            Long orderCnyValue = CnyValue - gfsCnyValue;
            Long orderYzbValue = YzbValue - gfsYzbValue;

            Assert.assertEquals(pfAssetOrder.getCnyAmt(), orderCnyValue, "订单实付金额摊销错误");
            Assert.assertEquals(pfAssetOrder.getYzbAmt(), orderYzbValue, "订单实付有赞币摊销错误");

        } else {
            Assert.assertEquals(pfAssetOrder.getCnyAmt(), CnyValue, "订单实付金额摊销错误");
            Assert.assertEquals(pfAssetOrder.getYzbAmt(), YzbValue, "订单实付金额摊销错误");
        }

        //将订单退款
        refundOrderByKdtId(amortizeKdtId);
        //resetShopBalance(wscKdtId.intValue());
        //recycleYzcoin(wscKdtId);
    }


    @Override
    public PlainResult<String> createNormalOrder(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);
        Byte type = 25;

        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();

        if (itemId == basicWechatItemId) {
            PreferentialDescApi itemPromtion = new PreferentialDescApi();
            itemPromtion.setType(type);
            itemPromtion.setSelected(true);
            itemPromtion.setPromotionId(promotionId);

            itemPromotionList.add(itemPromtion);

            orderItemForm.setItemPromotionList(itemPromotionList);
        }

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);
        logger.info("创建订单参数:{}", JSON.toJSONString(createOrderForm));
        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);

        return resultCreateNormalOrder;
    }

}
