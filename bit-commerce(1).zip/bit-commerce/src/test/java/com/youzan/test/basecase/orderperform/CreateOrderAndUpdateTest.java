package com.youzan.test.basecase.orderperform;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderDetail;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.order.OrderListApi;
import com.youzan.yop.api.entity.order.OrderSimpleApi;
import com.youzan.yop.api.entity.order.SimpleOrderAndStatusApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.ListValidOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.form.order.SearchOrderListForm;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2020/8/17 5:19 下午
 * 创建订单，并且进行抵扣升级
 * 校验服务期生效顺序：抵扣升级的服务期在原来服务期之后生效
 */

public class CreateOrderAndUpdateTest extends TnBaseTest {
    public static String account1 = "15558185323";

    @JSONData(value = "dataResource/basecase.orderperform/CreateOrderAndUpdateRequestData.json", key = "request")
    private CreateOrderForm createOrderForm;

//    @BeforeMethod
//    public void beforeMethod() {
//        logger.info("before method 清理数据数据：" + jyl);
//        clearCache(jyl);
//    }

    /**
     * 抵扣升级 校验服务期生效顺序
     * 教育(2020 )基础版
     */

    @Test(enabled = false)
    public void createOrderTest() {
        Long jyl = newEduKdtId();
        rechargeShopBalance(jyl.toString(), 99999999);
        createOrderForm.setKdtId(jyl);
        //1.如果有未关闭订单，先关闭

        //2. 创建订单
        PlainResult<String> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                    @Override
                    public PlainResult<String> doExecute() {
                        return orderRemoteService.createNormalOrder(createOrderForm);
                    }

                    @Override
                    public boolean handleResult(PlainResult<String> plainResult) {
                        return plainResult.getCode() == 200;
                    }
                }, 5, 100);
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        Assert.assertEquals(plainResult.getCode(), 200);

        if (plainResult.getCode() == 200) {

            //3.预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.parseLong(plainResult.getData()), (byte) 4);
            Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

            //4.余额支付
            cashierPay(preparePayApiPlainResult, account1, jyl);

            //5.查询订购记录
            SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
            searchOrderListForm.setKdtId(jyl);
            searchOrderListForm.setUserId(1L);
            searchOrderListForm.setPageNo(2);
            searchOrderListForm.setPageSize(10);
            searchOrderListForm.setState((byte) 1);
            searchOrderListForm.setAppId(ItemInfo.WSC_BD_680000_2021.getAppId());
            searchOrderListForm.setCombine(false);
            searchOrderListForm.setSource(1);
            searchOrderListForm.setWithKdtIdList(null);
            PlainResult<PageApi<OrderListApi>> orderResult = orderRemoteService.listOrder(searchOrderListForm);

            //订购状态:已付款
            Assert.assertEquals(orderResult.getCode(), 200);

            //6. 根据参数查询有效订单，以及对应appId服务期
            ListValidOrderForm listValidOrderForm = new ListValidOrderForm();
            List<Long> kdtid = new ArrayList<>();
            kdtid.add(0, jyl);
            listValidOrderForm.setKdtIds(kdtid);
            PlainResult<Map<Long, List<SimpleOrderAndStatusApi>>> validOrderAndStatusResult = orderRemoteService.listValidOrderAndStatus(listValidOrderForm);
            Assert.assertEquals(validOrderAndStatusResult.getCode(), 200);

            //7.根据参数查询有效订单
            PlainResult<List<OrderSimpleApi>> listValidOrderResult = orderRemoteService.listValidOrder(listValidOrderForm);
            Assert.assertEquals(listValidOrderResult.getCode(), 200);
        }
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        //二次创建订单，进行版本升级 itemid会变
        List<OrderItemForm> items = new ArrayList<>();
        OrderItemForm orderItemForm = new OrderItemForm();
        orderItemForm.setItemId(74219);
        orderItemForm.setQuantity(1);
        items.add(orderItemForm);
        createOrderForm.setItems(items);
        PlainResult<String> result2 = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                    @Override
                    public PlainResult<String> doExecute() {
                        return orderRemoteService.createNormalOrder(createOrderForm);
                    }

                    @Override
                    public boolean handleResult(PlainResult<String> plainResult) {
                        return plainResult.getCode() == 200;
                    }
                }, 5, 100);
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        Assert.assertEquals(result2.getCode(), 200);

        if (result2.getCode() == 200) {
            //4.预支付
            PlainResult<PreparePayApi> continueResult = preparePay(Long.parseLong(result2.getData()), (byte) 4);

            Assert.assertEquals(continueResult.getCode(), 200);

            //5.余额支付
            cashierPay(continueResult, account1, jyl);

            //查一下礼包的表和履约的表，确认数据确实生成
            List<TdOrder> tdOrderRecords = queryTdOrderByKdtIdAndState(jyl);

            if (tdOrderRecords.size() > 0) {
                String td_no = tdOrderRecords.get(0).getTdNo();
                List<PfOrder> pfOrderRecords =
                        pfOrderMapper.selectList(
                                new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBuyKdtId, jyl).eq(PfOrder::getBizOrderId, td_no));
                List<PfOrderDetail> pfOrderDetailsListAll = new ArrayList();
                pfOrderRecords.forEach(item -> {
                    Long id = item.getId();
                    List<PfOrderDetail> pfOrderDetails =
                            pfOrderDetailMapper.selectList(
                                    new QueryWrapper<PfOrderDetail>().lambda().eq(PfOrderDetail::getBuyKdtId, jyl).eq(PfOrderDetail::getPfOrderId, id));
                    pfOrderDetailsListAll.addAll(pfOrderDetails);
                });

                List<PfOrderStatus> pfOrderStatusListAll = new ArrayList();
                pfOrderRecords.forEach(itemStatus -> {
                    Long d = itemStatus.getId();
                    List<PfOrderStatus> pfOrderStatuses =
                            pfOrderStatusMapper.selectList(
                                    new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, jyl).eq(PfOrderStatus::getPfOrderId, d));
                    pfOrderStatusListAll.addAll(pfOrderStatuses);
                });
                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.getMessage();
                }

                // 取基础版的失效时间 降序排序，取第一个
                List<PfOrderStatus> orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", jyl).eq("item_id", "atom_sku_edu_single_year").eq("level", "new_basic").eq("group_type", "product_with_paid").orderByDesc("expire_time"));
                if (!(orderStatusListBasic.size() > 0)) {
                    orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", jyl).eq("level", "new_basic").eq("item_id", "atom_sku_edu_single_year").eq("group_type", "product_with_paid").orderByDesc("expire_time"));
                }
                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
                Assert.assertTrue(orderStatusListBasic.size() > 0);

                // 取升级后的生效时间 升排序，取第一个
                List<PfOrderStatus> orderStatusListProfession = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, jyl).eq(PfOrderStatus::getLevel, "profession").eq(PfOrderStatus::getItemId, "atom_sku_edu_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByDesc(PfOrderStatus::getEffectTime));
                if (!(orderStatusListProfession.size() > 0)) {
                    orderStatusListProfession = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, jyl).eq(PfOrderStatus::getLevel, "profession").eq(PfOrderStatus::getItemId, "atom_sku_edu_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByDesc(PfOrderStatus::getEffectTime));
                }
                Assert.assertTrue(orderStatusListProfession.size() > 0);

                Date professionDate = orderStatusListProfession.get(0).getEffectTime();
                Date basicDate = orderStatusListBasic.get(0).getExpireTime();

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

                String basicDateString = dateFormat.format(basicDate);
                String professionDateString = dateFormat.format(professionDate);

                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.printStackTrace();
                }

                //比较两个版本软件的订单创建时间
//                Assert.assertTrue(professionDateString.equals(basicDateString));
            }
        }
    }
}
