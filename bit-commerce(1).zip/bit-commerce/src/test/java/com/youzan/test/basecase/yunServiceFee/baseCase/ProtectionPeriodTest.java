package com.youzan.test.basecase.yunServiceFee.baseCase;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageDO;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeYopProtocolDTO;
import com.youzan.commerce.test.entity.dataobject.perform.PfFeeResourcePackageEntity;
import com.youzan.commerce.test.entity.dataobject.perform.PfProtectionPeriodEntity;
import com.youzan.commerce.test.mapper.perform.PfProtectionPeriodMapper;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.perform.api.QuotaRemoteService;
import com.youzan.ycm.perform.request.quota.ModifyProtectionPeriodRequest;
import com.youzan.ycm.perform.response.quota.ModifyProtectionPeriodResponse;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.youzan.commerce.test.utils.DateUtil.durationDays;
import static org.awaitility.Awaitility.with;

/**
 * @author wulei
 * @date 2021/1/18 11:19
 * 云服务费3.0 修改店铺保护期
 * 专用测试手机：17540783535
 */
@Slf4j
public class ProtectionPeriodTest extends YunBaseTest {
    private List<Long> yunFeeWSCCheck = Arrays.asList(58820821L);

    @Dubbo
    private QuotaRemoteService quotaRemoteService;

    /**
     * 修改保护期校验
     */
    @Test
    public void modifyPeriodNormalTest(){
        Long kdt = newWscKdtId();
        // 修改保护期为1-100的随机数
        Integer period = (int) (Math.random()*100)+1;
        ModifyProtectionPeriodRequest modifyProtectionPeriodRequest = new ModifyProtectionPeriodRequest();
        modifyProtectionPeriodRequest.setKdtId(kdt);
        modifyProtectionPeriodRequest.setPeriod(period);
        PlainResult<ModifyProtectionPeriodResponse> result = quotaRemoteService.modifyProtectionPeriod(modifyProtectionPeriodRequest);
        Assert.assertEquals(200, result.getCode());
        // 校验保护期表记录
        periodModifyDBCheck(kdt,period);

        // 修改后，下单微商城，校验过期时间是否是设置的值
        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdt, "yunKdtName9", wscWXItemId_2021, 1);
        Assert.assertEquals(200, result2.getCode());
        feeResourceWSCBasicOneYearOrder(kdt,period);
        // 删除保护期的设置
        pfProtectionPeriodMapper.delete(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdt.toString()));

    }

    /**
     * 参数全为空
     */
    @Test
    public void modifyPeriodNoParamTest(){
        // 修改保护期为1-100的随机数
        Integer period = (int) (Math.random()*100)+1;
        ModifyProtectionPeriodRequest modifyProtectionPeriodRequest = new ModifyProtectionPeriodRequest();
        PlainResult<ModifyProtectionPeriodResponse> result = quotaRemoteService.modifyProtectionPeriod(modifyProtectionPeriodRequest);
        Assert.assertEquals(600, result.getCode());
        Assert.assertEquals("断言错误", result.getMessage());

    }

    /**
     * kdtId为空
     */
    @Test
    public void modifyPeriodNoKdtIdTest(){
        // 修改保护期为1-100的随机数
        Integer period = (int) (Math.random()*100)+1;
        ModifyProtectionPeriodRequest modifyProtectionPeriodRequest = new ModifyProtectionPeriodRequest();
        modifyProtectionPeriodRequest.setPeriod(period);
        PlainResult<ModifyProtectionPeriodResponse> result = quotaRemoteService.modifyProtectionPeriod(modifyProtectionPeriodRequest);
        Assert.assertEquals(600, result.getCode());
        Assert.assertEquals("断言错误", result.getMessage());

    }

    /**
     * period为空
     */
    @Test
    public void modifyPeriodNoPeriodTest(){
        // 修改保护期为1-100的随机数
        Integer period = (int) (Math.random()*100)+1;
        ModifyProtectionPeriodRequest modifyProtectionPeriodRequest = new ModifyProtectionPeriodRequest();
        modifyProtectionPeriodRequest.setKdtId(yunFeeWSCCheck.get(0));
        PlainResult<ModifyProtectionPeriodResponse> result = quotaRemoteService.modifyProtectionPeriod(modifyProtectionPeriodRequest);
        Assert.assertEquals(600, result.getCode());
        Assert.assertEquals("断言错误", result.getMessage());

    }

    /**
     * period为负值
     */
    @Test
    public void modifyPeriodNegativePeriodTest(){
        // 修改保护期为1-100的随机数
        Integer period = (int) (Math.random()*100)+1;
        ModifyProtectionPeriodRequest modifyProtectionPeriodRequest = new ModifyProtectionPeriodRequest();
        modifyProtectionPeriodRequest.setKdtId(yunFeeWSCCheck.get(0));
        modifyProtectionPeriodRequest.setPeriod(-period);
        PlainResult<ModifyProtectionPeriodResponse> result = quotaRemoteService.modifyProtectionPeriod(modifyProtectionPeriodRequest);
        Assert.assertEquals(600, result.getCode());
        Assert.assertEquals("保护期不能为负数", result.getMessage());
    }

    /**
     * pf_protection_period 表校验
     * @param kdtId
     * @param period
     */
    public void periodModifyDBCheck(Long kdtId,Integer period){
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfProtectionPeriodMapper.selectList(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdtId.toString())).size() == 1L);

        PfProtectionPeriodEntity pfProtectionPeriodEntity = pfProtectionPeriodMapper.selectOne(new QueryWrapper<PfProtectionPeriodEntity>().lambda().eq(PfProtectionPeriodEntity::getApplyYcmId,kdtId.toString()));

        Assert.assertEquals(kdtId.toString(), pfProtectionPeriodEntity.getApplyYcmId());
        Assert.assertEquals("KDT_ID", pfProtectionPeriodEntity.getApplyYcmType());
        Assert.assertEquals(period, pfProtectionPeriodEntity.getProtectionPeriod());
        log.info("修改保护期成功="+period);
    }

    /**
     * 线上购买-微商城1年基础班，10000额度，6800元：计费侧数据校验
     * @param kdt_id
     */
    public void feeResourceWSCBasicOneYearOrder(Long kdt_id,int periodDays) {
        //pf_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString())).size() >= 1L);

        PfFeeResourcePackageEntity pfFeeResourcePackageEntity = pfFeeResourcePackageMapper.selectOne(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdt_id.toString()));

        Assert.assertEquals(pfFeeResourcePackageEntity.getGrantQuota().toString(), "10000");
        Assert.assertEquals(pfFeeResourcePackageEntity.getState(), Integer.valueOf(1));
        Assert.assertEquals(pfFeeResourcePackageEntity.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");
        Assert.assertEquals(pfFeeResourcePackageEntity.getQuotaType(),Integer.valueOf(2));
        Assert.assertEquals(pfFeeResourcePackageEntity.getAppCategory(),"software_meal");

        // 计费侧表-fc_fee_resource_package表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString())).size() == 1L);

        FeeResourcePackageDO fc_fee_resource_package = feeResourcePackageMapper.selectOne(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdt_id.toString()));

        Assert.assertEquals(fc_fee_resource_package.getTotal(), "10000");
        Assert.assertEquals(fc_fee_resource_package.getState(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getResourceMode(),Integer.valueOf(1),"计费侧数据resource_mode=1失败");
        Assert.assertEquals(fc_fee_resource_package.getFeeType(), Integer.valueOf(1));
        Assert.assertEquals(fc_fee_resource_package.getEffectTime().toString(),"Thu Jan 01 00:00:00 CST 1970");


        // 计费侧表-fc_fee_yop_protocol表校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeYopProtocolMapper.selectOne(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString())).getState() == 1);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        FeeYopProtocolDTO feeYopProtocolDTO = feeYopProtocolMapper.selectOne(new QueryWrapper<FeeYopProtocolDTO>().eq("kdt_id", kdt_id.toString()));

        Assert.assertEquals(feeYopProtocolDTO.getQuota(), "10000");
        Assert.assertEquals(feeYopProtocolDTO.getState(), Integer.valueOf(1));
        Assert.assertEquals(feeYopProtocolDTO.getQuotaType(), Integer.valueOf(2));

        // 3各表的expire_time
        Date fee_resource_packageExpireTime = fc_fee_resource_package.getExpireTime();//
        Date fc_fee_yop_protocol = feeYopProtocolDTO.getExpireTime();//
        Date pf_fee_expire = pfFeeResourcePackageEntity.getExpireTime();//

        // fee_resource.expire_time = pf_fee.expire_time
        Assert.assertEquals(fee_resource_packageExpireTime, pf_fee_expire);

        // 保护期校验
        Long result23 = durationDays(fc_fee_yop_protocol,pf_fee_expire);

        Assert.assertEquals(result23, Long.valueOf(periodDays));

        logger.info("计费侧，购买微商城1年基础版本，校验成功");
    }

}
