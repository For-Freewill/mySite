package com.youzan.test.market.basecase.activity;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.request.activity.SaveOrderFullReduceActivityRequest;
import com.youzan.ycm.market.response.activity.SaveOrderFullReduceActivityResponse;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.ConfirmOrderForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @program: bit-commerce
 * @description 不同配置的满减活动的订购
 * @author: tianning
 * @create: 2021-01-18 19:06
 **/

public class FullReductionActivityTest extends TnBaseTest {

    @JSONData(value = "dataResource/apicase.market/FullReductionRequestData.json", key = "orderWithFullReductionRequest")
    private CreateOrderForm orderWithFullReductionRequest;

    @JSONData(value = "dataResource/apicase.market/FullReductionRequestData.json", key = "fullReductionWithSameAmountRequest")
    private SaveOrderFullReduceActivityRequest fullReductionWithSameAmountRequest;

    @JSONData(value = "dataResource/apicase.market/FullReductionRequestData.json", key = "fullReductionWithSameLadderWithDiffAmountRequest")
    private SaveOrderFullReduceActivityRequest fullReductionWithSameLadderWithDiffAmountRequest;

    @JSONData(value = "dataResource/apicase.market/confirmOrderRequestData.json", key = "confirmOrderForm")
    private ConfirmOrderForm confirmOrderForm;

    //用来做营销满减的订购的微商城的店铺
    //15558185311
    public static Long REDUCTIONKDTID = 58804142L;
    public static String REDUCTIONKDTIDNAME = "故障注入测试7";

    /**
     * biz后台创建满减活动，活动名称：营销满减CI田宁专用-勿动；
     * 配置同一阶梯，配置不同金额，验证不通过
     * 不会走到订购，配置的时候就拦截了
     */

    @BeforeMethod
    public void init() {
        try {
            sleep(1000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * biz后台创建满减活动，活动名称：营销满减CI田宁专用-勿动；
     * 同一阶梯，配置不同金额，验证可以正常配置活动
     */
    @Test
    public void createFullReductionActivityWithSameLadderWithDiffAmount() {
        try {
            PlainResult<SaveOrderFullReduceActivityResponse> saveOrderFullReduceActivityResult = orderFullReduceActivityRemoteService.saveActivity(fullReductionWithSameLadderWithDiffAmountRequest);

            Assert.assertEquals(saveOrderFullReduceActivityResult.getCode(), 315);
            Assert.assertEquals(saveOrderFullReduceActivityResult.getMessage(), "阶梯满减参数排列不合要求");
        } finally {
            invalidFullReductionActivity();
            deleteFullReductionActivity();
        }
    }

    /**
     * biz后台创建满减活动，活动名称：营销满减CI田宁专用-勿动；
     * 同一阶梯，配置相同金额，验证去重
     * 不会走到订购，配置的时候就拦截了
     */
    @Test
    public void createFullReductionActivityWithSameLadderWithRepeatAmount() {
        try {
            PlainResult<SaveOrderFullReduceActivityResponse> saveOrderFullReduceActivityResult = orderFullReduceActivityRemoteService.saveActivity(fullReductionWithSameAmountRequest);

            Assert.assertEquals(saveOrderFullReduceActivityResult.getCode(), 315);
            Assert.assertEquals(saveOrderFullReduceActivityResult.getMessage(), "阶梯满减参数重复或者不存在");
        } finally {
            invalidFullReductionActivity();
            deleteFullReductionActivity();
        }
    }

    /**
     * biz后台创建满减活动，活动名称：营销满减CI田宁专用-勿动；
     * 不同阶梯，配置不同金额
     */
    @Test
    public void createFullReductionActivityWithDiffLadderWithDiffAmount() {
        try {
            PlainResult<SaveOrderFullReduceActivityResponse> saveOrderFullReduceActivityResult = orderFullReduceActivityRemoteService.saveActivity(fullReductionWithDiffLadderWithDiffAmountRequest);

            Assert.assertEquals(saveOrderFullReduceActivityResult.getCode(), 200);
            Assert.assertEquals(saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getProductChannels().get(0), "WSC");

            Assert.assertNotNull(saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId());

            List<MkActivity> mkActivityLists =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().eq("name", fullReductionName).eq("state", "AUDITED_PASS").orderByDesc("created_at"));
            Assert.assertEquals(mkActivityLists.get(0).getId().toString(), saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId());
            Assert.assertEquals(mkActivityLists.get(0).getState(), "AUDITED_PASS");
        } finally {
            invalidFullReductionActivity();
            deleteFullReductionActivity();
        }
    }

    /**
     * biz后台创建满减活动，活动名称：营销满减CI田宁专用-勿动；
     * 不同阶梯，配置不同金额，包含指定某一个商品，验证金额命中顺序
     * 1、配置满减活动
     * 2、订购电商（2021）基础版（百度小程序）
     */
    @Test
    public void createOrderWithFullReductionTest() {
        try {
            List<PreferentialDescApi> orderPromotionList = new ArrayList<>();
            PreferentialDescApi preferentialDescApi = new PreferentialDescApi();
            preferentialDescApi.setReduceAmount(ItemInfo.WSC_WX_680000_2021.getMoney().longValue());
            preferentialDescApi.setSelected(true);
            preferentialDescApi.setDesc("营销阶梯满减4000-40CI田宁专用-勿动");
            preferentialDescApi.setName("营销阶梯满减4000-40CI田宁专用-勿动");
            preferentialDescApi.setType((byte) 21);
            PlainResult<SaveOrderFullReduceActivityResponse> reduceActivityResponseResult = createFullReductionActivity();
            preferentialDescApi.setPromotionId(Long.valueOf(reduceActivityResponseResult.getData().getFullReduceActivityDTO().getActivityId()));

            orderPromotionList.add(preferentialDescApi);
            orderWithFullReductionRequest.setOrderPromotionList(orderPromotionList);

            PlainResult<String> createNormalOrderResult = createNormalOrder(orderWithFullReductionRequest, REDUCTIONKDTID);
            Assert.assertEquals(createNormalOrderResult.getCode(), 200);
        } finally {
            invalidFullReductionActivity();
            deleteFullReductionActivity();
        }
    }
}
