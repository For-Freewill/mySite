package com.youzan.test.basecase.valueAmortize;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfAsset;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.entity.order.CalOrderPriceApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.response.ItemPreferentialInfoResultApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author wuwu
 * @date 2021/1/18 8:00 PM
 */
public class TryGiftValueAmortizeTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(TryGiftValueAmortizeTest.class);
    public Long tryShopKdtId = 73741083L;
    public String tryShopKdtName = "CI-接口自动化-试用期礼包测试";
    public Long basicTryGiftPromotion = 47842L;
    public Long proTryGiftPromotion = 47849L;
    public Long ultTryGiftPromotion = 47850L;
    public int professionItemId = 76357;
    public int ultimateItemId_2022 = 76358;
    List<? extends Number> tryPromtionList = Arrays.asList(basicTryGiftPromotion, proTryGiftPromotion, ultTryGiftPromotion);


    @Test
    public void tryGiftValueAmortizeForProWscTest() {
        //将店铺改成试用期店铺
        setShopTryTime(tryShopKdtId);

        //初始化店铺及充钱
        initShopByKdtId(tryShopKdtId);
        rechargeYzcoin(tryShopKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(tryShopKdtId), cny + 1000);

        //验证商品选择页面有试用期礼包显示
        PlainResult<List<ItemPreferentialInfoResultApi>> preferentialInfoResult =
                fetchItemPreferentialInfoOnline(tryShopKdtId, 1, professionItemId, 1, 1);
        logger.info("商品优惠信息：{}", JSON.toJSONString(preferentialInfoResult));
        Boolean present = preferentialInfoResult.getData().get(0).getPresentList().stream().
                filter(v -> v.getPromotionId().equals(proTryGiftPromotion)).findAny().isPresent();
        Assert.assertEquals(present, Boolean.TRUE, "商品选择页面没有展示试用期礼包");

        //验证订单计算页面有试用期礼包
        PlainResult<CalOrderPriceApi> calOrderPriceResult =
                calOrderPrice(tryShopKdtId, tryShopKdtName, professionItemId, 1);
        logger.info("订单计算优惠信息：{}", JSON.toJSONString(calOrderPriceResult));
        Boolean orderPresent = calOrderPriceResult.getData().getItems().get(0).getItemPromotionList().stream().
                filter(v -> v.getPromotionId().equals(proTryGiftPromotion)).findAny().isPresent();
        Assert.assertEquals(orderPresent, Boolean.TRUE, "订单确认页没有展示试用期礼包");

        //验证创建订单后生成试用期礼包，试用期礼包不参与摊销

        //创建一笔订单（基础版）
        PlainResult<String> orderCreateResult = createNormalOrderWithMultiApp(tryShopKdtId, tryShopKdtName, Arrays.asList(professionItemId, fuwuPackageItemId), 1, yzb);
        logger.info("创建订单结果：{}", JSON.toJSONString(orderCreateResult));

        //td_order
        Long tdOrderId = Long.valueOf(orderCreateResult.getData());

        waitForPfAssetData(tdOrderId);

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", tdOrderId));

        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
                .eq("biz_order_id",tdOrder.getTdNo())
                .eq("biz_order_type","trade_order")
                .eq("app_id","combine_spu_wsc"));


        List<PfAsset> pfAssetOrderList = pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo())
                .eq("app_id", "combine_spu_wsc"));

        Boolean isTryGiftType = pfAssetOrderList.stream().filter(v -> v.getSourceType().equals("try_gift")).findAny().isPresent();
        //校验试用期礼包类型
        Assert.assertEquals(isTryGiftType, Boolean.TRUE, "创建订单时没有生成试用期礼包");

        //校验试用期礼包不参与摊销，pf_asset里的微商城实付 = pf_order的实付
        Long pfAssetCnyAmount = 0L;

        for (PfAsset pfAsset:pfAssetOrderList) {
            if(pfAsset.getItemId().equals("combine_sku_wsc_2022_profession_year")) {
                pfAssetCnyAmount = pfAsset.getCnyAmt();
                break;
            }
        }
        Long pfOrderRealPrice = pfOrder.getRealPrice();

        logger.info("pforder的实付：{},pfasset的实付：{}",pfOrderRealPrice,pfAssetCnyAmount);
        Assert.assertEquals(pfOrder.getRealPrice(),pfAssetCnyAmount,"礼包参与摊销啦！！！！");


    }


    @Test
    public void tryGiftValueAmortizeForBasicWscTest() {
        //将店铺改成试用期店铺
        setShopTryTime(tryShopKdtId);

        //初始化店铺及充钱
        initShopByKdtId(tryShopKdtId);
        rechargeYzcoin(tryShopKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(tryShopKdtId), cny + 1000);
        int basicWechatItemId = 76354;

        //验证商品选择页面有试用期礼包显示
        PlainResult<List<ItemPreferentialInfoResultApi>> preferentialInfoResult =
                fetchItemPreferentialInfoOnline(tryShopKdtId, 1, basicWechatItemId, 1, 1);
        logger.info("商品优惠信息：{}", JSON.toJSONString(preferentialInfoResult));
        Boolean present = preferentialInfoResult.getData().get(0).getPresentList().stream().
                filter(v -> v.getPromotionId().equals(basicTryGiftPromotion)).findAny().isPresent();
        Assert.assertEquals(present, Boolean.TRUE,"商品选择页面没有展示试用期礼包");

        //验证订单计算页面有试用期礼包
        PlainResult<CalOrderPriceApi> calOrderPriceResult =
                calOrderPrice(tryShopKdtId, tryShopKdtName, basicWechatItemId, 1);
        logger.info("订单计算优惠信息：{}", JSON.toJSONString(calOrderPriceResult));
        Boolean orderPresent = calOrderPriceResult.getData().getItems().get(0).getItemPromotionList().stream().
                filter(v -> v.getPromotionId().equals(basicTryGiftPromotion)).findAny().isPresent();
        Assert.assertEquals(orderPresent, Boolean.TRUE,"订单确认页没有展示试用期礼包");

        //验证创建订单后生成试用期礼包，试用期礼包不参与摊销

        //创建一笔订单（基础版）
        PlainResult<String> orderCreateResult = createNormalOrder(tryShopKdtId, tryShopKdtName, basicWechatItemId, 1, yzb);
        logger.info("创建订单结果：{}", JSON.toJSONString(orderCreateResult));

        //td_order
        Long tdOrderId = Long.valueOf(orderCreateResult.getData());

        waitForPfAssetData(tdOrderId);

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", tdOrderId));

        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
                .eq("biz_order_id",tdOrder.getTdNo())
                .eq("biz_order_type","trade_order")
                .eq("app_id","combine_spu_wsc"));

        List<PfAsset> pfAssetOrderList = pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo())
                .eq("app_id", "combine_spu_wsc"));

        Boolean isTryGiftType = pfAssetOrderList.stream().filter(v -> v.getSourceType().equals("try_gift")).findAny().isPresent();
        //校验试用期礼包类型
        Assert.assertEquals(isTryGiftType, Boolean.TRUE,"创建订单时没有生成试用期礼包");

        //校验试用期礼包不参与摊销，pf_asset里的微商城实付 = pf_order的实付
        Long pfAssetCnyAmount = 0L;

        for (PfAsset pfAsset:pfAssetOrderList) {
            if(pfAsset.getItemId().equals("combine_sku_wsc_2022_basic_wechat_year")) {
                pfAssetCnyAmount = pfAsset.getCnyAmt();
                break;
            }
        }
        Assert.assertEquals(pfOrder.getRealPrice(),pfAssetCnyAmount,"礼包参与摊销啦！！！！");


    }

    @Test
    public void tryGiftValueAmortizeForUltWscTest() {
        //将店铺改成试用期店铺
        setShopTryTime(tryShopKdtId);

        //初始化店铺及充钱
        initShopByKdtId(tryShopKdtId);
        rechargeYzcoin(tryShopKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(tryShopKdtId), cny + 1000);

        //验证商品选择页面有试用期礼包显示
        PlainResult<List<ItemPreferentialInfoResultApi>> preferentialInfoResult =
                fetchItemPreferentialInfoOnline(tryShopKdtId, 1, ultimateItemId_2022, 1, 1);
        logger.info("商品优惠信息：{}", JSON.toJSONString(preferentialInfoResult));
        Boolean present = preferentialInfoResult.getData().get(0).getPresentList().stream().
                filter(v -> v.getPromotionId().equals(ultTryGiftPromotion)).findAny().isPresent();
        Assert.assertEquals(present, Boolean.TRUE,"商品选择页面没有展示试用期礼包");

        //验证订单计算页面有试用期礼包
        PlainResult<CalOrderPriceApi> calOrderPriceResult =
                calOrderPrice(tryShopKdtId, tryShopKdtName, ultimateItemId_2022, 1);
        logger.info("订单计算优惠信息：{}", JSON.toJSONString(calOrderPriceResult));
        Boolean orderPresent = calOrderPriceResult.getData().getItems().get(0).getItemPromotionList().stream().
                filter(v -> v.getPromotionId().equals(ultTryGiftPromotion)).findAny().isPresent();
        Assert.assertEquals(orderPresent, Boolean.TRUE,"订单确认页没有展示试用期礼包");

        //验证创建订单后生成试用期礼包，试用期礼包不参与摊销

        //创建一笔订单（旗舰版）
        PlainResult<String> orderCreateResult = createNormalOrderWithMultiApp(tryShopKdtId, tryShopKdtName, Arrays.asList(ultimateItemId_2022, fuwuPackageItemId), 1, yzb);
        logger.info("创建订单结果：{}", JSON.toJSONString(orderCreateResult));

        //td_order
        Long tdOrderId = Long.valueOf(orderCreateResult.getData());

        waitForPfAssetData(tdOrderId);

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", tdOrderId));

        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
                .eq("biz_order_id",tdOrder.getTdNo())
                .eq("biz_order_type","trade_order")
                .eq("app_id","combine_spu_wsc"));

        List<PfAsset> pfAssetOrderList = pfAssetMapper.selectList(new QueryWrapper<PfAsset>().eq("out_biz_no", tdOrder.getTdNo())
                .eq("app_id", "combine_spu_wsc"));

        //判断是否包含了试用期礼包，是返回true，否返回false
        Boolean isTryGiftType = pfAssetOrderList.stream().filter(v -> v.getSourceType().equals("try_gift")).findAny().isPresent();
        //校验试用期礼包类型
        Assert.assertEquals(isTryGiftType, Boolean.TRUE,"创建订单时没有生成试用期礼包");

        //校验试用期礼包不参与摊销，pf_asset里的微商城实付 = pf_order的实付
        Long pfAssetCnyAmount = 0L;

        for (PfAsset pfAsset:pfAssetOrderList) {
            if(pfAsset.getItemId().equals("combine_sku_wsc_2022_ultimate_year")) {
                pfAssetCnyAmount = pfAsset.getCnyAmt();
                break;
            }
        }
        Assert.assertEquals(pfOrder.getRealPrice(),pfAssetCnyAmount,"礼包参与摊销啦！！！！");


    }

    @Override
    public PlainResult<String> createNormalOrderWithMultiApp(Long kdtId, String kdtName, List<Integer> itemList, int quantity, Long yzb) {
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        List<PreferentialDescApi> orderPromotionList = new ArrayList<>();


        for(int i = 0;i <itemList.size();i++) {
            //构造item参数
            OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(Integer.valueOf(itemList.get(i)), quantity);
            //获取商品的优惠
            PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(kdtId,1,Integer.valueOf(itemList.get(i)),quantity,1);

            logger.info("优惠信息：{}",JSON.toJSONString(itemPreferentialInfoResult));
            List<PreferentialDescApi> itemPromotionList = new ArrayList<>();
            //将获取到的商品级优惠传入参数
            if(itemPreferentialInfoResult.getData().size()>0) {
                //做非null判断
                if(itemPreferentialInfoResult.getData().get(0).getPresentList() != null) {
                    itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPresentList());
                }
                if(itemPreferentialInfoResult.getData().get(0).getPromotionList() != null) {
                    itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPromotionList());
                }

                itemPromotionList = itemPromotionList.stream().filter(v -> tryPromtionList.contains(v.getPromotionId())).collect(Collectors.toList());
                //将商品级优惠放入orderItemFormList
                orderItemForm.setItemPromotionList(itemPromotionList);
            }
            orderItemFormList.add(orderItemForm);

        }

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");
        logger.info("创建订单参数：{}",JSON.toJSONString(createOrderForm));

        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);

        return resultCreateNormalOrder;
    }


    @Override
    public PlainResult<String> createNormalOrder(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        //获取商品的优惠
        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(kdtId,1,itemId,quantity,1);

        logger.info("优惠信息：{}",itemPreferentialInfoResult);
        //将获取到的商品级优惠传入参数
        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();
        if(itemPreferentialInfoResult.getData().size()>0) {
            //做非null判断
            if(itemPreferentialInfoResult.getData().get(0).getPresentList() != null) {
                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPresentList());
            }
            if(itemPreferentialInfoResult.getData().get(0).getPromotionList() != null) {
                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPromotionList());
            }
            //如果创建订单的时候使用了有赞币，则续费送有赞币的优惠要排除
            if(yzb>0){
                itemPromotionList = itemPromotionList.stream().filter(v -> v.getType()!=6).collect(Collectors.toList());
            }
            //将商品级优惠放入orderItemFormList
            orderItemForm.setItemPromotionList(itemPromotionList);
        }

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);

        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        logger.info("创建订单参数：{}",JSON.toJSONString(createOrderForm));
        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);
        logger.info("创建订单结果：{}",JSON.toJSONString(resultCreateNormalOrder));

        return resultCreateNormalOrder;
    }


}
