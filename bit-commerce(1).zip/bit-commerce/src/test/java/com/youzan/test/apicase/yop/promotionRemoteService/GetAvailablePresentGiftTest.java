package com.youzan.test.apicase.yop.promotionRemoteService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.request.GetAvailablePresentGiftRequest;
import com.youzan.yop.api.response.GetAvailablePresentGiftResponse;
import org.apache.commons.collections.CollectionUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @author tianning
 * @date 2020/11/05 3:59 下午
 * 获取可以补发的礼包列表（包括买赠礼包以及买赠券）
 * 目前该接口只用于CRM侧补发礼包的业务场景
 * TODO 想找一条返回不为null的数据
 */

public class GetAvailablePresentGiftTest extends TnBaseTest {

    @Dubbo
    public PromotionRemoteService promotionRemoteService;

    /**
     * 正常场景
     */
    @Test
    public void getAvailablePresentGiftNormalTest() {
        GetAvailablePresentGiftRequest request = new GetAvailablePresentGiftRequest();
        List<TdOrder> tdOrderList = queryTdOrderByKdtIdAndState(GIFTKDTID1);

        String td_no = tdOrderList.get(0).getTdNo();
        List<PfOrder> pfOrdferRecords =
                pfOrderMapper.selectList(
                        new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBizOrderId, td_no).eq(PfOrder::getAppCategory, "software_meal").orderByDesc(PfOrder::getCreatedAt));

        request.setOrderId(pfOrdferRecords.get(0).getId().toString());

        PlainResult<GetAvailablePresentGiftResponse> getAvailablePresentGiftResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<GetAvailablePresentGiftResponse>>() {

                    @Override
                    public PlainResult<GetAvailablePresentGiftResponse> doExecute() {
                        return promotionRemoteService.getAvailablePresentGift(request);
                    }

                    @Override
                    public boolean handleResult(PlainResult<GetAvailablePresentGiftResponse> getAvailablePresentGiftResult) {
                        return getAvailablePresentGiftResult.getCode() == 200;
                    }
                }, 5, 100);
        Assert.assertEquals(getAvailablePresentGiftResult.getCode(), 200);
        Assert.assertTrue(CollectionUtils.isEmpty(getAvailablePresentGiftResult.getData().getAvailableGiftTemplateList()));
    }

    /**
     * 异常场景 orderId不存在
     */
    @Test
    public void getAvailablePresentGiftOrderIdNotExitTest() {
        GetAvailablePresentGiftRequest request = new GetAvailablePresentGiftRequest();
        request.setOrderId("6636914453880243200");
        PlainResult<GetAvailablePresentGiftResponse> getAvailablePresentGiftResult = promotionRemoteService.getAvailablePresentGift(request);
        Assert.assertEquals(getAvailablePresentGiftResult.getCode(), 1007);
        Assert.assertEquals(getAvailablePresentGiftResult.getMessage(), "不存在的订单");
    }

    /**
     * 异常场景 orderId为null
     */
    @Test
    public void getAvailablePresentGiftOrderIdNullTest() {
        GetAvailablePresentGiftRequest request = new GetAvailablePresentGiftRequest();
        request.setOrderId(null);
        PlainResult<GetAvailablePresentGiftResponse> getAvailablePresentGiftResult = promotionRemoteService.getAvailablePresentGift(request);
        Assert.assertEquals(getAvailablePresentGiftResult.getCode(), 130102);
        Assert.assertEquals(getAvailablePresentGiftResult.getMessage(), "参数非法");
    }

    /**
     * 异常场景 入参为null
     */
    @Test
    public void getAvailablePresentGiftParamNullTest() {
        PlainResult<GetAvailablePresentGiftResponse> getAvailablePresentGiftResult = promotionRemoteService.getAvailablePresentGift(null);
        Assert.assertEquals(getAvailablePresentGiftResult.getCode(), 130102);
        Assert.assertEquals(getAvailablePresentGiftResult.getMessage(), "参数非法");
    }
}

