package com.youzan.test.basecase.yunServiceFee.baseCase;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * @author wulei
 * @date 2020-10-19
 */
public class queryAdvanceQuotaTest extends YunBaseTest {

    public static String yunKdtName17 = "zidonghua200821";

    @Test // 下单2年WSC-基础版-可以预支
    public void testTwoYearCanAdvance() {
        Long kdtId = newWscKdtId();
        // 下单2年基础版本
        PlainResult<OrderCreateApi> result = testCreateOrder(kdtId, yunKdtName17, wscWXItemId_2021, 2);
        // 预期：可以预支
        testCanAdvanceOrderQuota(kdtId.toString(), Boolean.TRUE);
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 退款
        refundOrderNew(result.getData().getPayOrderId(), new Date(), 0L, 0L, "BY_MANUAL");
    }

    @Test // 买1续1，可以预支
    public void testOneMoreYearCanAdvance() {
        Long kdtId = newWscKdtId();
        // 下单1年基础版本
        PlainResult<OrderCreateApi> result = testCreateOrder(kdtId, yunKdtName17, wscWXItemId_2021, 1);
        // 预期：不能预支
        testCanAdvanceOrderQuota(String.valueOf(kdtId), Boolean.FALSE);
        // 续费1年基础版本
        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdtId, yunKdtName17, wscWXItemId_2021, 1);
        // 预期可以预支
        testCanAdvanceOrderQuota(String.valueOf(kdtId), Boolean.TRUE);
        // 退款下单1年的版本
        refundOrderNew(result.getData().getPayOrderId(), new Date(), 0L, 0L, "BY_MANUAL");
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 退款续费1年的版本
        refundOrderNew(result2.getData().getPayOrderId(), new Date(), 0L, 0L, "BY_MANUAL");
    }
}
