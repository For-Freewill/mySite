package com.youzan.test.basecase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.constant.refund.RefundModeConstants;
import com.youzan.commerce.test.constant.refund.RefundWayConstants;
import com.youzan.commerce.test.entity.dataobject.goods.GdGoodsIdMapping;
import com.youzan.commerce.test.entity.dataobject.market.MkPresent;
import com.youzan.commerce.test.entity.dataobject.market.MkPresentGift;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.commerce.test.entity.dataobject.market.coupon.*;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplateGoods;
import com.youzan.commerce.test.entity.dataobject.perform.PfAsset;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.shop.ShopProdRelation;
import com.youzan.commerce.test.entity.dataobject.shop.ShopProdVersionRelation;
import com.youzan.commerce.test.entity.dataobject.sms.SmsStockDetailEntity;
import com.youzan.commerce.test.entity.dataobject.sms.SmsStockEntity;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdPayOrder;
import com.youzan.commerce.test.kv.KvdsConstants;
import com.youzan.commerce.test.mapper.goods.GdGoodsIdMappingMapper;
import com.youzan.commerce.test.mapper.market.MkPresentGiftMapper;
import com.youzan.commerce.test.mapper.market.MkPresentMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityRuleMapper;
import com.youzan.commerce.test.mapper.market.coupon.*;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateMapper;
import com.youzan.commerce.test.mapper.perform.PfAssetMapper;
import com.youzan.commerce.test.mapper.perform.PfOrderMapper;
import com.youzan.commerce.test.mapper.perform.PfOrderStatusMapper;
import com.youzan.commerce.test.mapper.shop.ShopProdRelationMapper;
import com.youzan.commerce.test.mapper.shop.ShopProdVersionRelationMapper;
import com.youzan.commerce.test.mapper.sms.SmsStockDetailMapper;
import com.youzan.commerce.test.mapper.sms.SmsStockMapper;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.commerce.test.mapper.trade.TdPayOrderMapper;
import com.youzan.framework.redis.RedisClient;
import com.youzan.pay.acctrans.api.account.AccountService;
import com.youzan.pay.acctrans.api.account.dto.AccountDataDTO;
import com.youzan.pay.acctrans.api.acctrans.AcctransRechargeService;
import com.youzan.pay.acctrans.api.acctrans.AcctransTransferService;
import com.youzan.pay.acctrans.api.acctrans.dto.AcctransAccountingDTO;
import com.youzan.pay.acctrans.api.acctrans.request.AcctransRechargeRequest;
import com.youzan.pay.acctrans.api.acctrans.request.AcctransTransferRequest;
import com.youzan.pay.acctrans.common.model.enums.AccountType;
import com.youzan.pay.acctrans.common.model.enums.SubTransCodeEnum;
import com.youzan.pay.acctrans.common.model.enums.TransCodeEnum;
import com.youzan.pay.acctrans.common.model.model.AccountInfo;
import com.youzan.pay.core.api.model.response.DataResult;
import com.youzan.pay.core.common.model.enums.CurrencyCode;
import com.youzan.pay.core.common.model.enums.bizcode.ChannelType;
import com.youzan.pay.core.exception.BusinessException;
import com.youzan.pay.core.utils.KeyUtils;
import com.youzan.pay.customer.api.ops.UserInfoService;
import com.youzan.platform.push.api.stock.MsgSmsStockService;
import com.youzan.platform.push.api.stock.dto.StockDecResultDTO;
import com.youzan.platform.push.api.stock.dto.StockDecreaseDTO;
import com.youzan.shopcenter.shopconfig.api.dto.request.OperatorDTO;
import com.youzan.shopcenter.shopconfig.api.dto.request.ShopConfigSetRequest;
import com.youzan.shopcenter.shopconfig.api.service.ShopConfigWriteService;
import com.youzan.shopcenter.shopprod.api.service.lifecycle.LifecycleWriteService;
import com.youzan.shopcenter.shopprod.api.service.prod.ProdReadService;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.compare.service.CompareServiceImp;
import com.youzan.test.quickstart.utils.HttpUtil;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.ycm.gift.api.GiftAssetRemoteService;
import com.youzan.ycm.gift.api.GiftTemplateRemoteService;
import com.youzan.ycm.market.api.*;
import com.youzan.ycm.perform.api.PfAppStatusRemoteService;
import com.youzan.ycm.perform.request.status.FlushAppStatusRequest;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.ShopOperateRemoteService;
import com.youzan.yop.api.entity.EnablePromotionParam;
import com.youzan.yop.api.entity.ModifyRetail2WscApi;
import com.youzan.yop.api.entity.OpenAppPackagePreferentialApi;
import com.youzan.yop.api.entity.order.CalOrderPriceApi;
import com.youzan.yop.api.entity.order.OrderConfirmApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.entity.promotion.ycm.AppPromotionMutexApi;
import com.youzan.yop.api.entity.promotion.ycm.OrderPromotionMutexApi;
import com.youzan.yop.api.form.order.*;
import com.youzan.yop.api.form.shopMark.ModifyRetail2WscForm;
import com.youzan.yop.api.request.RefundCalculateNonConsumeRequest;
import com.youzan.yop.api.request.RefundNonConsumeRequest;
import com.youzan.yop.yzcoin.api.YzCoinService;
import com.youzan.yop.yzcoin.api.dto.YzCoinGrantDTO;
import com.youzan.yop.yzcoin.api.param.YzCoinGrantOrRecycleParam;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.collections.Lists;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.assertj.core.util.DateUtil.now;
import static org.awaitility.Awaitility.with;
import static org.awaitility.Duration.ONE_HUNDRED_MILLISECONDS;

/**
 * Created by wuwu on 2020/8/18
 **/
public class DeductBaseTest extends BaseTest {

    final static public Logger logger = LoggerFactory.getLogger(DeductBaseTest.class);
    public static final Pattern patternAtom = Pattern.compile("^atom");
    public static final Pattern patternCombine = Pattern.compile("^combine");
    public static final List<Long> softWareAppId = Arrays.asList(873L,6075L,6281L,39748L);

    @Dubbo
    public MarketRemoteService marketRemoteService;
    @Dubbo
    public AcctransRechargeService acctransRechargeService;
    @Dubbo
    public UserInfoService userInfoService;
    @Dubbo
    public AccountService accountService;
    @Dubbo
    public AcctransTransferService acctransTransferService;
    @Dubbo
    public YzCoinService yzCoinService;
    @Dubbo
    public com.youzan.yop.yzcoin.api.AccountService yopAccountService;
    @Dubbo
    public PfAppStatusRemoteService pfAppStatusRemoteService;
    @Dubbo
    public ShopOperateRemoteService shopOperateRemoteService;
    @Dubbo
    public CouponSendRemoteService couponSendRemoteService;
    @Dubbo
    public CouponAssetRemoteService couponAssetRemoteService;
    @Dubbo
    public AppStatusRemoteService appStatusRemoteService;
    @Dubbo
    public ShopConfigWriteService shopConfigWriteService;
    @Dubbo
    public PromotionRemoteService promotionRemoteService;
    @Dubbo
    public MsgSmsStockService msgSmsStockService;
    @Resource
    private RedisClient redisClient;
    @Dubbo
    public LifecycleWriteService lifecycleWriteService;
    @Dubbo
    public ProdReadService prodReadService;
    @Dubbo
    public CouponRemoteService couponRemoteService;
    @Dubbo
    public PresentRemoteService presentRemoteService;
    @Dubbo
    public GiftAssetRemoteService giftAssetRemoteService;
    @Dubbo
    public ActivityJoinQualificationRemoteService activityJoinQualificationRemoteService;
    @Dubbo
    public GiftTemplateRemoteService giftTemplateRemoteService;
    @Dubbo
    public ActivityJoinCountRemoteService activityJoinCountRemoteService;

    @Autowired(required = false)
    public CompareServiceImp compareServiceImp;

    @Http("trade")
    HttpUtil tradeHttp;

    @Autowired(required = false)
    public GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @Autowired(required = false)
    public TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    public PfAssetMapper pfAssetMapper;
    @Autowired(required = false)
    public PfOrderStatusMapper pfOrderStatusMapper;
    @Autowired(required = false)
    public PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    public ActivityMapper activityMapper;
    @Autowired(required = false)
    public CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    public CouponMapper couponMapper;
    @Autowired(required = false)
    public CouponRuleMapper couponRuleMapper;
    @Autowired(required = false)
    public CouponSnapshotMapper couponSnapshotMapper;
    @Autowired(required = false)
    public CouponSendRecordMapper couponSendRecordMapper;
    @Autowired(required = false)
    public CouponSendRecordDetailMapper couponSendRecordDetailMapper;
    @Autowired(required = false)
    public ShopProdRelationMapper shopProdRelationMapper;
    @Autowired(required = false)
    public ShopProdVersionRelationMapper shopProdVersionRelationMapper;
    @Autowired(required = false)
    public TdPayOrderMapper tdPayOrderMapper;
    @Autowired(required = false)
    public ActivityRuleMapper activityRuleMapper;
    @Autowired(required = false)
    public MkPresentGiftMapper mkPresentGiftMapper;
    @Autowired(required = false)
    SmsStockDetailMapper smsStockDetailMapper;
    @Autowired(required = false)
    SmsStockMapper smsStockMapper;
    @Autowired(required = false)
    GfTemplateMapper gfTemplateMapper;

    @Autowired(required = false)
    MkPresentMapper mkPresentMapper;

    @Autowired(required = false)
    GfTemplateGoodsMapper gfTemplateGoodsMapper;


    public Long wscKdtId = 59713305L;
    public String account = "1850755659127553L069";
    public String wscKdtName = "CI-接口自动化-摊销/抵扣测试10";
    public Long chargeYzb = 300000L;
    public Long yzb = 10000L;
    public int cny = 300000;
    public int basicWechatItemId = 8530;
    public int professionItemId = 8532;
    public int promoteAnalysisItemId_500 =7009;
    public int msgchargeItemId_6000 = 614;
    public int ultimate = 8533;
    public Long deductedAppId = 873L;
    public Long wscBasicWechatGift =8648L;

    //微商城2021 itemId
    public int basicWechatItemId_2021 = 8530;
    public int basicBaiduItemId_2021 = 8531;
    public int professionItemId_2021 = 8532;
    public int ultimateItemId_2021 = 8533;
    public int fuwuPackageItemId = 73454;
    public int retailPackageItemId = 73455;
    public int staffItemId = 7166;
    public int lsProItemId = 8274;
    public int lsfuwuPackageItemId = 73455;
    public int yunPosItemId = 7179;

    public String wscYcmItemId = "atom_sku_wsc_year";

    //微商城升级到零售
    //public Long wscToRetailKdtId = 58110621L;
    public Long wscToRetailKdtId = 59337352L;
    //public String wscToRetailKdtName = "Ci-接口自动化测试店铺-升级产品线";
    public String wscToRetailKdtName = "CI-接口自动化-微商城升级零售2";

    public Long basicRetailAppId = 6075L;
    public int retailBasicWechatItem = 8271;
    public int retailProfessionItem = 8274;

    //教育相关

    public Long eduAppId = 39748L;
    public int eduBasicItem2021 = 74217;
    public int wscExtAppId = 7251;





    //微商城店铺-不参加营销活动
    public Long wscNoPromtionKdtId = 59506173L;
    public String wscNoPromtionKdtName = "CI-接口自动化测试店铺-无营销";

    //券相关店铺
    public Long wscMarketKdtId = 58719461L;
    public String wscMarketKdtName = "CI-接口自动化测试店铺-3";


    //退款相关店铺
    public Long wscRefundKdtId2 = 58719547L;
    public String wscRefundKdtName2 = "CI-接口自动化-退款";

    public Long wscRefundKdtId = 59129861L;
    public String wscRefundKdtName = "CI-接口自动化-退款3";

    public Long consumeRefundKdtId = 59449376L;
    public String consumeRefundKdtName = "CI-接口自动化-库存型商品4";

    //无服务期店铺
    public Long wscNoStatusKdtId = 58816677L;
    public String wscNoStatusKdtName = "CI-接口自动化-无服务期店铺";



    //微商城店铺-创建订单接口
    public Long wscCreateOrderKdtId = 58520234L;
    public String wscCreateOrderKdtName = "CI-接口自动化-createNormalOrder";

    //零售连锁店铺
    public Long lslsKdtId = 59503013L;
    public String lslsKdtName = "CI-接口自动化-零售连锁2";

    //批量退款专用
    public Long batchRefundKdtId = 59802581L;
    public String batchRefundKdtName = "CI-接口自动化测试-批量退款专用1";

    //全新店铺（服务包专用）
    public Long wscNoBuyKdtId = 58802982L;
    public String wscNoBuyKdtName = "CI-接口自动化-全新店铺（服务包专用）";

    //服务包下单校验专用
    public Long wscAndPackageKdtId = 58802888L;
    public String wscAndPackageKdtName = "CI-接口自动化-服务包下单校验";

    //服务包下单校验专用
    public Long wscHasAllPromotionKdtId = 58811472L;
    public String wscHasAllPromotionKdtName = "CI-接口自动化-带所有营销创建订单";

    //支付专用
    public Long payKdtId = 59318884L;
    public String payKdtName = "CI-接口自动化-支付测试";


    //摊销专用
    public Long amortizeKdtId = 60129288L;
    public String amortizeKdtName = "CI-接口自动化-摊销测试2";

    //摊销专用
    public Long baseRefundKdtId = 59323843L;
    public String baseRefundKdtName = "CI-接口自动化-base退款";

    //礼包折算专用
    public Long giftConvertKdtId = 59506304L;
    public String giftConvertKdtName = "CI-接口自动化-礼包折算3";

    //订单方案查询店铺
    public Long SHEME_KDT_ID = 58812932L;
    public String SHEME_KDT_NAME = "CI-接口自动化-订单方案查询";


    //周期型退款金额计算
    public Long refundMoneyCalKdtId = 59504886L;
    public String refundMoneyCalKdtName = "CI-接口自动化-退款金额计算";

    //库存型退款金额计算
    public Long consumeRefundMoneyCalKdtId = 59740027L;
    public String consumeRefundMoneyCalKdtName = "CI-接口自动化-库存型退款金额计算";

    //抵扣升级订单退款金额校验
//    public Long deductionRefundKdtId = 59911748L;
//    public String deductionRefundKdtName = "CI-接口自动化-抵扣升级订单退款";

    /**
     * 账务转账接口入参转换
     *
     * @param payerUserNo
     * @param payeeUserNo
     * @param payerAcctType
     * @param payeeAcctType
     * @param transCode
     * @param subTransCode
     * @param channelCode
     * @param amount
     * @return
     */
    public static AcctransTransferRequest genAcctransTransferRequest(String payerUserNo, String payeeUserNo,
                                                                     Integer payerAcctType, Integer payeeAcctType, String transCode, String subTransCode,
                                                                     String channelCode, Long amount) {

        AcctransTransferRequest request = new AcctransTransferRequest();

        //随机生成一个唯一id 作为请求ID
        String bizUniqueId = String.valueOf(KeyUtils.generateWaterNumber());

        AccountInfo payerAccountInfo = new AccountInfo();
        payerAccountInfo.setAccountType(payerAcctType);
        payerAccountInfo.setUserNo(payerUserNo);
        request.setPayerAccountInfo(payerAccountInfo);

        AccountInfo payeeAccountInfo = new AccountInfo();
        payeeAccountInfo.setAccountType(payeeAcctType);
        payeeAccountInfo.setUserNo(payeeUserNo);
        request.setPayeeAccountInfo(payeeAccountInfo);

        request.setChannelCode(channelCode);
        request.setTransCode(transCode);
        request.setSubTransCode(subTransCode);
        request.setAmount(amount);
        request.setClientId(bizUniqueId);
        request.setAcquireNo("A" + bizUniqueId);
        request.setOrderNo("E" + bizUniqueId);

        request.setAppName("ci-test");
        request.setCurrencyCode("156");
        request.setOperator("233333");
        request.setParternerBizType("304001");
        request.setParternerId("810005448700");
        request.setRemark("余额置为0工具-转账");
        request.setRequestTime(DateFormatUtils.format(new Date(), "yyyyMMdd"));

        return request;
    }

    /**
     * 店铺余额充值，单位（元）
     *
     * @param kdtId
     * @param money
     */

    public void rechargeShopBalance(String kdtId, int money) {
        String userNo = kdtId;
        money = money * 100;
        int inputType = 0;
        //根据kdtId 获取userNo
        PlainResult<String> result = new PlainResult<>();
        try {
            result = userInfoService.queryUserNoByKdtId(Integer.parseInt(kdtId));
            if (!result.isSuccess() || result.getData() == null) {
                logger.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
                throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
            }
        } catch (Exception e) {
            logger.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
            throw new BusinessException("微商城店铺kdtId不存在，请确认kdtId是否填写正确！");
        }
        userNo = result.getData();

        String waterNo = String.valueOf(KeyUtils.generateWaterNumber());
        AcctransRechargeRequest rechargeRequest = new AcctransRechargeRequest();
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setUserNo(String.valueOf(userNo));
        accountInfo.setAccountType(AccountType.BASE_ACCT.getType());
        rechargeRequest.setAccountInfo(accountInfo);
        rechargeRequest.setAppName("biz-commerce");
        rechargeRequest.setClientId(waterNo);
        rechargeRequest.setAcquireNo(waterNo);
        rechargeRequest.setAmount(money);
        rechargeRequest.setChannelCode(ChannelType.BALANCE.getCode());
        rechargeRequest.setCurrencyCode(CurrencyCode.CNY.getNum());
        rechargeRequest.setOperator("ci-test");
        rechargeRequest.setOrderNo(waterNo);
        rechargeRequest.setParternerBizType("301001");
        rechargeRequest.setParternerId("301001");
        rechargeRequest.setRemark("接口测试调用");
        rechargeRequest.setSubTransCode(SubTransCodeEnum.RECHARGE_RECHARGESETTLE.getCode());
        rechargeRequest.setTransCode(TransCodeEnum.RECHARGE.getCode());
        rechargeRequest.setRequestTime("test");
        DataResult<AcctransAccountingDTO> rechargeResult = acctransRechargeService.recharge(rechargeRequest);

        if (!rechargeResult.isSuccess()) {
            logger.error("AcctransService 充值接口调用失败,waterNo=" + rechargeResult.getRequestId() + "! ");
            throw new BusinessException("AcctransService 充值接口调用失败！返回结果为：" + JSON.toJSONString(rechargeResult));
        }
    }

    /**
     * 重置店铺余额为0
     *
     * @param kdtId
     */

    public void resetShopBalance(int kdtId) {
        //根据kdtId 获取userNo
        PlainResult<String> result = userInfoService.queryUserNoByKdtId(kdtId);
        if (!result.isSuccess() || result.getData() == null) {
            logger.error("查不到kdtId对应的userNo,kdtId=" + kdtId + "! ");
            throw new BusinessException("微商城店铺不存在，请确认kdtId是否填写正确！");
        }
        String userNo = result.getData();

        DataResult<AccountDataDTO> accountInfo = accountService.getAccountInfo(userNo, 10);
        if (!result.isSuccess() || result.getData() == null) {
            logger.error("查不到对应的acctNo,userNo=" + userNo + "! ");
            throw new BusinessException("微商城店铺账号信息不存在，请确认kdtId是否填写正确！");
        }

        long availableAmount = accountInfo.getData().getAvailable();
        //把钱转到固定的店铺中去：店铺：kangyunTest kdt_id：29801098 "userNo": "180712135047000000" "acctNo": "180712135047000000"
        AcctransTransferRequest request = genAcctransTransferRequest(userNo, "180712135047000000", 10, 10,
                "100", "100001", "5006", availableAmount);
        DataResult<AcctransAccountingDTO> transferResult = acctransTransferService.transfer(request);

        if (!transferResult.isSuccess()) {
            logger.error("AcctransService 充值接口调用失败,waterNo=" + transferResult.getRequestId() + "! ");
            throw new BusinessException("AcctransService 充值接口调用失败！返回结果为：" + JSON.toJSONString(transferResult));
        }
    }

    /**
     * 有赞币充值
     *
     * @param kdtId
     * @param money
     */
    public void rechargeYzcoin(long kdtId, long money) {
        money = money * 100;
        YzCoinGrantOrRecycleParam yzcoinParam = new YzCoinGrantOrRecycleParam();
        String waterNo = String.valueOf(KeyUtils.generateWaterNumber());
        yzcoinParam.setKdtId(kdtId);
        yzcoinParam.setInfo("ci-test充值");
        yzcoinParam.setMoney(money);
        yzcoinParam.setOutWaterNo(waterNo);
        yzcoinParam.setType("grant");
        yzcoinParam.setSourceTag("ci-test");

        PlainResult<YzCoinGrantDTO> result = yzCoinService.grant(yzcoinParam);
        if (!result.isSuccess()) {
            logger.error("YzCoinService 充值有赞币接口调用失败！");
            throw new BusinessException("YzCoinService 充值有赞币接口调用失败！返回结果为：" + JSON.toJSONString(result));
        }
    }

    /**
     * 回收有赞币
     *
     * @param kdtId
     */
    public void recycleYzcoin(long kdtId) {
        String recycleWaterNo = String.valueOf(KeyUtils.generateWaterNumber());
        YzCoinGrantOrRecycleParam yzCoinRecycleParam = new YzCoinGrantOrRecycleParam();
        yzCoinRecycleParam.setKdtId(kdtId);
        yzCoinRecycleParam.setInfo("ci-test回收");
        yzCoinRecycleParam.setMoney(yopAccountService.getBalanceByKdtId(kdtId).getData().getBalance());
        yzCoinRecycleParam.setOutWaterNo(recycleWaterNo);
        yzCoinRecycleParam.setType("recycle");
        yzCoinRecycleParam.setSourceTag("ci-test");
        PlainResult<Long> result = yzCoinService.recycle(yzCoinRecycleParam);

        if (!result.isSuccess()) {
            logger.error("YzCoinService 充值有赞币接口调用失败！");
            throw new BusinessException("YzCoinService 充值有赞币接口调用失败！返回结果为：" + JSON.toJSONString(result));
        }
    }

    /**
     * 根据yop的appid获得ycm的appid
     *
     * @param appId
     * @return
     */
    public String getYcmAppId(Long appId) {
        String ycmAppid = "";
        List<GdGoodsIdMapping> gdGoodsIds = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().eq("yop_id", appId));
        for (GdGoodsIdMapping gdGoodsId : gdGoodsIds) {
            if (patternAtom.matcher(gdGoodsId.getYcmId()).find()) {
                ycmAppid = gdGoodsId.getYcmId();
                return ycmAppid;
            }
        }
        return ycmAppid;
    }

    public Long getYopAppId(String ycmId) {
        GdGoodsIdMapping gdGoodsIds = gdGoodsIdMappingMapper.selectOne(new QueryWrapper<GdGoodsIdMapping>().eq("ycm_id", ycmId));
        Long yopId = Long.valueOf(gdGoodsIds.getYopId());
        return yopId;
    }

    /**
     * 向前向后平移服务期
     *
     * @param kdtId
     * @param appId
     * @param days
     * @return
     */
    public Boolean movePerformStatusByAppId(Long kdtId, Long appId, Integer days) {
        String ycmAppId = getYcmAppId(appId);
        Calendar calendar = Calendar.getInstance();//日历对象
        // 按服务期生效顺序获取服务期，包括已经过期的
        List<PfOrderStatus> orderStatusList = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>()
                .eq("apply_ycm_id", kdtId)
                .eq("app_id", ycmAppId)
                .eq("apply_ycm_type", "KDT_ID")
                .eq("state", "valid")
                .orderByAsc("effect_time"));

        //处理服务期平移
        List<PfOrderStatus> waitUpdateList = new ArrayList<>();
        for (PfOrderStatus pfOrderStatus : orderStatusList) {
            calendar.setTime(pfOrderStatus.getEffectTime());//设置生效日期
            calendar.add(Calendar.DATE, days);
            Date orderStatusNewEffectTime = calendar.getTime();

            calendar.setTime(pfOrderStatus.getExpireTime());//设置失效效日期
            calendar.add(Calendar.DATE, days);
            Date orderStatusNewExpireTime = calendar.getTime();
            pfOrderStatus.setEffectTime(orderStatusNewEffectTime);
            pfOrderStatus.setExpireTime(orderStatusNewExpireTime);
            waitUpdateList.add(pfOrderStatus);
        }

        for (PfOrderStatus pfOrderStatus : waitUpdateList) {
            int updateOrderStatusCount = pfOrderStatusMapper.updateById(pfOrderStatus);
        }

        //刷新缓存,同步服务期
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        flushAppStatusRequest.setAppId(ycmAppId);
        flushAppStatusRequest.setKdtId(String.valueOf(kdtId));
        pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        marketRemoteService.concurrentStatus(kdtId, appId.intValue());

        return true;

    }

//    public Date getTimeByMove(String timeType, int num) {
//        Calendar calendar = Calendar.getInstance();//日历对象
//        if(timeType == "DATE") {
//            calendar.setTime(now());
//            calendar.add(Calendar.DATE,num);
//        }else if(timeType == "YEAR") {
//            calendar.setTime(now());
//            calendar.add(Calendar.YEAR,num);
//        }
//        return calendar.getTime();
//    }

    /**
     * 校验订单的服务期生成时间正确
     * @param pfOrderId
     * @param itemId
     * @param performedYear
     */
    public void checkPfOrderStatus(Long pfOrderId,String itemId,int performedYear) {
        Calendar calendar = Calendar.getInstance();//日历对象
        PfOrderStatus orderStatus = pfOrderStatusMapper.selectOne(new QueryWrapper<PfOrderStatus>()
                .eq("pf_order_id", pfOrderId)
                .eq("state", "valid")
                .eq("item_id",itemId)
                .eq("group_type","product_with_paid"));
        Date effectTime = orderStatus.getEffectTime();
        Date expiredTime = orderStatus.getExpireTime();
        calendar.setTime(effectTime);
        calendar.add(Calendar.YEAR,performedYear);
        Date expectExpiredTime = calendar.getTime();
        Assert.assertEquals(expiredTime,expectExpiredTime,"服务期不正确");
    }

    /**
     * 获取item下的满减活动，如果有多个，取第一个，如果没有则返回空
     *
     * @param kdtId
     * @param kdtName
     * @param itemId
     * @param quantity
     * @return
     */

    public Long getFullReduce(Long kdtId, String kdtName, int itemId, int quantity) {
        OrderItemForm confirmOrderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(confirmOrderItemForm);

        ConfirmOrderForm confirmOrderForm = ConstructionParam.getConfirmOrderForm(kdtId, kdtName, orderItemFormList);
        PlainResult<OrderConfirmApi> confirmApiPlainResult = orderRemoteService.confirmOrder(confirmOrderForm);
        logger.info("确认订单页返回数据：" + JSON.toJSON(confirmApiPlainResult));
        Assert.assertEquals(confirmApiPlainResult.getCode(), 200, confirmApiPlainResult.getMessage());
        List<OrderPromotionMutexApi> getOrderPromotionList = confirmApiPlainResult.getData().getOrderPromotionList();
        if (getOrderPromotionList.size() > 0) {
            logger.info("有订单满减活动,活动ID有：" + getOrderPromotionList);
            Long promotionId = confirmApiPlainResult.getData().getOrderPromotionList().get(0).getOrderPromotionMutexList().get(0).getPromotionId();
            logger.info("准备使用的活动id：" + promotionId);
            return promotionId;
        } else {
            return null;
        }
    }

    //获取需要解决互斥的商品级营销，并取第一个
    public OpenAppPackagePreferentialApi getItemMutexPromotion(Long kdtId, String kdtName, int itemId, int quantity) {
        OrderItemForm confirmOrderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(confirmOrderItemForm);

        ConfirmOrderForm confirmOrderForm = ConstructionParam.getConfirmOrderForm(kdtId, kdtName, orderItemFormList);
        PlainResult<OrderConfirmApi> confirmApiPlainResult = orderRemoteService.confirmOrder(confirmOrderForm);
        logger.info("确认订单页返回数据：" + JSON.toJSON(confirmApiPlainResult));
        Assert.assertEquals(confirmApiPlainResult.getCode(), 200, confirmApiPlainResult.getMessage());
        List<OrderPromotionMutexApi> getOrderPromotionList = confirmApiPlainResult.getData().getOrderPromotionList();
        List<AppPromotionMutexApi> itemPromotionMutexList = confirmApiPlainResult.getData().getItems().get(0).getItemPromotionMutexList();
        for(AppPromotionMutexApi itemPromotionMutex:itemPromotionMutexList) {
            if(itemPromotionMutex.getHasMutex()) {
                OpenAppPackagePreferentialApi appPromotionMutexList = itemPromotionMutex.getAppPromotionMutexList().get(0);
                return appPromotionMutexList;
            }
        }
        return null;
    }

    public PlainResult<Long> createOrder(Long kdtId, String kdtName, int itemId, int quantity,Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

//        //解决互斥
//        //获取商品的优惠
//        PlainResult<List<ItemPreferentialInfoResultApi>> itemPreferentialInfoResult = fetchItemPreferentialInfoOnline(kdtId,1,itemId,quantity,1);
//        logger.info("优惠信息：{}",itemPreferentialInfoResult);        //商品级别优惠参数
//
//        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();
//        //将获取到的商品级优惠传入参数
//        if(itemPreferentialInfoResult.getData().size()>0) {
//            //做非null判断
//            if(itemPreferentialInfoResult.getData().get(0).getPresentList() != null) {
//                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPresentList());
//            }
//            if(itemPreferentialInfoResult.getData().get(0).getPromotionList() != null) {
//                itemPromotionList.addAll(itemPreferentialInfoResult.getData().get(0).getPromotionList());
//            }
//            //送有赞币的营销活动去掉
//            itemPromotionList = itemPromotionList.stream().filter(v -> v.getType()!=6).collect(Collectors.toList());
//            //将商品级优惠放入orderItemFormList
//            orderItemForm.setItemPromotionList(itemPromotionList);
//        }
//        orderItemFormList.add(orderItemForm);
        Long promotionId = getFullReduce(kdtId, kdtName, itemId, quantity);
        List<PreferentialDescApi> orderPromotionList = ConstructionParam.getOrderPromotionList(kdtId, kdtName, itemId, promotionId, 1);

        //微商城订单创建参数
        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList, orderPromotionList, yzb);

        logger.info("创建订单的参数：" + JSON.toJSON(createOrderForm));
        PlainResult<Long> orderCreateApiPlainResult = orderRemoteService.createOrder(createOrderForm);

        logger.info("创建订单结果：{}",JSON.toJSONString(orderCreateApiPlainResult));
        return orderCreateApiPlainResult;
    }

    public PlainResult<Long> createOrderWithMultiApps(Long kdtId, String kdtName, List<Integer> itemIds, int quantity,Long yzb) {
        //构造item参数
        List<PreferentialDescApi> orderPromotionList = new ArrayList<>();
        List<OrderItemForm> orderItemFormList = new ArrayList<>();

        for(Integer itemId : itemIds) {
            OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
            orderItemFormList.add(orderItemForm);


        }

        //获取订单级别的优惠
        ConfirmOrderForm confirmOrderForm = ConstructionParam.getConfirmOrderForm(kdtId, kdtName, orderItemFormList);
        PlainResult<OrderConfirmApi> confirmOrderResult = orderRemoteService.confirmOrder(confirmOrderForm);
        logger.info("确认订单-订单计算返回数据：{}",JSON.toJSON(confirmOrderResult));

        //将订单级别优惠传入参数
        /**满减优惠,并过滤掉selected = false的优惠<====对于老的creatOrder，是不会帮着选的，另谋出路吧
        for(int OrderPromotionNum = 0;OrderPromotionNum < confirmOrderResult.getData().getOrderPromotionList().size();OrderPromotionNum++) {
            List<PreferentialDescApi> getFullReduceList = confirmOrderResult.getData().getOrderPromotionList().get(OrderPromotionNum).getOrderPromotionMutexList().
                    stream().filter(v -> v.getSelected()!=false).collect(Collectors.toList());
            orderPromotionList.addAll(getFullReduceList);
        }
        */
        if(confirmOrderResult.getData().getOrderPromotionList().size()>0) {
            List<PreferentialDescApi> getFullReduceList = new ArrayList<>();
            getFullReduceList.add(confirmOrderResult.getData().getOrderPromotionList().get(0).getOrderPromotionMutexList().get(0));
            orderPromotionList.addAll(getFullReduceList);
        }


        //对orderPromotionList过滤一下（因为不同的插件可能会有相同的订单级别优惠）
//        List<PreferentialDescApi> newOrderPromotionList = orderPromotionList.stream().collect(
//                Collectors. collectingAndThen(
//                        Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PreferentialDescApi::getName))), ArrayList::new));

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList, orderPromotionList, yzb);

        logger.info("创建订单的参数：" + JSON.toJSON(createOrderForm));
        PlainResult<Long> orderCreateApiPlainResult = orderRemoteService.createOrder(createOrderForm);

        logger.info("创建订单结果：{}",JSON.toJSONString(orderCreateApiPlainResult));
        return orderCreateApiPlainResult;
    }

    //public get

    /**
     * 构造计算退款金额的参数
     *
     * @param orderId
     * @param refundMode
     * @return
     */
    public RefundCalculateNonConsumeRequest buildCalculateNonConsumeRequest(String orderId, String refundMode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(new Date());

        RefundCalculateNonConsumeRequest calculateNonConsumeRequest = new RefundCalculateNonConsumeRequest();
        calculateNonConsumeRequest.setOrderId(orderId);
        calculateNonConsumeRequest.setRefundMode(refundMode);
        calculateNonConsumeRequest.setRefundCalculateTime(refundTime);

        return calculateNonConsumeRequest;
    }


    public void refundOrder(String orderId, Long refundCnyAmt, Long refundYzbAmt, String refundMode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(new Date());

        RefundNonConsumeRequest refundNonConsumeRequest = new RefundNonConsumeRequest();
        refundNonConsumeRequest.setMemo("");
        refundNonConsumeRequest.setOperatorId("2135");
        refundNonConsumeRequest.setOrderId(orderId);
        refundNonConsumeRequest.setRefundCalculateTime(refundTime);
        refundNonConsumeRequest.setRefundMode(refundMode);
        refundNonConsumeRequest.setRefundYzbAmt(refundYzbAmt);
        refundNonConsumeRequest.setRefundCnyAmt(refundCnyAmt);
        refundNonConsumeRequest.setRefundWay("ORIG");
        PlainResult<Boolean> refundResult = refundRemoteService.refundNonConsume(refundNonConsumeRequest);
        Assert.assertEquals(refundResult.getMessage(), "successful");
        Assert.assertEquals(refundResult.getCode(), 200);
        Assert.assertTrue(refundResult.getData());

    }

    /**
     * 全部退款
     * @param orderId
     */
    public PlainResult<Boolean> refundOrderByAll(Long orderId) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(new Date());

        RefundNonConsumeRequest refundNonConsumeRequest = new RefundNonConsumeRequest();
        refundNonConsumeRequest.setMemo("");
        refundNonConsumeRequest.setOperatorId("2135");
        refundNonConsumeRequest.setOrderId(String.valueOf(orderId));
        refundNonConsumeRequest.setRefundCalculateTime(refundTime);
        refundNonConsumeRequest.setRefundMode("BY_ALL");
        refundNonConsumeRequest.setRefundWay("ORIG");
        PlainResult<Boolean> refundResult = refundRemoteService.refundNonConsume(refundNonConsumeRequest);
        logger.info(JSON.toJSONString(refundResult));
        return refundResult;
//        Assert.assertEquals(refundResult.getMessage(), "successful");
//        Assert.assertEquals(refundResult.getCode(), 200);
//        Assert.assertTrue(refundResult.getData());

    }

    /**
     * 获取应用的订单类型的有效服务期，存在则返回true，不存在则返回false
     *
     * @param kdtId
     * @param appId
     * @param orderId：tdOrder表里的id
     * @return
     */

    public boolean getAppStatus(Long kdtId, Long appId, Long orderId) {
        String ycmAppId = getYcmAppId(appId);

        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //根据tdorder里的tdno来获取对应appid的pf_order_id
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));

        //查询有效的订单服务期的sql语句
        Wrapper<PfOrderStatus> queryWrapper = new QueryWrapper<PfOrderStatus>()
                .eq("pf_order_id", pfOrder.getId())
                .eq("apply_ycm_id", kdtId)
                .eq("apply_ycm_type", "KDT_ID")
                .eq("app_id", ycmAppId)
                .eq("state", "valid")
                .eq("group_type", "product_with_paid");

        //校验微商城服务期生成
        List<PfOrderStatus> pfOrderStatusList = pfOrderStatusMapper.selectList(queryWrapper);
        if (pfOrderStatusList.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * 根据tdOrderId获取tdNo
     * @param tdOrderId
     * @return
     */
    public String getTdNo(Long tdOrderId) {
        try {
            //获取tdOrderId下的tdNo
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", tdOrderId));

            return tdOrder.getTdNo();
        } catch (Exception e) {
            logger.error("查询pfOrderId失败");
            throw new BusinessException("查询pfOrderId失败");
        }
    }

    /**
     * 根据td order id获取pf order id
     */
    public Long getPfOrderId(String tdOrderId) {
        try {
            //获取tdOrderId下的tdNo
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", Long.valueOf(tdOrderId)));

            //根据tdorder里的tdno来获取对应appid的pf_order_id
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            return pfOrder.getId();
        } catch (Exception e) {
            logger.error("查询pfOrderId失败");
            throw new BusinessException("查询pfOrderId失败");
        }

    }

    /**
     * 获取所有服务期里最早生效时间，包括礼包
     * @param kdtId
     * @param appId
     * @return
     */
    public Date getEffectTimeByKdtIdAndAppId(Long kdtId,Integer appId) {
        String ycmAppId = getYcmAppId(Long.valueOf(appId));

        // 按服务期生效顺序获取服务期，包括已经过期的
        PfOrderStatus orderStatus = pfOrderStatusMapper.selectOne(new QueryWrapper<PfOrderStatus>()
                .eq("apply_ycm_id", kdtId)
                .eq("app_id", ycmAppId)
                .eq("apply_ycm_type", "KDT_ID")
                .orderByAsc("effect_time")
                .last("limit 1"));

        if(orderStatus != null) {
            return orderStatus.getEffectTime();
        }else {
            return null;
        }
    }

    /**
     * 获取所有服务期里最大过期时间，包括礼包
     * @param kdtId
     * @param appId
     * @return
     */
    public Date getExpiredTimeByKdtIdAndAppId(Long kdtId,Integer appId) {
        String ycmAppId = getYcmAppId(Long.valueOf(appId));

        // 按服务期过期顺序获取服务期，包括已经过期的
        PfOrderStatus orderStatus = pfOrderStatusMapper.selectOne(new QueryWrapper<PfOrderStatus>()
                .eq("apply_ycm_id", kdtId)
                .eq("app_id", ycmAppId)
                .eq("apply_ycm_type", "KDT_ID")
                .orderByDesc("expire_time")
                .last("limit 1"));

        if(orderStatus != null) {
            return orderStatus.getExpireTime();
        }else {
            return null;
        }
    }


    /**
     * 获取订单服务期天数
     * @param kdtId
     * @param appId
     * @return
     */
    public Date getOrderLeftAppStatusDaysByOrderIdAndAppIdId(Long kdtId,Integer appId) {
        String ycmAppId = getYcmAppId(Long.valueOf(appId));

        // 按服务期过期顺序获取服务期，包括已经过期的
        PfOrderStatus orderStatus = pfOrderStatusMapper.selectOne(new QueryWrapper<PfOrderStatus>()
                .eq("apply_ycm_id", kdtId)
                .eq("app_id", ycmAppId)
                .eq("apply_ycm_type", "KDT_ID")
                .orderByDesc("expire_time")
                .last("limit 1"));

        if(orderStatus != null) {
            return orderStatus.getExpireTime();
        }else {
            return null;
        }
    }

    public boolean getPfOrderState(Long tdOrderId) {
        //String ycmAppId = getYcmAppId(appId);
        //List<String> refundStates = Stream.of("refund_applied","refunded","refund_slip").collect(toList());
        List<String> refundStates = Lists.newArrayList("refund_applied","refunded","refund_slip");
        //根据td order id查找对应appid的pf order id
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", tdOrderId));
        //根据tdorder里的tdno来获取对应appid的pf_order_id
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
        pfOrder.getPerformState().equals("refund_applied");
        //pfOrder.getTradeState().equals("refund_applied")||pfOrder.getTradeState().equals("refunded")||pfOrder.getTradeState().equals("refund_slip");
        if(pfOrder.getPerformState().equals("invalid")&&( refundStates.contains(pfOrder.getTradeState()))) {
            return true;
        }else {
            logger.info("pfOrder 的 performStata:{}",pfOrder.getPerformState());
            logger.info("pfOrder 的 refundStates:{}",pfOrder.getTradeState());
        }
        return false;

    }

    /**
     * 根据tdOrderId获取pfOrderId
     * @param tdOrderId
     * @return
     */
    public Long getPfOrderIdByTdOrderId(Long tdOrderId) {
        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", tdOrderId));

        //根据tdorder里的tdno来获取对应appid的pf_order_id
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));

        if(null == pfOrder) {
            return null;
        }

        Long pfOrderId = pfOrder.getId();

        return pfOrderId;

    }

    public List<PfOrderStatus> getGiftStatusList(Long kdtId, Long appId, Long orderId) {
        String ycmAppId = getYcmAppId(appId);

        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //根据tdorder里的tdno来获取对应appid的pf_order_id
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));

        //查询有效的订单服务期的sql语句
        Wrapper<PfOrderStatus> queryWrapper = new QueryWrapper<PfOrderStatus>()
                .eq("pf_order_id", pfOrder.getId())
                .eq("apply_ycm_id", kdtId)
                .eq("apply_ycm_type", "KDT_ID")
                .eq("app_id", ycmAppId)
                .eq("state", "valid")
                .eq("group_type", "product_with_present");

        //校验微商城服务期生成
        List<PfOrderStatus> pfGiftStatusList = pfOrderStatusMapper.selectList(queryWrapper);

        return pfGiftStatusList;
    }

    /**
     * 将活动置为失效
     */
    public void setActivityValid(Long id) {
        //判断失效时间是否大于当前时间，如果是，则直接改状态
        Calendar calendar = Calendar.getInstance();//日历对象
        MkActivity mkActivity = activityMapper.selectById(id);
        if (now().before(mkActivity.getExpireTime())) {
            mkActivity.setState("AUDITED_PASS");
            activityMapper.update(mkActivity, new UpdateWrapper<MkActivity>()
                    .eq("id", id));
        } else {
            //将过期时间设置为当前时间加1年
            calendar.setTime(now());
            calendar.add(Calendar.YEAR, 1);
            mkActivity.setExpireTime(calendar.getTime());
            mkActivity.setState("AUDITED_PASS");
            activityMapper.update(mkActivity, new UpdateWrapper<MkActivity>()
                    .eq("id", id));
        }
    }

    /**
     * 将活动置失效
     */
    public void setActivityInvalid(Long id) {
        MkActivity mkActivity = new MkActivity();
        mkActivity.setState("CANCELED");
        activityMapper.update(mkActivity, new UpdateWrapper<MkActivity>()
                .eq("id", id));
    }

    /**
     * 将零售单店降级成微商城单店，需要先将零售退款
     *
     * @param kdtId
     */

    public void retailToWsc(Long kdtId) {
        //将店铺降级为微商城店铺
        //设置店铺的参数
        ModifyRetail2WscForm modifyRetail2WscForm = new ModifyRetail2WscForm();
        modifyRetail2WscForm.setKdtId(kdtId);
        modifyRetail2WscForm.setOperatorId(123L);//123随便写的

        //调用降级接口，但好像即使降级失败也可以成功
        PlainResult<ModifyRetail2WscApi> resultModifyRetail2Wsc = shopOperateRemoteService.modifyRetail2Wsc(modifyRetail2WscForm);
        logger.info("降级结果：{}", JSONObject.toJSON(resultModifyRetail2Wsc));
    }

    /**
     * 等待履约，最长20s
     * @param orderId
     */
    public void waitForSplitOrder(Long orderId) {
        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //根据tdorder里的tdno来获取对应appid的pf_order_id
        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("等待pf_order拆单结束...")
                .atMost(20L, TimeUnit.SECONDS)
                .until(() -> pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo())).size() >0);



    }

    /**
     * 等待履约，最长20s
     *
     * @param kdtId
     * @param appId
     * @param orderId
     */
    public void waitForPerform(Long kdtId, Long appId, Long orderId) {
        String ycmAppId = "";
        if(softWareAppId.contains(appId)) {
            List<GdGoodsIdMapping> gdGoodsIds = gdGoodsIdMappingMapper.selectList(new QueryWrapper<GdGoodsIdMapping>().eq("yop_id", appId));
            for (GdGoodsIdMapping gdGoodsId : gdGoodsIds) {
                if (patternCombine.matcher(gdGoodsId.getYcmId()).find()) {
                    ycmAppId = gdGoodsId.getYcmId();
                }
        }
        } else {
            ycmAppId = getYcmAppId(appId);
        }

        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //根据tdorder里的tdno来获取对应appid的pf_order_id
        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("等待pf_order拆单成功...")
                .atMost(50L, TimeUnit.SECONDS)
                .until(() -> pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo())).size()>0);

        PfOrder pfOrder = pfOrderMapper.selectOne(
                new QueryWrapper<PfOrder>()
                        .eq("biz_order_id", tdOrder.getTdNo())
                        .eq("app_id",ycmAppId));

        //等待pf_order里的state变成performed
        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("等待pf_order订单状态变为performed...")
                .atMost(500L, TimeUnit.SECONDS)
                .until(() -> pfOrderMapper.selectOne(
                        new QueryWrapper<PfOrder>()
                                .eq("id",pfOrder.getId())).getPerformState().equals("performed"));


        /**
         * 次处pf_order_status不作校验，pf_order_status 与pf_order的perform state是一个事物
         */
        //等待履约873在pf_order_status表里有数据
//        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
//                .and().with().pollDelay(1, TimeUnit.SECONDS)
//                .await("等待履约...")
//                .atMost(20L, TimeUnit.SECONDS)
//                .until(() -> getAppStatus(kdtId, appId, orderId));

    }

    /**
     * 等待被升级的订单状态变为upgrade
     * @param orderId
     */
    public void waitForPfOrderStateChanged(Long orderId) {
        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //根据tdorder里的tdno来获取对应appid的pf_order_id
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));

        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("等待被升级的订单状态变为upgrade...")
                .atMost(50L, TimeUnit.SECONDS)
                .until(() -> pfOrderMapper.selectOne(
                        new QueryWrapper<PfOrder>()
                                .eq("id",pfOrder.getId())).getTradeState().equals("upgrade"));

    }

    /**
     * 支付成功后，等待td_pay_order表数据落成功
     * @param tdOrderId
     */
    public void waitForTdPayOrderDAta(Long tdOrderId) {
        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", tdOrderId));

        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("创建订单成功，等待td_pay_order表数据落成功")
                .atMost(20L, TimeUnit.SECONDS)
                .until(() -> tdPayOrderMapper.selectList(new QueryWrapper<TdPayOrder>()
                        .eq("td_no",tdOrder.getTdNo())).size() ==1);
    }

    /**
     * 抵扣升级后等待被升级的订单状态变为upgrade...
     * @param orderId
     */
    public void waitForPfAssetData(Long orderId) {
        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("等待被升级的订单状态变为upgrade...")
                .atMost(20L, TimeUnit.SECONDS)
                .until(() -> pfAssetMapper.selectList(new QueryWrapper<PfAsset>()
                        .eq("out_biz_no",tdOrder.getTdNo())
                        .eq("app_id","combine_spu_wsc")
                        .eq("source_type","product_with_paid")).size()>0);


    }

    /**
     * 等待库存履约，最长15s
     * @param kdtId
     * @param orderId
     */
    public void waitPerformForStock(Long kdtId, Long orderId) {
        //获取tdOrderId下的tdNo
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderId));

        //根据tdorder里的tdno来获取对应appid的pf_order_id
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));

        //等待履约:履约订单的状态为：performed
        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("等待履约...")
                .atMost(20L, TimeUnit.SECONDS)
                .until(() -> pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("id",pfOrder.getId())).getPerformState().equals("performed"));
        try {
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 等待回收服务期，最长10s（只能给一个tdOrder对应一个pfOrder的情况，多个的不适用）
     *
     * @param kdtId
     * @param appId
     * @param orderId
     */
    public void waitForRefund(Long kdtId, Long appId, Long orderId) {
        //等到订单服务期失效
        //logger.info("开始等待退款。。。");
        with().pollInterval(ONE_HUNDRED_MILLISECONDS)
                .and().with().pollDelay(1, TimeUnit.SECONDS)
                .await("等待退款...")
                .atMost(30L, TimeUnit.SECONDS)
                .until(() -> !getAppStatus(kdtId, appId, orderId)&&getPfOrderState(orderId));

    }

    public String generate23Sequence() {
        //16位
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYYMMddHHmmssSSS");
        String randomString = simpleDateFormat.format(new Date()) + (int) Math.random() * 100;
        logger.info("生成随机E单：" + "EAUTO" + randomString);
        return "EAUTO" + randomString;
    }

    public String generateOutBizNo() {
        //16位
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYYMMddHHmmssSSS");
        String randomString = simpleDateFormat.format(new Date()) + (int) Math.random() * 100;
        logger.info("生成随机bizNo" +":" + randomString);
        return  randomString;
    }

    /**
     * 删除业务方短信记录
     * @param kdtId
     */
    public void deleteSmsData(Long kdtId){
        logger.info("开始清理短信数据---kdtid---"+kdtId);
        smsStockDetailMapper.delete(new QueryWrapper<SmsStockDetailEntity>().eq("kdt_id",kdtId)) ;
        smsStockMapper.delete(new QueryWrapper<SmsStockEntity>().eq("kdt_id",kdtId)) ;
    }

    public void decreaseMsgStock(Long kdtId,Long stockNum){
        StockDecreaseDTO stockDecreaseDTO = new StockDecreaseDTO();

        stockDecreaseDTO.setSerialNo(generate23Sequence());
        stockDecreaseDTO.setDecReason("wuwu_test");
        stockDecreaseDTO.setKdtId(kdtId);
        stockDecreaseDTO.setStock(stockNum);

        PlainResult<StockDecResultDTO> decreaseResult = msgSmsStockService.decrease(stockDecreaseDTO);
        //不了解业务方的落库操作，无脑等3s
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Assert.assertEquals(decreaseResult.getCode(),200,decreaseResult.getMessage());
    }

    /**
     *
     * @param pfOrder
     * @param pfOrderStatusCal
     * @param refundNonConsumeRequest
     */
    public void checkRefundCnyAndYzb(PfOrder pfOrder, Map<String,Long> pfOrderStatusCal, com.youzan.ycm.perform.request.refund.RefundNonConsumeRequest refundNonConsumeRequest) {
        Long unUsedPfOrderStatus = pfOrderStatusCal.get("unUsed");
        Long allPfOrderStatus = pfOrderStatusCal.get("all");
        Long usedPfOrderStatus = pfOrderStatusCal.get("used");

        //剩余价值计算
        if(usedPfOrderStatus == 0L && refundNonConsumeRequest.getRefundWay() == RefundWayConstants.ACCOUNT
                || refundNonConsumeRequest.getRefundWay() == RefundWayConstants.ACCOUNT && refundNonConsumeRequest.getRefundMode() == RefundModeConstants.ALL) {
            Long refundCny = 0L;
            Long refundYzb = pfOrder.getYzbPrice();
            Long refundAccountPrice = pfOrder.getRealPrice();
            Assert.assertEquals(pfOrder.getReturnRealPrice(),refundCny,"退款cny不正确");
            Assert.assertEquals(pfOrder.getReturnYzbPrice(),refundYzb,"退款yzb不正确");
            Assert.assertEquals(pfOrder.getReturnAccountPrice(),refundAccountPrice,"退到订购账户的金额不正确");

        } else if(refundNonConsumeRequest.getRefundMode() == RefundModeConstants.MANUAL
                && refundNonConsumeRequest.getRefundWay() == RefundWayConstants.ACCOUNT) {
            Long refundCny = 0L;
            Long refundYzb = refundNonConsumeRequest.getRefundYzbAmt();
            Long refundAccountPrice = refundNonConsumeRequest.getRefundCnyAmt();
            Assert.assertEquals(pfOrder.getReturnRealPrice(),refundCny,"退款cny不正确");
            Assert.assertEquals(pfOrder.getReturnYzbPrice(),refundYzb,"退款yzb不正确");
            Assert.assertEquals(pfOrder.getReturnAccountPrice(),refundAccountPrice,"退到订购账户的金额不正确");

        }else if(refundNonConsumeRequest.getRefundWay() == RefundWayConstants.ACCOUNT) {
            Long refundCny = 0L;
            Long refundYzb = 0L;
            Long refundAccountPrice = pfOrder.getRealPrice()*(unUsedPfOrderStatus-1)/allPfOrderStatus;
            Assert.assertEquals(pfOrder.getReturnRealPrice(),refundCny,"退款cny不正确");
            Assert.assertEquals(pfOrder.getReturnYzbPrice(),refundYzb,"退款yzb不正确");
            Assert.assertEquals(pfOrder.getReturnAccountPrice(),refundAccountPrice,"退到订购账户的金额不正确");

        }else if(refundNonConsumeRequest.getRefundMode() == RefundModeConstants.ALL) {
            Assert.assertEquals(pfOrder.getReturnRealPrice(),pfOrder.getRealPrice(),"退款cny不正确");
            Assert.assertEquals(pfOrder.getReturnYzbPrice(),pfOrder.getYzbPrice(),"退款yzb不正确");
        } else if(refundNonConsumeRequest.getRefundMode() == RefundModeConstants.VALUE) {
            /**
             * 移动服务期-100,此时剩余服务期是730-100-1 = 629
             */
            Long refundCny = pfOrder.getRealPrice()*(unUsedPfOrderStatus-1)/allPfOrderStatus;
            Long refundYzb = 0L;
            Assert.assertEquals(pfOrder.getReturnRealPrice(),refundCny,"退款cny不正确");
            Assert.assertEquals(pfOrder.getReturnYzbPrice(),refundYzb,"退款yzb不正确");

        }else if(refundNonConsumeRequest.getRefundMode() == RefundModeConstants.MANUAL) {
            Assert.assertEquals(pfOrder.getReturnRealPrice(),refundNonConsumeRequest.getRefundCnyAmt(),"退款cny不正确");
            Assert.assertEquals(pfOrder.getReturnYzbPrice(),refundNonConsumeRequest.getRefundYzbAmt(),"退款yzb不正确");

        }

    }


    /**
     * 根据订单id获取当前订单已使用的服务期和初使服务期的服务期时长和
     * @param pfOrder
     * @return
     */
    public Map<String,Long> getPfOrderStatus(PfOrder pfOrder,String itemId) {
        // 按服务期生效顺序获取服务期，包括已经过期的
        PfOrderStatus orderStatus = pfOrderStatusMapper.selectOne(new QueryWrapper<PfOrderStatus>()
                .eq("pf_order_id", pfOrder.getId())
                .eq("state", "valid")
                .eq("item_id",itemId));
        Assert.assertNotNull(orderStatus,"服务期未找到");

        LocalDate effectTime = orderStatus.getEffectTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate expiredTime = orderStatus.getExpireTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate nowTime = now().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        Long pfOrderStatusAllDays = expiredTime.toEpochDay() - effectTime.toEpochDay();
        Long pfOrderStatusUsedDays = nowTime.toEpochDay() - effectTime.toEpochDay();
        Long pfOrderStatusUnUsedDays = expiredTime.toEpochDay() - nowTime.toEpochDay();


        Map<String,Long> pfOrderStatus = new HashMap<>();
        pfOrderStatus.put("all",pfOrderStatusAllDays);
        pfOrderStatus.put("used",pfOrderStatusUsedDays);
        pfOrderStatus.put("unUsed",pfOrderStatusUnUsedDays);
        return pfOrderStatus;
    }


    /**
     * 同步店铺下所有插件+软件的服务期（不包括权益商品）
     *
     * @param kdtId
     */
    public void concurrentStatus(Long kdtId) {
        //String ycmAppId = getYcmAppId(appId);

        //根据kdtId查询店铺下所有的插件&软件服务期（权益不包括）
        //查询服务期的sql语句
        List<PfOrderStatus> pfOrderStatusList = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().select("DISTINCT app_id")
                .eq("apply_ycm_id", kdtId)
                .eq("apply_ycm_type", "KDT_ID"));
        List<String> appIds = new ArrayList<>();

        //刷新店铺内所有服务期的缓存,同步服务期
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        //flushAppStatusRequest.setAppId(ycmAppId);
        flushAppStatusRequest.setKdtId(String.valueOf(kdtId));
        pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        for (PfOrderStatus pfOrderStatus : pfOrderStatusList) {
            Long yopId = getYopAppId(pfOrderStatus.getAppId());
            //同步服务期
            marketRemoteService.concurrentStatus(kdtId, yopId.intValue());
        }
    }

    /**
     * 获取list1和list2不同的元素，用的时候一般调用两次，参数对换一下，分别对比出列表与另一个列表不一样的元素
     * @param list1
     * @param list2
     * @return
     */

    public List<String> getDiffrentString2(List<String> list1, List<String> list2) {
        long st = System.nanoTime();
        Map<String,Integer> map = new HashMap<String,Integer>(list1.size()+list2.size());
        List<String> diff = new ArrayList<>();
        for (String string : list1) {
            map.put(string, 1);
        }
        for (String string : list2) {
            Integer cc = map.get(string);
            if(cc!=null)
            {
                map.put(string, ++cc);
                continue;
            }
            map.put(string, 1);
        }
        for(Map.Entry<String, Integer> entry:map.entrySet())
        {
            if(entry.getValue()==1)
            {
                diff.add(entry.getKey());
            }
        }
        System.out.println("total times "+(System.nanoTime()-st));
        return list1;
    }


    public List<String> getDiffrentString(List<String> list1, List<String> list2) {
        long st = System.nanoTime();
        List<String> diff = new ArrayList<String>();
        for(String str:list1)
        {
            if(!list2.contains(str))
            {
                diff.add(str);
            }
        }
        System.out.println("getDiffrent total times "+(System.nanoTime()-st));
        return diff;
    }

    public List<List> getDiffrentString1(List<List> list1, List<List> list2) {
        long st = System.nanoTime();
        Map<List,Integer> map = new HashMap<List,Integer>(list1.size()+list2.size());
        List<List> diff = new ArrayList<>();
        for (List list : list1) {
            map.put(list, 1);
        }
        for (List list : list2) {
            Integer cc = map.get(list);
            if(cc!=null)
            {
                map.put(list, ++cc);
                continue;
            }
            map.put(list, 1);
        }
        for(Map.Entry<List, Integer> entry:map.entrySet())
        {
            if(entry.getValue()==1)
            {
                diff.add(entry.getKey());
            }
        }
        System.out.println("total times "+(System.nanoTime()-st));
        return list1;
    }

//    public String listToString(List list, char separator) {
//        StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < list.size(); i++) {
//            sb.append(list.get(i)).append(separator);
//        }
//        return list.isEmpty()?"":sb.toString().substring(0, sb.toString().length() - 1);
//    }

    public String listToString(List<String> list, char separator) {
        return org.apache.commons.lang.StringUtils.join(list.toArray(),separator);
    }

    /**
     * 清理券数据（吴吴使用，不适合其他人）
     * @param couponId
     */
    public void deleteCouponData(Long couponId) {
        logger.info("-----------开始清理礼包券配置信息----------");
        logger.info("-----------礼包券id+" + couponId + "----------");
//        couponMapper.delete(new QueryWrapper<MkCoupon>().eq("id", couponId));
//        couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().eq("coupon_id", couponId));
//        couponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshot>().eq("coupon_id", couponId));
        couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().eq("coupon_id", couponId).ne("id",169310));
        List<MkCouponSendRecord> mkCouponSendRecordList = couponSendRecordMapper.selectList(new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId));
        couponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId).ne("id",3603));

        if (mkCouponSendRecordList.size() > 0) {
            for (MkCouponSendRecord mkCouponSendRecord:mkCouponSendRecordList) {
                couponSendRecordDetailMapper.delete(new QueryWrapper<MkCouponSendRecordDetail>().eq("send_record_id", mkCouponSendRecord.getId()).ne("id",167105));

            }
        }
    }

    /**
     * 清理券数据（从雷飞云那copy来的）
     *
     * @param couponId
     */
    public void deleteCouponDataAll(Long couponId) {
        logger.info("-----------开始清理礼包券配置信息----------");
        logger.info("-----------礼包券id+" + couponId + "----------");
        couponMapper.delete(new QueryWrapper<MkCoupon>().eq("id", couponId));
        couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().eq("coupon_id", couponId));
        couponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshot>().eq("coupon_id", couponId));
        couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().eq("coupon_id", couponId));
        List<MkCouponSendRecord> mkCouponSendRecordList = couponSendRecordMapper.selectList(new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId));
        couponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecord>().eq("coupon_id", couponId));

        if (mkCouponSendRecordList != null) {
            for(MkCouponSendRecord mkCouponSendRecord : mkCouponSendRecordList)
                couponSendRecordDetailMapper.delete(new QueryWrapper<MkCouponSendRecordDetail>().eq("send_record_id", mkCouponSendRecord.getId()));
        }
    }

    public void enableAllPromotion(Long kdtId,String kdtName,Integer itemId,int quantity) {
        List<Byte> promotionList = new ArrayList<>();
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);

        CalOrderPriceForm calOrderPriceForm = ConstructionParam.getCalOrderPriceForm(kdtId, kdtName, orderItemFormList);
        PlainResult<CalOrderPriceApi> calOrderPriceApiPlainResult = orderRemoteService.calOrderPrice(calOrderPriceForm);
        logger.info("确认订单-订单计算返回数据：{}",JSON.toJSON(calOrderPriceApiPlainResult));

        //获取软件商品级优惠
        List<PreferentialDescApi> itemPromotionList = calOrderPriceApiPlainResult.getData().getItems().get(0).getItemPromotionList();

        for(PreferentialDescApi itemPromotion:itemPromotionList) {
            promotionList.add(itemPromotion.getType());
        }


        List<PreferentialDescApi> orderPromotionList = new ArrayList<>();
        //将订单级别优惠传入参数
        //满减优惠,并过滤掉selected = false的优惠

        for(int OrderPromotionNum = 0;OrderPromotionNum < calOrderPriceApiPlainResult.getData().getOrderPromotionList().size();OrderPromotionNum++) {
            List<PreferentialDescApi> getFullReduceList = calOrderPriceApiPlainResult.getData().getOrderPromotionList().get(OrderPromotionNum).getOrderPromotionMutexList().
                    stream().filter(v -> v.getSelected()!=false).collect(Collectors.toList());
            orderPromotionList.addAll(getFullReduceList);
        }

        for(PreferentialDescApi orderPromotion:orderPromotionList) {
            promotionList.add(orderPromotion.getType());
        }

        logger.info("活动ID：{}",promotionList);

        //if(!promotionList.contains(22))


        //获取软件订单级优惠

        //根据所有营销type进行对比，得到没有得营销类型

        //
    }

    public boolean getAppStatusByKdtIdAndAppId(Long kdtId, Long appId) {
        String ycmAppId = getYcmAppId(appId);
        //查询有效的订单服务期的sql语句
        Wrapper<PfOrderStatus> queryWrapper = new QueryWrapper<PfOrderStatus>()
                .eq("apply_kdt_id", kdtId)
                //.eq("apply_ycm_type", "KDT_ID")
                .eq("app_id", ycmAppId)
                .eq("state", "valid")
                //.eq("group_type", "product_with_paid")
                .gt("expire_time",now());

        //校验微商城服务期生成
        List<PfOrderStatus> pfOrderStatusList = pfOrderStatusMapper.selectList(queryWrapper);
        if (pfOrderStatusList.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * 设置店铺的team_close value为0，即：店铺不为打烊状态
     * @param kdtId
     */
    public void setShopTeamCloseConfig(Long kdtId,String value) {
        ShopConfigSetRequest shopConfigSetRequest = new ShopConfigSetRequest();

        shopConfigSetRequest.setKdtId(kdtId);
        shopConfigSetRequest.setKey("team_close");
        shopConfigSetRequest.setValue(value);
        OperatorDTO operatorDTO  = new OperatorDTO();
        operatorDTO.setFromApp("CI_TEST");
        operatorDTO.setId(111L);
        operatorDTO.setName("SHANGYEHUA");
        operatorDTO.setType(1);
        shopConfigSetRequest.setOperator(operatorDTO);

        PlainResult<Boolean> setShopConfigResult = shopConfigWriteService.setShopConfig(shopConfigSetRequest);


        if (!setShopConfigResult.isSuccess()) {
            logger.error("设置team_close失败");
            throw new BusinessException("设置team_close失败" + JSON.toJSONString(setShopConfigResult));
        }
    }

    /**
     * 设置试用期时间为当前时间到7天后
     * @param kdtId
     */
    public void setShopTryTime(Long kdtId) {
        Date beginTime = now();
        Calendar calendar = Calendar.getInstance();//日历对象
        calendar.setTime(now());
        calendar.add(Calendar.DATE,7);
        Date endtIme = calendar.getTime();

        String status = "try";
        /**更新店铺 shop_prod_version_relation 表
         * lifecycle_status = 'try';
         * lifecycle_begin_time = now();
         * lifecycle_end_time = now()+7day
         */

        //获取shop_prod_version_relation 表数据
        ShopProdVersionRelation shopProdVersionRelation = shopProdVersionRelationMapper.selectOne(new QueryWrapper<ShopProdVersionRelation>()
                .eq("kdt_id",kdtId)
                .eq("prod_code","wsc"));
        shopProdVersionRelation.setLifecycleBeginTime(beginTime);
        shopProdVersionRelation.setLifecycleEndTime(endtIme);
        shopProdVersionRelation.setLifecycleStatus(status);
        shopProdVersionRelationMapper.updateById(shopProdVersionRelation);

        /**更新店铺 shop_prod_relation 表
         * lifecycle_status = 'try';
         * begin_time = now();
         * end_time = now()+7day
         */
        //获取shop_prod_relation 表数据
        ShopProdRelation shopProdRelation = shopProdRelationMapper.selectOne(new QueryWrapper<ShopProdRelation>()
                .eq("kdt_id",kdtId)
                .eq("prod_code","wsc"));
        shopProdRelation.setBeginTime(beginTime);
        shopProdRelation.setEndTime(endtIme);
        shopProdRelation.setLifecycleStatus(status);
        shopProdRelationMapper.updateById(shopProdRelation);

        //设置team_close状态为0
        setShopTeamCloseConfig(kdtId,"0");

        //清两个数据表的缓存
        String key = String.format(KvdsConstants.SHOP_PROD_RELATION,kdtId);
        redisClient.opsForKey().del(key);

    }

    /**
     * 初始化店铺产品生命周期
     * @param kdtId
     * @param prodCode
     */
    public void initLifecycle(Long kdtId,String prodCode) {
        PlainResult<Boolean> result =lifecycleWriteService.initLifecycle(kdtId,prodCode);
        if (!result.isSuccess()){
            logger.error("初始化店铺：{} 失败",kdtId);
            throw new BusinessException("初始化店铺：{} 失败" + JSON.toJSONString(result));        }
    }


    /**
     * 开启销售礼包 关闭用PromotionRemoteService:closeKdtPromotion
     * @param kdtId
     * @param preferentialId
     * @param promotionId
     * @param salesId
     */
    public void enableKdtPromotion(Long kdtId,Integer preferentialId,Long promotionId,Long salesId) {
        EnablePromotionParam enablePromotionParam = new EnablePromotionParam();
        enablePromotionParam.setKdtId(kdtId);
        enablePromotionParam.setPreferentialId(preferentialId);
        enablePromotionParam.setPromotionId(promotionId);
        enablePromotionParam.setSalesId(salesId);
        PlainResult<Boolean> result = promotionRemoteService.enableKdtPromotion(enablePromotionParam);

        logger.info("开启销售开启礼包结果：{}",JSON.toJSONString(result));
        if (result.getData()) {
            logger.error("开启销售礼包：{} 失败", kdtId);
            throw new BusinessException("开启销售礼包失败，开启结果：" + JSON.toJSONString(result));
        }

    }


    /**
     * 凭证支付审核，有待审核的则将待审核的订单置为fail，无则直接返回
     * @param kdtId
     * @param status
     * 成功-"SUCCESS"
     * 失败-"FAIL"
     * @return
     */
    public String commonAcceptPaymentMessage(Long kdtId, String status) {
//        Map header = new HashMap();
//        header.put("Content-Type", "application/json;charset=UTF-8");

        //根据收单号查询cent、outBizNo、partnerId
        TdPayOrder tdPayOrder = tdPayOrderMapper.selectOne(new QueryWrapper<TdPayOrder>()
                .eq("payer_id",kdtId)
                .eq("state","WAIT_V"));
        if(null == tdPayOrder) {
            return null;
        }
        long cent1 = tdPayOrder.getApplyAmt();
        Map<String,Object> payAmount = new HashMap<>();
        payAmount.put("cent",cent1);
        Map<String, Object> uniformPayEvent = new HashMap<>();
        uniformPayEvent.put("payTool","TRANSFER_VOUCHER");
        uniformPayEvent.put("payAmount",payAmount);
        uniformPayEvent.put("outBizNo",tdPayOrder.getTdNo());
        uniformPayEvent.put("partnerId",tdPayOrder.getPartnerId());
        uniformPayEvent.put("acquireNo", tdPayOrder.getPayAcquireNo());
        uniformPayEvent.put("status", status);

        String stringResult = tradeHttp.doPostReturnResponse("/test/acceptPaymentMessage", uniformPayEvent);

        return stringResult;
    }

    /**
     * 凭证支付审核
     * @param acquireNo
     * @param status
     * 成功-"SUCCESS"
     * 失败-"FAIL"
     * @return
     */
    public String acceptPaymentMessage(String acquireNo, String status) {
//        Map header = new HashMap();
//        header.put("Content-Type", "application/json;charset=UTF-8");

        //根据收单号查询cent、outBizNo、partnerId
        TdPayOrder tdPayOrder = tdPayOrderMapper.selectOne(new QueryWrapper<TdPayOrder>()
                .eq("pay_acquire_no",acquireNo));

        //因为这个方法一般是在凭证支付的时候使用，所以一定是有一笔待审核的订单的，如果没有则需要跑抛出错误
        Assert.assertNotEquals(tdPayOrder,null,"未找到待审核的订单");

        long cent1 = tdPayOrder.getApplyAmt();
        Map<String,Object> payAmount = new HashMap<>();
        payAmount.put("cent",cent1);
        Map<String, Object> uniformPayEvent = new HashMap<>();
        uniformPayEvent.put("payTool","TRANSFER_VOUCHER");
        uniformPayEvent.put("payAmount",payAmount);
        uniformPayEvent.put("outBizNo",tdPayOrder.getTdNo());
        uniformPayEvent.put("partnerId",tdPayOrder.getPartnerId());
        uniformPayEvent.put("acquireNo", acquireNo);
        uniformPayEvent.put("status", status);

        String stringResult = tradeHttp.doPostReturnResponse("/test/acceptPaymentMessage", uniformPayEvent);

        return stringResult;
    }


    public Date getTomorrow() {
        Date day=new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(day);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        return calendar.getTime();
    }

    public Long createSelfOrder(Long kdtId,int itemId) {
        Long appId = 1000447967L;

        //1. 创建一个订单
        PlainResult<Long> createOrderResult = createOrder(kdtId, "CI-test", itemId, 1, 0L);
        Assert.assertEquals(createOrderResult.getCode(),200,createOrderResult.getMessage());
        //付款
        if (createOrderResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(createOrderResult.getData()), (byte) 4);
            //cashierPay(preparePayApiPlainResult, account, wscKdtId);
            Assert.assertEquals(preparePayApiPlainResult.isSuccess(),true,preparePayApiPlainResult.getMessage());
        }
        Long tdOrderId = createOrderResult.getData();
        waitForPerform(kdtId,appId,tdOrderId);
        return tdOrderId;
    }


    public List<Long> getGiftTempleId(Long couponId) {
        //从mk activity rule里找出presentId
        List<Long> giftTempleIds = new ArrayList<>();
        List<MkCouponRule> mkCouponRuleList = couponRuleMapper.selectList(new QueryWrapper<MkCouponRule>().lambda().eq(MkCouponRule::getCouponId,couponId));
        for(MkCouponRule mkCouponRule:mkCouponRuleList) {
            JSONArray jsonArray = JSONArray.parseArray(mkCouponRule.getActions());
            String presentId = jsonArray.getJSONObject(0).getString("presentId");

            //根据presentId获取giftTempleId
            MkPresentGift mkPresentGift = mkPresentGiftMapper.selectOne(new QueryWrapper<MkPresentGift>().lambda().eq(MkPresentGift::getPresentId,presentId));
            Long giftTempleId = mkPresentGift.getGiftTemplateId();
            giftTempleIds.add(giftTempleId);
        }

        return giftTempleIds;
    }

    public List<Long> getCouponPresentId(Long couponId) {
        //从mk coupon rule里找出presentId
        List<Long> presentIdList = new ArrayList<>();
        List<MkCouponRule> mkCouponRuleList = couponRuleMapper.selectList(new QueryWrapper<MkCouponRule>().lambda().eq(MkCouponRule::getCouponId,couponId));
        for(MkCouponRule mkCouponRule: mkCouponRuleList) {
            JSONArray jsonArray = JSONArray.parseArray(mkCouponRule.getActions());
            String presentId = jsonArray.getJSONObject(0).getString("presentId");
            presentIdList.add(Long.valueOf(presentId));
        }

        return presentIdList;
    }


    public List<Long> getActivityPresentId(Long activityId) {
        //从mk activity rule里找出presentId
        List<Long> presentIdList = new ArrayList<>();
        List<MkActivityRule> mkActivityRuleList = activityRuleMapper.selectList(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId,activityId));
        for(MkActivityRule mkActivityRule: mkActivityRuleList) {
            JSONArray jsonArray = JSONArray.parseArray(mkActivityRule.getActions());
            String presentId = jsonArray.getJSONObject(0).getString("presentId");
            presentIdList.add(Long.valueOf(presentId));
        }

        return presentIdList;
    }

    /**
     * 删除所有买赠礼包活动相关数据
     * @param id
     */
    public void deletePresentActivity(Long id) {
        //如果是买赠礼包，则需要删除mk_activity,mk_activity_rule,mk_present,mk_present_gift,gf_template,gf_template_goods
        List<Long> presentIds = getActivityPresentId(id);
        List<Long> giftTempleIds = getGiftTempleId(id);
        activityMapper.deleteById(id);
        activityRuleMapper.delete(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId,id));
        for(Long presentId:presentIds) {
            mkPresentGiftMapper.deleteById(presentId);
            mkPresentMapper.deleteById(presentId);

        }
        for(Long giftTempleId:giftTempleIds) {
            gfTemplateMapper.deleteById(giftTempleId);
            gfTemplateGoodsMapper.delete(new QueryWrapper<GiftTemplateGoods>().lambda().eq(GiftTemplateGoods::getTemplate_id,giftTempleId));
        }

    }


    /**
     * 删除买赠券活动所有相关数据
     * @param id
     */
    public void deleteCouponActivity(Long id) {
        //如果是买赠券，则需要删除mk_coupon,mk_coupon_rule,mk_present,mk_present_gift,gf_template,gf_template_goods
        List<Long> presentIds = getCouponPresentId(id);
        List<Long> giftTempleIds = getGiftTempleId(id);
        couponMapper.deleteById(id);
        couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().lambda().eq(MkCouponRule::getCouponId,id));
        for(Long presentId:presentIds) {
            mkPresentGiftMapper.deleteById(presentId);
            mkPresentMapper.deleteById(presentId);
        }
        for(Long giftTempleId:giftTempleIds) {
            gfTemplateMapper.deleteById(giftTempleId);
            gfTemplateGoodsMapper.delete(new QueryWrapper<GiftTemplateGoods>().lambda().eq(GiftTemplateGoods::getTemplate_id,giftTempleId));
        }
    }

}
