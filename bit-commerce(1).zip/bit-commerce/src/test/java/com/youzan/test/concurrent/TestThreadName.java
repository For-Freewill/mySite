package com.youzan.test.concurrent;

import com.youzan.api.common.response.PlainResult;
import com.youzan.platform.service_chain.context.ServiceChainContext;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.redeemcode.RedeemCodeRemoteService;
import com.youzan.ycm.market.request.redeemcode.AcquireRedeemCodeRequest;
import com.youzan.ycm.market.response.redeemcode.AcquireRedeemCodeResponse;
import lombok.SneakyThrows;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;


/**
 * @author leifeiyun
 * @date 2021/1/6
 **/
public class TestThreadName extends ConcurrentBaseTest {
    @Dubbo
    RedeemCodeRemoteService redeemCodeRemoteService;

    @SneakyThrows
    @DataProvider(parallel = true, name = "acquireData")
    public Object[][] datas() {
        Object[][] objects = new Object[][]{
                {"lfy0"},
                {"lfy1"},
                {"lfy2"}
        };
        Thread.sleep(1000);
        logger.info("dataProvider:"+Thread.currentThread().getId()+"："+Thread.currentThread().getName());
        return objects;
    }

    @SneakyThrows
    @Test(threadPoolSize = 5, invocationCount = 100, dataProvider = "acquireData")
    public void testRedeemConcurrent(String acquireBizNo) {

        logger.info("acquireBizNo:"+acquireBizNo+":当前method线程信息" + Thread.currentThread().getId() + ":" + Thread.currentThread().getName());
    }
}
