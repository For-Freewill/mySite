package com.youzan.test.market.basecase.activity;//package com.youzan.test.basecase.market.activity;
//
//import com.youzan.test.basecase.DeductBaseTest;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * @author wuwu
// * @date 2021/1/25 8:37 PM
// */
//public class DiscountActivityTest extends DeductBaseTest {
//    Logger logger = LoggerFactory.getLogger(DiscountActivityTest.class);
//
//
//}
