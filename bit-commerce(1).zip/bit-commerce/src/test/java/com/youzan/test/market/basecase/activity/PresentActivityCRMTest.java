package com.youzan.test.market.basecase.activity;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponAsset;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.market.api.PresentRemoteService;
import com.youzan.ycm.market.request.present.DistributeStockToKdtRequest;
import com.youzan.ycm.market.response.present.DistributeStockToKdtResponse;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.apache.commons.collections.CollectionUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-03-25 15:32
 **/
public class PresentActivityCRMTest extends TnBaseTest {

    //WSC店铺
    public static Long COUPONKDTID = 59445351L;
    public static String COUPONKDTIDNAME = "买赠券CI使用店铺";

    @JSONData(value = "dataResource/apicase.market/OrderWithPresentActivityRequestData.json", key = "createOrderFormWithCRM")
    private CreateOrderForm createOrderFormWithCRM;

    @Dubbo
    PresentRemoteService presentRemoteService;

    @BeforeMethod
    public void init() {
        try {
            sleep(1000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * 1、biz后台创建买赠券，活动名称：营销买赠券CI专用-勿动；对应的配置：产品线为微商城单店；新签&续签&回签；CRM配额开启；
     * 2、电商2021百度小程序基础版订购 + 礼包名称：营销买赠券CI专用-勿动
     * 验证：买赠券，可以订购
     */
    @Test
    public void presentActivityTest() {
        Long couponId = null;

        List<MkCouponAsset> mkCouponAssetsList = new ArrayList<>();
        try {
            //1、创建一个买赠券
            couponId = createPresentCoupon().getData();

            //2、店铺充值
            rechargeShopBalance(COUPONKDTID.toString(), 99999999);

            //3、如果有未关闭订单，先关闭
            closeWaitPayOrder(COUPONKDTID);

            //4、退服务期，使得该店铺可以作为新购店铺重新使用
            refundOrderByKdtId(COUPONKDTID);

            //5、订购  产品线是WSC，预期买赠活动可用
            rechargeShopBalance(COUPONKDTID.toString(), 99999999);

            closeWaitPayOrder(COUPONKDTID);

            refundOrderByKdtId(COUPONKDTID);

            PlainResult<String> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                        @Override
                        public PlainResult<String> doExecute() {
                            return orderRemoteService.createNormalOrder(createOrderFormWithCRM);
                        }

                        @Override
                        public boolean handleResult(PlainResult<String> plainResult) {
                            return plainResult.getCode() == 200;
                        }
                    }, 5, 100);
            try {
                sleep(3000);
            } catch (Throwable e) {
                e.printStackTrace();
            }

            Assert.assertEquals(plainResult.getCode(), 200);

            if (plainResult.getCode() == 200) {
                //5.1、预支付
                PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.parseLong(plainResult.getData()), (byte) 4);
                Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

                //5.2、余额支付
                cashierPay(preparePayApiPlainResult, account, COUPONKDTID);
            }

            //5.3、查一下订单表，确认数据确实生成
            List<TdOrder> tdOrderRecords = queryTdOrderByKdtIdAndState(COUPONKDTID);
            Assert.assertTrue(CollectionUtils.isNotEmpty(tdOrderRecords));

            //6、发放到指定的某一个店铺
            DistributeStockToKdtRequest distributeStockToKdtRequest = new DistributeStockToKdtRequest();
            distributeStockToKdtRequest.setBizNo(tdOrderRecords.get(0).getTdNo());
            distributeStockToKdtRequest.setBizType("YCM_TRADE_NO");
            distributeStockToKdtRequest.setKdtId(COUPONKDTID);
            distributeStockToKdtRequest.setDistributeStock(1L);
            distributeStockToKdtRequest.setPromotionType("COUPON");
            distributeStockToKdtRequest.setPromotionId(couponId);
            distributeStockToKdtRequest.setTargetProdLine("WSC");
            PlainResult<DistributeStockToKdtResponse> distributeStockToKdtResult = presentRemoteService.distributeStockToKdt(distributeStockToKdtRequest);
            Assert.assertEquals(distributeStockToKdtResult.getCode(), 200);
            Assert.assertTrue(distributeStockToKdtResult.getData().getDistributeSuccess());

            //7、验证下该券确实发到该店铺，且是已领取待回收状态
            mkCouponAssetsList = couponAssetMapper.selectList(new QueryWrapper<MkCouponAsset>().lambda().eq(MkCouponAsset::getCouponId, couponId).orderByDesc(MkCouponAsset::getCreatedAt));
            Assert.assertTrue(CollectionUtils.isNotEmpty(mkCouponAssetsList));
            Assert.assertEquals(mkCouponAssetsList.get(0).getState(), "RECEIVED");
        } finally {
            //清理掉券资产表
            mkCouponAssetsList.forEach(item -> {
                couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().eq("id", item.getId()));
            });
            couponInvalid(couponId);
            deletePresentCouponData();
        }
    }
}
