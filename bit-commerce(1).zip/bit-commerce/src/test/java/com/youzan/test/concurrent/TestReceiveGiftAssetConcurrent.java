package com.youzan.test.concurrent;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.enums.market.coupon.CouponAssetStateEnum;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.gift.api.GiftAssetRemoteService;
import com.youzan.ycm.gift.request.ReceiveGiftAssetRequest;
import com.youzan.ycm.gift.response.ReceiveGiftAssetResponse;
import com.youzan.ycm.market.api.CouponAssetRemoteService;
import com.youzan.ycm.market.constant.YcmIDTypeConstant;
import com.youzan.ycm.market.request.couponasset.SaveCouponAssetRequest;
import com.youzan.ycm.market.response.couponasset.SaveCouponAssetResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * 并发领取礼包资产
 *
 * @author leifeiyun
 * @date 2021/1/6
 **/
public class TestReceiveGiftAssetConcurrent extends ConcurrentBaseTest {

    @Dubbo
    GiftAssetRemoteService giftAssetRemoteService;


    @DataProvider(parallel = true,name="receiveGiftAssetData")
    public Object[][] datas() {
       Object[][] objects = new Object[][]{
               {"2015870050428236004"}
       };
       return objects;
    }

    @Test(threadPoolSize=5, invocationCount=10,dataProvider = "receiveGiftAssetData")
    public void testReceiveGiftAssetConcurrent(String assetId){

        ReceiveGiftAssetRequest request = new ReceiveGiftAssetRequest();
        request.setGiftAssetId(Long.valueOf(assetId));
        request.setGiftAssetIdStr(assetId);

        PlainResult<ReceiveGiftAssetResponse> result =  giftAssetRemoteService.receiveGiftAsset(request);
        logger.info("ReceiveGiftAssetResponse.getData()--》："+result.getData());
    }
}
