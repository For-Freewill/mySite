package com.youzan.test.cloudService.apicase.yop;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.status.ServiceDetailApi;
import com.youzan.yop.api.form.status.SearchCurrentShopServiceDetailForm;
import org.apache.commons.collections.CollectionUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * create：2021/09/02
 * @大爷
 */

public class ListCurrentShopServiceDetailTest extends YunBaseTest {
    public static Long wsc_basic = 60334094L;
    public static String appId="44521";
    public static String state ="EFFECT";

    @Dubbo
    public AppStatusRemoteService appStatusRemoteService;

    @Test
    //查询当前店铺下订购插件详情：
    public void ListCurrentShopServiceDetailTestFx() {
        PlainResult<PageApi<ServiceDetailApi>> result = appStatusRemoteService.listCurrentShopServiceDetail(form(wsc_basic,appId,state));
        logger.info(JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);

    }

    //查询非当前店铺下的插件详情
    @Test
    public void ListCurrentShopServiceDetailTestFx2(){
        PlainResult<PageApi<ServiceDetailApi>> result = appStatusRemoteService.listCurrentShopServiceDetail(form(wsc_basic,"34802",state));
        logger.info(JSON.toJSONString(result));
        PageApi<ServiceDetailApi> data = result.getData();
        logger.info(JSON.toJSONString(data));
        Assert.assertTrue(CollectionUtils.isEmpty(data.getContent()));
        Assert.assertEquals(data.getTotalPages(),0);

    }


    public SearchCurrentShopServiceDetailForm form(Long kdtId, String appId, String state) {
        SearchCurrentShopServiceDetailForm searchCurrentShopServiceDetailForm = new SearchCurrentShopServiceDetailForm();
        searchCurrentShopServiceDetailForm.setKdtId(kdtId);
        searchCurrentShopServiceDetailForm.setAppId(appId);
        searchCurrentShopServiceDetailForm.setState(state);
        searchCurrentShopServiceDetailForm.setPageNumber(1);
        searchCurrentShopServiceDetailForm.setPageSize(20);
        return searchCurrentShopServiceDetailForm;

    }
}
