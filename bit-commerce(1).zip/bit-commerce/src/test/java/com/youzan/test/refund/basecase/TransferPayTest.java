package com.youzan.test.refund.basecase;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.pay.unified.cashier.api.request.v3.result.PreOrderPayResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wuwu
 * @date 2021/3/1 1:43 PM
 */
public class TransferPayTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(TransferPayTest.class);

    @Test(enabled = false)
    public void transferPayTest() {
        closeWaitPayOrder(payKdtId);
        recycleGiftAssetByKdtId(payKdtId);
        try{
            refundOrderByAll(payKdtId);
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        commonAcceptPaymentMessage(payKdtId,"FAIL");
        rechargeYzcoin(payKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(payKdtId), cny + 1000);
        concurrentStatus(payKdtId);

        //创建凭证支付订单
        PlainResult<String> createOrderResult = createNormalOrder(payKdtId, payKdtName, basicWechatItemId, 1, 0L);
        logger.info("新的创建订单结果是：{}", createOrderResult);
        Assert.assertEquals(createOrderResult.getCode(), 200, createOrderResult.getMessage());

        PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(createOrderResult.getData()), (byte) 4);
        logger.info(JSON.toJSONString(preparePayApiPlainResult));
        PlainResult<PreOrderPayResult> preOrderResult = transferPayOrder(payKdtId,preparePayApiPlainResult);

        waitForTdPayOrderDAta(Long.valueOf(createOrderResult.getData()));
        String msgResult =  acceptPaymentMessage(preOrderResult.getData().getTargetId(),"SUCCESS");
        logger.info("审核结果："+msgResult);
        Assert.assertNotEquals(getPfOrderIdByTdOrderId(Long.valueOf(createOrderResult.getData())),null,"获取子订单id失败");

        //等待服务期履约
        waitForPerform(payKdtId,873L,Long.valueOf(createOrderResult.getData()));

        //退款
        PlainResult<Boolean> refundResult = refundOrderByAll(getPfOrderIdByTdOrderId(Long.valueOf(createOrderResult.getData())));

        if(refundResult.getCode() == 152200) {
            logger.info(refundResult.getMessage());
        }
        waitForRefund(payKdtId,873L,Long.valueOf(createOrderResult.getData()));
    }

}
