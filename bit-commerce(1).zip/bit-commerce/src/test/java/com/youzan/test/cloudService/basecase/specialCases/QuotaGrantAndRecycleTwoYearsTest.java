package com.youzan.test.cloudService.basecase.specialCases;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * Created by wulei on 2020-07-29.
 */
public class QuotaGrantAndRecycleTwoYearsTest extends YunBaseTest {
    /**
     * 场景二：
     * 1、订购微商城基础版1年期；
     * 2、查询计费侧额度是否正常发放；
     * 3、判断是否可以预支；
     * 4、退款；
     * 5、查询计费测额度是否正常回收；
     * 6、继续订购微商城专业版两年期；
     * 7、查询计费侧额度是否正常发放，查询商业化侧是否生成延期发放记录；
     * 8、判断当前店铺是否可以预支；
     * 9、预支额度；
     * 10、查询计费侧额度是否正常发放；
     * 11、重复预支；
     * 12、退款；
     * 13、查询计费测额度是否正常回收。
     */

    //  两年期且额度未发放的情况
    @Test
    public void testQuatoGrantAndRecycleNotGrant() {

        long yunKdtId2 = newWscKdtId();

        PlainResult<OrderCreateApi> result1 = testCreateOrder(yunKdtId2, yunKdtName2, wscWXItemId_2021, 2);

        //  查询计费侧额度是否正常发放
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        testQueryTotalQuota(yunKdtId2, 10000);

        //  yop侧有一条延迟发放记录
        queryWaitPerformRecord(yunKdtId2, 1);

        //  退款
        Long payOrderId = result1.getData().getPayOrderId();

        refundOrderNew(payOrderId, new Date(), 0L, 0L, "BY_MANUAL");

        // 查看计费侧额度是否正常回收
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId2, 0);

        //  yop侧没有延迟发放记录
        queryWaitPerformRecord(yunKdtId2, 0);


        //testQuotaByRefund(yunKdtId1,311596167560335L,3158694128734521824L);
        //testQuotaByRefund(yunKdtId1,311596167685337L,3158694128734521880L);
    }

    //  两年期且额度发放的情况
//    @Test(enabled = false)
    @Test
    public void testQuatoGrantAndRecycleGranted() {

        long yunKdtId5 = newWscKdtId();
        PlainResult<OrderCreateApi> result2 = testCreateOrder(yunKdtId5, yunKdtName5, wscProfessionItemId_2021, 2);

        //  查询计费侧额度是否正常发放
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        testQueryTotalQuota(yunKdtId5, 20000);

        //  yop侧有一条延迟发放记录
        queryWaitPerformRecord(yunKdtId5, 1);

        //  手动发放额度
        Long payOrderId = result2.getData().getPayOrderId();
        updateEffectAndExpiretime(payOrderId);
        activeWaitPerformRecord(payOrderId);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //  查询额度
        testQueryTotalQuota(yunKdtId5, 40000);

        //  退款
        refundOrderNew(payOrderId, new Date(), 0L, 0L, "BY_MANUAL");

        // 查看计费侧额度是否正常回收
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId5, 0);

        //  yop侧没有延迟发放记录
        queryWaitPerformRecord(yunKdtId5, 0);
    }

    //手动回收额度

     /*   testQuotaByRefund(yunKdtId4, 311596624176033L,3158694128734574820L);
        testQuotaByRefund(yunKdtId7, 311596545066919L,3158694128734542472L);
        testQuotaByRefund(yunKdtId7,  311596595262925L,3158694128734542903L);*/

}


