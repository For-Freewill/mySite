package com.youzan.test.apicase.yop.ycmRefactorRemoteService;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.YcmRefactorRemoteService;
import com.youzan.yop.api.entity.CheckYcmShopApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wuwu
 * @date 2021/1/13 5:25 PM
 * @吴吴
 */
public class CheckIsYcmShopByKdtIdTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(CheckIsYcmShopByKdtIdTest.class);
    public Long yopKdtId = 51926873L;
    public Long ycmKdtId = 58815095L;
    public Long yopToYcmKdtId = 55941839L;
    @Dubbo
    public YcmRefactorRemoteService ycmRefactorRemoteService;
    @Test
    public void checkYopShopByKdtIdTest() {
        PlainResult<CheckYcmShopApi> result = ycmRefactorRemoteService.checkIsYcmShopByKdtId(yopKdtId);
        logger.info("店铺类型：{}", JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getData().getIsYcmShop(),Boolean.valueOf(false));
    }

    @Test
    public void checkYcmShopByKdtIdTest() {
        PlainResult<CheckYcmShopApi> result = ycmRefactorRemoteService.checkIsYcmShopByKdtId(ycmKdtId);
        logger.info("店铺类型：{}",JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getData().getIsYcmShop(),Boolean.valueOf(true));
    }

    @Test
    public void checkYopToYcmShopByKdtIdTest() {
        PlainResult<CheckYcmShopApi> result = ycmRefactorRemoteService.checkIsYcmShopByKdtId(yopToYcmKdtId);
        logger.info("店铺类型：{}",JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getData().getIsYcmShop(),Boolean.valueOf(true));
    }

    @Test
    public void checkShopByKdtIdWithNullTest() {
        PlainResult<CheckYcmShopApi> result = ycmRefactorRemoteService.checkIsYcmShopByKdtId(null);
        logger.info("店铺类型：{}",JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getMessage(),"系统错误，查询失败！");
    }

}
