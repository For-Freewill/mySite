package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.StartTest;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.promotion.crm.OpenAppCrmPromotionApi;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @program: bit-commerce
 * @description 根据preferentialId+kdtId查询优惠信息(兼容新老系统的营销活动)
 * @author: tianning
 * @create: 2021-03-24 13:17
 **/
public class GetPreferentialWithCompatibilityTest extends StartTest {

    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void getPreferentialWithCompatibilityTest() {
            Long kdtId = 58711819L;
            Integer preferentialId = 8406;
            PlainResult<OpenAppCrmPromotionApi> getPreferentialWithCompatibilityResult = promotionRemoteService.getPreferentialWithCompatibility(preferentialId, kdtId);
            Assert.assertEquals(getPreferentialWithCompatibilityResult.getCode(), 200);
    }

    /**
     * 异常用例 -- 赠品不存在
     */
    @Test
    public void getPreferentialWithCompatibilityNotExitTest() {
        Integer preferentialId = 1;
        Long kdtId = 58711819L;
        PlainResult<OpenAppCrmPromotionApi> getPreferentialWithCompatibilityResult = promotionRemoteService.getPreferentialWithCompatibility(preferentialId, kdtId);
        Assert.assertEquals(getPreferentialWithCompatibilityResult.getCode(), 130624);
    }
}
