package com.youzan.test.apicase.ycmJob.JobService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.StartTest;
import com.youzan.commerce.test.entity.dataobject.ycmJob.JbcJob;
import com.youzan.commerce.test.entity.dataobject.ycmJob.JbcTask;
import com.youzan.commerce.test.mapper.ycmJob.JbcJobMapper;
import com.youzan.commerce.test.mapper.ycmJob.JbcTaskMapper;
import com.youzan.commerce.test.utils.TimeUtils;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.job.api.JobService;
import com.youzan.ycm.job.api.RegisterService;
import com.youzan.ycm.job.api.TaskService;
import com.youzan.ycm.job.dto.CreateJobDTO;
import com.youzan.ycm.job.dto.ScheduleConfigDTO;
import com.youzan.ycm.job.request.JobActivateRequest;
import com.youzan.ycm.job.request.JobRegisterRequest;
import com.youzan.ycm.job.response.JobActivateResponse;
import com.youzan.ycm.job.response.JobRegisterResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @program: bit-commerce
 * @description  基本的任务注册，任务激活，任务删除，bizno随机生成
 * @author: tianning
 * @create: 2021-04-14 16:56
 **/

public class JobBaseForQueryJobTest extends StartTest {

    @Dubbo
    public TaskService taskService;
    @Dubbo
    public RegisterService registerService;
    @Dubbo
    public JobService jobService;

    @Autowired(required = false)
    public JbcJobMapper jbcJobMapper;
    @Autowired(required = false)
    public JbcTaskMapper jbcTaskMapper;

    public String jobName = "AsynchronousTaskForQueryForCI";
    public String jobNo = "";
    public String bizNo = "";
    public String applicationName = "bit-commerce";

    /**
     * 注册并激活任务
     */
    public String registerJobForQueryJobTest() {
        String bizNo = Long.toString(random());

        JobRegisterRequest jobRegisterRequest = new JobRegisterRequest();

        CreateJobDTO createJobDTO = new CreateJobDTO();
        createJobDTO.setApplicationName("bit-commerce");
        createJobDTO.setBizNo(bizNo);
        createJobDTO.setTaskCnt(10L);
        createJobDTO.setJobName(jobName);

        ScheduleConfigDTO scheduleConfigDTO = new ScheduleConfigDTO();
        scheduleConfigDTO.setDispatchWindowSize(20L);

        scheduleConfigDTO.setExecutableTime(TimeUtils.getTimeWithOffset(-1000L));
        scheduleConfigDTO.setTimeout(60L);

        jobRegisterRequest.setCreateJobDTO(createJobDTO);
        jobRegisterRequest.setScheduleConfigDTO(scheduleConfigDTO);

        PlainResult<JobRegisterResponse> registerJobResult = registerService.registerJob(jobRegisterRequest);
        Assert.assertEquals(registerJobResult.getCode(), 200);
        Assert.assertEquals(registerJobResult.getData().getJobDTO().getApplicationName(), "bit-commerce");
        Assert.assertEquals(registerJobResult.getData().getJobDTO().getJobName(), jobName);

        //此时只有主任务，没有子任务
        List<JbcJob> jbcJobList =
                jbcJobMapper.selectList(
                        new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getJobName, jobName).orderByDesc(JbcJob::getCreatedAt));
        Assert.assertTrue(CollectionUtils.isNotEmpty(jbcJobList));
        Assert.assertEquals(jbcJobList.get(0).getState(), registerJobResult.getData().getJobDTO().getState());

        jobNo = jbcJobList.get(0).getJobNo();

        //激活注册的任务
        JobActivateRequest jobActivateRequest = new JobActivateRequest();
        jobActivateRequest.setApplicationName("bit-commerce");
        jobActivateRequest.setBizNo(bizNo);
        jobActivateRequest.setJobName(jobName);

        PlainResult<JobActivateResponse> activateResult = registerService.activate(jobActivateRequest);
        Assert.assertEquals(activateResult.getCode(), 200);
        Assert.assertTrue(activateResult.getData().getIsActivateSuccess());

        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        //查询jobNo真的存在，主任务的状态:如果是立即执行，那么就是DOING；如果是等待一段时间执行，那么就是WAIT，这里面是立即执行，所以状态是DOING
        List<JbcJob> jbcJobActivateList =
                jbcJobMapper.selectList(
                        new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getJobName, jobName).orderByDesc(JbcJob::getCreatedAt));
        Assert.assertTrue(CollectionUtils.isNotEmpty(jbcJobActivateList));
        Assert.assertEquals(jbcJobActivateList.get(0).getState(), "DOING");

        //查询有子任务
        List<JbcTask> jbcTaskActivateList =
                jbcTaskMapper.selectList(
                        new QueryWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, jobNo).orderByDesc(JbcTask::getCreatedAt));

        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        Assert.assertTrue(CollectionUtils.isNotEmpty(jbcTaskActivateList));
        bizNo = jbcJobList.get(0).getBizNo();
        return bizNo;
    }

    /**
     * 删除任务
     */
    public void deleteJob() {
        List<JbcJob> jbcJobList =
                jbcJobMapper.selectList(
                        new QueryWrapper<JbcJob>().lambda().eq(JbcJob::getJobName, jobName).orderByDesc(JbcJob::getCreatedAt));
        if (CollectionUtils.isNotEmpty(jbcJobList)) {
            jbcJobList.forEach(item -> {
                jbcTaskMapper.delete(new UpdateWrapper<JbcTask>().lambda().eq(JbcTask::getJobNo, item.getJobNo()));
                jbcJobMapper.delete(new UpdateWrapper<JbcJob>().lambda().eq(JbcJob::getJobName, jobName));
            });
        }
    }

    /**
     * 生成随机数
     */
    public Long random() {
        return System.currentTimeMillis();
    }
}

