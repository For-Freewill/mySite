package com.youzan.test.checkTest.createOrderCheck;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.yop.api.entity.OfflineOrderFormV2;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.OrderItemFormV2;
import com.youzan.yop.api.response.CreateOfflineOrderResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.assertj.core.util.DateUtil.now;

/**
 * @author wuwu
 * @date 2020/12/24 11:17 AM
 */
public class FuwuPackageOrderTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(FuwuPackageOrderTest.class);

    public Long retailFuwuCheckKdtId = 59917613L;
    public String retailFuwuCheckKdtName = "CI-接口自动化-零售单店服务包";

    public Long retailFuwuCheckRenewKdtId = 59917410L;
    public String retailFuwuCheckRenewKdtName = "CI-接口自动化-零售单店服务包续费";

    public Long offlineKdtId = 59917739L;

    /**
     * 单独订购服务包
     */
    @Test
    public void createFuwuPackage() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrder
                (wscNoBuyKdtId,wscNoBuyKdtName,fuwuPackageItemId,1,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"新店上线服务（电商版）不允许单独订购",result.getMessage());

    }
    /**
     * 新购基础版 + 服务包
     */
    @Test
    public void createFuwuPackage1() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(basicWechatItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 新购基础版 不带服务包
     */
    @Test
    public void createFuwuPackageNewBasic() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrder
                (wscNoBuyKdtId,wscNoBuyKdtName,basicWechatItemId,1,0L);
        logger.info("创建服务包订单：{}",result);
        Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful",result.getMessage());

    }

    /**
     * 新购专业版，不带服务包
     */
    @Test
    public void createFuWuPackage2() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(professionItemId_2021),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040);
        Assert.assertEquals(result.getMessage(),"订购专业版，必须同时订购新店上线服务（电商版），请添加商品",result.getMessage());
    }

    /**
     * 新购旗舰版，不带服务包
     */
    @Test
    public void createFuWuPackage3() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(ultimateItemId_2021),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040);
        Assert.assertEquals(result.getMessage(),"订购旗舰版，必须同时订购新店上线服务（电商版），请添加商品",result.getMessage());

    }


    /**
     * 新购专业版+服务包
     */
    @Test
    public void createFuwuPackage4() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful");

    }

    /**
     * 新购旗舰版+服务包
     */
    @Test
    public void createFuwuPackage5() {
        closeWaitPayOrder(wscNoBuyKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscNoBuyKdtId,wscNoBuyKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful",result.getMessage());

    }

    /**
     * 续费基础版不带服务包
     */
    @Test
    public void createFuwuPackageRebewBasic() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,2,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        }

    /**
     * 续费基础版 + 服务包
     */
    @Test
    public void createFuwuPackage6() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,1,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        String tdOrderId = resultBasic.getData();
        //logger.info("tdorderid:{}",tdOrderId);
        //付款
        if (resultBasic.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultBasic.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(basicWechatItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());
    }


    /**
     * 续费专业版 + 服务包
     */
    @Test
    public void createFuwuPackage7() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 续费专业版 不带服务包
     */

    @Test
    public void createFuwuPackageRenewPro() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建专业版版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,professionItemId_2021,2,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());
    }

    /**
     * 续费旗舰版 +服务包
     */

    @Test
    public void createFuwuPackage8() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建专业版版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,ultimateItemId_2021,1,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());

        String tdOrderId = resultCreateOrder.getData();
        //付款
        if (resultCreateOrder.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultCreateOrder.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 续费旗舰版 不带服务包
     */

    @Test
    public void createFuwuPackageRenewUlt() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建专业版版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,ultimateItemId_2021,2,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());
    }


    /**
     * 升级到专业版 + 服务包
     */
    @Test
    public void createFuwuPackage9() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,2,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        //logger.info("tdorderid:{}",tdOrderId);
        //付款
        if (resultBasic.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultBasic.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(professionItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 升级到旗舰版 +服务包
     */
    @Test
    public void createFuwuPackage10() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,basicWechatItemId_2021,2,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

        //logger.info("tdorderid:{}",tdOrderId);
        //付款
        if (resultBasic.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultBasic.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 降级到专业版+服务包
     */
    @Test
    public void createFuwuPackage11() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建旗舰版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,ultimateItemId_2021,1,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());

        String tdOrderId = resultCreateOrder.getData();
        //付款
        if (resultCreateOrder.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(resultCreateOrder.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscAndPackageKdtId);
        }
        //移动服务期
        movePerformStatusByAppId(wscAndPackageKdtId,873L,-350);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (wscAndPackageKdtId,wscAndPackageKdtName,Arrays.asList(ultimateItemId_2021,fuwuPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（电商版），请删除商品",result.getMessage());

    }

    /**
     * 单独订购服务包
     */
    @Test
    public void createRetailFuwuPackage() {
        closeWaitPayOrder(retailFuwuCheckKdtId);
        PlainResult<String> result = createNormalOrder
                (retailFuwuCheckKdtId,retailFuwuCheckKdtName,retailPackageItemId,1,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"新店上线服务（同城零售版）不允许单独订购",result.getMessage());

    }
    /**
     * 新购基础版 + 服务包
     */
    @Test
    public void createRetailFuwuPackage1() {
        closeWaitPayOrder(retailFuwuCheckKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (retailFuwuCheckKdtId,retailFuwuCheckKdtName,Arrays.asList(retailBasicWechatItem,retailPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040,result.getMessage());
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（同城零售版），请删除商品",result.getMessage());

    }

    /**
     * 新购基础版 不带服务包
     */
    @Test
    public void createRetailFuwuPackageNewBasic() {
        closeWaitPayOrder(retailFuwuCheckKdtId);
        PlainResult<String> result = createNormalOrder
                (retailFuwuCheckKdtId,retailFuwuCheckKdtName,retailBasicWechatItem,1,0L);
        logger.info("创建服务包订单：{}",result);
        Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful",result.getMessage());

    }

    /**
     * 新购专业版，不带服务包
     */
    @Test
    public void createRetailFuWuPackage2() {
        closeWaitPayOrder(retailFuwuCheckKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (retailFuwuCheckKdtId,retailFuwuCheckKdtName,Arrays.asList(retailProfessionItem),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),141040);
        Assert.assertEquals(result.getMessage(),"订购专业版，必须同时订购新店上线服务（同城零售版），请添加商品",result.getMessage());
    }


    /**
     * 新购专业版+服务包
     */
    @Test
    public void createRetailFuwuPackage4() {
        closeWaitPayOrder(retailFuwuCheckKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (retailFuwuCheckKdtId,retailFuwuCheckKdtName,Arrays.asList(retailProfessionItem,retailPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        //Assert.assertEquals(result.getCode(),200,result.getMessage());
        Assert.assertEquals(result.getMessage(),"successful");

    }

    /**
     * 续费基础版不带服务包
     */
    @Test
    public void createRetailFuwuPackageRebewBasic() {
        closeWaitPayOrder(retailFuwuCheckRenewKdtId);
        refundOrderByKdtId(retailFuwuCheckRenewKdtId);
        // 创建基础版订单
        PlainResult<String> resultBasic = createNormalOrder(retailFuwuCheckRenewKdtId,retailFuwuCheckRenewKdtName,retailBasicWechatItem,2,0L);
        Assert.assertEquals(resultBasic.getCode(), 200, resultBasic.getMessage());

    }

    /**
     * 续费基础版 + 服务包
     */
    @Test
    public void createRetailFuwuPackage6() {
        closeWaitPayOrder(retailFuwuCheckRenewKdtId);
        refundOrderByKdtId(retailFuwuCheckRenewKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (retailFuwuCheckRenewKdtId,retailFuwuCheckRenewKdtName,Arrays.asList(retailBasicWechatItem,retailPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（同城零售版），请删除商品",result.getMessage());
    }


    /**
     * 续费专业版 + 服务包
     */
    @Test
    public void createRetailFuwuPackage7() {
        closeWaitPayOrder(retailFuwuCheckRenewKdtId);
        refundOrderByKdtId(retailFuwuCheckRenewKdtId);
        PlainResult<String> result = createNormalOrderWithMultiApp
                (retailFuwuCheckRenewKdtId,retailFuwuCheckRenewKdtName,Arrays.asList(retailProfessionItem,retailPackageItemId),2,0L);
        logger.info("创建服务包订单：{}",result);
        Assert.assertEquals(result.getMessage(),"该店铺不允许订购新店上线服务（同城零售版），请删除商品",result.getMessage());

    }

    /**
     * 续费专业版 不带服务包
     */

    @Test
    public void createRetailFuwuPackageRenewPro() {
        closeWaitPayOrder(wscAndPackageKdtId);
        refundOrderByKdtId(wscAndPackageKdtId);
        rechargeShopBalance(String.valueOf(wscAndPackageKdtId), cny + 1000);
        // 创建专业版版订单
        PlainResult<String> resultCreateOrder = createNormalOrder(wscAndPackageKdtId,wscAndPackageKdtName,professionItemId_2021,2,0L);
        Assert.assertEquals(resultCreateOrder.getCode(), 200, resultCreateOrder.getMessage());
    }


    /**
     * 线下订购服务包--可订购
     */

    @Test
    public void createOfflineWithPackage() {
        closeWaitPayOrder(offlineKdtId);
        OfflineOrderFormV2 offlineOrderFormV2 = buildOfflineOrderFormV2(offlineKdtId,10000,fuwuPackageItemId,1,false);
        PlainResult<CreateOfflineOrderResponse> result = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2);
        logger.info("订购微商城服务包结果："+ JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);
    }

    /**
     * 预落单服务包--可订购
     */
    @Test(enabled = false)
    public void createOfflineWithPackageAndOrderIsWaitForPay() {
        closeWaitPayOrder(offlineKdtId);
        OfflineOrderFormV2 offlineOrderFormV2 = buildOfflineOrderFormV2(offlineKdtId,10000,fuwuPackageItemId,1,true);
        Date createTime = now();
        PlainResult<CreateOfflineOrderResponse> result = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2);
        logger.info("订购微商城服务包结果："+ JSON.toJSONString(result));
        Assert.assertEquals(result.getCode(),200);
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("buyer_id",offlineKdtId).ge("created_at",createTime));
        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id",tdOrder.getTdNo()));

        Assert.assertEquals("CREATED",tdOrder.getState());
        Assert.assertEquals("OFFLINE_TO_ONLINE",tdOrder.getOrderWay());
        Assert.assertEquals(pfOrder.getTradeState(),"init");
        Assert.assertEquals(pfOrder.getPerformState(),"init");
    }


    /**
     *
     * @param kdtId
     * @param realPrice
     * @param itemId
     * @param quantity
     * @param isWaitForOrder 是否预落单
     * @return
     */
    public OfflineOrderFormV2 buildOfflineOrderFormV2(Long kdtId,Integer realPrice,Integer itemId, Integer quantity,Boolean isWaitForOrder) {
        OfflineOrderFormV2 offlineOrderFormV2 = new OfflineOrderFormV2();

        offlineOrderFormV2.setKdtId(kdtId.toString());
        offlineOrderFormV2.setNeedAdminSign((byte) 0);
        offlineOrderFormV2.setOperatorId(3046l);
        offlineOrderFormV2.setRealPrice(realPrice);
        offlineOrderFormV2.setType(0);
        offlineOrderFormV2.setDiscountAmount(0L);
        offlineOrderFormV2.setOriginPrice(0L);
        offlineOrderFormV2.setUserId(123L);
        if(isWaitForOrder) {
            offlineOrderFormV2.setWaitPayOrder(true);
        }
        List<OrderItemFormV2> items = new ArrayList<>();
        OrderItemFormV2 orderItemForm = new OrderItemFormV2();
        orderItemForm.setItemId(itemId);
        orderItemForm.setQuantity(quantity);
        orderItemForm.setBuyType((byte) 1);
        orderItemForm.setApplyKdtId(kdtId.toString());
        orderItemForm.setNewMigration(null);
        items.add(orderItemForm);

        offlineOrderFormV2.setItems(items);
        return offlineOrderFormV2;
    }

}
