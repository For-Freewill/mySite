/*
package com.youzan.test.apicase.yop.promotionRemoteService;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.promotion.ShopValidPromotionKdtJoinApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

*/
/**
 * @author wuwu
 * @date 2021/1/6 7:01 PM
 *//*

public class GetValidPromotionKdtJoinByKdtIdTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(GetValidPromotionKdtJoinByKdtIdTest.class);
    public Integer preferentialId1 =3299;
    public Integer preferentialId2 =3300;
    public Long crmPromotionId = 6595L;
    public Long salesId = 5718L;

    */
/**
     * 正常用例：kdtid下有销售开启礼包
     *//*

    @Test(enabled = false)
    public void getValidPromotionKdtJoinByKdtIdTest() {
        enableKdtPromotion(wscHasAllPromotionKdtId,preferentialId1,crmPromotionId,salesId);
        enableKdtPromotion(wscHasAllPromotionKdtId,preferentialId2,crmPromotionId,salesId);
        List<Long> kdtIds = Arrays.asList(wscHasAllPromotionKdtId);
        PlainResult<List<ShopValidPromotionKdtJoinApi>> result =  promotionRemoteService.getValidPromotionKdtJoinByKdtId(kdtIds);

        logger.info("result:{}", JSON.toJSONString(result));
        List<Integer> promotions = Arrays.asList(preferentialId1,preferentialId2);

        Assert.assertEquals(result.getData().size(),2,"该店铺有"+result.getData().size()+"个销售开启的礼包");
        for (ShopValidPromotionKdtJoinApi promotionKdtJoinApi:result.getData()) {
            Assert.assertEquals(promotions.contains(promotionKdtJoinApi.getPreferentialId()),true,"销售开启礼包id错误");
        }

    }

    */
/**
     * 参数的kdtid下无销售开启礼包
     *//*

    @Test(enabled = false)
    public void getValidPromotionKdtJoinByKdtIdWithNoGiftTest() {
        List<Long> kdtIds = Arrays.asList(wscKdtId);
        PlainResult<List<ShopValidPromotionKdtJoinApi>> result =  promotionRemoteService.getValidPromotionKdtJoinByKdtId(kdtIds);

        logger.info("result:{}", JSON.toJSONString(result));

        Assert.assertEquals(result.getData().size(),0,"该店铺有"+result.getData().size()+"个销售开启的礼包");
    }

    */
/**
     *  参数kdtid个数大于1
     *//*

    @Test(enabled = false)
    public void getValidPromotionKdtJoinByKdtIdsTest() {
        enableKdtPromotion(wscHasAllPromotionKdtId,preferentialId1,crmPromotionId,salesId);
        enableKdtPromotion(wscHasAllPromotionKdtId,preferentialId2,crmPromotionId,salesId);
        List<Long> kdtIds = Arrays.asList(wscKdtId,wscHasAllPromotionKdtId);
        PlainResult<List<ShopValidPromotionKdtJoinApi>> result =  promotionRemoteService.getValidPromotionKdtJoinByKdtId(kdtIds);

        logger.info("result:{}", JSON.toJSONString(result));

        Assert.assertEquals(result.getData().size(),2,"该店铺有"+result.getData().size()+"个销售开启的礼包");
        List<Integer> promotions = Arrays.asList(preferentialId1,preferentialId2);
        for (ShopValidPromotionKdtJoinApi promotionKdtJoinApi:result.getData()) {
            Assert.assertEquals(promotions.contains(promotionKdtJoinApi.getPreferentialId()),true,"销售开启礼包id错误");
        }
    }

    */
/**
     *  参数kdtid列表为空
     *//*

    @Test(enabled = false)
    public void getValidPromotionKdtJoinByKdtIdIsNullTest() {
        List<Long> kdtIds = new ArrayList<>();

        PlainResult<List<ShopValidPromotionKdtJoinApi>> result =  promotionRemoteService.getValidPromotionKdtJoinByKdtId(kdtIds);

        logger.info("result:{}", JSON.toJSONString(result));

        Assert.assertEquals(result.getData().size(),0,"该店铺有"+result.getData().size()+"个销售开启的礼包");
    }

    */
/**
     *  参数kdtid列表为不存在的店铺
     *//*

    @Test(enabled = false)
    public void getValidPromotionKdtJoinByKdtIdIsStringTest() {
        List<Long> kdtIds = Arrays.asList(111L);

        PlainResult<List<ShopValidPromotionKdtJoinApi>> result =  promotionRemoteService.getValidPromotionKdtJoinByKdtId(kdtIds);

        logger.info("result:{}", JSON.toJSONString(result));

        Assert.assertEquals(result.getData().size(),0,"该店铺有"+result.getData().size()+"个销售开启的礼包");
    }



}
*/
