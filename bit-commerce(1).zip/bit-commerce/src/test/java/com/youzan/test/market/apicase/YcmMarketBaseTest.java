package com.youzan.test.market.apicase;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponAsset;
import com.youzan.commerce.test.entity.dataobject.market.redeemCode.MkRedeemCodeConf;
import com.youzan.commerce.test.entity.dataobject.market.redeemCode.MkRedeemCodeContent;
import com.youzan.commerce.test.entity.dataobject.market.redeemCode.MkRedeemCodeRecord;
import com.youzan.commerce.test.mapper.market.coupon.CouponAssetMapper;
import com.youzan.commerce.test.mapper.market.redeem.MkRedeemCodeConfMapper;
import com.youzan.commerce.test.mapper.market.redeem.MkRedeemCodeContentMapper;
import com.youzan.commerce.test.mapper.market.redeem.MkRedeemCodeRecordMapper;
import com.youzan.test.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author tianning
 * @date 2020/8/9 11:12 下午
 */
public class YcmMarketBaseTest extends BaseTest {

    final static public Logger logger = LoggerFactory.getLogger(YcmMarketBaseTest.class);

    @Autowired(required = false)
    CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    MkRedeemCodeConfMapper mkRedeemCodeConfMapper;
    @Autowired(required = false)
    MkRedeemCodeContentMapper mkRedeemCodeContentMapper;
    @Autowired(required = false)
    MkRedeemCodeRecordMapper mkRedeemCodeRecordMapper;

    /**
     * 优惠券码数据删除操作
     */
    public void deleteRedeemCodeData(String redeemCode) {
        //注意删除数据的顺序
        MkRedeemCodeRecord mkRedeemCodeRecord = mkRedeemCodeRecordMapper.selectOne(new QueryWrapper<MkRedeemCodeRecord>()
                .eq("redeem_code", redeemCode));
        logger.info("-------开始清理券码【" + redeemCode + "】相关的信息------");

        //1.delete asset
        couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>()
                .eq("source_order_id", mkRedeemCodeRecord.getId())
                .eq("source_order_type", "REDEEM_CODE_RECORD"));
        logger.info("券资产信息已清理，source_order_id：-->" + mkRedeemCodeRecord.getId());

        //2.delete content
        mkRedeemCodeContentMapper.delete(new QueryWrapper<MkRedeemCodeContent>()
                .eq("rel_conf_id", mkRedeemCodeRecord.getRelConfId()));
        logger.info("券码内容相关信息已清理，rel_conf_id：--->" + mkRedeemCodeRecord.getRelConfId());
        //3.delete recordbelong_to_id
        mkRedeemCodeRecordMapper.delete(new QueryWrapper<MkRedeemCodeRecord>()
                .eq("rel_conf_id", mkRedeemCodeRecord.getRelConfId()));
        logger.info("券码记录相关信息已清理，rel_conf_id：--->" + mkRedeemCodeRecord.getRelConfId());

        //4.delete conf
        mkRedeemCodeConfMapper.delete(new QueryWrapper<MkRedeemCodeConf>()
                .eq("id", mkRedeemCodeRecord.getRelConfId()));
        logger.info("券码配置相关信息已清理，rel_conf_id：--->" + mkRedeemCodeRecord.getRelConfId());

    }

}
