package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.promotion.crm.OpenAppCrmPromotionApi;
import com.youzan.yop.api.form.promotion.OpenAppCrmPromotionForm;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @author wulei
 * @date 2020/9/28 19:00
 * 根据id查询优惠信息
 */
public class ListCrmPreferentialTest extends BaseTest {
    @Dubbo
    public PromotionRemoteService promotionRemoteService;

    /**
     * @desc 场景1:正常测试-查询礼包
     */
    @Test
    public void listCrmPreferentialNormalTest() {
        PlainResult<List<OpenAppCrmPromotionApi>> result = promotionRemoteService.listCrmPreferential(form(57313015L));
        Assert.assertEquals(result.getCode(), 200);
        if (result.getData().size() > 0) {
            result.getData().forEach(item -> {
                if (item.getProCanJoin().booleanValue() == Boolean.FALSE) {
                    Assert.assertEquals(item.getJoinReason(), "不符合活动条件，无法参与");
                }
            });
        }

    }

    public OpenAppCrmPromotionForm form(Long kdtId) {
        OpenAppCrmPromotionForm openAppCrmPromotionForm = new OpenAppCrmPromotionForm();
        openAppCrmPromotionForm.setKdtId(kdtId);
        openAppCrmPromotionForm.setJoinWay(null);
        openAppCrmPromotionForm.setState(null);
        openAppCrmPromotionForm.setIsOnlyOne(null);
        openAppCrmPromotionForm.setJoined(null);
        openAppCrmPromotionForm.setLastId(null);
        return openAppCrmPromotionForm;
    }

}
