package com.youzan.test.market.basecase.gift;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplate;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateMapper;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.test.quickstart.compare.service.CompareServiceImp;
import com.youzan.ycm.gift.request.CreatePresentAssetRequest;
import com.youzan.ycm.gift.request.ReceiveGiftAssetRequest;
import com.youzan.ycm.gift.request.RecycleGiftAssetRequestBiz;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.CreatePresentGiftAssetResponse;
import com.youzan.ycm.gift.response.ReceiveGiftAssetResponse;
import com.youzan.ycm.gift.response.RecycleGiftAssetResponse;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2021/1/14 5:19 下午
 * TODO 【田宁】串流程case demo
 * 礼包四部曲：
 * biz后台礼包发放买赠礼包接口
 * 1、创建礼包模板：com.youzan.ycm.gift.api.GiftTemplateRemoteService#saveGiftTemplate
 * 2、发放礼包：com.youzan.ycm.gift.api.GiftAssetRemoteService#createPresentGiftAsset
 * 3、领取礼包：com.youzan.ycm.gift.api.GiftAssetRemoteService#receiveGiftAsset(发放礼包是手动领取的情况下)
 * 4、回收礼包：com.youzan.ycm.gift.api.GiftAssetRemoteService#recycleByBackstage  （biz后台新礼包页面回收接口）
 */

public class PresentGiftForFinanceTest extends TnBaseTest {

    @Autowired(required = false)
    public GfTemplateGoodsMapper gfTemplateGoodsMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gAssetGoodsMapper;
    @Autowired(required = false)
    public CompareServiceImp compareServiceImp;

    @JSONData(value = "dataResource/basecase.gift/CreatePresentGiftRequestData.json", key = "createPresentGiftTemplateRequest")
    private SaveGiftTemplateRequest createPresentGiftTemplateRequest;
    @JSONData(value = "dataResource/basecase.createOrder/CreateCompensateRequestData.json", key = "createPresentGiftTemplateExpectResult")
    private PlainResult<SaveGiftTemplateResponse> createPresentGiftTemplateExpectResult;

    /**
     * 创建买赠礼包  发放买赠礼包   领取买赠礼包   回收买赠礼包
     */
    @Test(enabled = false)
    public void presentGiftTest() {
        Long template_id = null;

        try {
            //2、前置准备

            //3、创建买赠礼包模板
            PlainResult<SaveGiftTemplateResponse> createGiftAssetResult = createGiftTemplete(createPresentGiftTemplateRequest);

            //3.1、粗暴校验接口返回状态码
            Assert.assertEquals(createGiftAssetResult.getCode(), 200);

            /*//3.2、如果涉及排序，那么用CollectionCompareConfig创建对象进行排序和字段过滤
            CollectionCompareConfig collectionCompareConfig = new CollectionCompareConfig();

            //对比前排序 -- 这里可能存在写不对路径
            collectionCompareConfig.setJsonArrayPath("$.data.giftTemplateDTO.giftTemplateGoodsDTOList");
            collectionCompareConfig.setSortKey("spuId");

            //3.3、如果要过滤多个字段，用CompareConfig处理
            List<String> list = new ArrayList();
            list.add("/data/giftTemplateDTO/templateId");
            list.add("/data/giftTemplateDTO/templateIdStr");
            collectionCompareConfig.getIgnoredPaths().addAll(list);

            //3.3（1）、如果只过滤一个字段
            collectionCompareConfig.getIgnoredPaths().add("/data/giftTemplateDTO/templateId");

            //3.4、结果断言
            compareServiceImp.compare(createGiftAssetResult, createPresentGiftTemplateExpectResult, collectionCompareConfig);*/

            //3.5、查询DB确认数据OK
            String name = "创建买赠礼包模板";

            List<GiftTemplate> giftTemplateList =
                    gfTemplateMapper.selectList(
                            new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, name).orderByDesc(GiftTemplate::getCreated_at));
            Assert.assertTrue(giftTemplateList.size() > 0);
            Assert.assertEquals(giftTemplateList.get(0).getName(), "创建买赠礼包模板");
            Assert.assertEquals(giftTemplateList.get(0).getType(), "PRESENT_GIFT");

            //礼包模板ID，删数据使用
            template_id = createGiftAssetResult.getData().getGiftTemplateDTO().getTemplateId();

            //4. biz后台买赠礼包发放
            CreatePresentAssetRequest createPresentAssetRequest = new CreatePresentAssetRequest();
            List<Long> giftTemplateId = new ArrayList<>();
            giftTemplateId.add(0, template_id);
            createPresentAssetRequest.setGiftTemplateIds(giftTemplateId);

            List<String> giftTemplateIdStr = new ArrayList<>();
            giftTemplateIdStr.add(0, template_id.toString());
            createPresentAssetRequest.setGiftTemplateIdsStr(giftTemplateIdStr);
            createPresentAssetRequest.setDays(365);
            createPresentAssetRequest.setOperator("tianning");
            createPresentAssetRequest.setReason("买赠礼包发放测试");
            createPresentAssetRequest.setReceiveGiftType("By_HAND");

            //发放礼包的条件：一定是软件才可以给发礼包：pf_order表中：biz_order_type='trade_order' perform_state = 'performed' app_category='software'
            List<PfOrder> pfOrder =
                    pfOrderMapper.selectList(
                            new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBuyKdtId, PRESENTKDTID).eq(PfOrder::getBizOrderType, "trade_order").eq(PfOrder::getPerformState, "performed").eq(PfOrder::getAppCategory, "software_meal").orderByDesc(PfOrder::getCreatedAt));
            List<String> pfOrderIdList = new ArrayList<>();
            Assert.assertTrue(pfOrder.size() > 0);

            Long pfOrderId = pfOrder.get(0).getId();

            pfOrderIdList.add(pfOrderId.toString());
            createPresentAssetRequest.setPfOrderIds(pfOrderIdList);

            PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<CreatePresentGiftAssetResponse>>() {

                        @Override
                        public PlainResult<CreatePresentGiftAssetResponse> doExecute() {
                            return giftAssetRemoteService.createPresentGiftAsset(createPresentAssetRequest);
                        }

                        @Override
                        public boolean handleResult(PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult) {
                            return presentGiftAssetResult.getCode() == 200;
                        }
                    }, 5, 100);

            Long giftAssetId = presentGiftAssetResult.getData().getGiftAssetIds().get(0);

            Assert.assertEquals(presentGiftAssetResult.getCode(), 200);

            List<GiftAsset> giftAssetList =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getId, giftAssetId));

            //此时礼包的状态是待领取
            Assert.assertEquals(giftAssetList.get(0).getState(), "WAIT_RECEIVE");

            //5、领取买赠礼包
            ReceiveGiftAssetRequest receiveGiftAssetRequest = new ReceiveGiftAssetRequest();

            receiveGiftAssetRequest.setGiftAssetId(giftAssetId);
            receiveGiftAssetRequest.setGiftAssetIdStr(giftAssetId.toString());
            PlainResult<ReceiveGiftAssetResponse> receiveGiftAssetResponsePlainResult = giftAssetRemoteService.receiveGiftAsset(receiveGiftAssetRequest);
            Assert.assertEquals(receiveGiftAssetResponsePlainResult.getCode(), 200);

            List<GiftAsset> giftAssetListReceived =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getId, giftAssetId));
            //此时礼包的状态是已领取
            Assert.assertEquals(giftAssetListReceived.get(0).getState(), "RECEIVED");

            //6、回收买赠礼包
            RecycleGiftAssetRequestBiz recycleGiftAssetRequestBiz = new RecycleGiftAssetRequestBiz();
            recycleGiftAssetRequestBiz.setGiftAssetId(giftAssetListReceived.get(0).getId());
            recycleGiftAssetRequestBiz.setGiftAssetIdStr(giftAssetListReceived.get(0).getId().toString());
            recycleGiftAssetRequestBiz.setRemark("买赠礼包回收");
            recycleGiftAssetRequestBiz.setType("PRESENT_GIFT");

            try {
                sleep(6000);
            } catch (Throwable e) {
                e.getMessage();
            }

            PlainResult<RecycleGiftAssetResponse> recycleGiftAssetResult = giftAssetRemoteService.recycleByBackstage(recycleGiftAssetRequestBiz);

            try {
                sleep(4000);
            } catch (Throwable e) {
                e.getMessage();
            }

            Assert.assertEquals(recycleGiftAssetResult.getCode(), 200);
            List<GiftAsset> giftAssetListRecycled =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().eq("id", giftAssetId));
            //此时礼包的状态是已回收
            Assert.assertEquals(giftAssetListRecycled.get(0).getState(), "RECYCLED");
        } finally {
            //7、数据清理  来无影去无踪
            deleteTemplateData();
        }
    }

    /**
     * 创建买赠礼包  发放买赠礼包  不领取的情况下直接回收买赠礼包
     */
    @Test(enabled = false)
    public void presentGiftWithoutReceiveTest() {
        Long template_id = null;

        try {
            PlainResult<SaveGiftTemplateResponse> createGiftAssetResult = createGiftTemplete(createPresentGiftTemplateRequest);

            Assert.assertEquals(createGiftAssetResult.getCode(), 200);

            String name = "创建买赠礼包模板";

            List<GiftTemplate> giftTemplateList =
                    gfTemplateMapper.selectList(
                            new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, name).orderByDesc(GiftTemplate::getCreated_at));
            Assert.assertTrue(giftTemplateList.size() > 0);
            Assert.assertEquals(giftTemplateList.get(0).getName(), "创建买赠礼包模板");
            Assert.assertEquals(giftTemplateList.get(0).getType(), "PRESENT_GIFT");

            template_id = createGiftAssetResult.getData().getGiftTemplateDTO().getTemplateId();

            CreatePresentAssetRequest createPresentAssetRequest = new CreatePresentAssetRequest();
            List<Long> giftTemplateId = new ArrayList<>();
            giftTemplateId.add(0, template_id);
            createPresentAssetRequest.setGiftTemplateIds(giftTemplateId);

            List<String> giftTemplateIdStr = new ArrayList<>();
            giftTemplateIdStr.add(0, template_id.toString());
            createPresentAssetRequest.setGiftTemplateIdsStr(giftTemplateIdStr);
            createPresentAssetRequest.setDays(365);
            createPresentAssetRequest.setOperator("tianning");
            createPresentAssetRequest.setReason("买赠礼包发放测试");
            createPresentAssetRequest.setReceiveGiftType("By_HAND");

            //发放礼包的条件：一定是软件才可以给发礼包：pf_order表中：biz_order_type='trade_order' perform_state = 'performed' app_category='software'
            List<PfOrder> pfOrder =
                    pfOrderMapper.selectList(
                            new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBuyKdtId, PRESENTKDTID).eq(PfOrder::getBizOrderType, "trade_order").eq(PfOrder::getPerformState, "performed").eq(PfOrder::getAppCategory, "software_meal").orderByDesc(PfOrder::getCreatedAt));
            List<String> pfOrderIdList = new ArrayList<>();
            Assert.assertTrue(pfOrder.size() > 0);

            Long pfOrderId = pfOrder.get(0).getId();

            pfOrderIdList.add(pfOrderId.toString());
            createPresentAssetRequest.setPfOrderIds(pfOrderIdList);

            PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<CreatePresentGiftAssetResponse>>() {

                        @Override
                        public PlainResult<CreatePresentGiftAssetResponse> doExecute() {
                            return giftAssetRemoteService.createPresentGiftAsset(createPresentAssetRequest);
                        }

                        @Override
                        public boolean handleResult(PlainResult<CreatePresentGiftAssetResponse> presentGiftAssetResult) {
                            return presentGiftAssetResult.getCode() == 200;
                        }
                    }, 5, 100);

            Long giftAssetId = presentGiftAssetResult.getData().getGiftAssetIds().get(0);

            Assert.assertEquals(presentGiftAssetResult.getCode(), 200);

            List<GiftAsset> giftAssetList =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getId, giftAssetId));

            //此时礼包的状态是待领取
            Assert.assertEquals(giftAssetList.get(0).getState(), "WAIT_RECEIVE");

            //不领取直接回收买赠礼包
            RecycleGiftAssetRequestBiz recycleGiftAssetRequestBiz = new RecycleGiftAssetRequestBiz();
            recycleGiftAssetRequestBiz.setGiftAssetId(giftAssetList.get(0).getId());
            recycleGiftAssetRequestBiz.setGiftAssetIdStr(giftAssetList.get(0).getId().toString());
            recycleGiftAssetRequestBiz.setRemark("买赠礼包回收");
            recycleGiftAssetRequestBiz.setType("PRESENT_GIFT");

            try {
                sleep(6000);
            } catch (Throwable e) {
                e.getMessage();
            }

            PlainResult<RecycleGiftAssetResponse> recycleGiftAssetResult = giftAssetRemoteService.recycleByBackstage(recycleGiftAssetRequestBiz);

            try {
                sleep(5000);
            } catch (Throwable e) {
                e.getMessage();
            }

            Assert.assertEquals(recycleGiftAssetResult.getCode(), 200);
            List<GiftAsset> giftAssetListRecycled =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().eq("id", giftAssetId));
            //此时礼包的状态是已回收
            Assert.assertEquals(giftAssetListRecycled.get(0).getState(), "RECYCLED");
        } finally {
            //数据清理  来无影去无踪
            deleteTemplateData();
        }
    }
}

