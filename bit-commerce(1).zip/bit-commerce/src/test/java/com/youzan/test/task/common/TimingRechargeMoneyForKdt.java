package com.youzan.test.task.common;

import com.alibaba.fastjson.JSON;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import java.util.List;

/**
 * @author leifeiyun
 * @date 2020/11/13
 **/
public class TimingRechargeMoneyForKdt extends BaseTest {
    @JSONData("/dataResource/clearData/timingRechargeKdtIds.json")
    private List<String> kdtIds;

    @Test
    public void rechargeMoneyForKdtId() {
        List<String> failedKdtIds = Lists.newArrayList();
        for (String kdtId : kdtIds) {
            try {
                logger.info("开始给店铺充值余额,kdtid：{}", kdtId);
                rechargeShopBalance(kdtId, 99999999);
            } catch (Exception e) {
                failedKdtIds.add(kdtId);
                logger.info("给店铺充值余额失败,kdtid：{}", kdtId);
            }

        }
        Assert.assertEquals(failedKdtIds.size(),0,
                "店铺余额充值失败kdtids："+ JSON.toJSONString(failedKdtIds));
    }

}

