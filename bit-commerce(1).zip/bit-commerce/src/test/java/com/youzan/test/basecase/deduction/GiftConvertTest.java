package com.youzan.test.basecase.deduction;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfAsset;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.DeductBaseTest;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.yop.api.entity.order.CalOrderPriceApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.promotion.PreferentialDescApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/1/21 8:44 PM
 */
public class GiftConvertTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(DeductionTest.class);
    public Long promotionId = 8649L;

    /**
     * 礼包还未开始生效的情况
     */
    @Test
    public void orderGiftConvertTest() {
        initShopByKdtId(giftConvertKdtId);
        rechargeYzcoin(giftConvertKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(giftConvertKdtId), cny);

        setActivityValid(promotionId);

        PlainResult<String> result =createNormalOrder(giftConvertKdtId,giftConvertKdtName,basicWechatItemId,1,0L);
        logger.info("创建订单的结果：{}",result);

        setActivityInvalid(promotionId);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, giftConvertKdtId);
        }

        waitForPerform(giftConvertKdtId,873L,Long.valueOf(result.getData()));

        //查看确认订单也礼包折算个数正确
        PlainResult<CalOrderPriceApi> calOrderPriceResult = calOrderPrice(giftConvertKdtId,giftConvertKdtName,professionItemId,1);
        logger.info("订单计算结果：{}",JSON.toJSONString(calOrderPriceResult));
        Assert.assertEquals(calOrderPriceResult.getData().getItems().get(0).getGiftConvertInfo().getConvertTotalDays(),Integer.valueOf(10),"礼包折算数量不正确");

        //创建升级订单
        PlainResult<String> renewResult =createNormalOrder(giftConvertKdtId,giftConvertKdtName,professionItemId,1,0L);
        logger.info("创建订单的结果：{}",renewResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, giftConvertKdtId);
        }

        waitForPerform(giftConvertKdtId,873L,Long.valueOf(renewResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewResult.getData()));


        //查看最终礼包天数
        PfAsset pfAsset = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>()
                .eq("out_biz_no",tdOrder.getTdNo())
                .eq("source_type","convert_product_with_present"));

        //校验礼包的价值可折算的天数=10天
        Assert.assertEquals(pfAsset.getItemNum(),Long.valueOf(10),"升级订单创建后礼包折算的天数不正确");

        waitForPfOrderStateChanged(Long.valueOf(result.getData()));
        initShopByKdtId(giftConvertKdtId);
    }

    /**
     *买赠礼包已经开始生效了1天
     */
    @Test
    public void orderGiftConvertNotAllTest() {
        initShopByKdtId(giftConvertKdtId);
        rechargeYzcoin(giftConvertKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(giftConvertKdtId), cny);

        setActivityValid(promotionId);

        PlainResult<String> result =createNormalOrder(giftConvertKdtId,giftConvertKdtName,basicWechatItemId,1,0L);
        logger.info("创建订单的结果：{}",result);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, giftConvertKdtId);
        }

        waitForPerform(giftConvertKdtId,873L,Long.valueOf(result.getData()));
        setActivityInvalid(promotionId);

        //将服务期往前移动366天 TODO 如果当年是闰年需要移动367天
        movePerformStatusByAppId(giftConvertKdtId,873L,-366);

        //查看确认订单也礼包折算个数正确
        PlainResult<CalOrderPriceApi> calOrderPriceResult = calOrderPrice(giftConvertKdtId,giftConvertKdtName,professionItemId,1);
        logger.info("订单计算结果：{}",JSON.toJSONString(calOrderPriceResult));
        logger.info("礼包可折算的天数：{}",calOrderPriceResult.getData().getItems().get(0).getGiftConvertInfo().getConvertTotalDays());
        Assert.assertEquals(calOrderPriceResult.getData().getItems().get(0).getGiftConvertInfo().getConvertTotalDays(),Integer.valueOf(9),"礼包折算数量不正确");

        //创建升级订单
        PlainResult<String> renewResult =createNormalOrder(giftConvertKdtId,giftConvertKdtName,professionItemId,1,0L);
        logger.info("创建订单的结果：{}",renewResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, giftConvertKdtId);
        }

        waitForPerform(giftConvertKdtId,873L,Long.valueOf(renewResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewResult.getData()));


        //查看最终礼包天数
        PfAsset pfAsset = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>()
                .eq("out_biz_no",tdOrder.getTdNo())
                .eq("source_type","convert_product_with_present"));

        //校验礼包的价值可折算的天数=10天
        Assert.assertEquals(pfAsset.getItemNum(),Long.valueOf(9),"升级订单创建后礼包折算的天数不正确");

        initShopByKdtId(giftConvertKdtId);
    }


    /**
     *礼包折算不到一天的情况
     */
    @Test
    public void canNotOrderGiftConvertTest() {
        initShopByKdtId(giftConvertKdtId);
        rechargeYzcoin(giftConvertKdtId, chargeYzb);
        rechargeShopBalance(String.valueOf(giftConvertKdtId), cny);

        setActivityValid(promotionId);

        PlainResult<String> result =createNormalOrder(giftConvertKdtId,giftConvertKdtName,basicWechatItemId,1,0L);
        logger.info("创建订单的结果：{}",result);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+result.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(result.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, giftConvertKdtId);
        }

        waitForPerform(giftConvertKdtId,873L,Long.valueOf(result.getData()));
        setActivityInvalid(promotionId);

        //将服务期往前移动366天 TODO 如果当年是闰年需要移动367天
        movePerformStatusByAppId(giftConvertKdtId,873L,-384);

        //查看确认订单也礼包折算个数正确
        PlainResult<CalOrderPriceApi> calOrderPriceResult = calOrderPrice(giftConvertKdtId,giftConvertKdtName,professionItemId,1);
        logger.info("订单计算结果：{}",JSON.toJSONString(calOrderPriceResult));
        //logger.info("礼包可折算的天数：{}",calOrderPriceResult.getData().getItems().get(0).getGiftConvertInfo().getConvertTotalDays());
        Assert.assertEquals(calOrderPriceResult.getData().getItems().get(0).getGiftConvertInfo(),null,"礼包折算数量不正确");

        //创建升级订单
        PlainResult<String> renewResult =createNormalOrder(giftConvertKdtId,giftConvertKdtName,professionItemId,1,0L);
        logger.info("创建订单的结果：{}",renewResult);

        //付钱
        Assert.assertEquals(result.getCode(),200,"创建订单失败："+renewResult.getMessage());
        if (result.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(renewResult.getData()), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, giftConvertKdtId);
        }

        waitForPerform(giftConvertKdtId,873L,Long.valueOf(renewResult.getData()));

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", renewResult.getData()));


        //查看最终礼包天数
        PfAsset pfAsset = pfAssetMapper.selectOne(new QueryWrapper<PfAsset>()
                .eq("out_biz_no",tdOrder.getTdNo())
                .eq("source_type","convert_product_with_present"));

        //校验礼包的价值可折算的天数=10天
        Assert.assertEquals(pfAsset,null,"升级订单创建后礼包折算的天数不正确");
        //waitForPerform(giftConvertKdtId,873L,);
        initShopByKdtId(giftConvertKdtId);
    }

    /**
     * 补偿礼包的折算
     */




    @Override
    public PlainResult<String> createNormalOrder(Long kdtId, String kdtName, int itemId, int quantity, Long yzb) {
        //构造item参数
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(itemId, quantity);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);
        Byte type = 25;

        List<PreferentialDescApi> itemPromotionList = new ArrayList<>();

        if (itemId == basicWechatItemId) {
            PreferentialDescApi itemPromtion = new PreferentialDescApi();
            itemPromtion.setType(type);
            itemPromtion.setSelected(true);
            itemPromtion.setPromotionId(promotionId);

            itemPromotionList.add(itemPromtion);

            orderItemForm.setItemPromotionList(itemPromotionList);
        }

        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(kdtId, kdtName, orderItemFormList,yzb);
        logger.info("创建订单参数:{}", JSON.toJSONString(createOrderForm));
        /**新的创建订单需要给出订单营销计算类型 OrderMarketingCalType
         *  普通计算 - NORMAL_CALC
         *  最优解计算 - BEST_CALC
         */
        createOrderForm.setOrderMarketingCalType("BEST_CALC");

        PlainResult<String> resultCreateNormalOrder =
                orderRemoteService.createNormalOrder(createOrderForm);

        return resultCreateNormalOrder;
    }
}
