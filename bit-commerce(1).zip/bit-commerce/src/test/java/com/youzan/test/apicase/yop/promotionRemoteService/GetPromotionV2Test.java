package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.request.GetPromotionV2Request;
import com.youzan.yop.api.response.GetPromotionV2Response;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @program: bit-commerce
 * @description 后台查询营销详情
 * @author: tianning
 * @create: 2021-03-24 11:27
 **/
public class GetPromotionV2Test extends TnBaseTest {

    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void getPromotionV2Test() {
        PlainResult<Long> createPromotionResult = null;
        try {
            GetPromotionV2Request request = new GetPromotionV2Request();
            createPromotionResult = createPromotion();
            request.setPromotionId(createPromotionResult.getData());
            request.setPromotionType("ACTIVITY");
            PlainResult<GetPromotionV2Response> getPromotionV2Result = promotionRemoteService.getPromotionV2(request);
            Assert.assertEquals(getPromotionV2Result.getCode(), 200);
        } finally {
            invalidPresentActivity(createPromotionResult.getData());
            deletePresentCouponData();
        }
    }

    /**
     * 异常用例
     */
    @Test
    public void getPromotionV2PromotionTypeStringNullTest() {
        PlainResult<Long> createPromotionResult = null;
        try {
            GetPromotionV2Request request = new GetPromotionV2Request();
            createPromotionResult = createPromotion();
            request.setPromotionId(createPromotionResult.getData());
            request.setPromotionType("");
            PlainResult<GetPromotionV2Response> getPromotionV2Result = promotionRemoteService.getPromotionV2(request);
            Assert.assertEquals(getPromotionV2Result.getCode(), 200);
        } finally {
            invalidPresentActivity(createPromotionResult.getData());
            deletePresentCouponData();
        }
    }

    /**
     * 异常用例
     */
    @Test
    public void getPromotionV2PromotionIdNullTest() {
        GetPromotionV2Request request = new GetPromotionV2Request();
        request.setPromotionId(null);
        request.setPromotionType("ACTIVITY");
        PlainResult<GetPromotionV2Response> getPromotionV2Result = promotionRemoteService.getPromotionV2(request);
        Assert.assertEquals(getPromotionV2Result.getCode(), 130102);
    }

    /**
     * 异常用例
     */
    @Test
    public void getPromotionV2ParamNullTest() {
        PlainResult<GetPromotionV2Response> getPromotionV2Result = promotionRemoteService.getPromotionV2(null);
        Assert.assertEquals(getPromotionV2Result.getCode(), 130501);
    }
}
