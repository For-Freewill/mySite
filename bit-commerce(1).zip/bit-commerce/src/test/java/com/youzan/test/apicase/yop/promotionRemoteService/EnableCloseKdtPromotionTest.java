package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.EnablePromotionParam;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author wulei
 * @date 2020/9/28 16:00
 * 给店铺发送优惠资格
 * select ycm_activity_id from promotion_activity_id_mapping where  yop_promotion_id=915
 * select * from open_application_preferential where  promotion_id=915 * rule.presentid=preferentialId
 * <p>
 * <p>todo @leifeiyun
 * invoke com.youzan.yop.api.PromotionRemoteService.enableKdtPromotion({"kdtId":57313015,"promotionId":1223,"preferentialId":969,"salesId":123})
 */
public class EnableCloseKdtPromotionTest extends BaseTest {
    public static Long wsc_qijian = 57313015L;
    public static String wsc_qijian_name = "微商城单店11111";

    public static Long wsc_null = 57507053L;
    public static String wsc_null_name = "微商城空店-自动化";
    @Dubbo
    public PromotionRemoteService promotionRemoteService;


    /**
     * @desc 场景1：异常测试-活动不存在
     */
    @Test
    public void enableKdtPromotionNoActivityTest() {
        PlainResult<Boolean> result = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 10L, 1, 123L));
        Assert.assertEquals(result.getCode(), 130727);
        Assert.assertEquals(result.getMessage(), "不是进行中的活动，无法开启");
    }

    /**
     * @desc 场景2：异常测试-全网生效活动不支持开启
     */
    @Test
    public void enableKdtPromotionCannotEnableTest() {
        PlainResult<Boolean> result = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 1223L, 969, 123L));
        Assert.assertEquals(result.getCode(), 130730);
        Assert.assertEquals(result.getMessage(), "全网生效活动不支持开启");
    }

    /**
     * @desc 场景3：异常测试-全网生效活动不支持开启
     */
    @Test
    public void enableKdtPromotionYcmNoDataTest() {
        PlainResult<Boolean> result = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 914L, 2000077401, 123L));
        Assert.assertEquals(result.getCode(), 130624);
//        Assert.assertEquals(result.getMessage(), "ycm获取数据失败");
    }

    /**
     * @desc 场景4：异常测试-全网生效活动不支持开启
     */
    @Test
    public void enableKdtPromotionYcmNoData2Test() {
        PlainResult<Boolean> result = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 914L, 2000077401, 123L));
        Assert.assertEquals(result.getCode(), 130624);
//        Assert.assertEquals(result.getMessage(), "ycm获取数据失败");
    }

    /**
     * @desc 场景5：正常测试-参与活动
     */
    @Test
    public void enableKdtPromotionNormalTest() {
        PlainResult<Boolean> result1 = promotionRemoteService.closeKdtPromotion(form(wsc_qijian, 1224L, 970, 123L));
        Assert.assertEquals(result1.getCode(), 130624);

//        PlainResult<Boolean> result = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 1224L, 970, 123L));
//        Assert.assertEquals(result.getCode(), 130624);
//        Assert.assertEquals(result.getMessage(), "successful");
    }

    /**
     * @desc 场景6：正常测试-参与2次活动报错
     */
    @Test
    public void enableKdtPromotionRepeatPartInTest() {
        // 取消参与
//        PlainResult<Boolean> result = promotionRemoteService.closeKdtPromotion(form(wsc_qijian, 1224L, 970, 123L));
//        Assert.assertEquals(result.getCode(), 130624);
//        Assert.assertEquals(result.getMessage(), "successful");

        // 参与1次
//        PlainResult<Boolean> result1 = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 1224L, 970, 123L));
//        Assert.assertEquals(result1.getCode(), 200);
//        Assert.assertEquals(result1.getMessage(), "successful");

        // 参与2次
//        PlainResult<Boolean> result2 = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 1224L, 970, 123L));
//        Assert.assertEquals(result2.getCode(), 130726);
//        Assert.assertEquals(result2.getMessage(), "已经参与此活动");
    }

    /**
     * @desc 场景7：异常测试-活动不匹配
     */
    @Test
    public void enableKdtPromotionNotMatchTest() {
        // 取消参与
        PlainResult<Boolean> result = promotionRemoteService.closeKdtPromotion(form(wsc_qijian, 1224L, 971, 123L));
        Assert.assertEquals(result.getCode(), 130624);
        Assert.assertEquals(result.getMessage(), "无可失效的资格或无权限进行失效");

        // 参与1次
//        PlainResult<Boolean> result1 = promotionRemoteService.enableKdtPromotion(form(wsc_qijian, 1224L, 971, 123L));
//        Assert.assertEquals(result1.getCode(), 200);
//        Assert.assertEquals(result1.getMessage(), "successful");
    }

    /**
     * @desc 场景8：正常测试-取消不存在的pref
     */
    @Test
    public void closeKdtPromotionNormalTest() {
        // 取消参与
        PlainResult<Boolean> result = promotionRemoteService.closeKdtPromotion(form(wsc_qijian, 1224L, 97111, 123L));
        Assert.assertEquals(result.getCode(), 130624);
        Assert.assertEquals(result.getMessage(), "无可失效的资格或无权限进行失效");
    }

    /**
     * @desc 场景9：正常测试-取消不存在promotion
     */
    @Test
    public void closeKdtPromotionNotExistTest() {
        // 取消参与
        PlainResult<Boolean> result = promotionRemoteService.closeKdtPromotion(form(wsc_qijian, 1223L, 97111, 123L));
        Assert.assertEquals(result.getCode(), 130624);
        Assert.assertEquals(result.getMessage(), "无可失效的资格或无权限进行失效");
    }

    /**
     * 入参
     *
     * @param kdtId
     * @param promotionId
     * @param preferentialId
     * @param salesId
     * @return
     */
    public EnablePromotionParam form(Long kdtId, Long promotionId, Integer preferentialId, Long salesId) {
        EnablePromotionParam enablePromotionParam = new EnablePromotionParam();
        enablePromotionParam.setKdtId(kdtId);
        enablePromotionParam.setPromotionId(promotionId);
        enablePromotionParam.setPreferentialId(preferentialId);
        enablePromotionParam.setSalesId(salesId);
        return enablePromotionParam;
    }
}
