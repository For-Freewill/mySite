package com.youzan.test.refund.basecase;

import com.youzan.test.basecase.DeductBaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

/**
 * @author wuwu
 * @date 2021/5/17 11:51 AM
 */
public class RefundAndShowStateTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(RefundAndShowStateTest.class);
    public Long promotionId = 8649L;
    String refundMode = "BY_VALUE";


    @Test
    public void refundAndOrderDetailStateTest(){
        /**
         * 1. 下单，订单有两个子订单
         */

        /**
         * 2. 将其中一个订单退款，该子订单在订单详情页状态为退款中或已退款
         */

        /**
         * 3. 将另外一个订单退款，订单详情页另一个状态为已退款
         */
    }

    @Test
    public void refundAndOrderListStateTest(){
        /**
         * 1. 下单，订单有两个子订单
         */

        /**
         * 2. 将其中一个订单退款，订单列表状态为订购成功
         */

        /**
         * 3. 将另外一个订单退款，订单列表状态为已退款
         */
    }

    @Test
    public void onlyOneChildOrderRefundAndOrderDetailStateTest(){
        /**
         * 1. 下单，订单只有1个子订单
         */

        /**
         * 2. 将其中一个订单退款，该子订单在订单详情页状态为退款中或已退款
         */

    }

    @Test
    public void onlyOneChildOrderRefundAndOrderListStateTest(){
        /**
         * 1. 下单，订单有两个子订单
         */

        /**
         * 2. 将其中一个订单退款，订单列表状态为订购成功
         */

        /**
         * 3. 将另外一个订单退款，订单列表状态为已退款
         */
    }

}
