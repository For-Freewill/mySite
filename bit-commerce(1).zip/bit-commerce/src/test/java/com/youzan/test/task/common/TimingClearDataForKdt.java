package com.youzan.test.task.common;


import com.alibaba.fastjson.JSON;
import com.youzan.test.BaseTest;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import java.util.Arrays;
import java.util.List;

public class TimingClearDataForKdt extends YunBaseTest {
    @JSONData("/dataResource/clearData/timingClearKdtIds.json")
    private List<Long> kdtIds;

    @Test
    public void clearDataForKdt() {
        List<Long> failedRefundKdtIds = Lists.newArrayList();
        List<Long> failedClearKdtIds = Lists.newArrayList();

        //开始清理数据
        for (Long kdtId : kdtIds) {
            try {
                logger.info("开始店铺 {} 清理数据", kdtId);
                godBlessU(kdtId);
                logger.info("店铺 {} 清理完成，开始清商品缓存", kdtId);
                clearCache(kdtId);
            } catch (Exception e) {
                failedClearKdtIds.add(kdtId);
                logger.info("店铺 {} 清理数据异常: {}", kdtId, e.getMessage());
            }
        }
        Assert.assertEquals(failedClearKdtIds.size(),0,
                "清理失败kdtids："+ JSON.toJSONString(failedClearKdtIds));
    }
}
