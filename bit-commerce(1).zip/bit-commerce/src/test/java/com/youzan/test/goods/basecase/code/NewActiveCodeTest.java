package com.youzan.test.goods.basecase.code;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.bitcomparecommon.aop.CompareConfig;
import com.youzan.bitcomparecommon.aop.CompareUtil;
import com.youzan.commerce.test.entity.dataobject.goods.*;
import com.youzan.commerce.test.entity.dataobject.trade.TdActivationCodeApplyRecordEntity;
import com.youzan.commerce.test.entity.dataobject.trade.TdActivationCodeEntity;
import com.youzan.commerce.test.entity.dataobject.trade.TdActivationCodeGoodsItemEntity;
import com.youzan.commerce.test.mapper.trade.*;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.test.quickstart.compare.service.CompareServiceImp;
import com.youzan.ycm.code.api.YcmRedeemCodeRemoteService;
import com.youzan.ycm.code.dto.YcmCodeStatisticDTO;
import com.youzan.ycm.code.request.*;
import com.youzan.ycm.code.response.*;
import com.youzan.ycm.qa.enable.platform.api.response.enable.EnableNewKdtIdResponse;
import com.youzan.ycm.trade.api.dto.output.UniversalCodeApplyRecordDTO;
import com.youzan.ycm.trade.api.dto.output.activation.ActivationCodeSpuDTO;
import com.youzan.ycm.trade.api.dto.output.activation.YcmActivationCodeDTO;
import com.youzan.ycm.trade.api.request.CodePageQueryRequest;
import com.youzan.ycm.trade.api.request.CodeSupportSkuListRequest;
import com.youzan.ycm.trade.api.request.UniversalCodeApplyRecordPageQueryRequest;
import com.youzan.ycm.trade.api.result.GetAvailableExpireTimeListResponse;
import com.youzan.ycm.trade.api.result.PageResponse;
import com.youzan.ycm.trade.api.result.*;
import com.youzan.ycm.trade.api.service.ActivationCodeQueryRemoteService;
import com.youzan.yop.api.ActivationCodeRemoteService;
import com.youzan.yop.api.entity.OpenActivationCodeCheckApi;
import com.youzan.yop.api.entity.OpenCodeCheckResApi;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.youzan.test.basecase.yunServiceFee.baseCase.AdvanceQuotaTest.yunKdtName9;
import static org.awaitility.Awaitility.with;

/**
 * @author wulei
 * @date 2021/1/7 14:45
 * 新激活码场景case：13972383152
 */
public class NewActiveCodeTest extends YunBaseTest {

    @Autowired(required = false)
    public CompareServiceImp compareServiceImp;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "items")
    private List<YcmActivationCodeDTO> items;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "getAvailableExpireTimeListServiceTest")
    private PlainResult<GetAvailableExpireTimeListResponse> getAvailableExpireTimeListResponsePlainResult;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "codeCreateConfig")
    private PlainResult<CodeCreateGetConfigResponse> codeCreateConfig;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "ycmRedeemCodeDTO")
    private YcmCodeStatisticDTO ycmRedeemCodeDTO;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "ItemList")
    private LinkedHashMap ItemList;

    //创建激活码场景
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_NEW_SIGN_KUAI_SHOU")
    private CreateYcmCodeRequest unique_code_NEW_SIGN_KUAI_SHOU;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_NEW_SIGN_JING_DONG")
    private CreateYcmCodeRequest unique_code_NEW_SIGN_JING_DONG;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_NEW_SIGN_YZ_APPLETS")
    private CreateYcmCodeRequest unique_code_NEW_SIGN_YZ_APPLETS;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_RENEW_SIGN_KUAI_SHOU")
    private CreateYcmCodeRequest unique_code_RENEW_SIGN_KUAI_SHOU;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_RENEW_SIGN_JING_DONG")
    private CreateYcmCodeRequest unique_code_RENEW_SIGN_JING_DONG;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_RENEW_SIGN_YZ_APPLETS")
    private CreateYcmCodeRequest unique_code_RENEW_SIGN_YZ_APPLETS;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_NOT_LIMIT_KUAI_SHOU")
    private CreateYcmCodeRequest unique_code_NOT_LIMIT_KUAI_SHOU;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_NOT_LIMIT_JING_DONG")
    private CreateYcmCodeRequest unique_code_NOT_LIMIT_JING_DONG;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "unique_code_NOT_LIMIT_YZ_APPLETS")
    private CreateYcmCodeRequest unique_code_NOT_LIMIT_YZ_APPLETS;

    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "combine_sku_retail_single_2021_profession_year")
    private CreateYcmCodeRequest combine_sku_retail_single_2021_profession_year;


    // 复杂场景1-WSC2021
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "WSC2021_unique_code_RENEW_KUAI_SHOU")
    private CreateYcmCodeRequest WSC2021_unique_code_RENEW_KUAI_SHOU;

    // 复杂场景2-LS2021
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "LS2021_unique_code_RENEW_KUAI_SHOU")
    private CreateYcmCodeRequest LS2021_unique_code_RENEW_KUAI_SHOU;

    // 复杂场景3-非打包售卖，不支持创建激活码
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "Not_sale_feidabao")
    private CreateYcmCodeRequest Not_sale_feidabao;

    // 复杂场景3-非打包售卖，市场洞察
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "Not_sale_market_insight")
    private CreateYcmCodeRequest Not_sale_market_insight;

    // 复杂场景3-周期库存型，续费不支持
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "Period_Stock_1_RENEW")
    private CreateYcmCodeRequest Period_Stock_1_RENEW;

    // 复杂场景3-周期库存型，不限制不支持
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "Period_Stock_2_NOLIMIT")
    private CreateYcmCodeRequest Period_Stock_2_NOLIMIT;


    // 复杂场景4-2次通用码，3次激活
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "WSC2021_universal_code_2_NOT_LIMIT_TAO_BAO")
    private CreateYcmCodeRequest WSC2021_universal_code_2_NOT_LIMIT_TAO_BAO;

    // 复杂场景4-1次通用码，2个商品
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "WSC2021_2_Softwares")
    private CreateYcmCodeRequest WSC2021_2_Softwares;

    // 复杂场景5-2次唯一码-生成2个码
    @JSONData(value = "dataResource/basecase.newActiveCode/newActiveCodeData.json", key = "WSC2021_unique_code_2_RENEW_KUAI_SHOU")
    private CreateYcmCodeRequest WSC2021_unique_code_2_RENEW_KUAI_SHOU;

    @Dubbo
    private YcmRedeemCodeRemoteService ycmRedeemCodeRemoteService;
    @Dubbo
    private ActivationCodeQueryRemoteService activationCodeQueryRemoteService;
    @Dubbo
    private ActivationCodeRemoteService activationCodeRemoteService;

    // 激活码关联数据库
    @Autowired(required = false)
    public CdRedeemCodeMapper cdRedeemCodeMapper;
    @Autowired(required = false)
    public CdRedeemCodeBatchMapper cdRedeemCodeBatchMapper;
    @Autowired(required = false)
    public CdRedeemCodeApplyRecordMapper cdRedeemCodeApplyRecordMapper;
    @Autowired(required = false)
    public CdRedeemCodeApplyMutexMapper cdRedeemCodeApplyMutexMapper;
    @Autowired(required = false)
    public CdRedeemCodeDistributeRecordMapper cdRedeemCodeDistributeRecordMapper;
    @Autowired(required = false)
    public TdActivationCodeMapper tdActivationCodeMapper;
    @Autowired(required = false)
    public TdActivationCodeGoodsItemMapper tdActivationCodeGoodsItemMapper;
    @Autowired(required = false)
    public TdActivationCodeApplyRecordMapper tdActivationCodeApplyRecordMapper;

    CompareConfig compareConfig = new CompareConfig();

    // 唯一码-激活码 创建与微商城店铺核销
    @Test
    public void A01YcmCodeCreateYcmCodeTest() throws InterruptedException {
        CreateYcmCodeRequest createYcmCodeRequest = new CreateYcmCodeRequest();
        // 场景1-null
        PlainResult<CreateYcmCodeResponse> config = ycmRedeemCodeRemoteService.createYcmCode(createYcmCodeRequest);
        Assert.assertEquals(5200001, config.getCode());
        Assert.assertEquals("参数非法", config.getMessage());

        // ############ 唯一码 创建 ##################
        // 场景2-unique_code_NEW_SIGN_KUAI_SHOU
        applyCheck(createUniqueCodeCheck(unique_code_NEW_SIGN_KUAI_SHOU), newWscKdtId());
        logger.info("unique_code_NEW_SIGN_KUAI_SHOU-WSC店铺-创建/核销成功");

        // 场景3-unique_code_NEW_SIGN_JING_DONG
        applyCheck(createUniqueCodeCheck(unique_code_NEW_SIGN_JING_DONG), newWscKdtId());
        logger.info("unique_code_NEW_SIGN_JING_DONG-WSC店铺-创建/核销成功");

        // 场景4-unique_code_NEW_SIGN_YZ_APPLETS
        applyCheck(createUniqueCodeCheck(unique_code_NEW_SIGN_YZ_APPLETS), newWscKdtId());
        logger.info("unique_code_NEW_SIGN_JING_DONG-WSC店铺-创建/核销成功");

        // 场景5-unique_code_RENEW_SIGN_KUAI_SHOU
        createUniqueCodeCheck(unique_code_RENEW_SIGN_KUAI_SHOU);
        logger.info("unique_code_RENEW_SIGN_KUAI_SHOU-创建成功");

        // 场景6-unique_code_RENEW_SIGN_JING_DONG
        createUniqueCodeCheck(unique_code_RENEW_SIGN_JING_DONG);
        logger.info("unique_code_RENEW_SIGN_JING_DONG-创建成功");

        // 场景7-unique_code_RENEW_SIGN_YZ_APPLETS
        createUniqueCodeCheck(unique_code_RENEW_SIGN_YZ_APPLETS);
        logger.info("unique_code_RENEW_SIGN_YZ_APPLETS-创建成功");

        // 场景8-unique_code_NOT_LIMIT_KUAI_SHOU
        applyCheck(createUniqueCodeCheck(unique_code_NOT_LIMIT_KUAI_SHOU), newWscKdtId());
        logger.info("unique_code_NOT_LIMIT_KUAI_SHOU-WSC店铺-创建/核销成功");

        // 场景9-unique_code_NOT_LIMIT_JING_DONG
        applyCheck(createUniqueCodeCheck(unique_code_NOT_LIMIT_JING_DONG), newWscKdtId());
        logger.info("unique_code_NOT_LIMIT_JING_DONG-WSC店铺-创建/核销成功");

        // 场景10-unique_code_NOT_LIMIT_YZ_APPLETS
        applyCheck(createUniqueCodeCheck(unique_code_NOT_LIMIT_YZ_APPLETS), newWscKdtId());
        logger.info("unique_code_NOT_LIMIT_YZ_APPLETS-WSC店铺-创建/核销成功");

        // 场景11-combine_sku_retail_single_2021_profession_year wsc店铺激活零售的激活码
        applyCheck(createUniqueCodeCheck(combine_sku_retail_single_2021_profession_year), newWscKdtId());
        logger.info("combine_sku_retail_single_2021_profession_year-WSC店铺激活零售场景-创建/核销成功");
    }

    // 唯一码2个-校验生成2个
    @Test
    public void A02YcmCodeCreateUniqueYcmCodeTest() throws InterruptedException {
        // 场景11-2个唯一码，生成2个
        String batch_no = createMultiUniqueCodeCheck(WSC2021_unique_code_2_RENEW_KUAI_SHOU);
    }

    // 激活码-异常场景,非打包售卖
    @Test
    public void A03YcmCodeCreateYcmCodeAbnormalTest() throws InterruptedException {
        // 场景1-非打包类：插件
        createNotSaleCodeCheck(Not_sale_feidabao);

        // 场景2-非打包类：市场洞察
        createNotSaleCodeCheck(Not_sale_market_insight);

        // 周期库存型-续签不支持
        PlainResult<CreateYcmCodeResponse> config = ycmRedeemCodeRemoteService.createYcmCode(Period_Stock_1_RENEW);
        Assert.assertEquals(5202010, config.getCode());
        Assert.assertEquals("包含周期库存型商品的激活码不允许使用在非新购场景", config.getMessage());

        // 周期库存型-不限制 不支持
        PlainResult<CreateYcmCodeResponse> config2 = ycmRedeemCodeRemoteService.createYcmCode(Period_Stock_2_NOLIMIT);
        Assert.assertEquals(5202010, config2.getCode());
        Assert.assertEquals("包含周期库存型商品的激活码不允许使用在非新购场景", config2.getMessage());
    }

    // 唯一码-激活码 创建与零售店铺核销
    @Test
    public void A04YcmCodeApplyYcmCodeTest() throws InterruptedException {
        // 场景:核销唯一码-LS店铺
        // 场景2-unique_code_NEW_SIGN_KUAI_SHOU
        applyCheck(createUniqueCodeCheck(unique_code_NEW_SIGN_KUAI_SHOU), newRetailKdtId());
        logger.info("unique_code_NEW_SIGN_KUAI_SHOU-LS店铺-创建/核销成功");

        // 场景3-unique_code_NEW_SIGN_JING_DONG
        applyCheck(createUniqueCodeCheck(unique_code_NEW_SIGN_JING_DONG), newRetailKdtId());
        logger.info("unique_code_NEW_SIGN_JING_DONG-LS店铺-创建/核销成功");

        // 场景4-unique_code_NEW_SIGN_JING_DONG
        applyCheck(createUniqueCodeCheck(unique_code_NEW_SIGN_YZ_APPLETS), newRetailKdtId());
        logger.info("unique_code_NEW_SIGN_JING_DONG-LS店铺-创建/核销成功");

        // 场景8-unique_code_NOT_LIMIT_KUAI_SHOU
        applyCheck(createUniqueCodeCheck(unique_code_NOT_LIMIT_KUAI_SHOU), newRetailKdtId());
        logger.info("unique_code_NOT_LIMIT_KUAI_SHOU-LS店铺-创建/核销成功");

        // 场景9-unique_code_NOT_LIMIT_JING_DONG
        applyCheck(createUniqueCodeCheck(unique_code_NOT_LIMIT_JING_DONG), newRetailKdtId());
        logger.info("unique_code_NOT_LIMIT_JING_DONG-LS店铺-创建/核销成功");

        // 场景10-unique_code_NOT_LIMIT_YZ_APPLETS
        applyCheck(createUniqueCodeCheck(unique_code_NOT_LIMIT_YZ_APPLETS), newRetailKdtId());
        logger.info("unique_code_NOT_LIMIT_YZ_APPLETS-LS店铺-创建/核销成功");

    }

    // 核销激活码-异常测试
    @Test
    public void A05YcmCodeApplyYcmCodeAbNormalTest() {
        // 场景1：【过期】不支持激活
        PlainResult<ApplyYcmCodeResponse> result1 = applyAbnormalCheck("HQT5T4V9YS2R", wscKdtId);
        Assert.assertEquals(5202004, result1.getCode());
        Assert.assertEquals("兑换码已过期,不可核销", result1.getMessage());

        // 场景2：【已失效】不支持激活
        PlainResult<ApplyYcmCodeResponse> result2 = applyAbnormalCheck("7C8H8S3EHWEG", wscKdtId);
        Assert.assertEquals(5202004, result2.getCode());
        Assert.assertEquals("兑换码已失效,不可再核销", result2.getMessage());

        // 场景3：【已使用 2/2】通用码，不支持激活
        PlainResult<ApplyYcmCodeResponse> result3 = applyAbnormalCheck("5DRMJEXNKRXD", wscKdtId);
        Assert.assertEquals(5202004, result3.getCode());
        Assert.assertEquals("兑换码核销次数超过上限,不可再核销", result3.getMessage());

        // 场景4：【已使用 1/1】唯一码，不支持激活
        PlainResult<ApplyYcmCodeResponse> result4 = applyAbnormalCheck("E8EGZ8BV9EJ5", wscKdtId);
        Assert.assertEquals(5202004, result4.getCode());
        Assert.assertEquals("兑换码核销次数超过上限,不可再核销", result4.getMessage());

        // 场景5：【未生效】不支持激活
        PlainResult<ApplyYcmCodeResponse> result5 = applyAbnormalCheck("7WB96X97VCFU", wscKdtId);
        Assert.assertEquals(5202004, result5.getCode());
        Assert.assertEquals("未到兑换码可核销时间,不可核销", result5.getMessage());

        // 场景6：零售单店，核销校验失败 微商城+插件 激活码
        String wscWithPluginCode = "DEPD6ZPWQQQ5";
        // 确保状态还是可用的
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
        queryYcmCodeDetailRequest.setCode(wscWithPluginCode);
        PlainResult<QueryYcmCodeDetailResponse> config = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(200, config.getCode());
        Assert.assertEquals("VALID", config.getData().getYcmRedeemCodeDTO().getState());

        Long kdtId = newRetailKdtId();

        PlainResult<OpenCodeCheckResApi> result6 = AbnormalCheck(wscWithPluginCode, kdtId);
        if (result6.getCode() == 170002) {
            Assert.assertEquals("当前类型店铺无法使用该激活码", result6.getMessage());
        } else if (result6.getCode() == 40207) {
            Assert.assertEquals("操作太频繁，请24小时后再试", result6.getMessage());
        } else {
            Assert.fail("LS 激活码微商城 校验失败");
        }

        // 场景7：零售单店，核销校验失败 微商城 激活码
        String wscOnlyCode = "MPVTUZT2NCNW";
        // 确保状态还是可用的
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest1 = new QueryYcmCodeDetailRequest();
        queryYcmCodeDetailRequest1.setCode(wscOnlyCode);
        PlainResult<QueryYcmCodeDetailResponse> config1 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest1);
        Assert.assertEquals(200, config1.getCode());
        Assert.assertEquals("VALID", config1.getData().getYcmRedeemCodeDTO().getState());

        PlainResult<OpenCodeCheckResApi> result7 = AbnormalCheck(wscOnlyCode, kdtId);
        if (result7.getCode() == 170002) {
            Assert.assertEquals("当前类型店铺无法使用该激活码", result6.getMessage());
        } else if (result7.getCode() == 40207) {
            Assert.assertEquals("操作太频繁，请24小时后再试", result6.getMessage());
        } else {
            Assert.fail("LS 激活码微商城 校验失败");
        }

    }

    // 查询SPU列表
    @Test
    public void A06getSupportCodeSpuListTest() {
        PlainResult<CodeSupportSpuListResponse> spu = activationCodeQueryRemoteService.getSupportCodeSpuList();
        Assert.assertEquals(200, spu.getCode());
        if (spu.getData().getSpuDTOList().size() >= 10) {
            for (ActivationCodeSpuDTO activationCodeSpuDTO : spu.getData().getSpuDTOList()) {
                if (activationCodeSpuDTO.getSpuName().equals("QQ小程序") || activationCodeSpuDTO.getSpuName().equals("WSP测试插件0929-05")) {
                    Assert.fail("不应该显示：QQ小程序,WSP测试插件0929-05");
                }
            }
        } else {
            Assert.fail("SPU列表异常");
        }
        ActivationCodeSpuDTO activationCodeSpuDTO1 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO1.setSpuName("有赞微商城");
        activationCodeSpuDTO1.setSpuId("combine_spu_wsc");

        ActivationCodeSpuDTO activationCodeSpuDTO2 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO2.setSpuName("周期购");
        activationCodeSpuDTO2.setSpuId("atom_spu_period_buy");

        ActivationCodeSpuDTO activationCodeSpuDTO3 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO3.setSpuName("社区团购");
        activationCodeSpuDTO3.setSpuId("atom_spu_group_buy");

        ActivationCodeSpuDTO activationCodeSpuDTO4 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO4.setSpuName("有赞微商城");
        activationCodeSpuDTO4.setSpuId("combine_spu_retail_single");

        ActivationCodeSpuDTO activationCodeSpuDTO5 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO5.setSpuName("社区团购");
        activationCodeSpuDTO5.setSpuId("atom_spu_group_buy");

        ActivationCodeSpuDTO activationCodeSpuDTO6 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO6.setSpuName("分销员");
        activationCodeSpuDTO6.setSpuId("atom_spu_salesman_advance");

        ActivationCodeSpuDTO activationCodeSpuDTO7 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO7.setSpuName("秒杀");
        activationCodeSpuDTO7.setSpuId("atom_spu_seconds_kill");

        ActivationCodeSpuDTO activationCodeSpuDTO8 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO8.setSpuName("新店上线服务（微商城A版）");
        activationCodeSpuDTO8.setSpuId("atom_spu_youzan_rights_new_shop_ecommerce");

        ActivationCodeSpuDTO activationCodeSpuDTO90 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO90.setSpuName("定金膨胀");
        activationCodeSpuDTO90.setSpuId("atom_spu_down_payment_expand");

        ActivationCodeSpuDTO activationCodeSpuDTO91 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO91.setSpuName("支付宝小程序");
        activationCodeSpuDTO91.setSpuId("atom_spu_alipay_mini_program");

        ActivationCodeSpuDTO activationCodeSpuDTO92 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO92.setSpuName("新店上线服务（微商城B版）");
        activationCodeSpuDTO92.setSpuId("atom_spu_youzan_rights_new_shop_local_retail");
        ActivationCodeSpuDTO activationCodeSpuDTO93 = new ActivationCodeSpuDTO();
        activationCodeSpuDTO93.setSpuName("旺小店");
        activationCodeSpuDTO93.setSpuId("combine_spu_wang_xiao_dian");
        List<ActivationCodeSpuDTO> activationCodeSpuDTO = new ArrayList<>();
        activationCodeSpuDTO.add(0, activationCodeSpuDTO1);
        activationCodeSpuDTO.add(1, activationCodeSpuDTO2);
        activationCodeSpuDTO.add(2, activationCodeSpuDTO3);
        activationCodeSpuDTO.add(3, activationCodeSpuDTO4);
        activationCodeSpuDTO.add(4, activationCodeSpuDTO5);
        activationCodeSpuDTO.add(5, activationCodeSpuDTO6);
        activationCodeSpuDTO.add(6, activationCodeSpuDTO8);
        activationCodeSpuDTO.add(7, activationCodeSpuDTO8);
        activationCodeSpuDTO.add(8, activationCodeSpuDTO90);
        activationCodeSpuDTO.add(9, activationCodeSpuDTO91);
        activationCodeSpuDTO.add(10, activationCodeSpuDTO92);
        activationCodeSpuDTO.add(10, activationCodeSpuDTO93);



        if (!spu.getData().getSpuDTOList().containsAll(activationCodeSpuDTO)) {
            Assert.fail("应该显示：发票充值,有赞微商城，但是未显示");
        }
    }

    // 查询SKU列表
    @Test
    public void A07getSupportCodeSkuListTest() {
        CodeSupportSkuListRequest codeSupportSkuListRequest = new CodeSupportSkuListRequest();

        // 微商城-4个SKU
        codeSupportSkuListRequest.setSpuId("combine_spu_wsc");
        PlainResult<CodeSupportSkuListResponse> sku2 = activationCodeQueryRemoteService.getSupportCodeSkuList(codeSupportSkuListRequest);
        Assert.assertEquals(4, sku2.getData().getSkuDTOList().size());
        Assert.assertEquals("combine_sku_wsc_2021_basic_baidu_year", sku2.getData().getSkuDTOList().get(2).getSkuId());
        Assert.assertEquals("电商（2021）基础版（百度小程序）", sku2.getData().getSkuDTOList().get(2).getSkuName());
        Assert.assertEquals("combine_sku_wsc_2021_profession_year", sku2.getData().getSkuDTOList().get(3).getSkuId());
        Assert.assertEquals("电商（2021）专业版", sku2.getData().getSkuDTOList().get(3).getSkuName());
        Assert.assertEquals("combine_sku_wsc_2021_ultimate_year", sku2.getData().getSkuDTOList().get(0).getSkuId());
        Assert.assertEquals("电商（2021）旗舰版", sku2.getData().getSkuDTOList().get(0).getSkuName());
        Assert.assertEquals("combine_sku_wsc_2021_basic_wechat_year", sku2.getData().getSkuDTOList().get(1).getSkuId());
        Assert.assertEquals("电商（2021）基础版（微信小程序）", sku2.getData().getSkuDTOList().get(1).getSkuName());

        // 零售-4个SKU
        codeSupportSkuListRequest.setSpuId("combine_spu_retail_single");
        PlainResult<CodeSupportSkuListResponse> sku3 = activationCodeQueryRemoteService.getSupportCodeSkuList(codeSupportSkuListRequest);
        Assert.assertEquals(4, sku3.getData().getSkuDTOList().size());
        Assert.assertEquals("combine_sku_retail_single_2021_basic_alipay_weapp_year", sku3.getData().getSkuDTOList().get(0).getSkuId());
        Assert.assertEquals("（2022）门店基础版（支付宝小程序）", sku3.getData().getSkuDTOList().get(0).getSkuName());
        Assert.assertEquals("combine_sku_retail_single_2021_profession_year", sku3.getData().getSkuDTOList().get(3).getSkuId());
        Assert.assertEquals("（2022）门店专业版", sku3.getData().getSkuDTOList().get(3).getSkuName());
        Assert.assertEquals("combine_sku_retail_single_2021_basic_wechat_app_year", sku3.getData().getSkuDTOList().get(2).getSkuId());
        Assert.assertEquals("（2022）门店基础版（微信小程序）", sku3.getData().getSkuDTOList().get(2).getSkuName());
        Assert.assertEquals("combine_sku_retail_single_2021_basic_baidu_weapp_year", sku3.getData().getSkuDTOList().get(1).getSkuId());
        Assert.assertEquals("（2022）门店基础版（百度小程序）", sku3.getData().getSkuDTOList().get(1).getSkuName());

        // 周期购-1个SKU
        codeSupportSkuListRequest.setSpuId("atom_spu_period_buy");
        PlainResult<CodeSupportSkuListResponse> sku4 = activationCodeQueryRemoteService.getSupportCodeSkuList(codeSupportSkuListRequest);
        Assert.assertEquals(1, sku4.getData().getSkuDTOList().size());
        Assert.assertEquals("atom_sku_period_buy_year", sku4.getData().getSkuDTOList().get(0).getSkuId());
        Assert.assertEquals("1年", sku4.getData().getSkuDTOList().get(0).getSkuName());
    }

    // 激活码创建配置信息
    @Test
    public void A08getCodeCreateConfigRequest() {
        PlainResult<CodeCreateGetConfigResponse> config = activationCodeQueryRemoteService.getCodeCreateConfigRequest();
        Assert.assertEquals(200, config.getCode());
        Assert.assertEquals(3, config.getData().getCodeApplySceneDTOList().size());
        Assert.assertEquals(4, config.getData().getCodeSellChannelDTOList().size());

        CompareUtil.projectRequestCompare(config, codeCreateConfig, compareConfig);
    }

    // 获取可失效时间列表
    @Test
    public void A09getAvailableExpireTimeListServiceTest() {
        PlainResult<GetAvailableExpireTimeListResponse> expireTimeListService = activationCodeQueryRemoteService.getAvailableExpireTimeListService();
        Assert.assertEquals(200, expireTimeListService.getCode());
        Assert.assertEquals(2, expireTimeListService.getData().getCodeExpireTimeDTOList().size());

        CompareUtil.projectRequestCompare(expireTimeListService, getAvailableExpireTimeListResponsePlainResult, compareConfig);
    }

    // 激活码列表筛选
    @Test
    public void A10codePageQueryTest() {
        CodePageQueryRequest codePageQueryRequest = new CodePageQueryRequest();
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
        Assert.assertEquals(200, codePageQuery.getCode());
        // 校验1：查询全部，校验总量
        if (codePageQuery.getData().getTotal() <= 1730) {
            Assert.fail("激活码总数异常，数量过低");
        }
        // 校验2：查询指定激活码：86KKWNH95KDG
        codePageQueryRequest.setCode("86KKWNH95KDG");
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery1 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
        Assert.assertEquals(200, codePageQuery1.getCode());
        CompareUtil.projectRequestCompare(items, codePageQuery1.getData().getItems(), compareConfig);

        // 校验3：按照[状态]查询，每一种都有结果
        List<String> stateList = new ArrayList<>();
        stateList.add(0, "TO_BE_VALID"); //未生效
        stateList.add(1, "VALID"); //生效中
        stateList.add(2, "USED_UP"); //已使用
        stateList.add(3, "INVALID"); //已失效
        stateList.add(4, "EXPIRED"); //已过期
        for (String state : stateList) {
            CodePageQueryRequest codePageQueryRequest1 = new CodePageQueryRequest();
            codePageQueryRequest1.setState(state);
            codePageQueryRequest1.setCreateStartTime("2020-12-01 00:00:00");
            codePageQueryRequest1.setCreateEndTime("2022-12-08 00:00:00");
            PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery2 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
            if (codePageQuery2.getData().getTotal() <= 0) {
                Assert.fail("指定[状态]查询数量返回异常:" + state);
            }
        }

        // 校验4：按照[适用场景]查询，每一种都有结果
        List<String> sceneList = new ArrayList<>();
        sceneList.add(0, "NEW_SIGN"); //新签
        sceneList.add(1, "RENEW_SIGN"); //续费
        sceneList.add(2, "NOT_LIMIT"); //不限

        for (String scene : sceneList) {
            CodePageQueryRequest codePageQueryRequest1 = new CodePageQueryRequest();
            codePageQueryRequest1.setCodeApplyScene(scene);
            codePageQueryRequest1.setCreateStartTime("2020-12-01 00:00:00");
            codePageQueryRequest1.setCreateEndTime("2022-12-08 00:00:00");
            PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery2 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
            if (codePageQuery2.getData().getTotal() <= 0) {
                Assert.fail("指定[适用场景]查询数量返回异常:" + scene);
            }
        }

        // 校验5：按照[码类型]查询，每一种都有结果
        List<String> typeList = new ArrayList<>();
        typeList.add(0, "unique_code"); //唯一码
        typeList.add(1, "universal_code"); //通用码

        for (String type : typeList) {
            CodePageQueryRequest codePageQueryRequest1 = new CodePageQueryRequest();
            codePageQueryRequest1.setCodeType(type);
            codePageQueryRequest1.setCreateStartTime("2020-12-01 00:00:00");
            codePageQueryRequest1.setCreateEndTime("2022-12-08 00:00:00");
            PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery2 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
            if (codePageQuery2.getData().getTotal() <= 0) {
                Assert.fail("指定[码类型]查询数量返回异常:" + type);
            }
        }

        // 校验6：按照[批次号]查询，这一批次200个码
        codePageQueryRequest.setCode(null);
        codePageQueryRequest.setBatchNo("25202101071041370108064");
        codePageQueryRequest.setCreateStartTime("2020-12-01 00:00:00");
        codePageQueryRequest.setCreateEndTime("2022-12-08 00:00:00");
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery3 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
        Assert.assertEquals(200, codePageQuery3.getCode());
        Assert.assertEquals(200, codePageQuery3.getData().getTotal());

        // 校验7：按照[商品名称]查询
        CodePageQueryRequest codePageQueryRequest1 = new CodePageQueryRequest();
        codePageQueryRequest1.setSkuName("专业版");
        codePageQueryRequest1.setCreateStartTime("2020-12-01 00:00:00");
        codePageQueryRequest1.setCreateEndTime("2022-12-08 00:00:00");
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery4 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest1);
        Assert.assertEquals(200, codePageQuery4.getCode());
        if (codePageQuery4.getData().getTotal() < 62) {
            Assert.fail("指定[商品名称：有赞微商城：]查询数量返回异常，实际查询返回：" + codePageQuery4.getData().getTotal());
        }
        // 不存在的商品名称
        codePageQueryRequest1.setSkuName("wulei");
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery41 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest1);
        Assert.assertEquals(200, codePageQuery41.getCode());
        Assert.assertEquals(0, codePageQuery41.getData().getTotal());

        // 校验8：组合查询
        CodePageQueryRequest codePageQueryRequest2 = new CodePageQueryRequest();
        codePageQueryRequest2.setSkuName("有赞微商城");
        codePageQueryRequest2.setCreateStartTime("2020-12-31 00:00:00");
        codePageQueryRequest2.setCreateEndTime("2022-12-08 00:00:00");
        codePageQueryRequest2.setCodeApplyScene("NEW_SIGN");
        codePageQueryRequest2.setCodeType("universal_code");
        codePageQueryRequest2.setState("EXPIRED");
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery5 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest2);
        Assert.assertEquals(200, codePageQuery5.getCode());
        Assert.assertEquals(5, codePageQuery5.getData().getItems().size());
        Assert.assertEquals("V3NF94GK4KEH", codePageQuery5.getData().getItems().get(0).getCode());

        // 校验8：组合查询:2
        CodePageQueryRequest codePageQueryRequest3 = new CodePageQueryRequest();
        codePageQueryRequest3.setCreateStartTime("2020-12-01 00:00:00");
        codePageQueryRequest3.setCreateEndTime("2022-12-08 00:00:00");
        codePageQueryRequest3.setSkuName("有赞微商城");
        codePageQueryRequest3.setCodeApplyScene("NEW_SIGN");
        codePageQueryRequest3.setCodeType("universal_code");
        codePageQueryRequest3.setState("EXPIRED");
        codePageQueryRequest3.setCode("Q6687B65Z69E1");
        codePageQueryRequest3.setBatchNo("25202012221937180102448");
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery6 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest3);
        Assert.assertEquals(200, codePageQuery6.getCode());
        Assert.assertEquals(0, codePageQuery6.getData().getItems().size());
        // 查询3
        codePageQueryRequest3.setSkuName("有赞微商城");
        codePageQueryRequest3.setCodeApplyScene("RENEW_SIGN");
        codePageQueryRequest3.setCodeType("universal_code");
        codePageQueryRequest3.setState("EXPIRED");
        codePageQueryRequest3.setCode("Q6687B65Z69E");
        codePageQueryRequest3.setBatchNo("25202012221937180102448");
        PlainResult<PageResponse<YcmActivationCodeDTO>> codePageQuery7 = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest3);
        Assert.assertEquals(200, codePageQuery7.getCode());
        Assert.assertEquals(0, codePageQuery7.getData().getItems().size());
    }

    // 已经激活的通用码列表筛选
    @Test
    public void A11universalCodeApplyRecordPageQueryTest() {
        UniversalCodeApplyRecordPageQueryRequest universalCodeApplyRecordPageQueryRequest = new UniversalCodeApplyRecordPageQueryRequest();
        universalCodeApplyRecordPageQueryRequest.setApplyStartTime("2020-12-01 00:00:00");
        universalCodeApplyRecordPageQueryRequest.setApplyEndTime("2022-12-08 00:00:00");
        universalCodeApplyRecordPageQueryRequest.setPageNumber(Integer.valueOf(1));
        universalCodeApplyRecordPageQueryRequest.setPageSize(Integer.valueOf(20));
        // 校验1：查询通用码：3NBB8TM6954K-已激活列表（60/150）
        universalCodeApplyRecordPageQueryRequest.setCode("3NBB8TM6954K");
        PlainResult<PageResponse<UniversalCodeApplyRecordDTO>> codeApplyRecordPageQuery = activationCodeQueryRemoteService.universalCodeApplyRecordPageQuery(universalCodeApplyRecordPageQueryRequest);
        Assert.assertEquals(200, codeApplyRecordPageQuery.getCode());
        Assert.assertEquals(20, codeApplyRecordPageQuery.getData().getItems().size());
        Assert.assertEquals(60, codeApplyRecordPageQuery.getData().getTotal());

        // 校验2：查询结果，再次查询：手机号码
        universalCodeApplyRecordPageQueryRequest.setApplyYcmMobile("16873162823");
        PlainResult<PageResponse<UniversalCodeApplyRecordDTO>> codeApplyRecordPageQuery1 = activationCodeQueryRemoteService.universalCodeApplyRecordPageQuery(universalCodeApplyRecordPageQueryRequest);
        Assert.assertEquals(200, codeApplyRecordPageQuery1.getCode());
        Assert.assertEquals(1, codeApplyRecordPageQuery1.getData().getItems().size());
        Assert.assertEquals(1, codeApplyRecordPageQuery1.getData().getTotal());

        // 校验3：查询结果，再次查询：手机号码：
        universalCodeApplyRecordPageQueryRequest.setApplyYcmMobile("13018975654");
        PlainResult<PageResponse<UniversalCodeApplyRecordDTO>> codeApplyRecordPageQuery2 = activationCodeQueryRemoteService.universalCodeApplyRecordPageQuery(universalCodeApplyRecordPageQueryRequest);
        Assert.assertEquals(200, codeApplyRecordPageQuery2.getCode());
        Assert.assertEquals(20, codeApplyRecordPageQuery2.getData().getItems().size());
        Assert.assertEquals(53, codeApplyRecordPageQuery2.getData().getTotal());

        // 校验3：查询结果，再次查询：店铺ID：
        universalCodeApplyRecordPageQueryRequest.setApplyYcmMobile(null);
        universalCodeApplyRecordPageQueryRequest.setApplyYcmId("58801853");
        PlainResult<PageResponse<UniversalCodeApplyRecordDTO>> codeApplyRecordPageQuery3 = activationCodeQueryRemoteService.universalCodeApplyRecordPageQuery(universalCodeApplyRecordPageQueryRequest);
        Assert.assertEquals(200, codeApplyRecordPageQuery3.getCode());
        Assert.assertEquals(7, codeApplyRecordPageQuery3.getData().getItems().size());
        Assert.assertEquals(7, codeApplyRecordPageQuery3.getData().getTotal());

        // 校验4：组合查询
        universalCodeApplyRecordPageQueryRequest.setApplyYcmMobile("13018975654");
        universalCodeApplyRecordPageQueryRequest.setApplyYcmId("58802807");
        PlainResult<PageResponse<UniversalCodeApplyRecordDTO>> codeApplyRecordPageQuery4 = activationCodeQueryRemoteService.universalCodeApplyRecordPageQuery(universalCodeApplyRecordPageQueryRequest);
        Assert.assertEquals(200, codeApplyRecordPageQuery4.getCode());
        Assert.assertEquals(7, codeApplyRecordPageQuery4.getData().getItems().size());
        Assert.assertEquals(7, codeApplyRecordPageQuery3.getData().getTotal());

        // 校验5：组合查询,再次查询
        universalCodeApplyRecordPageQueryRequest.setActivationYcmTradeNo("23202012241834190113716");
        PlainResult<PageResponse<UniversalCodeApplyRecordDTO>> codeApplyRecordPageQuery5 = activationCodeQueryRemoteService.universalCodeApplyRecordPageQuery(universalCodeApplyRecordPageQueryRequest);
        Assert.assertEquals(200, codeApplyRecordPageQuery5.getCode());
        Assert.assertEquals(1, codeApplyRecordPageQuery5.getData().getItems().size());
        Assert.assertEquals(1, codeApplyRecordPageQuery5.getData().getTotal());
    }

    // 查询激活码详情
    @Test
    public void A12YcmCodeQueryYcmCodeDetail() {
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
        // 场景1-null校验
        queryYcmCodeDetailRequest.setCode(null);
        PlainResult<QueryYcmCodeDetailResponse> config = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(5200001, config.getCode());
        Assert.assertEquals("参数非法", config.getMessage());

        // 场景2-空校验
        queryYcmCodeDetailRequest.setCode("");
        PlainResult<QueryYcmCodeDetailResponse> config2 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(5200001, config2.getCode());
        Assert.assertEquals("参数非法", config2.getMessage());

        // 场景3-不存在的code
        queryYcmCodeDetailRequest.setCode("1");
        PlainResult<QueryYcmCodeDetailResponse> config3 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(200, config3.getCode());
        Assert.assertEquals("查询商业化码信息不存在", config3.getMessage());

        // 场景3-存在的code-通用码-未使用
        queryYcmCodeDetailRequest.setCode("S3QKXJ6MCE82");
        PlainResult<QueryYcmCodeDetailResponse> config4 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(200, config4.getCode());
        Assert.assertEquals(1, config4.getData().getApplyRecordNoList().size());
        Assert.assertEquals("25202101041834170202160", config4.getData().getApplyRecordNoList().get(0));
        CompareUtil.projectRequestCompare(ycmRedeemCodeDTO, config4.getData().getYcmRedeemCodeDTO(), compareConfig);
        Assert.assertEquals("NOT_LIMIT", config4.getData().getYcmCodeDetailBizContent().get("codeApplyScene"));
        Assert.assertEquals("100.0", config4.getData().getYcmCodeDetailBizContent().get("price").toString());
        Assert.assertEquals("JING_DONG", config4.getData().getYcmCodeDetailBizContent().get("sellChannel"));
        List<LinkedHashMap> item = (ArrayList<LinkedHashMap>) config4.getData().getYcmCodeDetailBizContent().get("goodsItemList");
        Assert.assertEquals("atom_sku_message_recharge_one_thousand", item.get(0).get("skuId"));
        Assert.assertEquals("1000条", item.get(0).get("skuName"));
        Assert.assertEquals("1.0", item.get(0).get("skuNum").toString());
        Assert.assertEquals("atom_spu_message_recharge", item.get(0).get("spuId"));
        Assert.assertEquals("短信充值", item.get(0).get("spuName"));
    }

    // 复杂场景1-激活续费类型的WSC-2021
    @Test
    public void A13YcmCodeApplyWSCYcmCodeTest() throws InterruptedException {
        Long kdtId = newWscKdtId();
        // 下单1年基础版本
        PlainResult<OrderCreateApi> result = testCreateOrder(kdtId, yunKdtName9, wscWXItemId_2021, 1);
        // 订购微商城2021-基础版
        Assert.assertEquals(200, result.getCode());
        // 微商城 2021-基础版
        applyCheck(createUniqueCodeCheck(WSC2021_unique_code_RENEW_KUAI_SHOU), kdtId);
        // 可以预支
        testCanAdvanceOrderQuota(kdtId.toString(), Boolean.TRUE);
    }

    // 复杂场景2-激活续费类型的LS-2021
    @Test
    public void A14YcmCodeApplyLSYcmCodeTest() throws InterruptedException {
        Long kdtId = newRetailKdtId();

        // 订购LS2021-基础版
        PlainResult<OrderCreateApi> result = testCreateOrder(kdtId, yunKdtName9, lsWXItemId_2021, 1);

        Assert.assertEquals(200, result.getCode());
        // LS 2021-基础版 激活码生生成和获取
        applyCheck(createUniqueCodeCheck(LS2021_unique_code_RENEW_KUAI_SHOU), kdtId);
        // 可以预支
        testCanAdvanceOrderQuota(kdtId.toString(), Boolean.TRUE);
    }

    // 复杂场景3-WSC-2021-2次通用码-激活第2次报错:1个2次的通用码，一个手机号码只能激活1个店铺，激活第2店铺失败
    @Test
    public void A15YcmCodeApplyUniversalYcmCodeTest() throws InterruptedException {
        // 创建 通用码2，WSC
        EnableNewKdtIdResponse result1 =  getKdtId("wsc");
        EnableNewKdtIdResponse result2 =  getKdtId("wsc");
        //如果获取的2个店铺是同1手机号码，再进行验证
        if(result1.getUserId().equals(result2.getUserId())){
            Long kdtId1=result1.getKdtId();
            Long kdtId2=result2.getKdtId();

            String code = createUniqueCodeCheck(WSC2021_universal_code_2_NOT_LIMIT_TAO_BAO);
            try{
                // 创建后数据库判断
                universalCodeCreatedDBCheck(code);
                // 激活2次-同一个手机仅可以激活1次，此case存在问题
                universalCodeApplyCheck(code, kdtId1, "VALID", 0);

                // 激活前-校验激活码状态-VALID
                QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
                queryYcmCodeDetailRequest.setCode(code);
                PlainResult<QueryYcmCodeDetailResponse> beforeApply = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
                Assert.assertEquals(200, beforeApply.getCode());
                Assert.assertEquals("VALID", beforeApply.getData().getYcmRedeemCodeDTO().getState());
                Assert.assertEquals(1, beforeApply.getData().getApplyRecordNoList().size());

                // 核销
                ApplyYcmCodeRequest applyYcmCodeRequest = new ApplyYcmCodeRequest();
                applyYcmCodeRequest.setCode(code);
                applyYcmCodeRequest.setApplyChannel("PC");
                applyYcmCodeRequest.setApplyYcmId(kdtId2.toString());
                applyYcmCodeRequest.setApplyYcmType("KDT_ID");
                PlainResult<ApplyYcmCodeResponse> applyResult = ycmRedeemCodeRemoteService.applyYcmCode(applyYcmCodeRequest);
                Assert.assertEquals(5202014, applyResult.getCode());
                Assert.assertEquals("激活码已使用，一个激活码只能在一个手机号绑定的店铺兑换一次", applyResult.getMessage());
            }finally {
                // 清理
                clearActivateCode(code);
            }
        }


    }

    // 回收激活码：唯一码，通用码回收
    @Test
    public void A16YcmCodeInvalidateCodeTest() throws InterruptedException {
        // ####################### 场景1-通用码
        // 创建激活码-通用码
        String code = createUniqueCodeCheck(WSC2021_universal_code_2_NOT_LIMIT_TAO_BAO);
        // 回收
        InvalidateYcmCodeRequest invalidateYcmCodeRequest = new InvalidateYcmCodeRequest();
        invalidateYcmCodeRequest.setCode(code);
        PlainResult<InvalidateYcmCodeResponse> result = ycmRedeemCodeRemoteService.invalidateYcmCode(invalidateYcmCodeRequest);
        Assert.assertEquals(200, result.getCode());
        // 校验状态
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
        queryYcmCodeDetailRequest.setCode(code);
        PlainResult<QueryYcmCodeDetailResponse> result1 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(200, result1.getCode());
        Assert.assertEquals("INVALID", result1.getData().getYcmRedeemCodeDTO().getState());

        // ####################### 场景2-唯一码
        // 创建激活码-唯一码
        String code1 = createUniqueCodeCheck(unique_code_NOT_LIMIT_YZ_APPLETS);
        // 回收
        InvalidateYcmCodeRequest invalidateYcmCodeRequest1 = new InvalidateYcmCodeRequest();
        invalidateYcmCodeRequest1.setCode(code1);
        PlainResult<InvalidateYcmCodeResponse> result2 = ycmRedeemCodeRemoteService.invalidateYcmCode(invalidateYcmCodeRequest1);
        Assert.assertEquals(200, result2.getCode());
        // 校验状态
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest1 = new QueryYcmCodeDetailRequest();
        queryYcmCodeDetailRequest1.setCode(code);
        PlainResult<QueryYcmCodeDetailResponse> result3 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest1);
        Assert.assertEquals(200, result3.getCode());
        Assert.assertEquals("INVALID", result3.getData().getYcmRedeemCodeDTO().getState());
    }

    // 延期激活码
    @Test
    public void A17YcmCodeEXTENDCodeTest() throws InterruptedException {
        // ####################### 场景1-通用码
        // 创建激活码-通用码
        String code = createUniqueCodeCheck(WSC2021_universal_code_2_NOT_LIMIT_TAO_BAO);
        // 延期 30天
        UpdateYcmCodeExpireTimeRequest updateYcmCodeExpireTimeRequest = new UpdateYcmCodeExpireTimeRequest();
        updateYcmCodeExpireTimeRequest.setCode(code);
        updateYcmCodeExpireTimeRequest.setTimeIntervalUnit("DAY");
        updateYcmCodeExpireTimeRequest.setTimeInterval(30L);
        updateYcmCodeExpireTimeRequest.setTimeUpdateType("EXTEND");

        PlainResult<UpdateYcmCodeExpireTimeResponse> result = ycmRedeemCodeRemoteService.updateYcmCodeExpireTime(updateYcmCodeExpireTimeRequest);
        Assert.assertEquals(200, result.getCode());
        // 校验状态
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
        queryYcmCodeDetailRequest.setCode(code);
        PlainResult<QueryYcmCodeDetailResponse> result1 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(200, result1.getCode());
        Assert.assertEquals("2023-03-02 21:38:08", result1.getData().getYcmRedeemCodeDTO().getApplyEndTime());
        Assert.assertEquals("2021-01-07 21:38:08", result1.getData().getYcmRedeemCodeDTO().getApplyStartTime());
        Assert.assertEquals("VALID", result1.getData().getYcmRedeemCodeDTO().getState());
        Assert.assertEquals(Long.valueOf(2), result1.getData().getYcmRedeemCodeDTO().getRemainStock());
        Assert.assertEquals(3, result1.getData().getYcmRedeemCodeDTO().getBizExt().size());
        Assert.assertEquals("1", result1.getData().getYcmRedeemCodeDTO().getBizExt().get("expire_time_update_times"));

        // 再次延期1次
        PlainResult<UpdateYcmCodeExpireTimeResponse> result2 = ycmRedeemCodeRemoteService.updateYcmCodeExpireTime(updateYcmCodeExpireTimeRequest);
        Assert.assertEquals(5202002, result2.getCode());
        Assert.assertEquals("商业化码延期次数超过1次", result2.getMessage());


        // ####################### 场景2-唯一码
        // 创建激活码-唯一码
        String code1 = createUniqueCodeCheck(unique_code_NOT_LIMIT_YZ_APPLETS);
        // 延期 30天
        UpdateYcmCodeExpireTimeRequest updateYcmCodeExpireTimeRequest2 = new UpdateYcmCodeExpireTimeRequest();
        updateYcmCodeExpireTimeRequest2.setCode(code1);
        updateYcmCodeExpireTimeRequest2.setTimeIntervalUnit("YEAR");
        updateYcmCodeExpireTimeRequest2.setTimeInterval(1L);
        updateYcmCodeExpireTimeRequest2.setTimeUpdateType("EXTEND");

        PlainResult<UpdateYcmCodeExpireTimeResponse> result3 = ycmRedeemCodeRemoteService.updateYcmCodeExpireTime(updateYcmCodeExpireTimeRequest2);
        Assert.assertEquals(200, result3.getCode());
        // 校验状态
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest1 = new QueryYcmCodeDetailRequest();
        queryYcmCodeDetailRequest1.setCode(code1);
        PlainResult<QueryYcmCodeDetailResponse> result4 = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest1);
        Assert.assertEquals(200, result4.getCode());
        Assert.assertEquals("2024-01-31 21:38:08", result4.getData().getYcmRedeemCodeDTO().getApplyEndTime());
        Assert.assertEquals("2021-01-07 21:38:08", result4.getData().getYcmRedeemCodeDTO().getApplyStartTime());
        Assert.assertEquals("VALID", result4.getData().getYcmRedeemCodeDTO().getState());
        Assert.assertEquals(Long.valueOf(1), result4.getData().getYcmRedeemCodeDTO().getRemainStock());
        Assert.assertEquals(3, result4.getData().getYcmRedeemCodeDTO().getBizExt().size());
        Assert.assertEquals("1", result4.getData().getYcmRedeemCodeDTO().getBizExt().get("expire_time_update_times"));

        // 再次延期1次
        PlainResult<UpdateYcmCodeExpireTimeResponse> result5 = ycmRedeemCodeRemoteService.updateYcmCodeExpireTime(updateYcmCodeExpireTimeRequest2);
        Assert.assertEquals(5202002, result5.getCode());
        Assert.assertEquals("商业化码延期次数超过1次", result5.getMessage());

    }

    // 新店上线服务+2021 软件 todo 激活校验
    @Test
    public void A18YcmCodeNewSign2021WithNewShopSerTest() throws InterruptedException {
        Long kdtId = newWscKdtId();
        // 创建激活码-通用码+2软件
        String code = createUniqueCode2SoftwaresCheck(WSC2021_2_Softwares);
        applyCheck(code,kdtId);
    }

    /**
     * 清理激活码关联数据库
     *
     * @param code
     */
    public void clearActivateCode(String code) {
        if (StringUtils.isNotEmpty(code)) {
            String batchNo = cdRedeemCodeMapper.selectOne(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, code)).getBatchNo();
            cdRedeemCodeMapper.delete(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, code));
            cdRedeemCodeBatchMapper.delete(new QueryWrapper<CdRedeemCodeBatchEntity>().lambda().eq(CdRedeemCodeBatchEntity::getBatchNo, batchNo));
            cdRedeemCodeApplyRecordMapper.delete(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getCode, code));
            cdRedeemCodeApplyMutexMapper.delete(new QueryWrapper<CdRedeemCodeApplyMutexEntity>().lambda().eq(CdRedeemCodeApplyMutexEntity::getCode, code));
            cdRedeemCodeDistributeRecordMapper.delete(new QueryWrapper<CdRedeemCodeDistributeRecordEntity>().lambda().eq(CdRedeemCodeDistributeRecordEntity::getCode, code));
            tdActivationCodeMapper.delete(new QueryWrapper<TdActivationCodeEntity>().lambda().eq(TdActivationCodeEntity::getCode, code));
            tdActivationCodeGoodsItemMapper.delete(new QueryWrapper<TdActivationCodeGoodsItemEntity>().lambda().eq(TdActivationCodeGoodsItemEntity::getCode, code));
            tdActivationCodeApplyRecordMapper.delete(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getCode, code));
        }
    }

    /**
     * 唯一码 创建与校验
     *
     * @param request
     */
    public String createUniqueCodeCheck(CreateYcmCodeRequest request) throws InterruptedException {
        PlainResult<CreateYcmCodeResponse> config3 = ycmRedeemCodeRemoteService.createYcmCode(request);
        Assert.assertEquals(200, config3.getCode());
        Assert.assertEquals("successful", config3.getMessage());
        Assert.assertEquals(true, config3.getData().isOperateSuccess());
        Assert.assertEquals("wulei_wl", config3.getData().getCodeBatchDTO().getCreaterName());
        Assert.assertEquals("11734", config3.getData().getCodeBatchDTO().getCreaterYcmId());
        Assert.assertEquals("EMPLOYEE_ID", config3.getData().getCodeBatchDTO().getCreaterYcmType());
        // 创建后根据唯一码的批次吗查询的返回结果为1
        Thread.sleep(1000);
        CodePageQueryRequest codePageQueryRequest = new CodePageQueryRequest();
        codePageQueryRequest.setBatchNo(config3.getData().getCodeBatchDTO().getBatchNo());
        codePageQueryRequest.setCreateStartTime("2020-12-01 00:00:00");
        codePageQueryRequest.setCreateEndTime("2022-12-08 00:00:00");
        PlainResult<PageResponse<YcmActivationCodeDTO>> result = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
        logger.info("批次号：" + config3.getData().getCodeBatchDTO().getBatchNo());
        logger.info("激活码：" + result.getData().getItems().get(0).getCode());

        Assert.assertEquals(200, result.getCode());
        Assert.assertEquals(1, result.getData().getItems().size());
        Assert.assertEquals(config3.getData().getCodeBatchDTO().getBatchNo(), result.getData().getItems().get(0).getBatchNo());
        Assert.assertEquals("VALID", result.getData().getItems().get(0).getState());
        return result.getData().getItems().get(0).getCode();
    }

    /**
     * 唯一码 创建与校验
     *
     * @param request
     */
    public String createUniqueCode2SoftwaresCheck(CreateYcmCodeRequest request) throws InterruptedException {
        PlainResult<CreateYcmCodeResponse> config3 = ycmRedeemCodeRemoteService.createYcmCode(request);
        Assert.assertEquals(200, config3.getCode());
        Assert.assertEquals("successful", config3.getMessage());
        Assert.assertEquals(true, config3.getData().isOperateSuccess());
        Assert.assertEquals("wulei_wl", config3.getData().getCodeBatchDTO().getCreaterName());
        Assert.assertEquals("11734", config3.getData().getCodeBatchDTO().getCreaterYcmId());
        Assert.assertEquals("EMPLOYEE_ID", config3.getData().getCodeBatchDTO().getCreaterYcmType());
        // 创建后根据唯一码的批次吗查询的返回结果为1
        Thread.sleep(1000);
        CodePageQueryRequest codePageQueryRequest = new CodePageQueryRequest();
        codePageQueryRequest.setBatchNo(config3.getData().getCodeBatchDTO().getBatchNo());
        codePageQueryRequest.setCreateStartTime("2020-12-01 00:00:00");
        codePageQueryRequest.setCreateEndTime("2022-12-08 00:00:00");
        PlainResult<PageResponse<YcmActivationCodeDTO>> result = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
        logger.info("批次号：" + config3.getData().getCodeBatchDTO().getBatchNo());
        logger.info("激活码：" + result.getData().getItems().get(0).getCode());

        Assert.assertEquals(200, result.getCode());
        Assert.assertEquals(1, result.getData().getItems().size());
        Assert.assertEquals(config3.getData().getCodeBatchDTO().getBatchNo(), result.getData().getItems().get(0).getBatchNo());
        Assert.assertEquals("VALID", result.getData().getItems().get(0).getState());
        return result.getData().getItems().get(0).getCode();
    }

    /**
     * 唯一码 创建与校验2-库存为2
     *
     * @param request
     */
    public String createMultiUniqueCodeCheck(CreateYcmCodeRequest request) throws InterruptedException {
        PlainResult<CreateYcmCodeResponse> config3 = ycmRedeemCodeRemoteService.createYcmCode(request);
        Assert.assertEquals(200, config3.getCode());
        Assert.assertEquals("successful", config3.getMessage());
        Assert.assertEquals(true, config3.getData().isOperateSuccess());
        Assert.assertEquals("wulei_wl", config3.getData().getCodeBatchDTO().getCreaterName());
        Assert.assertEquals("11734", config3.getData().getCodeBatchDTO().getCreaterYcmId());
        Assert.assertEquals("EMPLOYEE_ID", config3.getData().getCodeBatchDTO().getCreaterYcmType());
        // 创建后根据唯一码的批次吗查询的返回结果为1
        Thread.sleep(1000);
        CodePageQueryRequest codePageQueryRequest = new CodePageQueryRequest();
        codePageQueryRequest.setBatchNo(config3.getData().getCodeBatchDTO().getBatchNo());
        codePageQueryRequest.setCreateStartTime("2020-12-01 00:00:00");
        codePageQueryRequest.setCreateEndTime("2022-12-08 00:00:00");
        PlainResult<PageResponse<YcmActivationCodeDTO>> result = activationCodeQueryRemoteService.codePageQuery(codePageQueryRequest);
        logger.info("批次号：" + config3.getData().getCodeBatchDTO().getBatchNo());
        logger.info("激活码：" + result.getData().getItems().get(0).getCode());

        Assert.assertEquals(200, result.getCode());
        Assert.assertEquals(2, result.getData().getItems().size());
        Assert.assertEquals(2, result.getData().getTotal());
        Assert.assertEquals(config3.getData().getCodeBatchDTO().getBatchNo(), result.getData().getItems().get(0).getBatchNo());
        Assert.assertEquals("VALID", result.getData().getItems().get(0).getState());
        return result.getData().getItems().get(0).getBatchNo();
    }

    /**
     * 通用码创建后的数据库校验
     *
     * @param code
     */
    public void universalCodeCreatedDBCheck(String code) {
        if (StringUtils.isNotEmpty(code)) {
            // cd_redeem_code 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> cdRedeemCodeMapper.selectList(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, code)).size() == 1);

            CdRedeemCodeEntity codeEntity = cdRedeemCodeMapper.selectOne(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, code));
            String batch_no = codeEntity.getBatchNo();
            Assert.assertEquals(code, codeEntity.getCode());
            Assert.assertEquals("", codeEntity.getDescription());
            Assert.assertEquals("", codeEntity.getName());
            Assert.assertEquals("universal_code", codeEntity.getType());
            Assert.assertEquals("VALID", codeEntity.getState());
            Assert.assertEquals("ycm_trade_order", codeEntity.getPerformType());
            Assert.assertEquals(Integer.valueOf(2), codeEntity.getInitStock());
            Assert.assertEquals("{\"code_identity_apply_times_upper_bound\":\"1\",\"identity_apply_times_upper_bound\":\"1\"}", codeEntity.getBizExt());
            Assert.assertEquals(null, codeEntity.getRecycle_time());
            dateCompare(codeEntity.getApplyStartTime(), "2021-01-07 09:38:08");
            dateCompare(codeEntity.getApplyEndTime(), "2023-01-31 09:38:08");


            // cd_redeem_code_batch 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> cdRedeemCodeBatchMapper.selectList(new QueryWrapper<CdRedeemCodeBatchEntity>().lambda().eq(CdRedeemCodeBatchEntity::getBatchNo, batch_no)).size() == 1);

            CdRedeemCodeBatchEntity cdRedeemCodeBatchEntity = cdRedeemCodeBatchMapper.selectOne(new QueryWrapper<CdRedeemCodeBatchEntity>().lambda().eq(CdRedeemCodeBatchEntity::getBatchNo, batch_no));
            Assert.assertEquals(batch_no, cdRedeemCodeBatchEntity.getBatchNo());
            Assert.assertEquals("ycm_trade_order", cdRedeemCodeBatchEntity.getPerformType());
            Assert.assertEquals("universal_code", cdRedeemCodeBatchEntity.getType());
            dateCompare(cdRedeemCodeBatchEntity.getApplyStartTime(), "2021-01-07 09:38:08");
            dateCompare(cdRedeemCodeBatchEntity.getApplyEndTime(), "2023-01-31 09:38:08");
            Assert.assertEquals(Integer.valueOf(2), cdRedeemCodeBatchEntity.getInitStock());
            Assert.assertEquals(Integer.valueOf(1), cdRedeemCodeBatchEntity.getCodeNum());
            Assert.assertEquals(Integer.valueOf(1), cdRedeemCodeBatchEntity.getCreatedCodeNum());
            Assert.assertEquals("EMPLOYEE_ID", cdRedeemCodeBatchEntity.getCreaterYcmType());
            Assert.assertEquals("11734", cdRedeemCodeBatchEntity.getCreaterYcmId());
            Assert.assertEquals("wulei_wl", cdRedeemCodeBatchEntity.getCreaterName());
            Assert.assertEquals("", cdRedeemCodeBatchEntity.getBizExt());
            Assert.assertEquals("{\"codeApplyScene\":\"NOT_LIMIT\",\"price\":\"100\",\"sellChannel\":\"TAO_BAO\",\"goodsItemList\":[{\"spuId\":\"combine_spu_wsc\",\"skuId\":\"combine_sku_wsc_2021_basic_baidu_year\",\"skuNum\":1}]}", cdRedeemCodeBatchEntity.getCodeCreateBizContent());

            // td_activation_code 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> tdActivationCodeMapper.selectList(new QueryWrapper<TdActivationCodeEntity>().lambda().eq(TdActivationCodeEntity::getCode, code)).size() == 1);

            TdActivationCodeEntity tdActivationCodeEntity = tdActivationCodeMapper.selectOne(new QueryWrapper<TdActivationCodeEntity>().lambda().eq(TdActivationCodeEntity::getCode, code));
            Assert.assertEquals(code, tdActivationCodeEntity.getCode());
            Assert.assertEquals(batch_no, tdActivationCodeEntity.getBatchNo());
            Assert.assertEquals("100", tdActivationCodeEntity.getPrice());
            Assert.assertEquals("TAO_BAO", tdActivationCodeEntity.getSellChannel());
            Assert.assertEquals("NOT_LIMIT", tdActivationCodeEntity.getCodeApplyScene());
            Assert.assertEquals("{}", tdActivationCodeEntity.getBizExt());

            // td_activation_code_goods_item 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> tdActivationCodeGoodsItemMapper.selectList(new QueryWrapper<TdActivationCodeGoodsItemEntity>().lambda().eq(TdActivationCodeGoodsItemEntity::getCode, code)).size() == 1);

            TdActivationCodeGoodsItemEntity tdActivationCodeGoodsItemEntity = tdActivationCodeGoodsItemMapper.selectOne(new QueryWrapper<TdActivationCodeGoodsItemEntity>().lambda().eq(TdActivationCodeGoodsItemEntity::getCode, code));
            Assert.assertEquals(code, tdActivationCodeGoodsItemEntity.getCode());
            Assert.assertEquals("combine_spu_wsc", tdActivationCodeGoodsItemEntity.getSpuId());
            Assert.assertEquals("有赞微商城", tdActivationCodeGoodsItemEntity.getSpuName());
            Assert.assertEquals("combine_sku_wsc_2021_basic_baidu_year", tdActivationCodeGoodsItemEntity.getSkuId());
            Assert.assertEquals("电商（2021）基础版（百度小程序）", tdActivationCodeGoodsItemEntity.getSkuName());
            Assert.assertEquals("4", tdActivationCodeGoodsItemEntity.getSkuSnapshot());
            Assert.assertEquals(Integer.valueOf(1), tdActivationCodeGoodsItemEntity.getSkuNum());
        }
    }

    /**
     * 通用码激活2次后的数据库校验：8表
     *
     * @param code
     */
    public void universalCodeAppliedDBCheck(String code) {
        if (StringUtils.isNotEmpty(code)) {
            // 1-cd_redeem_code 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> cdRedeemCodeMapper.selectList(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, code)).size() == 1);

            CdRedeemCodeEntity codeEntity = cdRedeemCodeMapper.selectOne(new QueryWrapper<CdRedeemCodeEntity>().lambda().eq(CdRedeemCodeEntity::getCode, code));
            String batch_no = codeEntity.getBatchNo();
            Assert.assertEquals(code, codeEntity.getCode());
            Assert.assertEquals("", codeEntity.getDescription());
            Assert.assertEquals("", codeEntity.getName());
            Assert.assertEquals("universal_code", codeEntity.getType());
            Assert.assertEquals("USED_UP", codeEntity.getState());
            Assert.assertEquals("ycm_trade_order", codeEntity.getPerformType());
            Assert.assertEquals(Integer.valueOf(2), codeEntity.getInitStock());
            Assert.assertEquals("{\"code_identity_apply_times_upper_bound\":\"1\",\"identity_apply_times_upper_bound\":\"1\"}", codeEntity.getBizExt());
            Assert.assertEquals(null, codeEntity.getRecycle_time());
            dateCompare(codeEntity.getApplyStartTime(), "2021-01-07 09:38:08");
            dateCompare(codeEntity.getApplyEndTime(), "2023-01-31 09:38:08");


            // 2-cd_redeem_code_batch 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> cdRedeemCodeBatchMapper.selectList(new QueryWrapper<CdRedeemCodeBatchEntity>().lambda().eq(CdRedeemCodeBatchEntity::getBatchNo, batch_no)).size() == 1);

            CdRedeemCodeBatchEntity cdRedeemCodeBatchEntity = cdRedeemCodeBatchMapper.selectOne(new QueryWrapper<CdRedeemCodeBatchEntity>().lambda().eq(CdRedeemCodeBatchEntity::getBatchNo, batch_no));
            Assert.assertEquals(batch_no, cdRedeemCodeBatchEntity.getBatchNo());
            Assert.assertEquals("ycm_trade_order", cdRedeemCodeBatchEntity.getPerformType());
            Assert.assertEquals("universal_code", cdRedeemCodeBatchEntity.getType());
            dateCompare(cdRedeemCodeBatchEntity.getApplyStartTime(), "2021-01-07 09:38:08");
            dateCompare(cdRedeemCodeBatchEntity.getApplyEndTime(), "2023-01-31 09:38:08");
            Assert.assertEquals(Integer.valueOf(2), cdRedeemCodeBatchEntity.getInitStock());
            Assert.assertEquals(Integer.valueOf(1), cdRedeemCodeBatchEntity.getCodeNum());
            Assert.assertEquals(Integer.valueOf(1), cdRedeemCodeBatchEntity.getCreatedCodeNum());
            Assert.assertEquals("EMPLOYEE_ID", cdRedeemCodeBatchEntity.getCreaterYcmType());
            Assert.assertEquals("11734", cdRedeemCodeBatchEntity.getCreaterYcmId());
            Assert.assertEquals("wulei_wl", cdRedeemCodeBatchEntity.getCreaterName());
            Assert.assertEquals("", cdRedeemCodeBatchEntity.getBizExt());
            Assert.assertEquals("{\"codeApplyScene\":\"NOT_LIMIT\",\"price\":\"100\",\"sellChannel\":\"TAO_BAO\",\"goodsItemList\":[{\"spuId\":\"combine_spu_wsc\",\"skuId\":\"combine_sku_wsc_2021_basic_baidu_year\",\"skuNum\":1}]}", cdRedeemCodeBatchEntity.getCodeCreateBizContent());

            // 3-td_activation_code 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> tdActivationCodeMapper.selectList(new QueryWrapper<TdActivationCodeEntity>().lambda().eq(TdActivationCodeEntity::getCode, code)).size() == 1);

            TdActivationCodeEntity tdActivationCodeEntity = tdActivationCodeMapper.selectOne(new QueryWrapper<TdActivationCodeEntity>().lambda().eq(TdActivationCodeEntity::getCode, code));
            Assert.assertEquals(code, tdActivationCodeEntity.getCode());
            Assert.assertEquals(batch_no, tdActivationCodeEntity.getBatchNo());
            Assert.assertEquals("100", tdActivationCodeEntity.getPrice());
            Assert.assertEquals("TAO_BAO", tdActivationCodeEntity.getSellChannel());
            Assert.assertEquals("NOT_LIMIT", tdActivationCodeEntity.getCodeApplyScene());
            Assert.assertEquals("{}", tdActivationCodeEntity.getBizExt());

            // 4-td_activation_code_goods_item 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> tdActivationCodeGoodsItemMapper.selectList(new QueryWrapper<TdActivationCodeGoodsItemEntity>().lambda().eq(TdActivationCodeGoodsItemEntity::getCode, code)).size() == 1);

            TdActivationCodeGoodsItemEntity tdActivationCodeGoodsItemEntity = tdActivationCodeGoodsItemMapper.selectOne(new QueryWrapper<TdActivationCodeGoodsItemEntity>().lambda().eq(TdActivationCodeGoodsItemEntity::getCode, code));
            Assert.assertEquals(code, tdActivationCodeGoodsItemEntity.getCode());
            Assert.assertEquals("combine_spu_wsc", tdActivationCodeGoodsItemEntity.getSpuId());
            Assert.assertEquals("有赞微商城", tdActivationCodeGoodsItemEntity.getSpuName());
            Assert.assertEquals("combine_sku_wsc_2021_basic_baidu_year", tdActivationCodeGoodsItemEntity.getSkuId());
            Assert.assertEquals("电商（2021）基础版（百度小程序）", tdActivationCodeGoodsItemEntity.getSkuName());
            Assert.assertEquals("3", tdActivationCodeGoodsItemEntity.getSkuSnapshot());
            Assert.assertEquals(Integer.valueOf(1), tdActivationCodeGoodsItemEntity.getSkuNum());

            // 5-cd_redeem_code_apply_record 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> cdRedeemCodeApplyRecordMapper.selectList(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getCode, code)).size() == 2);

            List<CdRedeemCodeApplyRecordEntity> cdRedeemCodeApplyRecordEntity = cdRedeemCodeApplyRecordMapper.selectList(new QueryWrapper<CdRedeemCodeApplyRecordEntity>().lambda().eq(CdRedeemCodeApplyRecordEntity::getCode, code));
            String biz_id1 = cdRedeemCodeApplyRecordEntity.get(0).getBizId();
            String biz_id2 = cdRedeemCodeApplyRecordEntity.get(1).getBizId();

            Assert.assertEquals(2, cdRedeemCodeApplyRecordEntity.size());
            Assert.assertEquals("SU", cdRedeemCodeApplyRecordEntity.get(0).getState());
            Assert.assertEquals("CODE_APPLY", cdRedeemCodeApplyRecordEntity.get(0).getBizType());
            Assert.assertEquals("PC", cdRedeemCodeApplyRecordEntity.get(0).getApplyChannel());
            Assert.assertEquals("KDT_ID", cdRedeemCodeApplyRecordEntity.get(0).getApplyYcmType());

            Assert.assertEquals("SU", cdRedeemCodeApplyRecordEntity.get(1).getState());
            Assert.assertEquals("CODE_APPLY", cdRedeemCodeApplyRecordEntity.get(1).getBizType());
            Assert.assertEquals("PC", cdRedeemCodeApplyRecordEntity.get(1).getApplyChannel());
            Assert.assertEquals("KDT_ID", cdRedeemCodeApplyRecordEntity.get(1).getApplyYcmType());

            // 6-cd_redeem_code_apply_mutex 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> cdRedeemCodeApplyMutexMapper.selectList(new QueryWrapper<CdRedeemCodeApplyMutexEntity>().lambda().eq(CdRedeemCodeApplyMutexEntity::getCode, code)).size() == 2);

            List<CdRedeemCodeApplyMutexEntity> cdRedeemCodeApplyMutexEntities = cdRedeemCodeApplyMutexMapper.selectList(new QueryWrapper<CdRedeemCodeApplyMutexEntity>().lambda().eq(CdRedeemCodeApplyMutexEntity::getCode, code));
            Assert.assertEquals("COMMIT_GLOBAL_APPLIER_TYPE", cdRedeemCodeApplyMutexEntities.get(0).getApplyYcmType());
            Assert.assertEquals("COMMIT_GLOBAL_APPLIER_ID", cdRedeemCodeApplyMutexEntities.get(0).getApplyYcmId());
            Assert.assertEquals("TRY_GLOBAL_APPLIER_TYPE", cdRedeemCodeApplyMutexEntities.get(1).getApplyYcmType());
            Assert.assertEquals("TRY_GLOBAL_APPLIER_ID", cdRedeemCodeApplyMutexEntities.get(1).getApplyYcmId());

            // 7-cd_redeem_code_distribute_record 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> cdRedeemCodeDistributeRecordMapper.selectList(new QueryWrapper<CdRedeemCodeDistributeRecordEntity>().lambda().eq(CdRedeemCodeDistributeRecordEntity::getCode, code)).size() == 2);

            List<CdRedeemCodeDistributeRecordEntity> cdRedeemCodeDistributeRecordEntities = cdRedeemCodeDistributeRecordMapper.selectList(new QueryWrapper<CdRedeemCodeDistributeRecordEntity>().lambda().eq(CdRedeemCodeDistributeRecordEntity::getCode, code));
            Assert.assertEquals("CODE_APPLY", cdRedeemCodeDistributeRecordEntities.get(0).getDistributeBizType());
            Assert.assertEquals(biz_id1, cdRedeemCodeDistributeRecordEntities.get(0).getDistributeBizId());
            Assert.assertEquals("KDT_ID", cdRedeemCodeDistributeRecordEntities.get(0).getCodeBelongYcmType());

            Assert.assertEquals("CODE_APPLY", cdRedeemCodeDistributeRecordEntities.get(1).getDistributeBizType());
            Assert.assertEquals(biz_id2, cdRedeemCodeDistributeRecordEntities.get(1).getDistributeBizId());
            Assert.assertEquals("KDT_ID", cdRedeemCodeDistributeRecordEntities.get(1).getCodeBelongYcmType());

            // 8-td_activation_code_apply_record 表全检验
            with().atMost(10, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                    .with().pollDelay(3, TimeUnit.SECONDS).until(
                    () -> tdActivationCodeApplyRecordMapper.selectList(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getCode, code)).size() == 2);
            List<TdActivationCodeApplyRecordEntity> tdActivationCodeApplyRecordEntities = tdActivationCodeApplyRecordMapper.selectList(new QueryWrapper<TdActivationCodeApplyRecordEntity>().lambda().eq(TdActivationCodeApplyRecordEntity::getCode, code));
            Assert.assertEquals("SU", tdActivationCodeApplyRecordEntities.get(0).getState());
            Assert.assertEquals(biz_id1, tdActivationCodeApplyRecordEntities.get(0).getBizId());
            Assert.assertEquals("KDT_ID", tdActivationCodeApplyRecordEntities.get(0).getApplyYcmType());
            Assert.assertEquals("CODE_APPLY", tdActivationCodeApplyRecordEntities.get(0).getBizType());

            Assert.assertEquals("SU", tdActivationCodeApplyRecordEntities.get(1).getState());
            Assert.assertEquals(biz_id2, tdActivationCodeApplyRecordEntities.get(1).getBizId());
            Assert.assertEquals("KDT_ID", tdActivationCodeApplyRecordEntities.get(1).getApplyYcmType());
            Assert.assertEquals("CODE_APPLY", tdActivationCodeApplyRecordEntities.get(1).getBizType());
        }
    }

    /**
     * 时间比较
     *
     * @param fromDate
     * @param timeString
     */
    public void dateCompare(Date fromDate, String timeString) {
        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Assert.assertEquals(timeString, ft.format(fromDate));
    }

    /**
     * 非打包售卖插件，无法创建激活码
     *
     * @param request
     */
    public void createNotSaleCodeCheck(CreateYcmCodeRequest request) {
        PlainResult<CreateYcmCodeResponse> config = ycmRedeemCodeRemoteService.createYcmCode(request);
        Assert.assertEquals(5202010, config.getCode());
        Assert.assertEquals("非打包售卖的套餐不支持创建激活码", config.getMessage());

    }

    /**
     * 核销激活码校验
     *
     * @param code
     */
    public void applyCheck(String code, Long kdt_id) {
        if (StringUtils.isNotEmpty(code)) {
            // 激活前-校验激活码状态-VALID
            QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
            queryYcmCodeDetailRequest.setCode(code);
            PlainResult<QueryYcmCodeDetailResponse> beforeApply = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
            Assert.assertEquals(200, beforeApply.getCode());
            Assert.assertEquals("VALID", beforeApply.getData().getYcmRedeemCodeDTO().getState());
            Assert.assertEquals(0, beforeApply.getData().getApplyRecordNoList().size());

            // 核销
            ApplyYcmCodeRequest applyYcmCodeRequest = new ApplyYcmCodeRequest();
            applyYcmCodeRequest.setCode(code);
            applyYcmCodeRequest.setApplyChannel("PC");
            applyYcmCodeRequest.setApplyYcmId(kdt_id.toString());
            applyYcmCodeRequest.setApplyYcmType("KDT_ID");
            PlainResult<ApplyYcmCodeResponse> applyResult = ycmRedeemCodeRemoteService.applyYcmCode(applyYcmCodeRequest);
            Assert.assertEquals(applyResult.getCode(),200);
            logger.info("核销成功新激活码:" + code);

            // 激活后-校验激活码状态-USED_UP
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            QueryYcmCodeDetailRequest queryYcmCodeDetailRequest1 = new QueryYcmCodeDetailRequest();
            queryYcmCodeDetailRequest1.setCode(code);
            PlainResult<QueryYcmCodeDetailResponse> afterApply = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest1);
            Assert.assertEquals(200, afterApply.getCode());
            Assert.assertEquals("USED_UP", afterApply.getData().getYcmRedeemCodeDTO().getState());
            Assert.assertEquals(1, afterApply.getData().getApplyRecordNoList().size());
        }
    }

    /**
     * 通用码 核销激活码校验
     *
     * @param code
     */
    public void universalCodeApplyCheck(String code, Long kdt_id, String state, int applyTimes) {
        if (StringUtils.isNotEmpty(code)) {
            // 激活前-校验激活码状态-VALID
            QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
            queryYcmCodeDetailRequest.setCode(code);
            PlainResult<QueryYcmCodeDetailResponse> beforeApply = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
            Assert.assertEquals(200, beforeApply.getCode());
            Assert.assertEquals("VALID", beforeApply.getData().getYcmRedeemCodeDTO().getState());
            Assert.assertEquals(applyTimes, beforeApply.getData().getApplyRecordNoList().size());

            // 核销
            ApplyYcmCodeRequest applyYcmCodeRequest = new ApplyYcmCodeRequest();
            applyYcmCodeRequest.setCode(code);
            applyYcmCodeRequest.setApplyChannel("PC");
            applyYcmCodeRequest.setApplyYcmId(kdt_id.toString());
            applyYcmCodeRequest.setApplyYcmType("KDT_ID");
            PlainResult<ApplyYcmCodeResponse> applyResult = ycmRedeemCodeRemoteService.applyYcmCode(applyYcmCodeRequest);
            Assert.assertEquals(200, applyResult.getCode());
            logger.info("核销成功新激活码:" + code);

            // 激活后-校验激活码状态-USED_UP
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            QueryYcmCodeDetailRequest queryYcmCodeDetailRequest1 = new QueryYcmCodeDetailRequest();
            queryYcmCodeDetailRequest1.setCode(code);
            PlainResult<QueryYcmCodeDetailResponse> afterApply = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest1);
            Assert.assertEquals(200, afterApply.getCode());
            Assert.assertEquals(state, afterApply.getData().getYcmRedeemCodeDTO().getState());
            Assert.assertEquals(applyTimes + 1, afterApply.getData().getApplyRecordNoList().size());
        }
    }

    /**
     * 激活码核销前-校验逻辑
     *
     * @param code
     */
    public PlainResult<OpenCodeCheckResApi> AbnormalCheck(String code, Long kdt_id) {
        if (StringUtils.isNotEmpty(code)) {
            //
            OpenActivationCodeCheckApi openActivationCodeCheckApi = new OpenActivationCodeCheckApi();
            openActivationCodeCheckApi.setActivationCode(code);
            openActivationCodeCheckApi.setKdtId(kdt_id);
            openActivationCodeCheckApi.setUserId(System.currentTimeMillis());
            openActivationCodeCheckApi.setIp(RandomStringUtils.random(13, "123456789"));
            PlainResult<OpenCodeCheckResApi> applyResult = activationCodeRemoteService.checkCodeForNew(openActivationCodeCheckApi);
            return applyResult;
        }
        return null;
    }

    /**
     * 核销激活码校验-返回结果
     *
     * @param code
     */
    public PlainResult<ApplyYcmCodeResponse> applyAbnormalCheck(String code, Long kdt_id) {
        if (StringUtils.isNotEmpty(code)) {
            // 核销
            ApplyYcmCodeRequest applyYcmCodeRequest = new ApplyYcmCodeRequest();
            applyYcmCodeRequest.setCode(code);
            applyYcmCodeRequest.setApplyChannel("PC");
            applyYcmCodeRequest.setApplyYcmId(kdt_id.toString());
            applyYcmCodeRequest.setApplyYcmType("KDT_ID");
            PlainResult<ApplyYcmCodeResponse> applyResult = ycmRedeemCodeRemoteService.applyYcmCode(applyYcmCodeRequest);
            return applyResult;
        }
        return null;
    }

    /**
     * 全部激活的通用码详情校验
     *
     * @param code
     */
    public void YcmCodeQueryYcmCodeDetailCheck(String code) {
        QueryYcmCodeDetailRequest queryYcmCodeDetailRequest = new QueryYcmCodeDetailRequest();
        queryYcmCodeDetailRequest.setCode(code);
        PlainResult<QueryYcmCodeDetailResponse> config = ycmRedeemCodeRemoteService.queryYcmCodeDetail(queryYcmCodeDetailRequest);
        Assert.assertEquals(200, config.getCode());
        Assert.assertEquals(2, config.getData().getApplyRecordNoList().size());
        Assert.assertEquals("NOT_LIMIT", config.getData().getYcmCodeDetailBizContent().get("codeApplyScene").toString());
        Assert.assertEquals("100.0", config.getData().getYcmCodeDetailBizContent().get("price").toString());
        Assert.assertEquals("TAO_BAO", config.getData().getYcmCodeDetailBizContent().get("sellChannel").toString());
        Assert.assertEquals("USED_UP", config.getData().getYcmRedeemCodeDTO().getState());
        Assert.assertEquals(Long.valueOf(0), config.getData().getYcmRedeemCodeDTO().getRemainStock());
        Assert.assertEquals(code, config.getData().getYcmRedeemCodeDTO().getCode());
        Assert.assertEquals(Long.valueOf(2), config.getData().getYcmRedeemCodeDTO().getInitStock());
        Assert.assertEquals("1", config.getData().getYcmRedeemCodeDTO().getBizExt().get("code_identity_apply_times_upper_bound").toString());
        Assert.assertEquals("1", config.getData().getYcmRedeemCodeDTO().getBizExt().get("identity_apply_times_upper_bound").toString());
        Assert.assertEquals("universal_code", config.getData().getYcmRedeemCodeDTO().getCodeType());
        Assert.assertEquals("ycm_trade_order", config.getData().getYcmRedeemCodeDTO().getCodePerformType());
    }

    /**
     * 通用码列表详情校验
     */
    public void universalCodeApplyRecordPageQueryCheck(String code) {
        UniversalCodeApplyRecordPageQueryRequest universalCodeApplyRecordPageQueryRequest = new UniversalCodeApplyRecordPageQueryRequest();
        universalCodeApplyRecordPageQueryRequest.setApplyStartTime("2020-12-01 00:00:00");
        universalCodeApplyRecordPageQueryRequest.setApplyEndTime("2022-12-08 00:00:00");
        universalCodeApplyRecordPageQueryRequest.setPageNumber(Integer.valueOf(1));
        universalCodeApplyRecordPageQueryRequest.setPageSize(Integer.valueOf(20));
        universalCodeApplyRecordPageQueryRequest.setCode(code);
        PlainResult<PageResponse<UniversalCodeApplyRecordDTO>> codeApplyRecordPageQuery = activationCodeQueryRemoteService.universalCodeApplyRecordPageQuery(universalCodeApplyRecordPageQueryRequest);

        Assert.assertEquals(200, codeApplyRecordPageQuery.getCode());
        Assert.assertEquals(2, codeApplyRecordPageQuery.getData().getItems().size());

        Assert.assertEquals(code, codeApplyRecordPageQuery.getData().getItems().get(0).getCode());
        Assert.assertEquals("SU", codeApplyRecordPageQuery.getData().getItems().get(0).getState());
        Assert.assertEquals("NOT_LIMIT", codeApplyRecordPageQuery.getData().getItems().get(0).getApplyScene());
        Assert.assertEquals(1, codeApplyRecordPageQuery.getData().getItems().get(0).getGoodsItemList().size());


        Assert.assertEquals(code, codeApplyRecordPageQuery.getData().getItems().get(1).getCode());
        Assert.assertEquals("SU", codeApplyRecordPageQuery.getData().getItems().get(1).getState());
        Assert.assertEquals("NOT_LIMIT", codeApplyRecordPageQuery.getData().getItems().get(1).getApplyScene());
        Assert.assertEquals(1, codeApplyRecordPageQuery.getData().getItems().get(1).getGoodsItemList().size());
    }


//    @Test()
//    public void clearTest() {
//        List<Long> kdtids = Arrays.asList(59614492L);
//        for(Long kd:kdtids){
//            godBlessU(kd);
//        }
//    }
}
