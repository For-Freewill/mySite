package com.youzan.test.onlineTrade.basecase.period_count;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.perform.PfOrderMapper;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.pay.unified.cashier.api.request.v3.request.PreOrderPayRequest;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * @author baoyan
 * @date 2020/8/26
 **/
public class YunPosTest extends PeriodCountBaseTest {
    public static Long userId = 690258785L;
    @Autowired(required = false)
    PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    YunBaseTest yunBaseTest;
    private Long retailKdtId = newRetailKdtId();
    //58819925L;
    private String retailKdtName = "retail-自动化-2";

    /**
     * 云POS->云POS新购
     * <p>
     *
     *
     *
     *
     *
     *
     *
     * 零售单店新购云POS
     * 验证新购服务期&员工个数
     * <p>
     * 1.创建员工订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证员工订购个数
     * 5.验证员工服务期
     * 6.验证员工购买标签为新签
     * 7.退款
     */


    @Test(priority = 0)
    public void test_newBuyYunPos_0() {
        logger.info("\ntest_newBuyYunPos_0--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResult = new PlainResult<>();
        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(retailKdtId);
            //存在云POS订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(retailKdtId, Long.valueOf(ItemInfo.YUN_POS.getAppId()), "", "BY_VALUE", new Date());
            String createNewYunPosDataFilePath = "src/test/resources/dataResource/basecase.plugin/yunPosNewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewYunPosDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(retailKdtId);
            //1.创建云POS订单
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResult = createOrder(createOrderForm);
            if (orderCreateApiPlainResult == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResult.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResult.getMessage());
            Assert.assertEquals(orderCreateApiPlainResult.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResult.getData().getPayOrderId(), orderCreateApiPlainResult.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResult.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResult.getData().getPayOrderId()));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证云POS服务期
            checkAppStatusWithAppIs(retailKdtId, 1, 1, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");

        } catch (Exception e) {
            logger.info("test_newBuyYunPos--case--异常：" + e.getMessage());
        } finally {
            if(orderCreateApiPlainResult==null || orderCreateApiPlainResult.getData()==null){
                /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");

            }
            if (orderCreateApiPlainResult != null && orderCreateApiPlainResult.getCode() == 200 && orderCreateApiPlainResult.getData().getPayOrderId() != null) {
                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResult.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_newBuyYunPos_0--end:" + new Date());
        }


    }

    /**
     * 云POS->增购云POS增购
     * <p>
     * 零售单店增购云POS
     * 验证新购服务期&云POS个数
     * <p>
     * 1.创建云POS订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证云POS订购个数
     * 5.验证云POS服务期
     * 6.验证云POS购买标签为新签
     * 7.增购云POS
     * 8.调用预支付
     * 9.支付订单
     * 10.验证云POS订购个数
     * 11.验证云POS服务期
     * 12.验证云POS购买标签为增购
     */
    @Test(priority = 1)
    public void test_addBuyYunPos_1() {
        logger.info("\ntest_addBuyYunPos_1--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultAdd = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(retailKdtId);
            //存在云POS订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(retailKdtId, Long.valueOf(ItemInfo.YUN_POS.getAppId()), "", "BY_VALUE", new Date());
            String createNewYunPosDataFilePath = "src/test/resources/dataResource/basecase.plugin/yunPosNewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewYunPosDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(retailKdtId);
            //1.创建云POS订单，订购5个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证云POS服务期
            checkAppStatusWithAppIs(retailKdtId, 1, 1, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");

            //6.增购云POS,增购6个
            Thread.sleep(500);
            OrderItemForm orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 3);
            orderItemForm.setQuantity(6);
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultAdd = createOrder(createOrderForm);
            if (orderCreateApiPlainResultAdd == null) {
                return;
            }
            logger.info("test_addBuyYunPos_1+orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);
            if (orderCreateApiPlainResultAdd.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(retailKdtId, orderCreateApiPlainResultAdd.getData().getPayOrderId());
                orderCreateApiPlainResultAdd = createOrder(createOrderForm);
                if (orderCreateApiPlainResultAdd == null) {
                    return;
                }
                logger.info("增购并续费云POS创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            }

            Assert.assertEquals(orderCreateApiPlainResultAdd.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultAdd.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultAdd.getData().getPayOrderId(), orderCreateApiPlainResultAdd.getMessage());
            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultAdd.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultAdd.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("6"));
            //4.验证云POS服务期
            checkAppStatusWithAppIs(retailKdtId, 1, 1, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为增购
            Assert.assertEquals(pfOrder.getBuyType(), "add_sign");


        } catch (Exception e) {
            logger.info("test_AddBuyYunPos--case--异常：" + e.getMessage());
        } finally {
            System.out.println("orderCreateApiPlainResultAdd：" + orderCreateApiPlainResultAdd);
            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultAdd == null || orderCreateApiPlainResultAdd.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }
            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultAdd != null && orderCreateApiPlainResultAdd.getCode() == 200 && orderCreateApiPlainResultAdd.getData().getPayOrderId() != null) {

                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultAdd.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_addBuyYunPos_1--end:" + new Date());
        }


    }

    /**
     * 云POS->续费云POS
     * <p>
     * 零售单店增购云POS
     * 验证新购服务期&云POS个数
     * <p>
     * 1.创建云POS订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证云POS订购个数
     * 5.验证云POS服务期
     * 6.验证云POS购买标签为新签
     * 7.续费云POS
     * 8.调用预支付
     * 9.支付订单
     * 10.验证云POS订购个数
     * 11.验证云POS服务期
     * 12.验证云POS购买标签为续费
     */

    @Test(priority = 2)
    public void test_ReNewBuyYunPos_2() {
        logger.info("\ntest_ReNewBuyYunPos_2--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultReNew = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(retailKdtId);
            //存在云POS订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(retailKdtId, Long.valueOf(ItemInfo.YUN_POS.getAppId()), "", "BY_VALUE", new Date());
            String createNewYunPosDataFilePath = "src/test/resources/dataResource/basecase.plugin/yunPosNewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewYunPosDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(retailKdtId);
            //1.创建云POS订单，订购5个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            PreOrderPayRequest preOrderPayRequest = new PreOrderPayRequest();
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
//        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
//                .inSql("biz_order_id","select td_no from td_order where id="+orderCreateApiPlainResult.getData().getPayOrderId()+""));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证云POS服务期
            checkAppStatusWithAppIs(retailKdtId, 1, 1, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");
            logger.info("check end ----------");

            //6.续费云POS,续费10个
            Thread.sleep(1000);
            OrderItemForm orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 2);
            orderItemForm.setQuantity(10);
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);

            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultReNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultReNew == null) {
                return;
            }
            if (orderCreateApiPlainResultReNew.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(retailKdtId, orderCreateApiPlainResultReNew.getData().getPayOrderId());
                orderCreateApiPlainResultReNew = createOrder(createOrderForm);
                if (orderCreateApiPlainResultReNew == null) {
                    return;
                }
                logger.info("增购并续费云POS创建订单失败：" + orderCreateApiPlainResultReNew.getMessage());
            }

            Assert.assertEquals(orderCreateApiPlainResultReNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultReNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultReNew.getData().getPayOrderId(), orderCreateApiPlainResultReNew.getMessage());

            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultReNew.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultReNew.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("10"));
            //4.验证云POS服务期，2年
            checkAppStatusWithAppIs(retailKdtId, 1, 2, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为续费
            Assert.assertEquals(pfOrder.getBuyType(), "renew_sign");


        } catch (Exception e) {
            logger.info("test_reNewBuyYunPos--case--异常：" + e.getMessage());
        } finally {
            logger.info("orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultReNew);
            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultReNew==null || orderCreateApiPlainResultReNew.getData()==null){
                 /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }
            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultNew != null && orderCreateApiPlainResultReNew.getCode() == 200 && orderCreateApiPlainResultReNew.getData().getPayOrderId() != null) {

                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultReNew.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_ReNewBuyYunPos_2--end:" + new Date());
        }


    }

    /**
     * 云POS->续费后增购云POS
     * <p>
     * 零售单店增购云POS
     * 验证新购服务期&云POS个数
     * <p>
     * 1.创建云POS订单
     * 2.调用预支付
     * 3.支付订单
     * 4.验证云POS订购个数
     * 5.验证云POS服务期
     * 6.验证云POS购买标签为新签
     * 7.续费云POS
     * 8.调用预支付
     * 9.支付订单
     * 10.验证云POS订购个数
     * 11.验证云POS服务期
     * 12.验证云POS购买标签为续费
     * 13.增购云POS
     * 14.调用预支付
     * 15.支付订单
     * 16.验证云POS服务期
     * 17.验证云POS购买标签为增购
     * 18.验证云POS个数
     */
    @Test(priority = 3)
    public void test_ReNewBuyYunPosWithAdd_3() {
        logger.info("\ntest_ReNewBuyYunPosWithAdd_3--start:" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultReNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultAdd = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(retailKdtId);
            //存在云POS订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(retailKdtId, Long.valueOf(ItemInfo.YUN_POS.getAppId()), "", "BY_VALUE", new Date());
            String createNewYunPosDataFilePath = "src/test/resources/dataResource/basecase.plugin/yunPosNewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewYunPosDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(retailKdtId);
            //1.创建云POS订单，订购5个
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            PreOrderPayRequest preOrderPayRequest = new PreOrderPayRequest();
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
//        PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>()
//                .inSql("biz_order_id","select td_no from td_order where id="+orderCreateApiPlainResult.getData().getPayOrderId()+""));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证云POS服务期
            checkAppStatusWithAppIs(retailKdtId, 1, 1, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");

            //6.续费云POS,续费10个
            Thread.sleep(1000);
            OrderItemForm orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 2);
            orderItemForm.setQuantity(10);
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);

            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultReNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultReNew == null) {
                return;
            }
            logger.info("test_ReNewBuyYunPosWithAdd_3+orderCreateApiPlainResultReNew:" + orderCreateApiPlainResultReNew);
            if (orderCreateApiPlainResultReNew.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(retailKdtId, orderCreateApiPlainResultReNew.getData().getPayOrderId());
                orderCreateApiPlainResultReNew = createOrder(createOrderForm);
                if (orderCreateApiPlainResultReNew == null) {
                    return;
                }
                logger.info("增购并续费云POS创建订单失败：" + orderCreateApiPlainResultReNew.getMessage());
            }
            Assert.assertEquals(orderCreateApiPlainResultReNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultReNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultReNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultReNew.getData().getPayOrderId(), orderCreateApiPlainResultReNew.getMessage());
            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultReNew.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultReNew.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("10"));
            //4.验证云POS服务期，2年
            Thread.sleep(3000);
            checkAppStatusWithAppIs(retailKdtId, 1, 2, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为续费
            Assert.assertEquals(pfOrder.getBuyType(), "renew_sign");

            //7.增购云POS,增购20个
            Thread.sleep(300);
            orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setBuyType((byte) 3);
            orderItemForm.setQuantity(20);
            orderItemForms = new ArrayList<>();
            orderItemForms.add(orderItemForm);
            createOrderForm.setItems(orderItemForms);
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultAdd = createOrder(createOrderForm);
            if (orderCreateApiPlainResultAdd == null) {
                return;
            }
            logger.info("test_ReNewBuyYunPosWithAdd_3+orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);
            if (orderCreateApiPlainResultAdd.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(retailKdtId, orderCreateApiPlainResultAdd.getData().getPayOrderId());
                orderCreateApiPlainResultAdd = createOrder(createOrderForm);
                if (orderCreateApiPlainResultAdd == null) {
                    return;
                }
                logger.info("增购并续费云POS创建订单失败:" + orderCreateApiPlainResultAdd.getMessage());

            }
            Assert.assertEquals(orderCreateApiPlainResultAdd.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultAdd.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultAdd.getData().getPayOrderId(), orderCreateApiPlainResultAdd.getMessage());


            //8.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultAdd.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultAdd.getData().getPayOrderId()));
            pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //9.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("20"));
            //10.验证云POS服务期，2年
            checkAppStatusWithAppIs(retailKdtId, 1, 2, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //11.验证云POS购买标签为增购
            Assert.assertEquals(pfOrder.getBuyType(), "add_sign");


        } catch (Exception e) {
            logger.info("test_ReNewBuyYunPosWithAdd--case--异常:" + e.getMessage());
        } finally {
            logger.info("orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);
            logger.info("orderCreateApiPlainResultReNew:" + orderCreateApiPlainResultReNew);
            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultReNew==null || orderCreateApiPlainResultReNew.getData()==null
                    || orderCreateApiPlainResultAdd == null || orderCreateApiPlainResultAdd.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }

            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultReNew != null && orderCreateApiPlainResultReNew.getCode() == 200 && orderCreateApiPlainResultReNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultAdd != null && orderCreateApiPlainResultAdd.getCode() == 200 && orderCreateApiPlainResultAdd.getData().getPayOrderId() != null
            ) {

                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultReNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultAdd.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_ReNewBuyYunPosWithAdd_3--end:" + new Date());
        }
    }


    /**
     * 云POS->增购并续费云POS增购
     * <p>
     * 零售单店增购云POS
     * 验证新购服务期&云POS个数
     * <p>
     * 1.创建云POS订单，包含5个云POS
     * 2.调用预支付
     * 3.支付订单
     * 4.验证云POS订购个数
     * 5.验证云POS服务期
     * 6.验证云POS购买标签为新签
     * 7.平移服务期，使得服务期剩余小于30天
     * 8.增购10个，选择增购并续费
     * 9.则实际产生2笔订单，增购的为10个，续费的为10+5=15个
     * 10.验证云POS订购个数
     * 11.验证云POS服务期
     * 12.验证云POS购买标签分别为增购和续费
     * 13.退款
     */
    @Test(priority = 4)
    public void test_addAndReNewBuyYunPos_4() {
        logger.info("\ntest_addAndReNewBuyYunPos_4--start" + new Date());
        PlainResult<OrderCreateApi> orderCreateApiPlainResultNew = new PlainResult<>();
        PlainResult<OrderCreateApi> orderCreateApiPlainResultAdd = new PlainResult<>();

        try {
            //存在待付款订单，则关闭订单
            closeWaitPayOrder(retailKdtId);
            //存在云POS订单，则退款（为了本次用例的稳定性，做一个数据清理前置动作）
            refundOrderBatch(retailKdtId, Long.valueOf(ItemInfo.YUN_POS.getAppId()), "", "BY_VALUE", new Date());
            Thread.sleep(500);
            String createNewYunPosDataFilePath = "src/test/resources/dataResource/basecase.plugin/yunPosNewCreateData.json";
            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createNewYunPosDataFilePath, CreateOrderForm.class);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtId(retailKdtId);
            //1.创建云POS订单，订购5个
            logger.info("createOrderForm:" + JSON.toJSONString(createOrderForm));
            orderCreateApiPlainResultNew = createOrder(createOrderForm);
            if (orderCreateApiPlainResultNew == null) {
                return;
            }
            Assert.assertEquals(orderCreateApiPlainResultNew.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultNew.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultNew.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultNew.getData().getPayOrderId(), orderCreateApiPlainResultNew.getMessage());
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResultNew.getData().getPayOrderId(), (byte) 4);

            //2.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultNew.getData().getPayOrderId()));
            PfOrder pfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            //3.验证云POS订购个数
            Assert.assertTrue(JSONObject.parseObject(pfOrder.getBizExt()).get("quantity").equals("5"));
            //4.验证云POS服务期
            checkAppStatusWithAppIs(retailKdtId, 1, 1, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //5.验证云POS购买标签为新签
            Assert.assertEquals(pfOrder.getBuyType(), "new_sign");

            //平移服务期，使得服务期小于30天
            moveAppStatus(retailKdtId, "atom_spu_pos_point", 345);

            String createAddAndRenewYunPosDataFilePath = "src/test/resources/dataResource/basecase.plugin/yunPosAddAndRenewCreateData.json";
            CreateOrderForm createOrderFormAdd = JsonCovertUntil.getObjectFromjson(createAddAndRenewYunPosDataFilePath, CreateOrderForm.class);
            createOrderFormAdd.setUserId(userId);
            createOrderFormAdd.setKdtId(retailKdtId);

            //6.增购并续费云POS,增购10个，续费15个
            Thread.sleep(5000);
            logger.info("createOrderForm:" + createOrderForm);
            orderCreateApiPlainResultAdd = createOrder(createOrderFormAdd);
            if (orderCreateApiPlainResultAdd == null) {
                return;
            }
            if (orderCreateApiPlainResultAdd.getCode() == 130601) {
                //存在待付款订单，则调用支付，进行付款
                payWaitPayOrder(retailKdtId, orderCreateApiPlainResultAdd.getData().getPayOrderId());
                orderCreateApiPlainResultAdd = createOrder(createOrderForm);
                if (orderCreateApiPlainResultAdd == null) {
                    return;
                }
                logger.info("增购并续费云POS创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            }
            Assert.assertEquals(orderCreateApiPlainResultAdd.getCode(), 200, "创建订单失败：" + orderCreateApiPlainResultAdd.getMessage());
            Assert.assertEquals(orderCreateApiPlainResultAdd.getMessage(), "successful");
            Assert.assertNotNull(orderCreateApiPlainResultAdd.getData().getPayOrderId(), orderCreateApiPlainResultAdd.getMessage());
            //7.调用预支付
            preparePayApiPlainResult = preparePay(orderCreateApiPlainResultAdd.getData().getPayOrderId(), (byte) 4);

            //8.支付订单
            cashierPay(preparePayApiPlainResult, account, retailKdtId);
            tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", orderCreateApiPlainResultAdd.getData().getPayOrderId()));
            //9.验证生成2笔子订单
            List<PfOrder> pfOrderList = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
            Assert.assertEquals(pfOrderList.size(), 2);

            //获取续费的订单
            PfOrder renewPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("item_id", "atom_sku_pos_point_year"));
            //获取增购的订单
            PfOrder addPfOrder = pfOrderMapper.selectOne(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()).eq("item_id", "atom_sku_pos_point_day"));

            //10.验证增购的个数
            Assert.assertTrue(JSONObject.parseObject(addPfOrder.getBizExt()).get("quantity").equals("10"));
            //11.验证续费的个数
            Assert.assertTrue(JSONObject.parseObject(renewPfOrder.getBizExt()).get("quantity").equals("15"));


            //12.验证云POS服务期（385=20（增购的天数）+365（续费的天数））
            Thread.sleep(500);
            checkAppStatusWithAppIs(retailKdtId, 6, 385, Collections.singletonList(ItemInfo.YUN_POS.getAppId()));
            //13.分别验证云POS购买标签为增购和续费
            Assert.assertEquals(addPfOrder.getBuyType(), "add_sign");
            Assert.assertEquals(renewPfOrder.getBuyType(), "renew_sign");


        } catch (Exception e) {
            logger.info("test_addAndReNewBuyYunPos--case--异常:" + e.getMessage());
        } finally {
            System.out.println("orderCreateApiPlainResultAdd:" + orderCreateApiPlainResultAdd);
            if(orderCreateApiPlainResultNew==null || orderCreateApiPlainResultNew.getData()==null
                    || orderCreateApiPlainResultAdd == null || orderCreateApiPlainResultAdd.getData()==null){
                  /*logger.info("环境问题，创建订单数据未正常返回，本次用例忽略") ;
                return;*/
                Assert.assertEquals(true,false,"环境问题，创建订单数据未正常返回");
            }

            if (orderCreateApiPlainResultNew != null && orderCreateApiPlainResultNew.getCode() == 200 && orderCreateApiPlainResultNew.getData().getPayOrderId() != null
                    && orderCreateApiPlainResultAdd != null && orderCreateApiPlainResultAdd.getCode() == 200 && orderCreateApiPlainResultAdd.getData().getPayOrderId() != null) {
                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultNew.getData().getPayOrderId()), "BY_VALUE", new Date());
                refundOrderBatch(retailKdtId, null, String.valueOf(orderCreateApiPlainResultAdd.getData().getPayOrderId()), "BY_VALUE", new Date());

            }
            logger.info("\ntest_addAndReNewBuyYunPos_4--end" + new Date());
        }

    }

  /*  @BeforeClass
    public void beforeClass() {
        deleteTestDataYcmByKdtId(retailKdtId);
        clearCache(String.valueOf(retailKdtId));
    }*/
      @BeforeMethod
      public void beforeMethod(){
          try {
              rechargeShopBalance(String.valueOf(retailKdtId),9999);
              Thread.sleep(5000);
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }

}
