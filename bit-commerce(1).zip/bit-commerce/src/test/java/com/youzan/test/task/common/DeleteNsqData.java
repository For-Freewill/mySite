/*
package com.youzan.test.task.common;

import com.youzan.api.common.response.PlainResult;
import com.youzan.bigdata.essync.dto.RestResult;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

*/
/**
 * @program: bit-commerce
 * @description
 * @author: tianning
 * @create: 2021-02-04 00:10
 **//*

@Slf4j
@RestController
@RequestMapping("/delete")
public class DeleteNsqData extends BaseTest {

    //
    @JSONData("clearData/DeleteNsqData.json")
    private

    @Test
    public void deleteNsqData(String topic, String channel){

    }
    @Resource
    private InterfaceService interfaceService;

    */
/**
     * 进行方法调用
     * 通过lookup接口返回topic的分区信息
     * GET http://{lookupd_addr}/lookup?topic={topic_name}&access=r
     * 通过nsqd setoffset接口重新设置消费位点
     * POST http://{broadcast_address}:{http_port}/channel/empty?topic={topic_name}&channel={channel_name}&partition={partition_id}
     *//*

    @RequestMapping(value = "/nsq", method = RequestMethod.POST)
    public RestResult<PageResponse<CouponAssetDTO>> deleteNsqData(@RequestBody QueryCouponAssetRequest request) {
        PlainResult<PageResponse<CouponAssetDTO>> result = couponAssetRemoteService.queryCouponAssetListByKdtId(request);
        return RestResultUtil.build(result);
    }
}
*/
