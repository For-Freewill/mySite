package com.youzan.test.cloudService.basecase.specialCases;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * Created by wulei on 2020-07-31.
 */
public class QuotaGrantAndRecycleRenewTest extends YunBaseTest {
    //  续费且额度未发放的情
    @Test
    public void testQuatoGrantAndRecycleNotGrant() {
        long yunKdtId3 = newWscKdtId();

        PlainResult<OrderCreateApi> result1 = testCreateOrder(yunKdtId3, yunKdtName3, wscWXItemId_2021, 1);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        PlainResult<OrderCreateApi> result2 = testCreateOrder(yunKdtId3, yunKdtName3, wscWXItemId_2021, 1);


        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //  查询计费额度是否成功发放
        testQueryTotalQuota(yunKdtId3, 10000);
        //  商业化侧有一条延期发放的记录
        queryWaitPerformRecord(yunKdtId3, 1);
        //  判断是否可以预支额度
        //    testCanAdvanceOrderQuota(yunKdtId3.toString(), "KDT_ID", false);

        //  退款续费订单
        Long payOrderId = result2.getData().getPayOrderId();

        refundOrderNew(payOrderId, new Date(), 0L, 0L, "BY_MANUAL");

        // 查看计费侧额度是否正常回收
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  计费侧额度没有回收
        testQueryTotalQuota(yunKdtId3, 10000);
        //  商业化侧没有待延期发放的记录
        queryWaitPerformRecord(yunKdtId3, 0);

        Long payOrderIdNew = result1.getData().getPayOrderId();
        refundOrderNew(payOrderIdNew, new Date(), 0L, 0L, "BY_MANUAL");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId3, 0);
    }

    //  这个发放太慢了
    //  新购单退款
    @Test(enabled = false)
    public void testQuatoGrantAndRecycleGrantedByReFund() {

        PlainResult<OrderCreateApi> result1 = testCreateOrder(yunKdtId6, yunKdtName6, wscWXItemId_2021, 1);
        PlainResult<OrderCreateApi> result2 = testCreateOrder(yunKdtId6, yunKdtName6, wscWXItemId_2021, 1);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //  查询计费额度是否成功发放
        testQueryTotalQuota(yunKdtId6, 10000);
        //  商业化侧有一条延期发放的记录
        queryWaitPerformRecord(yunKdtId6, 1);
        //  判断是否可以预支额度
        //    testCanAdvanceOrderQuota(yunKdtId3.toString(), "KDT_ID", false);

        //  退款新购订单
        Long payOrderId = result1.getData().getPayOrderId();

        refundOrderNew(payOrderId, new Date(), 0L, 0L, "BY_MANUAL");

        // 查看计费侧额度是否正常回收
        try {
            Thread.sleep(100000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  计费侧额度回收，但是会发放新额度
        testQueryTotalQuota(yunKdtId6, 10000);
        //  商业化侧没有待延期发放的记录
        queryWaitPerformRecord(yunKdtId6, 0);

        Long payOrderIdRenew = result2.getData().getPayOrderId();
        refundOrderNew(payOrderIdRenew, new Date(), 0L, 0L, "BY_MANUAL");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId6, 0);
    }

    //  自然到期
    @Test
    public void testQuatoGrantAndRecycleGranted() {
        // 清除数据
        long yunKdtId6 = newWscKdtId();

        PlainResult<OrderCreateApi> result1 = testCreateOrder(yunKdtId6, yunKdtName6, wscWXItemId_2021, 1);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        PlainResult<OrderCreateApi> result2 = testCreateOrder(yunKdtId6, yunKdtName6, wscWXItemId_2021, 1);

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //  查询计费额度是否成功发放
        //    testQueryTotalQuota(yunKdtId6, 10000);
        //  商业化侧有一条延期发放的记录
        queryWaitPerformRecord(yunKdtId6, 1);
        //  判断是否可以预支额度
        //    testCanAdvanceOrderQuota(yunKdtId3.toString(), "KDT_ID", false);


        //  手动发放额度
        Long payOrderIdNew = result1.getData().getPayOrderId();
        Long payOrderIdRenew = result2.getData().getPayOrderId();
        //   updateEffectAndExpiretime(payOrderIdNew);
        updateEffectAndExpiretime(payOrderIdRenew);
        activeWaitPerformRecord(payOrderIdRenew);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //  额度正常发放
        testQueryTotalQuota(yunKdtId6, 20000);
        //  商业化侧没有待延期发放的记录
        queryWaitPerformRecord(yunKdtId6, 0);
        //  退款
        refundOrderNew(payOrderIdNew, new Date(), 0L, 0L, "BY_MANUAL");
        refundOrderNew(payOrderIdRenew, new Date(), 0L, 0L, "BY_MANUAL");

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId6, 0);

    }
}