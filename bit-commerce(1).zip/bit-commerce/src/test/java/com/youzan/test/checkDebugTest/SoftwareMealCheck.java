package com.youzan.test.checkDebugTest;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.common.collect.Lists;
import com.youzan.commerce.test.entity.dataobject.goods.GdCombineItem;
import com.youzan.commerce.test.entity.dataobject.goods.GdCombineTemplateContent;
import com.youzan.commerce.test.mapper.goods.GdCombineItemMapper;
import com.youzan.commerce.test.mapper.goods.GdCombineTemplateContentMapper;
import com.youzan.commerce.test.mapper.goods.GdCombineTemplateMapper;
import com.youzan.test.basecase.DeductBaseTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wuwu
 * @date 2020/12/26 7:33 PM
 */
public class SoftwareMealCheck extends DeductBaseTest {
    @Autowired(required = false)
    GdCombineTemplateContentMapper gdCombineTemplateContentMapper;

    @Autowired(required = false)
    GdCombineTemplateMapper gdCombineTemplateMapper;

    @Autowired(required = false)
    GdCombineItemMapper gdCombineItemMapper;
    //有赞微商城基础版-微信小程序-2020
    public String wscBasicWechat2020 = "";

    //有赞微商城基础版-百度小程序-2020
    public String wscBasicBaiDu2020 = "";

    //有赞微商城专业版-

    @Test
    public void checkWscBasicWechat() {
        //String wscBaiscWechat_20 = "combine_sku_wsc_2020_profession_year";
//        List<String> appIdsFor2020 = Lists.newArrayList("combine_sku_wsc_2020_basic_wechat_year","combine_sku_wsc_2020_basic_baidu_year","combine_sku_wsc_2020_profession_year","combine_sku_wsc_2020_ultimate_year","combine_sku_retail_single_2020_basic_wechat_app_year","combine_sku_retail_single_2020_basic_baidu_weapp_year","combine_sku_retail_single_2020_profession_year");
//        List<String> appIdsFor2021 = Lists.newArrayList("combine_sku_wsc_2021_basic_wechat_year","combine_sku_wsc_2021_basic_baidu_year","combine_sku_wsc_2021_profession_year","combine_sku_wsc_2021_ultimate_year","combine_sku_retail_single_2021_basic_wechat_app_year","combine_sku_retail_single_2021_basic_baidu_weapp_year","combine_sku_retail_single_2021_profession_year");

        List<String> appIdsFor2020 = Lists.newArrayList("combine_sku_edu_single_2020_basic_day","combine_sku_edu_single_2020_profession_day");
        List<String> appIdsFor2021 = Lists.newArrayList("combine_sku_edu_single_2021_basic_day","combine_sku_edu_single_2021_profession_day");

//        List<String> appIdsFor2020 = Lists.newArrayList("combine_sku_wsc_2020_basic_wechat_day","combine_sku_wsc_2020_basic_baidu_day","combine_sku_wsc_2020_profession_day","combine_sku_wsc_2020_ultimate_day","combine_sku_retail_single_2020_basic_wechat_app_day","combine_sku_retail_single_2020_basic_baidu_weapp_day","combine_sku_retail_single_2020_profession_day");
//        List<String> appIdsFor2021 = Lists.newArrayList("combine_sku_wsc_2021_basic_wechat_day","combine_sku_wsc_2021_basic_baidu_day","combine_sku_wsc_2021_profession_day","combine_sku_wsc_2021_ultimate_day","combine_sku_retail_single_2021_basic_wechat_app_day","combine_sku_retail_single_2021_basic_baidu_weapp_day","combine_sku_retail_single_2021_profession_day");


        //获取2020版待比较的商品内容列表
        for(int i=0; i<appIdsFor2020.size(); i++) {
            System.out.println("======="+appIdsFor2021.get(i)+"开始比较=======");
            Long gdCombineTemplatesId2020 =gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>()
                    .eq("combine_item_id",appIdsFor2020.get(i))
                    .orderByDesc("snapshot_no").last("limit 1")).getCombineTemplateId();

            List<GdCombineTemplateContent> gdCombineTemplateContentList2020 = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>()
                    .eq("combine_template_id",gdCombineTemplatesId2020));

            List<String> waitForCheckGdCombineTemplateContentList2020 = new ArrayList<>();

            for (GdCombineTemplateContent gdCombineTemplateContent:gdCombineTemplateContentList2020) {
                List<String> newGdCombineTemplateContentList = new ArrayList<>();
                newGdCombineTemplateContentList.add(gdCombineTemplateContent.getItemId());
                newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplatePeriod()));
                newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplateQuantity()));
                waitForCheckGdCombineTemplateContentList2020.add(listToString(newGdCombineTemplateContentList,'-'));

            }


            Long gdCombineTemplatesId2021 =gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>()
                    .eq("combine_item_id",appIdsFor2021.get(i))
                    .orderByDesc("snapshot_no").last("limit 1")).getCombineTemplateId();

            List<GdCombineTemplateContent> gdCombineTemplateContentList2021 = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>()
                    .eq("combine_template_id",gdCombineTemplatesId2021));

            List<String> waitForCheckGdCombineTemplateContentList2021 = new ArrayList<>();

            for (GdCombineTemplateContent gdCombineTemplateContent:gdCombineTemplateContentList2021) {
                List<String> newGdCombineTemplateContentList = new ArrayList<>();
                newGdCombineTemplateContentList.add(gdCombineTemplateContent.getItemId());
                newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplatePeriod()));
                newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplateQuantity()));
                waitForCheckGdCombineTemplateContentList2021.add(listToString(newGdCombineTemplateContentList,'-'));
            }

//            System.out.println("2020待比较的内容："+waitForCheckGdCombineTemplateContentList2020);
//            System.out.println("2021待比较的内容："+waitForCheckGdCombineTemplateContentList2021);

            System.out.println("2020商品数量："+waitForCheckGdCombineTemplateContentList2020.size());
            System.out.println("2021商品数量："+waitForCheckGdCombineTemplateContentList2021.size());

            List<String> diffList = getDiffrentString(waitForCheckGdCombineTemplateContentList2020,waitForCheckGdCombineTemplateContentList2021);
            List<String> diffList2 = getDiffrentString(waitForCheckGdCombineTemplateContentList2021,waitForCheckGdCombineTemplateContentList2020);

            System.out.println("21年的比20年少"+diffList.size()+"个ksu");
            System.out.println("21年的比20年少的sku有："+diffList);

            System.out.println("21年比20年多"+diffList2.size()+"个sku");
            System.out.println("21年的比20年多的sku有："+diffList2);

        }



    }

    @Test
    public void checkDwdWscAndProfession2021Year() {

        Long gdCombineTemplatesId_2021Pro =gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>()
                .eq("combine_item_id","combine_sku_wsc_2021_profession_year")
                .orderByDesc("snapshot_no").last("limit 1")).getCombineTemplateId();

        List<GdCombineTemplateContent> gdCombineTemplateContentList_2021Pro = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>()
                .eq("combine_template_id",gdCombineTemplatesId_2021Pro));

        List<String> waitForCheckGdCombineTemplateContentList2021 = new ArrayList<>();

        for (GdCombineTemplateContent gdCombineTemplateContent:gdCombineTemplateContentList_2021Pro) {
            List<String> newGdCombineTemplateContentList = new ArrayList<>();
            newGdCombineTemplateContentList.add(gdCombineTemplateContent.getItemId());
            newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplatePeriod()));
            newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplateQuantity()));
            waitForCheckGdCombineTemplateContentList2021.add(listToString(newGdCombineTemplateContentList,'-'));
        }


        Long gdCombineTemplatesId_DwdPro =gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>()
                .eq("combine_item_id","combine_sku_wsc_multi_store_profession_year")
                .orderByDesc("snapshot_no").last("limit 1")).getCombineTemplateId();

        List<GdCombineTemplateContent> gdCombineTemplateContentList_DwdPro = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>()
                .eq("combine_template_id",gdCombineTemplatesId_DwdPro));

        List<String> waitForCheckGdCombineTemplateContentListDwdPro = new ArrayList<>();

        for (GdCombineTemplateContent gdCombineTemplateContent:gdCombineTemplateContentList_DwdPro) {
            List<String> newGdCombineTemplateContentList = new ArrayList<>();
            newGdCombineTemplateContentList.add(gdCombineTemplateContent.getItemId());
            newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplatePeriod()));
            newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplateQuantity()));
            waitForCheckGdCombineTemplateContentListDwdPro.add(listToString(newGdCombineTemplateContentList,'-'));
        }


        System.out.println("多网点总部商品数量："+waitForCheckGdCombineTemplateContentListDwdPro.size());
        System.out.println("2021商品数量："+waitForCheckGdCombineTemplateContentList2021.size());

        List<String> diffList = getDiffrentString(waitForCheckGdCombineTemplateContentListDwdPro,waitForCheckGdCombineTemplateContentList2021);
        List<String> diffList2 = getDiffrentString(waitForCheckGdCombineTemplateContentList2021,waitForCheckGdCombineTemplateContentListDwdPro);


        System.out.println(diffList);
        System.out.println(diffList.size());

        System.out.println(diffList2);
        System.out.println(diffList2.size());


    }


        @Test
        public void checkDwdWscAndProfession2021Day() {

            Long gdCombineTemplatesId_2021Pro =gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>()
                    .eq("combine_item_id","combine_sku_wsc_2021_profession_day")
                    .orderByDesc("snapshot_no").last("limit 1")).getCombineTemplateId();

            List<GdCombineTemplateContent> gdCombineTemplateContentList_2021Pro = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>()
                    .eq("combine_template_id",gdCombineTemplatesId_2021Pro));

            List<String> waitForCheckGdCombineTemplateContentList2021 = new ArrayList<>();

            for (GdCombineTemplateContent gdCombineTemplateContent:gdCombineTemplateContentList_2021Pro) {
                List<String> newGdCombineTemplateContentList = new ArrayList<>();
                newGdCombineTemplateContentList.add(gdCombineTemplateContent.getItemId());
                newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplatePeriod()));
                newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplateQuantity()));
                waitForCheckGdCombineTemplateContentList2021.add(listToString(newGdCombineTemplateContentList,'-'));
            }


        Long gdCombineTemplatesId_DwdPro =gdCombineItemMapper.selectOne(new QueryWrapper<GdCombineItem>()
                .eq("combine_item_id","combine_sku_wsc_multi_store_profession_day")
                .orderByDesc("snapshot_no").last("limit 1")).getCombineTemplateId();

        List<GdCombineTemplateContent> gdCombineTemplateContentList_DwdPro = gdCombineTemplateContentMapper.selectList(new QueryWrapper<GdCombineTemplateContent>()
                .eq("combine_template_id",gdCombineTemplatesId_DwdPro));

        List<String> waitForCheckGdCombineTemplateContentListDwdPro = new ArrayList<>();

        for (GdCombineTemplateContent gdCombineTemplateContent:gdCombineTemplateContentList_DwdPro) {
            List<String> newGdCombineTemplateContentList = new ArrayList<>();
            newGdCombineTemplateContentList.add(gdCombineTemplateContent.getItemId());
            newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplatePeriod()));
            newGdCombineTemplateContentList.add(String.valueOf(gdCombineTemplateContent.getTemplateQuantity()));
            waitForCheckGdCombineTemplateContentListDwdPro.add(listToString(newGdCombineTemplateContentList,'-'));
        }


        System.out.println("多网点总部商品数量："+waitForCheckGdCombineTemplateContentListDwdPro.size());
        System.out.println("2021商品数量："+waitForCheckGdCombineTemplateContentList2021.size());

        List<String> diffList = getDiffrentString(waitForCheckGdCombineTemplateContentListDwdPro,waitForCheckGdCombineTemplateContentList2021);
        List<String> diffList2 = getDiffrentString(waitForCheckGdCombineTemplateContentList2021,waitForCheckGdCombineTemplateContentListDwdPro);


        System.out.println(diffList);
        System.out.println(diffList.size());

        System.out.println(diffList2);
        System.out.println(diffList2.size());


    }
}
