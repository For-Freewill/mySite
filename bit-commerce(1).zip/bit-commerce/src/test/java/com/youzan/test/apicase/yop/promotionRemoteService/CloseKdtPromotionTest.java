package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.StartTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.EnablePromotionParam;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @program: bit-commerce
 * @description  关闭某个优惠资格
 * @author: tianning
 * @create: 2021-03-24 13:40
 * @营销
 **/
public class CloseKdtPromotionTest extends StartTest{
    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void closeKdtPromotionTest() {
        EnablePromotionParam enablePromotionParam = new EnablePromotionParam();
        enablePromotionParam.setKdtId(58711819L);
        enablePromotionParam.setPreferentialId(8406);
        enablePromotionParam.setPromotionId(15274L);
        enablePromotionParam.setSalesId(123L);
        PlainResult<Boolean> closeKdtPromotionResult = promotionRemoteService.closeKdtPromotion(enablePromotionParam);
        Assert.assertEquals(closeKdtPromotionResult.getMessage(), "无可失效的资格或无权限进行失效");
        Assert.assertEquals(closeKdtPromotionResult.getCode(), 130624);
    }

    /**
     * 异常用例
     */
    @Test
    public void closeKdtPromotionInvalidNullTest() {
        EnablePromotionParam enablePromotionParam = new EnablePromotionParam();
        enablePromotionParam.setKdtId(58711819L);
        enablePromotionParam.setPreferentialId(8406);
        enablePromotionParam.setPromotionId(15274L);
        enablePromotionParam.setSalesId(123L);
        PlainResult<Boolean> closeKdtPromotionResult = promotionRemoteService.closeKdtPromotion(enablePromotionParam);
        Assert.assertEquals(closeKdtPromotionResult.getMessage(), "无可失效的资格或无权限进行失效");
        Assert.assertEquals(closeKdtPromotionResult.getCode(), 130624);
    }
}
