package com.youzan.test.apicase.yop.stockRemoteService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.test.BaseTest;
import com.youzan.test.basecase.SimpleToolBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.StockRemoteService;
import com.youzan.yop.api.form.order.AutoBuyMsgOrderForm;
import com.youzan.yop.api.response.AutoBuyMsgResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * @author leifeiyun
 * @date 2021/2/19
 **/

public class StockAutoBuyTest extends SimpleToolBaseTest {
    @Dubbo
    StockRemoteService stockRemoteService;
    @Autowired(required = false)
    TdOrderMapper tdOrderMapper;
    Long kdtId = 58113442L;
/**
 * 短信自动充值，正常用例。自动充值1000条
 *
 * 如果排查确认用例问题是由于消息堵塞或者不可抗力，导致出现
 * 了脏数据，可以尝试删除业务方的数据。
 * delete from sms_stock where kdt_id='58113442';
 * delete from sms_stock_detail where kdt_id='58113442';
 *
 * 这张日志表可删可不删，影响不大
 * delete from sms_stock_log where kdt_id='58113442';
 *
 *
**/
    @Test()
    public void testAutoRechargeMsg(){
        closeWaitPayOrder(kdtId);
        AutoBuyMsgOrderForm autoBuyMsgOrderForm = new AutoBuyMsgOrderForm();
        autoBuyMsgOrderForm.setAppId(BaseTest.ItemInfo.SMS_1000.getAppId());
        autoBuyMsgOrderForm.setItemId(BaseTest.ItemInfo.SMS_1000.getItemId());
        autoBuyMsgOrderForm.setApplyKdtId(kdtId);
        autoBuyMsgOrderForm.setFromApp("msg-push");
        PlainResult<AutoBuyMsgResponse> result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        try {
            //时间设置这么长是根据debug时间调试出来的，确实挺长了，不然退款不行
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //消息堵了，老是把init状态误认为待付款，这里先暴力处理下，等开发有时间优化下这个接口@城固
        if(result.getCode()==152301){
            deleteTestDataYcmByKdtId(kdtId);
            clearCache(kdtId);
            result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        }

        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>()
                .eq("buyer_id",kdtId)
                .eq("order_way","AUTO")
                .orderByDesc("created_at")
                .last(" limit 1"));
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getMessage(),"successful");
        Assert.assertEquals(tdOrder.getId(),result.getData().getOrderId(),"短信自动订购tdOrderId与实际不符合");
        try {
            //时间设置这么长是根据debug时间调试出来的，确实挺长了，不然退款不行
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //充值库存后记得退款
        refundOrderBatch(kdtId, Long.valueOf(ItemInfo.SMS_1000.getAppId()),String.valueOf(result.getData().getOrderId()),"BY_VALUE",new Date());
    }

    @Test
    public void testAutoRechargeMsgWithoutKdtId(){
        AutoBuyMsgOrderForm autoBuyMsgOrderForm = new AutoBuyMsgOrderForm();
        autoBuyMsgOrderForm.setAppId(BaseTest.ItemInfo.SMS_1000.getAppId());
        autoBuyMsgOrderForm.setItemId(BaseTest.ItemInfo.SMS_1000.getItemId());
        autoBuyMsgOrderForm.setApplyKdtId(null);
        autoBuyMsgOrderForm.setFromApp("msg-push");
        PlainResult<AutoBuyMsgResponse> result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        Assert.assertEquals(result.getCode(),40200);
        Assert.assertEquals(result.getMessage(),"店铺id不能为空");
        Assert.assertEquals(result.getData(),false);
    }

    @Test()
    public void testAutoRechargeMsgWithFromApp(){
        AutoBuyMsgOrderForm autoBuyMsgOrderForm = new AutoBuyMsgOrderForm();
        autoBuyMsgOrderForm.setAppId(BaseTest.ItemInfo.SMS_1000.getAppId());
        autoBuyMsgOrderForm.setItemId(BaseTest.ItemInfo.SMS_1000.getItemId());
        autoBuyMsgOrderForm.setApplyKdtId(kdtId);
        autoBuyMsgOrderForm.setFromApp("");
        PlainResult<AutoBuyMsgResponse> result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        Assert.assertEquals(result.getCode(),130102);
        Assert.assertEquals(result.getMessage(),"参数非法");
    }
    @Test()
    public void testAutoRechargeMsgWithNUllFromApp(){
        AutoBuyMsgOrderForm autoBuyMsgOrderForm = new AutoBuyMsgOrderForm();
        autoBuyMsgOrderForm.setAppId(BaseTest.ItemInfo.SMS_1000.getAppId());
        autoBuyMsgOrderForm.setItemId(BaseTest.ItemInfo.SMS_1000.getItemId());
        autoBuyMsgOrderForm.setApplyKdtId(kdtId);
        autoBuyMsgOrderForm.setFromApp(null);
        PlainResult<AutoBuyMsgResponse> result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        Assert.assertEquals(result.getCode(),40200);
        Assert.assertEquals(result.getMessage(),"来源应用不能为空");
    }


    @Test()
    public void testAutoRechargeMsgWithoutAppId(){
        AutoBuyMsgOrderForm autoBuyMsgOrderForm = new AutoBuyMsgOrderForm();
        autoBuyMsgOrderForm.setAppId(null);
        autoBuyMsgOrderForm.setItemId(BaseTest.ItemInfo.SMS_1000.getItemId());
        autoBuyMsgOrderForm.setApplyKdtId(kdtId);
        autoBuyMsgOrderForm.setFromApp("msg-push");
        PlainResult<AutoBuyMsgResponse> result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        Assert.assertEquals(result.getCode(),40200);
        Assert.assertEquals(result.getMessage(),"应用id不能为空");
    }

    @Test()
    public void testAutoRechargeMsgWithoutItemId(){
        AutoBuyMsgOrderForm autoBuyMsgOrderForm = new AutoBuyMsgOrderForm();
        autoBuyMsgOrderForm.setAppId(BaseTest.ItemInfo.SMS_1000.getAppId());
        autoBuyMsgOrderForm.setItemId(null);
        autoBuyMsgOrderForm.setApplyKdtId(kdtId);
        autoBuyMsgOrderForm.setFromApp("msg-push");
        PlainResult<AutoBuyMsgResponse> result =  stockRemoteService.stockAutoBuy(autoBuyMsgOrderForm);
        Assert.assertEquals(result.getCode(),40200);
        Assert.assertEquals(result.getMessage(),"商品id不能为空");
    }
}
