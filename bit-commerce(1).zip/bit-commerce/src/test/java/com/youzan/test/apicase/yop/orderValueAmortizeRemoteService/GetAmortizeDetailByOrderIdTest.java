package com.youzan.test.apicase.yop.orderValueAmortizeRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.OrderValueAmortizeRemoteService;
import com.youzan.yop.api.entity.amortize.BaseValueAmortizeApi;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by baoyan on 2021-01-05.
 * @营销
 */
public class GetAmortizeDetailByOrderIdTest extends YunBaseTest {
    @Dubbo
    OrderValueAmortizeRemoteService orderValueAmortizeRemoteService;
    private long orderId = 311609160285397l;

    @Test
    public void  getAmortizeDetailByOrderIdNormalTest(){
        PlainResult<BaseValueAmortizeApi> result = orderValueAmortizeRemoteService.getAmortizeDetailByOrderId(orderId);
        logger.info(result.toString());
        Assert.assertEquals(result.getCode(),200);
        Assert.assertEquals(result.getData().getAppId().longValue(),6075l);
        Assert.assertEquals(result.getData().getOrderId().longValue(),orderId);
        Assert.assertEquals(result.getData().getTotalRealPrice().longValue(),155719l);
        Assert.assertEquals(result.getData().getTotalDeductionRealPrice().longValue(),1100474l);
        Assert.assertEquals(result.getData().getOrderValueAmortizeDetailApi().getAmortizeDeductRealPrice().longValue(),1100474l);
        Assert.assertEquals(result.getData().getOrderValueAmortizeDetailApi().getAmortizeRealPrice().longValue(),155719l);
        Assert.assertEquals(result.getData().getOrderValueAmortizeDetailApi().getOrderEffectDays().longValue(),365l);
    }


    @Test
    public void  getAmortizeDetailByOrderIdWithOutOrderIdTest(){
        PlainResult<BaseValueAmortizeApi> result = orderValueAmortizeRemoteService.getAmortizeDetailByOrderId(null);
        logger.info(result.toString());
        Assert.assertEquals(result.getCode(),130102);
    }
}
