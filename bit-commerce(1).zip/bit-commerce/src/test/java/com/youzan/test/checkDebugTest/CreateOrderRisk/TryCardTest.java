package com.youzan.test.checkDebugTest.CreateOrderRisk;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.DeductBaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author wuwu
 * @date 2021/1/25 7:15 PM
 */
public class TryCardTest extends DeductBaseTest {
    Logger logger = LoggerFactory.getLogger(TryCardTest.class);

    public Long kdtIdForTryCard = 58831174L;
    public String kdtNameForTryCard = "CI-接口自动化-体验卡订购";

    public Long kdtIdForTryCardNoStatus = 58831152L;
    public String kdtNameForTryCardNoStatus = "CI-接口自动化-体验卡（无基础服务不能订购）";


    public Long kdtIdForTryCard2 = 59200114L;
    public String kdtNameForTryCard2 = "CI-接口自动化-体验卡订购2";

    public int groupBuy14TryCardItemId = 7032;
    public int promoteAnalysis15TryCardItemId = 72968;
    public int grouponTryCard = 69;
    public int periodBuyExperienceTryCard = 7254;
    public int weappSdkExperienceTryCard = 7037;
    public int packageBuyTryCard = 72;


    @Test(dataProvider = "tryCard")
    public void tryCardCanNotBuyWithNoSoftStatus(int tryItemId) {
        PlainResult<Long>  result = compareServiceImp.invoke(()->createOrder(kdtIdForTryCardNoStatus,kdtNameForTryCardNoStatus,tryItemId,1,0L));
        Assert.assertEquals(result.getCode(),130604);
        Assert.assertEquals(result.getMessage(),"无法购买:此服务暂不可购买");
    }


    @Test(dataProvider = "tryCard")
    public void tryCardCanNotBuyWithSoftStatus(int tryItemId) {
        closeWaitPayOrder(kdtIdForTryCard);
        PlainResult<Long>  result = compareServiceImp.invoke(()->createOrder(kdtIdForTryCard,kdtNameForTryCard,tryItemId,100,0L));
        Assert.assertEquals(result.getCode(),130604);
        //Assert.assertEquals(result.getMessage(),"无法购买:此服务暂不可购买");
    }


    @Test(dataProvider = "tryCard")
    public void tryCardCanNotBuyWithSoftStatus_create(int tryItemId) {
        closeWaitPayOrder(kdtIdForTryCard2);
        PlainResult<Long>  result = createOrder(kdtIdForTryCard2,kdtNameForTryCard2,tryItemId,1,0L);
        Assert.assertEquals(result.getCode(),200);
        //Assert.assertEquals(result.getMessage(),"无法购买:此服务暂不可购买");
    }

    @Test(dataProvider = "tryCard")
    public void tryCardCanNotBuyWithSoftStatus_multiNumCreate(int tryItemId) {
        closeWaitPayOrder(kdtIdForTryCard2);
        PlainResult<Long>  result = createOrder(kdtIdForTryCard,kdtNameForTryCard,tryItemId,100,0L);
        Assert.assertEquals(result.getCode(),1540000);
        //Assert.assertEquals(result.getMessage(),"无法购买:此服务暂不可购买");
    }

    @DataProvider(name = "tryCard")
    public Object[][] tryCard() {
        return new Object[][]{
                {41}, {72}, {69}, {73}, {637}, {7048}, {72968}, {7190}, {7051}, {7186},
                {7032}, {71}, {7178}, {7271}, {73111}, {72969}
        };
    }



}
