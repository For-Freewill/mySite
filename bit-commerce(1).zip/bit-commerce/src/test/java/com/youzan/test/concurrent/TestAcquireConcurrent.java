package com.youzan.test.concurrent;

import com.youzan.api.common.response.PlainResult;
import com.youzan.platform.service_chain.context.ServiceChainContext;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.redeemcode.RedeemCodeRemoteService;
import com.youzan.ycm.market.request.redeemcode.AcquireRedeemCodeRequest;
import com.youzan.ycm.market.response.redeemcode.AcquireRedeemCodeResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;


/**
 * @author leifeiyun
 * @date 2021/1/6
 **/
public class TestAcquireConcurrent extends ConcurrentBaseTest {
    @Dubbo
    RedeemCodeRemoteService redeemCodeRemoteService;
    static Map serviceChainMap  = new HashMap();

    @DataProvider(parallel = true,name="acquireData")
    public Object[][] datas() {
       Object[][] objects = new Object[][]{
               {"lfy3000000905"},
               {"lfy4000000904"}
       };
       return objects;
    }
     static {
         serviceChainMap.put("name", "prj00XXX");
     }
    @Test(threadPoolSize=5, invocationCount=100,dataProvider = "acquireData")
    public void testRedeemConcurrent(String acquireBizNo){
        ServiceChainContext.setInvocationServiceChainContext(serviceChainMap);
        AcquireRedeemCodeRequest acquireRedeemCodeRequest = new AcquireRedeemCodeRequest();
        acquireRedeemCodeRequest.setAcquireBizNo(acquireBizNo);
        acquireRedeemCodeRequest.setRedeemCodeId(String.valueOf(1143));
        acquireRedeemCodeRequest.setAcquireBizType("NTC_TRADE_NO");
        acquireRedeemCodeRequest.setBelongToType("USER_PHONE_NO");
        acquireRedeemCodeRequest.setBelongToId("13500101989");
        PlainResult<AcquireRedeemCodeResponse> acquire =  redeemCodeRemoteService.acquire(acquireRedeemCodeRequest);
        logger.info("当前前程信息"+Thread.currentThread().getId()+":"+Thread.currentThread().getName());
        logger.info("acquire.getData()--》："+acquire.getData());

    }

    @Test(threadPoolSize=2, invocationCount=10,dataProvider = "acquireData")
    public void testRedeemConcurrent1(String acquireBizNo){
//        ServiceChainContext.setInvocationServiceChainContext(serviceChainMap);
        AcquireRedeemCodeRequest acquireRedeemCodeRequest = new AcquireRedeemCodeRequest();
        acquireRedeemCodeRequest.setAcquireBizNo(acquireBizNo);
        acquireRedeemCodeRequest.setRedeemCodeId(String.valueOf(1143));
        acquireRedeemCodeRequest.setAcquireBizType("NTC_TRADE_NO");
        acquireRedeemCodeRequest.setBelongToType("USER_PHONE_NO");
        acquireRedeemCodeRequest.setBelongToId("13500101989");
        PlainResult<AcquireRedeemCodeResponse> acquire =  redeemCodeRemoteService.acquire(acquireRedeemCodeRequest);
        logger.info("当前前程信息"+Thread.currentThread().getId()+":"+Thread.currentThread().getName());
//        logger.info("acquire.getData()--》："+acquire.getData());

    }
}
