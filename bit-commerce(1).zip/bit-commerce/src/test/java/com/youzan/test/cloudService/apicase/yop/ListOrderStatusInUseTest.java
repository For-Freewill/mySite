package com.youzan.test.cloudService.apicase.yop;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.apicase.yop.YopBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.entity.status.OrderStatusInUseApi;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @author wulei
 * @date 2020/9/25 3:59 下午
 * 查询店铺正在生效的订单有效期列表
 * @大爷
 */
public class ListOrderStatusInUseTest extends YopBaseTest {

    public static Long WSCKQUERY = 58711819L;
    public static String WSCKQUERYS = "58711819";
    public static String WSCKQUERYNAME = "CI查询专用店铺";

    @Dubbo
    public AppStatusRemoteService appStatusRemoteService;

    Integer appGroup = 3;//软件

    /**
     * 正常用例
     */
    @Test
    public void listOrderStatusInUseNormalTest() {
        PlainResult<List<OrderStatusInUseApi>> getAppStatusWithBasicResult = appStatusRemoteService.listOrderStatusInUse(61014027L, appGroup);
        Assert.assertEquals(getAppStatusWithBasicResult.getCode(), 200);
        Assert.assertEquals(getAppStatusWithBasicResult.getData().get(0).getAppId().longValue(), 873);
        Assert.assertEquals(getAppStatusWithBasicResult.getData().get(0).getItemId().longValue(), 8530);
        Assert.assertEquals(getAppStatusWithBasicResult.getData().get(0).getStatus().byteValue(), 1);
    }

    /**
     * 异常用例--参数都为空
     */
    @Test
    public void listOrderStatusInUseParameterNullTest() {
        PlainResult<List<OrderStatusInUseApi>> getAppStatusWithBasicResult = appStatusRemoteService.listOrderStatusInUse(null, null);
        Assert.assertEquals(getAppStatusWithBasicResult.getCode(), 130102);
        Assert.assertEquals(getAppStatusWithBasicResult.getMessage(), "参数非法");
    }

    /**
     * 异常用例--Appgroup为空
     */
    @Test
    public void listOrderStatusInUseAppgroupNullTest() {
        PlainResult<List<OrderStatusInUseApi>> getAppStatusWithBasicResult = appStatusRemoteService.listOrderStatusInUse(WSCKQUERY, null);
        Assert.assertEquals(getAppStatusWithBasicResult.getCode(), 130102);
        Assert.assertEquals(getAppStatusWithBasicResult.getMessage(), "参数非法");
    }

    /**
     * 异常用例--店铺为空
     */
    @Test
    public void listOrderStatusInUseKDTIDNullTest() {
        PlainResult<List<OrderStatusInUseApi>> getAppStatusWithBasicResult = appStatusRemoteService.listOrderStatusInUse(null, appGroup);
        Assert.assertEquals(getAppStatusWithBasicResult.getCode(), 130102);
        Assert.assertEquals(getAppStatusWithBasicResult.getMessage(), "参数非法");
    }
}
