package com.youzan.test.onlineTrade.basecase.period_count;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.goods.GdGoodsIdMapping;
import com.youzan.commerce.test.entity.dataobject.perform.*;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrderItem;
import com.youzan.commerce.test.mapper.goods.GdGoodsIdMappingMapper;
import com.youzan.commerce.test.mapper.perform.*;
import com.youzan.commerce.test.mapper.trade.TdOrderItemMapper;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.test.basecase.SimpleToolBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.ycm.perform.api.PfAppStatusRemoteService;
import com.youzan.ycm.perform.request.status.FlushAppStatusRequest;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.RefundRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.order.OrderListApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.entity.status.AppStatusInfoApi;
import com.youzan.yop.api.request.RefundCalculateNonConsumeRequest;
import com.youzan.yop.api.request.RefundNonConsumeRequest;
import com.youzan.yop.api.request.SearchOrderForRefundRequest;
import com.youzan.yop.api.response.RefundCalculateNonConsumeResponse;
import com.youzan.yop.api.response.RefundQueryOrderResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static com.youzan.commerce.test.utils.DateUtil.compareDate;
import static org.awaitility.Awaitility.with;

/**
 * @author baoyan
 * @date 2020/8/26
 **/
public class PeriodCountBaseTest extends SimpleToolBaseTest {
    final static Logger logger = LoggerFactory.getLogger(PeriodCountBaseTest.class);
//    public static Long wscKdtId = 58113442L;
    public static Long userId = 690258785L;
    @Autowired(required = false)
    PfBizRecordMapper pfBizRecordMapper;
    @Autowired(required = false)
    TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    PfOrderDetailMapper pfOrderDetailMapper;
    @Autowired(required = false)
    TdOrderItemMapper tdOrderItemMapper;
    @Autowired(required = false)
    PfOrderItemBizMapper pfOrderItemBizMapper;
    @Autowired(required = false)
    PfOrderStatusMapper pfOrderStatusMapper;
    @Autowired(required = false)
    GdGoodsIdMappingMapper gdGoodsIdMappingMapper;
    @Dubbo
    MarketRemoteService marketRemoteService;
    @Dubbo
    AppStatusRemoteService appStatusRemoteService;
    @Dubbo
    OrderRemoteService orderRemoteService;
    @Dubbo
    RefundRemoteService refundRemoteService;
    @Dubbo
    PfAppStatusRemoteService pfAppStatusRemoteService;

    public void deleteDataForPeriodCountCases(String payOrderId) {
        TdOrder tdOrder = tdOrderMapper.selectOne(new QueryWrapper<TdOrder>().eq("id", payOrderId));
        List<PfOrder> pfOrderList = pfOrderMapper.selectList(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
        TdOrderItem tdOrderItem = tdOrderItemMapper.selectOne(new QueryWrapper<TdOrderItem>().eq("td_no", tdOrder.getTdNo()));
        String bizItemNo = JSONObject.parseObject(tdOrderItem.getBizExt()).getString("item_biz");
        List<Long> pfOrderIdList = new ArrayList<>(pfOrderList.size());
        for (PfOrder i : pfOrderList) {
            pfOrderIdList.add(i.getId());
        }

        Integer pfBizRecordDelete = pfBizRecordMapper.delete(new QueryWrapper<PfBizRecord>().eq("biz_order_id", tdOrder.getTdNo()));
        Integer pfOrderIdDelete = pfOrderMapper.delete(new QueryWrapper<PfOrder>().eq("biz_order_id", tdOrder.getTdNo()));
        Integer pfOrderDetailDelete = pfOrderDetailMapper.delete(new QueryWrapper<PfOrderDetail>().in("pf_order_id", pfOrderIdList));
        Integer PfOrderItemBizDelete = pfOrderItemBizMapper.delete(new QueryWrapper<PfOrderItemBiz>().eq("item_biz_no", bizItemNo));
        Integer pfOrderStatusDelete = pfOrderStatusMapper.delete(new QueryWrapper<PfOrderStatus>().in("pf_order_id", pfOrderIdList));

    }

    /**
     * 对于订购应用，验证该应用服务期往后推一定的时间，可用这个方法进行校验，具体到appId维度
     *
     * @param kdtId
     * @param calendarType
     * @param count
     * @param appIds
     */
    public void checkAppStatusWithAppIs(Long kdtId, Integer calendarType, Integer count, List<Integer> appIds) {
        long start = System.currentTimeMillis();
        logger.info("checkAppStatusWithAppIs start:" + new Date());

        AtomicReference<PlainResult<List<AppStatusInfoApi>>> appStatusListInfo = new AtomicReference<>(new PlainResult<>());
//        Assert.assertNotNull(appStatusListInfo.get().getData());
        //开始轮询前，等待1分钟，如果未设置pollDelay，则取pollInterval的值
        with().pollInterval(40, TimeUnit.SECONDS)
                .and().with().pollDelay(10, TimeUnit.SECONDS)
                .and().with().atMost(4, TimeUnit.MINUTES)
                .await("验证服务期生成，别慌，要淡定")
                .until(
                        () -> {
                            appStatusListInfo.set(appStatusRemoteService.getAppStatusListInfo(ConstructionParam.getQueryAppStatusListForm(kdtId, appIds)));
                            logger.info("appStatusListInfo-->" + appStatusListInfo.get());
                            Assert.assertNotNull(appStatusListInfo.get().getData(),"履约数据未生成！");
                            for (int i = 0; i < appStatusListInfo.get().getData().size(); i++) {
                                logger.info("appStatusListInfo.getData().get(i).getExpireTime():--->" + appStatusListInfo.get().getData().get(i).getExpireTime());
                                boolean compareResult = compareDate(new Date(), appStatusListInfo.get().getData().get(i).getExpireTime(), calendarType, count);
                                logger.info("compareResult：---->" + compareResult);
                                if (compareResult == false) {
                                    return false;
                                }
                            }
                            return true;
                        });
        long end = System.currentTimeMillis() - start;
        logger.info("checkAppStatusWithAppIs end:" + new Date());
        logger.info("checkAppStatusWithAppIs need time:" + end + "ms");
        Assert.assertEquals(appStatusListInfo.get().getCode(), 200);
        Assert.assertEquals(appStatusListInfo.get().getMessage(), "successful");

    }


    /**
     * 存在待付款订单，则关闭订单
     */
    public void closeWaitPayOrder(Long kdtId) {
        PlainResult<PageApi<OrderListApi>> resultList = orderRemoteService.listOrder(ConstructionParam.getSearchOrderListForm(kdtId, (byte) 0));
        if (resultList.getData().getContent().size() > 0) {
            //关闭订单
            orderRemoteService.closeOrder(ConstructionParam.getOrderDetailForm(kdtId, resultList.getData().getContent().get(0).getId()));
        }
    }

    /**
     * 存在待付款订单，则调用支付付款
     */
    public void payWaitPayOrder(Long kdtId, Long payOrderId) {
        PlainResult<PageApi<OrderListApi>> resultList = orderRemoteService.listOrder(ConstructionParam.getSearchOrderListForm(kdtId, (byte) 0));
        if (resultList.getData().getContent().size() > 0) {
            //1.调用预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(payOrderId, (byte) 4);

            //2.支付订单
            cashierPay(preparePayApiPlainResult, account, wscKdtId);

        }
    }

    /**
     * 批量退款
     *
     * @param kdtId      店铺id
     * @param payOrderId 父订单号
     * @param refundMode 退款方式【全额，手动，部分】
     */
    public void refundOrderBatch(Long kdtId, Long appId, String payOrderId, String refundMode, Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(date);
        SearchOrderForRefundRequest searchOrderForRefundRequest = new SearchOrderForRefundRequest();
        searchOrderForRefundRequest.setKdtId(kdtId);
        searchOrderForRefundRequest.setOrderState((byte) 1);
        if (!"".equals(payOrderId)) {
            searchOrderForRefundRequest.setPayOrderId(payOrderId);
        }
        if (appId != null) {
            searchOrderForRefundRequest.setAppId(appId);
        }
        PlainResult<PageApi<RefundQueryOrderResponse>> searchwscResult = refundRemoteService.searchOrderForRefund(searchOrderForRefundRequest);

        for (int i = 0; i < searchwscResult.getData().getContent().size(); i++) {
            RefundCalculateNonConsumeRequest calculateNonConsumeRequest = new RefundCalculateNonConsumeRequest();
            calculateNonConsumeRequest.setOrderId(searchwscResult.getData().getContent().get(i).getOrderId());
            calculateNonConsumeRequest.setRefundMode(refundMode);
            calculateNonConsumeRequest.setRefundCalculateTime(refundTime);

            PlainResult<RefundCalculateNonConsumeResponse> calculateResult = refundRemoteService.calculateNonConsume(calculateNonConsumeRequest);
            if (calculateResult.getCode() == 152200 && "履约资产无对应履约明细，无法计算比例".equals(calculateResult.getMessage())) {
                //删除pf_order数据，因为生成了脏数据,pf_order中有数据，但是pf_order_status中无数据
                Integer pfOrderIdDelete = pfOrderMapper.delete(new QueryWrapper<PfOrder>().eq("id", calculateNonConsumeRequest.getOrderId()));
            } else {
                refundOrder(searchwscResult.getData().getContent().get(i).getOrderId(),
                        new Date(), calculateResult.getData().getRefundTotalCnyAmt(), calculateResult.getData().getRefundTotalYzbAmt(), refundMode);
            }


        }

    }


    public void refundOrder(String orderId, Date date, Long refundCnyAmt, Long refundYzbAmt, String refundMode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String refundTime = simpleDateFormat.format(date);

        RefundNonConsumeRequest refundNonConsumeRequest = new RefundNonConsumeRequest();
        refundNonConsumeRequest.setMemo("");
        refundNonConsumeRequest.setOperatorId("2135");
        refundNonConsumeRequest.setOrderId(orderId);
        refundNonConsumeRequest.setRefundCalculateTime(refundTime);
        refundNonConsumeRequest.setRefundMode(refundMode);
        refundNonConsumeRequest.setRefundYzbAmt(refundYzbAmt);
        refundNonConsumeRequest.setRefundCnyAmt(refundCnyAmt);
        refundNonConsumeRequest.setRefundWay("ORIG");
        PlainResult<Boolean> refundResult = refundRemoteService.refundNonConsume(refundNonConsumeRequest);
        Assert.assertEquals(refundResult.getMessage(), "successful");
        Assert.assertEquals(refundResult.getCode(), 200);
        Assert.assertTrue(refundResult.getData());

    }

    /**
     * appId维度，做一个服务期平移操作
     *
     * @param applyKdtId
     * @param appId
     * @param days
     */
    public void moveAppStatus(Long applyKdtId, String appId, Integer days) {
      /*  pfOrderStatusMapper.update(new PfOrderStatus(), new UpdateWrapper<PfOrderStatus>()
                .setSql("effect_time = date_sub(effect_time,interval'" + days + "' day),expire_time = date_sub(expire_time,interval'" + days + "' day)")
                .eq("app_id", appId)
                .eq("apply_kdt_Id", applyKdtId)
                .eq("state", "valid")
        );*/

        LambdaUpdateWrapper<PfOrderStatus> lambdaUpdateWrapper = new LambdaUpdateWrapper<>();
        lambdaUpdateWrapper.eq(PfOrderStatus::getAppId, appId).eq(PfOrderStatus::getApplyKdtId, String.valueOf(applyKdtId))
                .eq(PfOrderStatus::getState,"valid").setSql("effect_time = date_sub(effect_time,interval'" + days + "' day),expire_time = date_sub(expire_time,interval'" + days + "' day)");

        pfOrderStatusMapper.update(null, lambdaUpdateWrapper);


        //刷新缓存，detail数据
        FlushAppStatusRequest flushAppStatusRequest = new FlushAppStatusRequest();
        flushAppStatusRequest.setKdtId(String.valueOf(applyKdtId));
        flushAppStatusRequest.setAppId(appId);
        pfAppStatusRemoteService.flushAppStatusCatch(flushAppStatusRequest);
        //同步（实际不需要同步），但是规范起见以及避免脏数据
        GdGoodsIdMapping gdGoodsIdMapping = gdGoodsIdMappingMapper.selectOne(new QueryWrapper<GdGoodsIdMapping>().eq("ycm_id", appId));
        marketRemoteService.concurrentStatus(applyKdtId, Integer.valueOf(gdGoodsIdMapping.getYopId()));
    }


}
