package com.youzan.test.apicase.yop.wxdActivityInfoRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;

import com.youzan.uic.auth.api.model.CarmenClient;
import com.youzan.uic.auth.api.model.MobileUser;
import com.youzan.uic.auth.api.model.MobileUserLoginResult;
import com.youzan.uic.auth.api.model.Scene;
import com.youzan.uic.auth.api.model.param.MobileUserLoginDto;
import com.youzan.uic.auth.api.service.MobileUserService;
import com.youzan.yop.api.WxdActivityInfoRemoteService;
import com.youzan.yop.api.entity.wxd.ActivationCodeListResultApi;
import com.youzan.yop.api.entity.wxd.GetActivationCodeListApi;
import org.testng.annotations.Test;

/**
 * Created by baoyan on 2021-01-06.
 * @线上
 */
public class GetActivationCodeListTest extends YunBaseTest {
    @Dubbo
    MobileUserService mobileUserService;
    @Dubbo
    WxdActivityInfoRemoteService wxdActivityInfoRemoteService;
    private String mobile = "13018975651";
    private String captcha = "123456";
    private String token = null;

    @Test (enabled = false)
    public void getActivationCodeListNormalTest(){
        MobileUser mobileUser = new MobileUser();
        mobileUser.setMobile(mobile);
        mobileUser.setCountryCode("+86");
        mobileUser.setSmsCaptcha(captcha);
        mobileUser.setKdtId(5345398l);
        mobileUser.setAgreementSignedDefaultFlag(true);
        CarmenClient carmenClient = new CarmenClient();
        carmenClient.setClientId("a08f5e32909cc9418f");
        carmenClient.setClientSecret("28007a59d36ff6617848c879440ce609");
        Scene scene = new Scene();
        scene.setDeviceId("a57486e1-5d41-3ceb-93db-b3fa034b63ed");
        scene.setDeviceName("11");
        scene.setIpAddress("10.97.252.215");
        scene.setUserAgent("yago; Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36;");
        PlainResult<MobileUserLoginResult> result = mobileUserService.registerAndLoginBySmsCaptcha(mobileUser,carmenClient,scene);
        if(result.getCode()==200) {
             token = result.getData().getCarmenClientSession().getAccessToken();
        }
        GetActivationCodeListApi activationCodeListApi = new GetActivationCodeListApi();
        activationCodeListApi.setAccessToken(token);
        PlainResult<ActivationCodeListResultApi> wxdResult = wxdActivityInfoRemoteService.getActivationCodeList(activationCodeListApi);
        logger.info(result.toString());
        logger.info(token);
        logger.info(wxdResult.toString());

    }


}
