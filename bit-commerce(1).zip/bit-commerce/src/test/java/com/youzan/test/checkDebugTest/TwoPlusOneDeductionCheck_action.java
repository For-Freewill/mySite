package com.youzan.test.checkDebugTest;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.commerce.test.entity.dataobject.perform.PfRegulation;
import com.youzan.commerce.test.entity.dataobject.perform.PfRegulationExec;
import com.youzan.commerce.test.mapper.perform.PfRegulationExecMapper;
import com.youzan.commerce.test.mapper.perform.PfRegulationMapper;
import com.youzan.test.basecase.DeductBaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wuwu
 * @date 2021/1/5 9:36 PM
 */
public class TwoPlusOneDeductionCheck_action extends DeductBaseTest {
    @Autowired(required = false)
    public PfRegulationMapper pfRegulationMapper;

    @Autowired(required = false)
    public PfRegulationExecMapper pfRegulationExecMapper;

    Logger logger = LoggerFactory.getLogger(TwoPlusOneDeductionCheck_action.class);
    @Test
    public void compareProfession_21And20() {
        //获取20版可以抵扣的item_id
        //20基础版-抵扣
        String wscBaiscWechat_20 = "combine_sku_wsc_2020_profession_year";
        List<PfRegulation> pfRegulationList =pfRegulationMapper.selectList(new QueryWrapper<PfRegulation>().eq("is_delete",0));
        List<Long> pfRegulationIdList = new ArrayList<>();
        for (PfRegulation pfRegulation : pfRegulationList) {
            pfRegulationIdList.add(pfRegulation.getId());
        }
        List<PfRegulationExec> pfRegulationExecsList_wscWechat_20 =pfRegulationExecMapper.selectList(new QueryWrapper<PfRegulationExec>()
                .in("regulation_id",pfRegulationIdList)
                .like("regulation_condition",wscBaiscWechat_20)
                .like("regulation_action","TWO"));

        List<String> action_20 = new ArrayList<>();
        for (PfRegulationExec pfRegulationExec : pfRegulationExecsList_wscWechat_20) {
            action_20.add(pfRegulationExec.getRegulationAction());
        }


        String wscBaiscWechat_21 = "combine_sku_wsc_2021_profession_year";
        List<PfRegulationExec> pfRegulationExecsList_wscWechat_21 =pfRegulationExecMapper.selectList(new QueryWrapper<PfRegulationExec>()
                .in("regulation_id",pfRegulationIdList)
                .like("regulation_condition",wscBaiscWechat_21)
                .like("regulation_action","TWO"));

        List<String> action_21 = new ArrayList<>();
        for (PfRegulationExec pfRegulationExec : pfRegulationExecsList_wscWechat_21) {
            action_21.add(pfRegulationExec.getRegulationAction());
        }

        System.out.println("20的可抵扣个数："+action_20.size());
        System.out.println("21的可抵扣个数："+action_21.size());
        List<String> diffList = getDiffrentString(action_20,action_21);
        List<String> diffList2 = getDiffrentString(action_21,action_20);


        System.out.println(diffList);
        System.out.println(diffList.size());

        System.out.println(diffList2);
        System.out.println(diffList2.size());

    }

    @Test
    public void compareUltimate_21And20() {
        //获取20版可以抵扣的item_id
        //20基础版-抵扣
        String wscBaiscWechat_20 = "combine_sku_wsc_2020_ultimate_year";
        List<PfRegulation> pfRegulationList =pfRegulationMapper.selectList(new QueryWrapper<PfRegulation>().eq("is_delete",0));
        List<Long> pfRegulationIdList = new ArrayList<>();
        for (PfRegulation pfRegulation : pfRegulationList) {
            pfRegulationIdList.add(pfRegulation.getId());
        }
        List<PfRegulationExec> pfRegulationExecsList_wscWechat_20 =pfRegulationExecMapper.selectList(new QueryWrapper<PfRegulationExec>()
                .in("regulation_id",pfRegulationIdList)
                .like("regulation_condition",wscBaiscWechat_20)
                .like("regulation_action","TWO"));

        List<String> action_20 = new ArrayList<>();
        for (PfRegulationExec pfRegulationExec : pfRegulationExecsList_wscWechat_20) {
            action_20.add(pfRegulationExec.getRegulationAction());
        }


        String wscBaiscWechat_21 = "combine_sku_wsc_2021_ultimate_year";
        List<PfRegulationExec> pfRegulationExecsList_wscWechat_21 =pfRegulationExecMapper.selectList(new QueryWrapper<PfRegulationExec>()
                .in("regulation_id",pfRegulationIdList)
                .like("regulation_condition",wscBaiscWechat_21)
                .like("regulation_action","TWO"));

        List<String> action_21 = new ArrayList<>();
        for (PfRegulationExec pfRegulationExec : pfRegulationExecsList_wscWechat_21) {
            action_21.add(pfRegulationExec.getRegulationAction());
        }

        System.out.println("20的可抵扣个数："+action_20.size());
        System.out.println("21的可抵扣个数："+action_21.size());
        List<String> diffList = getDiffrentString(action_20,action_21);
        List<String> diffList2 = getDiffrentString(action_21,action_20);


        System.out.println(diffList);
        System.out.println(diffList.size());

        System.out.println(diffList2);
        System.out.println(diffList2.size());

    }
}
