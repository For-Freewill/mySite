package com.youzan.test.basecase.yunServiceFee.apiCase;

import com.baomidou.mybatisplus.core.assist.ISqlRunner;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.ListResult;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.yunfee.FeeResourcePackageDO;
import com.youzan.commerce.test.entity.dataobject.perform.PfFeeResourcePackageEntity;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.perform.api.PfOrderRemoteService;
import com.youzan.ycm.perform.api.PfStockRemoteService;
import com.youzan.ycm.perform.dto.feeQuota.FeeQuotaInfoDTO;
import com.youzan.ycm.perform.dto.order.PfOrderDTO;
import com.youzan.ycm.perform.request.order.QueryPfOrderByTradeOrderRequest;
import com.youzan.ycm.perform.request.stock.FeeQuotaInfoPageQueryRequest;
import com.youzan.ycm.perform.response.PageResponse;
import com.youzan.ycm.perform.response.advance.CanAdvanceOrderQuotaResponse;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;

/**
 * @author wulei
 * @date 2020/12/29 12:36
 * 专用测试手机：17540783535
 */
public class YunFeeWSCLSEduSceneTest extends YunBaseTest {
    @Dubbo
    private PfStockRemoteService pfStockRemoteService;

    // 微商城-2021
    @Test
    public void A1WSCBasicTest() {
        Long kdtId = newWscKdtId();
        yunFeeScene(kdtId,wscWXItemId_2021,"10000");
    }

    @Test
    public void A2WSCProfessionalTest() {
        Long kdtId = newWscKdtId();
        yunFeeScene(kdtId,wscProfessionItemId_2021,"20000");
    }

    @Test
    public void A3WSCUltimateTest() {
        Long kdtId = newWscKdtId();
        yunFeeScene(kdtId,wscUltimateItemId_2021,"40000");
    }

    // 零售-2021
    @Test
    public void A5LSBasicTest() {
        Long kdtId = newRetailKdtId();
        yunFeeScene(kdtId,lsWXItemId_2021,"10000");
    }

    @Test
    public void A6LSProfessionalTest() {
        Long kdtId = newRetailKdtId();
        yunFeeScene(kdtId,professionItemId_2021,"20000");
    }

    @Test
    public void A9EduProfessionalTest() {
        Long kdtId = newEduKdtId();
        yunFeeScene(kdtId,edu_pro_2020,"20000");
    }

    /**
     * 订购，续费，预支，查询，退款 流程校验
     * @param kdtId
     * @param itemId
     * @param quota
     */
    public void yunFeeScene(Long kdtId, Integer itemId, String quota) {
        // 场景1：购买微商城基础版本1年，无法预支
        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdtId, "CI自动化", itemId, 1);
        Assert.assertEquals(200, result1.getCode());
        if(itemId==8271 || itemId==8274) {//LS 保护期30天，跨年
            // pf_fee_resource_package 表校验
            pfFeeResourcePackageCheck(kdtId, quota, 1, 1, 53, 2, "software_meal");
            // fc_fee_resource_package 表校验
            fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 1, 53, 1);
            // fc_fee_resource_package 表校验
            fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 1, 53, 1);

        }else {
            // fc_fee_resource_package 表校验
            fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 1, 53, 1);
            // pf_fee_resource_package 表校验
            pfFeeResourcePackageCheck(kdtId, quota, 1, 1, 53, 2, "software_meal");
            // fc_fee_resource_package 表校验
            fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 1, 53, 1);
        }
        // fc_fee_yop_protocol 表校验
        fcFeeYopProtocolCheck(kdtId, quota, 1, 1, 1, 2);
        // 无法预支
        testCanAdvanceOrderQuota(kdtId.toString(), Boolean.FALSE);

        // 场景2：续订基础班1年，可以预支
        PlainResult<OrderCreateApi> result2 = testCreateOrder(kdtId, "CI自动化", itemId, 1);
        Assert.assertEquals(200, result2.getCode());

        // fc_fee_yop_protocol 表校验
        fcFeeYopProtocolCheck(kdtId, quota, 1, 1, 1, 2);
        // 可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdtId.toString(), Boolean.TRUE);
        // 预支第二年
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdtId, canAdvanceResult.getData().getOrderId().toString(), 0);
        Assert.assertEquals(String.valueOf(advanceResult.getCode()), "200");

        // 场景3：预支后校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdtId.toString())).size() == 2L);

        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdtId.toString())).size() == 2L);

        if(itemId==8271 || itemId==8274) {//LS 保护期30天，跨年
            // pf_fee_resource_package 表校验
            pfFeeResourcePackageCheck(kdtId, quota, 1, 2, 54, 2, "software_meal");
            // fc_fee_resource_package 表校验
            fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 2, 54, 1);

        }else {
            // pf_fee_resource_package 表校验
            pfFeeResourcePackageCheck(kdtId, quota, 1, 2, 54, 2, "software_meal");
            // fc_fee_resource_package 表校验
            fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 2, 54, 1);
        }

        // fc_fee_yop_protocol 表校验
        fcFeeYopProtocolCheck(kdtId, quota, 1, 2, 1, 2);
        // 云服务费详情查询
        pageFeeQuotaOrderCheck(kdtId);
        // 场景4：逆向退款全部订单
        godCannotHelpU(kdtId);
        yunFeeRefundStateCheck(kdtId);
    }


    /**
     * 订购，续费，预支，退款 流程校验
     * @param kdtId
     * @param itemId
     * @param quota
     */
    public void yunFeeSceneTwoYears(Long kdtId, Integer itemId, String quota) {
        // 场景1：购买微商城基础版本1年，无法预支
        PlainResult<OrderCreateApi> result1 = testCreateOrder(kdtId, "CI自动化", itemId, 2);
        Assert.assertEquals(200, result1.getCode());
        // pf_fee_resource_package 表校验
        pfFeeResourcePackageCheck(kdtId, quota, 1, 1, 52, 2, "software_meal");
        // fc_fee_resource_package 表校验
        fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 1, 52, 1);
        // fc_fee_yop_protocol 表校验
        fcFeeYopProtocolCheck(kdtId, quota, 1, 1, 1, 2);

        // 可以预支
        PlainResult<CanAdvanceOrderQuotaResponse> canAdvanceResult = testCanAdvanceOrderQuota(kdtId.toString(), Boolean.TRUE);
        // 预支第二年
        PlainResult<Boolean> advanceResult = testAdvanceOrderQuota(kdtId, canAdvanceResult.getData().getOrderId().toString(), 0);
        Assert.assertEquals(String.valueOf(advanceResult.getCode()), "200");

        // 场景3：预支后校验
        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> pfFeeResourcePackageMapper.selectList(new QueryWrapper<PfFeeResourcePackageEntity>().eq("apply_ycm_id", kdtId.toString())).size() == 2L);

        with().atMost(30, TimeUnit.SECONDS).pollInterval(3, TimeUnit.SECONDS).and()
                .with().pollDelay(3, TimeUnit.SECONDS).until(
                () -> feeResourcePackageMapper.selectList(new QueryWrapper<FeeResourcePackageDO>().eq("kdt_id", kdtId.toString())).size() == 2L);

        // pf_fee_resource_package 表校验
        pfFeeResourcePackageCheck(kdtId, quota, 1, 2, 53, 2, "software_meal");
        // fc_fee_resource_package 表校验
        fcFeeResourcePackageCheck(kdtId, quota, "0", 1, 2, 53, 1);
        // fc_fee_yop_protocol 表校验
        fcFeeYopProtocolCheck(kdtId, quota, 1, 2, 1, 2);

        // 场景4：逆向退款全部订单
        godCannotHelpU(kdtId);
        yunFeeRefundStateCheck(kdtId);
    }

    /**
     * 订购云服务费
     * @param kdtId
     */
    public void pageFeeQuotaOrderCheck(Long kdtId){
        FeeQuotaInfoPageQueryRequest feeQuotaInfoPageQueryRequest = new FeeQuotaInfoPageQueryRequest();
        feeQuotaInfoPageQueryRequest.setKdtId(kdtId);
        PlainResult<PageResponse<FeeQuotaInfoDTO>> result = pfStockRemoteService.pageFeeQuotaOrder(feeQuotaInfoPageQueryRequest);
        Assert.assertEquals(result.getCode(), 200);
        Assert.assertEquals(result.getData().getItems().size()>=1, true);
    }
}