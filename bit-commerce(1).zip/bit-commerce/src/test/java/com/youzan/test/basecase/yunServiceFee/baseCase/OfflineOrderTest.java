package com.youzan.test.basecase.yunServiceFee.baseCase;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by baoyan on 2020-07-31.
 */
public class OfflineOrderTest extends YunBaseTest {

    @Test
    public void testOfflineOrder() {
        long yunKdtId7 = newWscKdtId();
        PlainResult<List<Long>> result= bizOfflineOrder(yunKdtId7, 7284, 1, 50);

        if(result.getCode()==200) {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //  查询计费额度是否成功发放
            testQueryTotalQuota(yunKdtId7, 1);
        }
        //  退款
        List<TdOrder> tdOrderDOs = tdOrderMapper.selectList(new QueryWrapper<TdOrder>().eq("buyer_id", JSON.toJSONString(yunKdtId7))
        .eq("show_state","OFFLINE_PAY"));
        List<Long> tdOrderIdList = tdOrderDOs.stream().map(TdOrder::getId).collect(Collectors.toList());
        for (long tdOrderId : tdOrderIdList) {
            refundOrderQuota(tdOrderId);
        }

        // 查看计费侧额度是否正常回收
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId7, 0);

    }

}



