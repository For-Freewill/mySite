package com.youzan.test.basecase.orderperform;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2020/8/19 6:19 下午
 */

public class ContinueOrderTest extends TnBaseTest {

    public static Long lsl = 60031017L;
    public static String ls = "60031017";
    public static String lsName = "lsCI续费使用店铺";

    public static String account = "15558185323";

    String td_no = "";

    @JSONData(value = "dataResource/basecase.orderperform/ContinueOrderRequestData.json", key = "request")
    private CreateOrderForm createOrderForm;

    /**
     * ls2021基础版-百度小程序 续费
     */
    @Test(enabled = false)
    public void createOrderTest() {

        //1.如果有未关闭订单，先关闭
        closeWaitPayOrder(lsl);
        refundOrderByKdtId(lsl);

        //2. 创建订单
        PlainResult<String> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                    @Override
                    public PlainResult<String> doExecute() {
                        return orderRemoteService.createNormalOrder(createOrderForm);
                    }

                    @Override
                    public boolean handleResult(PlainResult<String> plainResult) {
                        return plainResult.getCode() == 200;
                    }
                }, 5, 100);

        Assert.assertEquals(plainResult.getCode(), 200);

        if (plainResult.getCode() == 200) {

            //3.预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.parseLong(plainResult.getData()), (byte) 4);
            Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

            //4.余额支付
            cashierPay(preparePayApiPlainResult, account, lsl);
            try {
                sleep(3000);
            } catch (Throwable e) {
                e.getMessage();
            }

            // 取基础版的失效时间 降序排序，取第一个
            List<PfOrderStatus> orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", lsl).eq("level", "basic").eq("item_id", "atom_sku_retail_single_year").eq("group_type", "product_with_paid").orderByDesc("expire_time"));
            if (!(orderStatusListBasic.size() < 0)) {
                orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", lsl).eq("level", "basic").eq("item_id", "atom_sku_retail_single_year").eq("group_type", "product_with_paid").orderByDesc("expire_time"));
            }
            Assert.assertTrue(orderStatusListBasic.size() > 0);

            //二次创建订单，进行续费
            PlainResult<Long> resultSecond = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<Long>>() {

                        @Override
                        public PlainResult<Long> doExecute() {
                            return orderRemoteService.createOrder(createOrderForm);
                        }

                        @Override
                        public boolean handleResult(PlainResult<Long> plainResult) {
                            return plainResult.getCode() == 200;
                        }
                    }, 5, 100);

            Assert.assertEquals(resultSecond.getCode(), 200);

            PlainResult<PreparePayApi> continueResult = preparePay(resultSecond.getData(), (byte) 4);
            Assert.assertEquals(continueResult.getCode(), 200);

            cashierPay(continueResult, account, lsl);

            //查一下礼包的表和履约的表，确认数据确实生成
            List<TdOrder> tdOrderRecords = queryTdOrderByKdtIdAndState(lsl);
            Assert.assertTrue(tdOrderRecords.size() > 0);

            td_no = tdOrderRecords.get(0).getTdNo();

            List<PfOrder> pfOrderRecords =
                    pfOrderMapper.selectList(
                            new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBuyKdtId, lsl).eq(PfOrder::getBizOrderId, td_no));

            List<PfOrderStatus> pfOrderStatusListAll = new ArrayList();
            pfOrderRecords.forEach(item -> {
                Long d = item.getId();
                List<PfOrderStatus> pfOrderStatuses =
                        pfOrderStatusMapper.selectList(
                                new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, lsl).eq(PfOrderStatus::getPfOrderId, d));
                pfOrderStatusListAll.addAll(pfOrderStatuses);
            });

            try {
                sleep(3000);
            } catch (Throwable e) {
                e.getMessage();
            }

            // 取续费后的生效时间 升序排序，取第一个
            List<PfOrderStatus> orderStatusListBasicContinue = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, lsl).eq(PfOrderStatus::getLevel, "basic").eq(PfOrderStatus::getItemId, "atom_sku_retail_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByDesc(PfOrderStatus::getCreatedAt));
            if (!(orderStatusListBasicContinue.size() > 0)) {
                orderStatusListBasicContinue = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, lsl).eq(PfOrderStatus::getLevel, "basic").eq(PfOrderStatus::getItemId, "atom_sku_retail_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByDesc(PfOrderStatus::getCreatedAt));
            }
            Assert.assertTrue(orderStatusListBasicContinue.size() > 0);

            Date basicDate = orderStatusListBasic.get(0).getExpireTime();
            Date continueDate = orderStatusListBasicContinue.get(0).getEffectTime();

            //比较两个版本软件的订单创建时间   由于有试用期礼包，因此基础版失效时间和续费的生效时间中间会差一点点
            Assert.assertTrue(basicDate.compareTo(continueDate) == 0);
        }
    }
}
