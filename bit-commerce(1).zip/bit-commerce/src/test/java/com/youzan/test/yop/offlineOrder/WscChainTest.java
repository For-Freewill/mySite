package com.youzan.test.yop.offlineOrder;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.mapper.perform.PfOrderMapper;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.shopcenter.outer.entity.common.ShopActiveVoucher;
import com.youzan.shopcenter.outer.entity.request.chain.WscSubShopCreateRequest;
import com.youzan.shopcenter.outer.service.chain.WscChainCreateOuterService;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import com.youzan.test.yop.YopBaseTest;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.RefundRemoteService;
import com.youzan.yop.api.entity.OfflineOrderForm;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.enums.AppStatusState;
import com.youzan.yop.api.request.SearchOrderForRefundRequest;
import com.youzan.yop.api.response.RefundQueryOrderResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.youzan.yop.api.enums.AppStatusState.EFFECT;

/**
 * created by leifeiyun on 2019/12/20
 **/
public class WscChainTest extends YopBaseTest {

    @Http("tetherpre")
    public HttpUtil tetherpreUntil;
    @Dubbo
    WscChainCreateOuterService wscChainCreateOuterService;
    @Dubbo
    AppStatusRemoteService appStatusRemoteService;
    @Dubbo
    MarketRemoteService marketRemoteService;
    @Dubbo
    RefundRemoteService refundRemoteService;
    @Autowired(required = false)
    PfOrderMapper pfOrderMapper;

    /**
     * 按年落单
     * 1.在已有店铺的基础上进行验证
     * 2.创建微商城连锁总部，并包含1个网店
     * 3.验证总部服务期
     * 4.获取方案列表验证
     * 5.激活1个网店
     * 6.验证1个网店的的订单额度和插件
     * 7.为网店分配店铺员工
     * 8.验证员工服务期
     * 9.为网店增购店铺员工
     * 10.验证增购员工
     * 11.退款增购员工，验证个数
     * 12.退款订购员工，验证服务期和格式
     * 13.退款网店和总部
     * 14.验证服务期
     */
    @Test
    public void testCreateWscChainAndActiveForYear() {
        //订购微商城连锁总部以及网店
        String createWscChainFilePath = "src/test/resources/data/order/offlineOrderWscChain.json";
        OfflineOrderForm offlineOrderForm = JsonCovertUntil.getObjectFromjson(createWscChainFilePath, OfflineOrderForm.class);
        PlainResult<Long> longPlainResult = marketRemoteService.createOfflineOrderReform(offlineOrderForm);
//        Long payOrderId = longPlainResult.getData();
        Assert.assertEquals(longPlainResult.getCode(), 200);
        Assert.assertEquals(longPlainResult.getMessage(), "successful");
        //为总部和网店续费店铺员工
        String createStaffFilePath = "src/test/resources/data/order/offlineOrderStaff.json";
        OfflineOrderForm offlineOrderFormStaff = JsonCovertUntil.getObjectFromjson(createStaffFilePath, OfflineOrderForm.class);
        longPlainResult = marketRemoteService.createOfflineOrderReform(offlineOrderFormStaff);
        Assert.assertEquals(longPlainResult.getCode(), 200);
        Assert.assertEquals(longPlainResult.getMessage(), "successful");

        //校验总部以及总部相应的插件的服务期，包括员工
        checkAppStatus(wscChainKdtId, EFFECT, Calendar.YEAR, 1);
        //校验网店以及网店相应的插件的服务期，包括员工
        checkAppStatus(wscChainStoreKdtId, AppStatusState.EFFECT, Calendar.YEAR, 1);


        SearchOrderForRefundRequest searchOrderForRefundRequest = new SearchOrderForRefundRequest();
        searchOrderForRefundRequest.setKdtId(wscChainKdtId);
        searchOrderForRefundRequest.setOrderState((byte) 1);
        PlainResult<PageApi<RefundQueryOrderResponse>> searchwscResult = refundRemoteService.searchOrderForRefund(searchOrderForRefundRequest);


        //退总部以及网店，以及员工服务期
        for (int i = 0; i < searchwscResult.getData().getContent().size(); i++) {
            refundOrder(searchwscResult.getData().getContent().get(i).getOrderId(),
                    new Date(), 100L, 100L, "BY_MANUAL");
            //AppStatusState.EXPIRED 这个筛选数据为空
            /*checkAppStatus(wscChainKdtId, AppStatusState.ALL,Calendar.YEAR,0);
            checkAppStatus(wscChainStoreKdtId,AppStatusState.ALL,Calendar.YEAR,0);*/
        }

    }

    /**
     * 按天落单
     * /**
     * 按天落单
     * 1.在已有店铺的基础上进行验证
     * 2.创建微商城连锁总部，并包含两个网店
     * 3.验证总部服务期
     * 4.获取方案列表验证
     * 5.激活2个网店
     * 6.验证2个网店的的订单额度和插件
     * 7.为两个网店分配店铺员工
     * 8.验证员工服务期
     * 9.为两个网店增购店铺员工
     * 10.验证增购员工
     * 11.退款增购员工，验证个数
     * 12.退款订购员工，验证服务期和格式
     * 13.退款网店和总部
     * 14.验证服务期
     */

    @Test
    public void testCreateWscChainAndActiveForDay() {

    }

    /**
     * 这个用例不跑集成，测试时候，为了批量创建网店并激活写的
     */
    @Test(enabled = false)
    public void batchActiveWscStore() throws ParseException {
        Long kdtId = 54419433L;
        String wscSubShopCreateRequestDataFilePath = "src/test/resources/data/shop/createWscStore.json";
        PfOrder pfOrder = new PfOrder();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        pfOrder.setRefundTime(simpleDateFormat.parse("0000-00-00 00:00:01"));
        pfOrder.setPerformTime(simpleDateFormat.parse("0000-00-00 00:00:01"));
       /* int count =  pfOrderMapper.update(pfOrder,new QueryWrapper<PfOrder>()
                .eq("buy_kdt_id",kdtId)
        .eq("perform_state","wait_perform")
                .eq("app_id","combine_spu_wsc_chain_bu_basic"));*/

        //Error attempting to get column 'perform_time' from result set.
        // Cause: java.sql.SQLException: Value '0000-00-00 00:00:00' can not be represented as java.sql.Timestamp
        List<PfOrder> pfOrderList = pfOrderMapper.selectList(new QueryWrapper<PfOrder>()
                .eq("buy_kdt_id", kdtId)
                .eq("app_id", "combine_spu_wsc_chain_bu_basic")
                .eq("perform_state", "wait_perform")
        );
        int length = pfOrderList.size();
        for (int i = 0; i < length; i++) {
            WscSubShopCreateRequest wscSubShopCreateRequest = JsonCovertUntil.getObjectFromjson(wscSubShopCreateRequestDataFilePath, WscSubShopCreateRequest.class);

            ShopActiveVoucher shopActiveVoucher = new ShopActiveVoucher();
            List<Long> orderSchemeId = new ArrayList<>();
            orderSchemeId.add(pfOrderList.get(i).getId());
            shopActiveVoucher.setOrderSchemeIds(orderSchemeId);
            wscSubShopCreateRequest.setActiveVoucher(shopActiveVoucher);
            wscSubShopCreateRequest.setShopName("baseWscChain-3-网店-" + i);
            wscSubShopCreateRequest.setHqKdtId(Long.valueOf(kdtId));
            wscChainCreateOuterService.createSubShop(wscSubShopCreateRequest);
        }
    }

    /**
     * 这个用例不跑集成，测试时候，为了批量创建网店并激活写的
     */
    @Test(enabled = false)
    public void batchActiveWscStorepre() throws ParseException {
        Long kdtId = 54419433L;
        String wscSubShopCreateRequestDataFilePath = "src/test/resources/data/shop/createWscStore.json";
        PfOrder pfOrder = new PfOrder();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


//        int length = pfOrderList.size();
       /* for(int i=0;i<length;i++){
            WscSubShopCreateRequest wscSubShopCreateRequest = JsonCovertUntil.getObjectFromjson(wscSubShopCreateRequestDataFilePath,WscSubShopCreateRequest.class);

            ShopActiveVoucher shopActiveVoucher = new ShopActiveVoucher();
            List<Long> orderSchemeId = new ArrayList<>();
            orderSchemeId.add(pfOrderList.get(i).getId());
            shopActiveVoucher.setOrderSchemeIds(orderSchemeId);
            wscSubShopCreateRequest.setActiveVoucher(shopActiveVoucher);
            wscSubShopCreateRequest.setShopName("baseWscChain-3-网店-"+i);
            wscSubShopCreateRequest.setHqKdtId(Long.valueOf(kdtId));
            wscChainCreateOuterService.createSubShop(wscSubShopCreateRequest);
        }*/

        Map paramMap = JsonCovertUntil.getObjectFromjson(wscSubShopCreateRequestDataFilePath, Map.class);
      /* paramMap.put("setShopName",);
       paramMap.put("setHqKdtId")*/
        Map headerMap = new HashMap<>();
        headerMap.put("content-length", "300");
        headerMap.put("x-request-protocol", "dubbo");
        headerMap.put("content-type", "application/x-www-form-urlencoded");


        String s = tetherpreUntil.doPostReturnResponse("/soa/com.youzan.shopcenter.outer.service.chain.WscChainCreateOuterService.createSubShop",
                paramMap, headerMap);

//        paramMap.put("")
    }
}

