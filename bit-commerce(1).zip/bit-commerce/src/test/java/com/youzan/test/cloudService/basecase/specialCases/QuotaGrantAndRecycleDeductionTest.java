package com.youzan.test.cloudService.basecase.specialCases;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * Created by wulei on 2020-07-31.
 */
public class QuotaGrantAndRecycleDeductionTest extends YunBaseTest {
    @Test
    public void testQuatoGrantAndRecycleDeduction() {
        long yunKdtId4 = newWscKdtId();

        // 买基础版
        PlainResult<OrderCreateApi> result1 = testCreateOrder(yunKdtId4, yunKdtName4, wscWXItemId_2021, 1);

        //  查询计费额度是否成功发放
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId4, 10000);

        // 买专业版
        PlainResult<OrderCreateApi> result2 = testCreateOrder(yunKdtId4,yunKdtName4,wscProfessionItemId_2021, 1);

        // 查看计费侧额度基础版是否正常回收，专业版是否正常发放
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId4, 20000);

        //  退款
        Long payOrderIdHigh = result2.getData().getPayOrderId();
        refundOrderNew(payOrderIdHigh, new Date(), 0L, 0L, "BY_MANUAL");

        //   查看计费侧额度是否正常回收
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        testQueryTotalQuota(yunKdtId4, 0);
    }
}
