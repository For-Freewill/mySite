package com.youzan.test.yop.allPluginBuy;

import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yago.api.OpenClient;
import com.youzan.test.yago.api.impl.OpenClientImpl;
import com.youzan.test.yop.YopBaseTest;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.entity.PageApi;
import com.youzan.yop.api.entity.order.OrderListApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderDetailForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import com.youzan.yop.api.form.order.SearchOrderListForm;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * created by leifeiyun on 2019/11/6
 **/
public class AllPluginBuy_Test extends YopBaseTest {
    public OpenClient openClient = new OpenClientImpl();
    @Dubbo
    private OrderRemoteService orderRemoteService;

    @Test(enabled = false)
    public void buyAllPlugin() {
        openClient.switchEnv("www");
        Long kdtId = 53533122L;
        String createPluginRequestDataFilePath = "src/test/resources/data/plugin/pluginCreateData.json";
        List<Integer> itemIds = Arrays.asList(2, 37, 69, 4, 778, 39, 639, 27, 41, 29, 38,
                72, 7024, 7085, 7086, 7087, 7088, 7089, 7090, 35, 40, 779, 42, 44, 46, 47, 57, 71, 67, 73,
                590, 591, 592, 593, 594, 595, 596, 597, 613, 614, 615, 616, 617, 618, 635, 636, 637, 7012,
                748, 752, 756, 757, 758, 759, 769, 7014, 780, 7048, 7006, 7007, 7008, 7009, 7010, 7011,
                781, 7031, 7032, 7039, 7028, 7185, 7035, 7037, 7077, 7081, 7166, 7167, 7091, 7092, 584,
                587, 52, 53, 699, 700, 7181, 7182, 7190, 49, 696, 7197, 7198, 7199, 7200, 7204, 7205, 7206,
                7207, 7208, 7209, 7210, 7211, 7212, 7213, 7214, 7215, 7216, 7173, 7174, 7175, 7176, 7177, 7217,
                7218, 7224, 7226, 7232, 7233, 7234, 7235, 7236, 7237, 7239, 7240, 7241, 7243, 7244, 7245, 7246,
                7247, 7248, 7249, 7250, 7179, 7183, 7253, 7254, 7255, 7256, 7257, 7258, 7259, 7261, 7263, 7264,
                7265, 7266, 7267, 7268, 7269, 7270, 7262, 7260, 7251, 7252, 7271, 7272, 7273, 7274, 7275, 7276,
                7281, 7093, 7094, 7283, 7284, 7079, 7291, 7294, 7295, 7296, 7298, 8003, 8004, 7279, 7280, 7277,
                8002, 7278, 8001, 7180, 8005, 8006, 8007, 7221, 8011, 8014, 8015, 8016, 8017, 8018, 8020, 8021,
                8022, 8118, 8119, 8120);

        for (Integer i : itemIds) {
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            OrderItemForm orderItemForm = new OrderItemForm();


            CreateOrderForm createOrderForm = JsonCovertUntil.getObjectFromjson(createPluginRequestDataFilePath, CreateOrderForm.class);

            orderItemForm = createOrderForm.getItems().get(0);
            orderItemForm.setItemId(i);
            orderItemForms.add(orderItemForm);

            createOrderForm.setItems(orderItemForms);


            createOrderForm.setKdtId(kdtId);
            createOrderForm.setUserId(userId);
            createOrderForm.setKdtName(createOrderForm.getKdtName());
            PlainResult<Long> createOrderResult = orderRemoteService.createOrder(createOrderForm);
            if (createOrderResult.getCode() == 200) {
                PlainResult<PreparePayApi> plainResult = preparePay(createOrderResult.getData(), (byte) 0);
                cashierPay(plainResult, account, kdtId);
                System.out.println("可订购itemId：" + i);

            } else if (createOrderResult.getCode() == 130601) {
                //关单
                SearchOrderListForm searchOrderListForm = new SearchOrderListForm();
                searchOrderListForm.setPageSize(20);
                searchOrderListForm.setPageNo(1);
                searchOrderListForm.setUserId(userId);
                searchOrderListForm.setKdtId(kdtId);
                searchOrderListForm.setState((byte) 0);
                PlainResult<PageApi<OrderListApi>> pageApiPlainResult = orderRemoteService.listOrder(searchOrderListForm);
                for (int n = 0; n < pageApiPlainResult.getData().getContent().size(); n++) {
                    OrderDetailForm orderDetailForm = new OrderDetailForm();
                    orderDetailForm.setUserId(userId);
                    orderDetailForm.setId(pageApiPlainResult.getData().getContent().get(n).getId());
                    orderDetailForm.setKdtId(kdtId);
                    orderRemoteService.closeOrder(orderDetailForm);

                }


                createOrderResult = orderRemoteService.createOrder(createOrderForm);


                /*PlainResult<PreparePayApi> plainResult = preparePay(createOrderResult.getData(), (byte) 0);
                cashierPay(plainResult,createOrderResult.getData().toString(),kdtId);*/
                System.out.println("可订购itemId：" + i);

            } else {
                System.out.println("不可订购itemId：" + i + "：失败原因：" + createOrderResult.getMessage());

            }


        }

    }
}
