package com.youzan.test.basecase.orderperform;

import com.alibaba.fastjson.JSON;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.comparejson.Compare;
import com.youzan.commerce.test.comparejson.CompareResult;
import com.youzan.commerce.test.dataprepare.driver.SimpleDriverService;
import com.youzan.commerce.test.dataprepare.entity.entity.DataSourceType;
import com.youzan.commerce.test.dataprepare.load.DataSource;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.apache.commons.collections.MapUtils;
import org.junit.Rule;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author tianning
 * @date 2020/8/27 10:19 上午
 * 2个异常场景
 */
public class CreaterOrderExceptionTest extends TnBaseTest {

    //该店铺服务期超过三年
    public static Long EXCEPTIONKDTID = 57112689L;
    public static String EXCEPTIONKDT = "57112689";

    public static Long LOWEXCEPTIONKDTID = 56409533L;
    public static String LOWEXCEPTIONKDT = "56409533";

    @Rule
    public SimpleDriverService driverService = new SimpleDriverService();

    public Compare compare = new Compare();

    /**
     * 专业版的情况下购买微商城（2020）基础版-微信小程序
     * check： 产品服务订购最长不能超过3年
     */
    @Test
    @DataSource(type = DataSourceType.JSON, files = {"basecase.orderperform/Create3YearOrderRequestData.json"})
    public void create3YearOrderTest() {
        rechargeShopBalance(EXCEPTIONKDT, 99999999);

        CreateOrderForm updateCreateOrderForm = (CreateOrderForm) driverService.param.get("com.youzan.yop.api.form.order.CreateOrderForm");

        String UpdateCreateOrderExpectResult = MapUtils.getString(driverService.param, "result");

        closeWaitPayOrder(EXCEPTIONKDTID);

        PlainResult<String> updateCreateOrderResult = orderRemoteService.createNormalOrder(updateCreateOrderForm);

        //是否有字段缺失
        CompareResult missingResult = compare.compareJSONStructure(JSON.toJSONString(updateCreateOrderResult), UpdateCreateOrderExpectResult);
        Assert.assertFalse(missingResult.getFieldMissing().size() > 0);

        //是否有字段比对失败
        CompareResult failureResult = compare.compareJSON(JSON.toJSONString(updateCreateOrderResult), UpdateCreateOrderExpectResult);
        Assert.assertFalse(failureResult.getFieldFailures().size() > 0);
        closeWaitPayOrder(EXCEPTIONKDTID);
    }

    /**
     * 专业版的情况下购买微商城（2020）基础版-微信小程序
     * check： 高版本无法购买低版本
     */
    @Test
    @DataSource(type = DataSourceType.JSON, files = {"basecase.orderperform/LowerVersionOrderRequestData.json"})
    public void createLowerOrderTest() {
        rechargeShopBalance(LOWEXCEPTIONKDT, 99999999);

        CreateOrderForm updateCreateOrderForm = (CreateOrderForm) driverService.param.get("com.youzan.yop.api.form.order.CreateOrderForm");

        String UpdateCreateOrderExpectResult = MapUtils.getString(driverService.param, "result");

        closeWaitPayOrder(LOWEXCEPTIONKDTID);

        PlainResult<String> updateCreateOrderResult = orderRemoteService.createNormalOrder(updateCreateOrderForm);

        Assert.assertEquals(updateCreateOrderResult.getMessage(),"你现在使用的有赞微商城为高版本，无法购买低版本");
        Assert.assertEquals(updateCreateOrderResult.getCode(),130033);

        closeWaitPayOrder(LOWEXCEPTIONKDTID);
    }
}