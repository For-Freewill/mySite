package com.youzan.test.onlineTrade.basecase.retail;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderDetail;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2020/8/27 2:19 下午
 */
public class FirstOrderRetailTest extends TnBaseTest {

    @JSONData(value = "dataResource/basecase.retail/FirstOrderRequestData.json", key = "createOrderForm")
    private CreateOrderForm createOrderForm;

    public static String accountLs = "15558185323";

  /*  public static Long RETAILKDTID = 60021230L;
    public static String RETAILKDT = "60021230";*/
    public static String RETAILKDTNAME = "零售CI店铺";

    /**
     * 低版本升级：零售单店服务期生效顺序：专业版>基础版
     * 同城基础版2021-微信小程序	  1年服务期
     * 满减活动1
     */
    @Test(enabled = false)
    public void createOrderTest() {
        long RETAILKDTID = newRetailKdtId();

        rechargeShopBalance(JSONObject.toJSONString(RETAILKDTID), 99999999);

     /*   closeWaitPayOrder(RETAILKDTID);

        refundOrderByKdtId(RETAILKDTID);*/
         createOrderForm.setKdtId(RETAILKDTID);

        PlainResult<Long> createOrderResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<Long>>() {

                    @Override
                    public PlainResult<Long> doExecute() {
                        return orderRemoteService.createOrder(createOrderForm);
                    }

                    @Override
                    public boolean handleResult(PlainResult<Long> plainResult) {

                        return plainResult.getCode() == 200;
                    }
                }, 5, 100);
        Assert.assertEquals(createOrderResult.getCode(), 200);

        if (createOrderResult.getCode() == 200) {

            //4.预支付
            PlainResult<PreparePayApi> preparePayUpdateResult = preparePay(createOrderResult.getData(), (byte) 4);

            //5.余额支付
            cashierPay(preparePayUpdateResult, accountLs, RETAILKDTID);

            try {
                sleep(4000);
            } catch (Throwable e) {
                e.printStackTrace();
            }

            //查一下第一次订购的礼包的表和履约的表，确认数据确实生成
            List<TdOrder> tdOrderRecords = queryTdOrderByKdtIdAndState(RETAILKDTID);
            if (!(tdOrderRecords.size() > 0)) {
                tdOrderRecords = queryTdOrderByKdtIdAndState(RETAILKDTID);
            }
            Assert.assertTrue(tdOrderRecords.size() > 0);
            String td_no = tdOrderRecords.get(0).getTdNo();

            if (td_no != null) {
                List<PfOrder> pfOrderRecords =
                        pfOrderMapper.selectList(
                                new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBizOrderId, td_no));
                List<PfOrderDetail> pfOrderDetailsListAll = new ArrayList();
                pfOrderRecords.forEach(item -> {
                    Long id = item.getId();
                    List<PfOrderDetail> pfOrderDetails =
                            pfOrderDetailMapper.selectList(
                                    new QueryWrapper<PfOrderDetail>().lambda().eq(PfOrderDetail::getPfOrderId, id));
                    pfOrderDetailsListAll.addAll(pfOrderDetails);
                });

                List<PfOrderStatus> pfOrderStatusListAll = new ArrayList();
                pfOrderRecords.forEach(itemStatus -> {
                    Long d = itemStatus.getId();
                    List<PfOrderStatus> pfOrderStatuses =
                            pfOrderStatusMapper.selectList(
                                    new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getPfOrderId, d));
                    pfOrderStatusListAll.addAll(pfOrderStatuses);
                });
            }

            List<PfOrderStatus> orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, RETAILKDTID).eq(PfOrderStatus::getLevel, "basic").eq(PfOrderStatus::getItemId, "atom_sku_retail_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByAsc(PfOrderStatus::getCreatedAt));
            if (!(orderStatusListBasic.size() > 0)) {
                orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, RETAILKDTID).eq(PfOrderStatus::getLevel, "basic").eq(PfOrderStatus::getItemId, "atom_sku_retail_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByDesc(PfOrderStatus::getExpireTime));
            }
            try {
                sleep(3000);
            } catch (Throwable e) {
                e.printStackTrace();
            }
            Assert.assertTrue(orderStatusListBasic.size() > 0);

            //二次创建订单，进行升级
            CreateOrderForm continueOrderForm = new CreateOrderForm();
            List<OrderItemForm> orderItemForms = new ArrayList<>();
            OrderItemForm orderItemForm = new OrderItemForm();
            orderItemForm.setQuantity(1);
            orderItemForm.setBuyType((byte) 1);
            orderItemForm.setItemId(ItemInfo.LS_ZY_1280000_2021.getItemId());
            orderItemForms.add(orderItemForm);

            continueOrderForm.setItems(orderItemForms);

            continueOrderForm.setKdtId(RETAILKDTID);
            continueOrderForm.setUserId(8107334721L);
            continueOrderForm.setKdtName(RETAILKDTNAME);

            PlainResult<Long> result2 = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<Long>>() {

                        @Override
                        public PlainResult<Long> doExecute() {
                            return orderRemoteService.createOrder(continueOrderForm);
                        }

                        @Override
                        public boolean handleResult(PlainResult<Long> plainResult) {
                            return plainResult.getCode() == 200;
                        }
                    }, 5, 100);

            Assert.assertEquals(result2.getCode(), 200);

            if (result2.getCode() == 200) {
                PlainResult<PreparePayApi> updateResult = preparePay(result2.getData(), (byte) 4);
                Assert.assertEquals(updateResult.getCode(), 200);

                cashierPay(updateResult, accountLs, RETAILKDTID);

                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.printStackTrace();
                }

                // 取专业版软件的生效时间 升序排序，取第一个
                List<PfOrderStatus> orderStatusListProfession = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, RETAILKDTID).eq(PfOrderStatus::getLevel, "profession").eq(PfOrderStatus::getItemId, "atom_sku_retail_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByAsc(PfOrderStatus::getEffectTime));
                if (!(orderStatusListProfession.size() > 0)) {
                    orderStatusListProfession = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, RETAILKDTID).eq(PfOrderStatus::getLevel, "profession").eq(PfOrderStatus::getItemId, "atom_sku_retail_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByAsc(PfOrderStatus::getEffectTime));
                }
                Assert.assertTrue(orderStatusListBasic.size() > 0);

                Date professionDate = orderStatusListProfession.get(0).getCreatedAt();
                Date basicDate = orderStatusListBasic.get(0).getCreatedAt();

                //比较两个版本软件的订单创建时间
                Assert.assertTrue(professionDate.compareTo(basicDate) > 0);
            }
        }
    }
}
