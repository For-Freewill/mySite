package com.youzan.test.offlineTrade.apicase.bizConsole;

import com.alibaba.fastjson.JSONObject;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by baoyan on 6/4/21.
 */
public class OfflineOrderAllAppListTest extends YunBaseTest {
    @Http("bizConsole")
    HttpUtil httpUtil;

    @Test
    public void OfflineOrderAllAppListNormalTest(){
        String result = httpUtil.doGetReturnResponse("/basic/offlineOrderAllAppList?kdtId=60005458&waitPayOrder=true");
        Map resultAfterParse = getMap(result);
        Assert.assertEquals(resultAfterParse.get("msg"),"操作成功");
        Assert.assertEquals(resultAfterParse.get("code"),0);
        Assert.assertTrue(resultAfterParse.get("data")!= null);
    }


    public  Map<String, Object> getMap(String json) {
        JSONObject jsonObject = JSONObject.parseObject(json);
        Map<String, Object> valueMap = new HashMap<String, Object>();
        valueMap.putAll(jsonObject);
        return valueMap;
    }
}
