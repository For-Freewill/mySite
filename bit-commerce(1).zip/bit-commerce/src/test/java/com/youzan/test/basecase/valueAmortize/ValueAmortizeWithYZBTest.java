package com.youzan.test.basecase.valueAmortize;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplate;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplateGoods;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateMapper;
import com.youzan.commerce.test.mapper.perform.PfAssetMapper;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.test.quickstart.compare.config.CollectionCompareConfig;
import com.youzan.test.quickstart.compare.service.CompareServiceImp;
import com.youzan.ycm.gift.dto.YcmIdDTO;
import com.youzan.ycm.gift.request.CreateMakeUpAssetRequest;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.CreateMakeUpGiftAssetResponse;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import com.youzan.yop.api.form.order.CreateOrderForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author tianning
 * @date 2020/9/29 6:19 下午
 * 现金+有赞币订购基础版，发一个补偿礼包，验证摊销
 */
public class ValueAmortizeWithYZBTest extends TnBaseTest {
    public static Long WSCKDTIDCIWRITE = 58112140L;
    public static String WSCKDTCIWRITE = "58112140";
    public static String WSCKDTCIWRITENAME = "WSCCI6";

    @Autowired(required = false)
    public CompareServiceImp compareServiceImp;
    @Autowired(required = false)
    public PfAssetMapper pfAssetMapper;
    @Autowired(required = false)
    public GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gAssetGoodsMapper;
    @Autowired(required = false)
    public GfTemplateGoodsMapper gfTemplateGoodsMapper;

    Logger logger = LoggerFactory.getLogger(ValueAmortizeWithYZBTest.class);

    //1、数据准备
    @JSONData(value = "dataResource/basecase.createOrder/ValueAmorizetizeWithYZBRequestData.json", key = "request")
    private CreateOrderForm createOrderForm;
    @JSONData(value = "dataResource/basecase.createOrder/CreateCompensateRequestData.json", key = "request")
    private SaveGiftTemplateRequest saveGiftTemplateRequest;
    @JSONData(value = "dataResource/basecase.createOrder/ValueAmorizetizeWithYZBRequestData.json", key = "expectResult")
    private PlainResult<Long> createOrderFormExpectResult;
    @JSONData(value = "dataResource/basecase.createOrder/CreateCompensateRequestData.json", key = "giftExpectResult")
    private PlainResult<SaveGiftTemplateResponse> saveGiftTemplateExpectResult;
    @JSONData(value = "dataResource/basecase.createOrder/CreateCompensateRequestData.json", key = "sendGiftExpectResult")
    private PlainResult<CreateMakeUpGiftAssetResponse> makeUpGiftAssetExpectResult;

    @BeforeMethod
    public void beforeMethod() {
        logger.info("before method 清理数据数据：" + WSCKDTIDCIWRITE);
        clearCache(WSCKDTCIWRITE);
    }

    @Test
    public void OrderValueAmortizeWithYZBTest() {
        Long template_id = null;

        try {
            //1.1、前置准备
            //1.1.1、店铺充值
            rechargeShopBalance(WSCKDTCIWRITE, 99999999);

            //1.1.2、待付款订单关闭
            closeWaitPayOrder(WSCKDTIDCIWRITE);

            //1.1.3、退服务期，暂时性的取代数据清理
            refundOrderByKdtId(WSCKDTIDCIWRITE);

            //1.1.4、创建订单，为了后面发放礼包使用
            PlainResult<String> createOrderFormResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                    new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                        @Override
                        public PlainResult<String> doExecute() {
                            return orderRemoteService.createNormalOrder(createOrderForm);
                        }

                        @Override
                        public boolean handleResult(PlainResult<String> plainResult) {
                            return plainResult.getCode() == 200;
                        }
                    }, 5, 100);

            //1.1.4.1、粗暴校验接口返回状态码
            Assert.assertEquals(createOrderFormResult.getCode(), 200);

            //1.1.4..2、如果涉及排序，那么用CollectionCompareConfig创建对象进行排序和字段过滤
            CollectionCompareConfig collectionCompareConfig = new CollectionCompareConfig();

            //对比前排序 -- 这里可能存在写不对路径
            collectionCompareConfig.setJsonArrayPath("$.data.giftTemplateDTO.giftTemplateGoodsDTOList");
            collectionCompareConfig.setSortKey("spuId");

            //1.1.4..3、如果要过滤多个字段，用CompareConfig处理
            List<String> list = new ArrayList();
            list.add("/data/giftTemplateDTO/templateId");
            list.add("/data/giftTemplateDTO/templateIdStr");
            collectionCompareConfig.getIgnoredPaths().addAll(list);

            //1.1.4..3（1）、如果只过滤一个字段
            //collectionCompareConfig.getIgnoredPaths().add("/data/giftTemplateDTO/templateId");

            //1.2、创建一个补偿礼包
            //这里可以通过compareServiceImp.invoke(()）可以做基础环境和当前某一SC环境的双重比对；不过该功能要自己评估是否有这个必要
            PlainResult<SaveGiftTemplateResponse> saveGiftTemplateResult = /*compareServiceImp.invoke(()->*/giftTemplateRemoteService.saveCommonGiftTemplate(saveGiftTemplateRequest);

            //1.2.1、礼包结果校验
            compareServiceImp.compare(saveGiftTemplateResult, saveGiftTemplateExpectResult, collectionCompareConfig);

            //清理数据使用
            template_id = saveGiftTemplateResult.getData().getGiftTemplateDTO().getTemplateId();

            //1.3、发放补偿礼包
            CreateMakeUpAssetRequest createMakeUpAssetRequest = new CreateMakeUpAssetRequest();
            createMakeUpAssetRequest.setDays(365);

            List<Long> giftTemplateIds = new ArrayList<>();
            giftTemplateIds.add(template_id.longValue());

            createMakeUpAssetRequest.setGiftTemplateIds(giftTemplateIds);

            List<String> giftTemplateIdsStr = new ArrayList<>();
            giftTemplateIdsStr.add(saveGiftTemplateResult.getData().getGiftTemplateDTO().getTemplateIdStr());
            createMakeUpAssetRequest.setGiftTemplateIdsStr(giftTemplateIdsStr);

            List<YcmIdDTO> ycmIds = new ArrayList<>();
            YcmIdDTO ycmIdDTO = new YcmIdDTO();
            ycmIdDTO.setYcmId(WSCKDTCIWRITE);
            ycmIdDTO.setYcmIdType(WSCKDTCIWRITENAME);
            ycmIds.add(ycmIdDTO);
            createMakeUpAssetRequest.setYcmIds(ycmIds);
            createMakeUpAssetRequest.setOperator("tianning");
            createMakeUpAssetRequest.setReason("发放补偿礼包");
            createMakeUpAssetRequest.setReceiveGiftType("By_HAND");

            PlainResult<CreateMakeUpGiftAssetResponse> makeUpGiftAssetResult = giftAssetRemoteService.createMakeUpGiftAsset(createMakeUpAssetRequest);
            Assert.assertEquals(makeUpGiftAssetResult.getCode(), 200);
            Assert.assertTrue(makeUpGiftAssetResult.getData().getGiftAssetIds().size() > 0);

            if (createOrderFormResult.getCode() == 200) {
                //1.3.1、开始验证摊销金额  预期补偿礼包不摊销金额
                Long orderId = Long.valueOf(createOrderFormResult.getData());
                List<TdOrder> tdOrderRecords =
                        tdOrderMapper.selectList(
                                new QueryWrapper<TdOrder>().lambda().eq(TdOrder::getId, orderId).orderByDesc(TdOrder::getCreatedAt));

                Assert.assertTrue(tdOrderRecords.get(0).getOrigPrice() == tdOrderRecords.get(0).getCurrencyAmt() + tdOrderRecords.get(0).getYzbAmt() + tdOrderRecords.get(0).getPromotionAmt());
            }
        } finally {
            //1.4、数据清理
            gfTemplateMapper.delete(new UpdateWrapper<GiftTemplate>().eq("id", template_id));
            gfTemplateGoodsMapper.delete(new UpdateWrapper<GiftTemplateGoods>().eq("template_id", template_id));
        }
    }
}
