package com.youzan.test.onlineTrade.basecase.yzyunOrder;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.trade.TdOrderMapper;
import com.youzan.test.basecase.SimpleToolBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.open.api.trade.YcmOrderCloseService;
import com.youzan.ycm.open.api.trade.YcmOrderCreateService;
import com.youzan.ycm.open.dto.common.YcmIdDTO;
import com.youzan.ycm.open.request.trade.CloseOrderRequest;
import com.youzan.ycm.open.request.trade.CreateOrderRequest;
import com.youzan.ycm.open.response.trade.CloseOrderResponse;
import com.youzan.ycm.open.response.trade.CreateOrderResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author baoyan
 * @date 2021/6/2
 **/
public class CreateOrderTest extends SimpleToolBaseTest {

    @Dubbo
    YcmOrderCreateService ycmOrderCreateService;
    @Dubbo
    YcmOrderCloseService ycmOrderCloseService;
    @Resource
    TdOrderMapper tdOrderMapper;

    @JSONData("dataResource/basecase.yzyunOrder/createOrder.json")
    CreateOrderRequest createOrderRequest;

    /**
     * 只验证有赞云无店铺id场景，创建订单和关闭订单，不验证履约流程，履约是商业化通用流程，
     * 在商业化的履约流程里面已经覆盖，在这里就不加重负担了
     *
     * 有赞云秀站订购，无kdtId的场景
     */
    @Test
    public void testCreateOrderForXiuzhanWithKdtId(){

        /**
         * 下单的时候这个接口会返回当前代付款的订单，有赞云那边会去做关单的动作，
         * 由于上一笔订单创建超时了导致有赞云本地数据回滚，所以第二次创建订单有赞云就查不到本地数据了
         *
         * 所以为了保证用例的稳定性，商业化先检查是否有待付款订单，有就关闭
         */

        String buyerId=createOrderRequest.getBuyerYcmID().getId();
        List<TdOrder> tdOrderList = tdOrderMapper.selectList(new QueryWrapper<TdOrder>().eq("buyer_id",buyerId)
        .eq("state","CREATED"));
        for(TdOrder tdOrder : tdOrderList){
            closeOrderWithKdtId(createOrderRequest.getBuyerYcmID(), String.valueOf(tdOrder.getId()),tdOrder.getChannel());
        }

        PlainResult<CreateOrderResponse> orderCreateResult =  ycmOrderCreateService.createOrder(createOrderRequest);
        Assert.assertEquals(orderCreateResult.getCode(),200);
        Assert.assertEquals(orderCreateResult.getMessage(),"successful");
        //验证生成待付款订单即可，其他流程不做验证
        Assert.assertNotNull(orderCreateResult.getData().getOrderId());

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String waitPayTradeOrderId = orderCreateResult.getData().getOrderId();
        CloseOrderRequest closeOrderRequest = new CloseOrderRequest();
        closeOrderRequest.setBuyerYcmID(createOrderRequest.getBuyerYcmID());
        closeOrderRequest.setOrderId(waitPayTradeOrderId);
        closeOrderRequest.setChannel(createOrderRequest.getChannel());
        PlainResult<CloseOrderResponse> closeOrderResult = ycmOrderCloseService.closeOrder(closeOrderRequest);
        Assert.assertEquals(closeOrderResult.getCode(),200);
        Assert.assertEquals(closeOrderResult.getMessage(),"successful");
        Assert.assertTrue(closeOrderResult.getData().getCloseSuccess());
        Assert.assertEquals(waitPayTradeOrderId,closeOrderResult.getData().getOrderId());
    }



    public void closeOrderWithKdtId(YcmIdDTO ycmIdDTO,String orderId,String channel){

        CloseOrderRequest closeOrderRequest = new CloseOrderRequest();
        closeOrderRequest.setBuyerYcmID(ycmIdDTO);
        closeOrderRequest.setOrderId(orderId);
        closeOrderRequest.setChannel(channel);
        PlainResult<CloseOrderResponse> closeOrderResult = ycmOrderCloseService.closeOrder(closeOrderRequest);
        Assert.assertEquals(closeOrderResult.getCode(),200);
        Assert.assertEquals(closeOrderResult.getMessage(),"successful");
        Assert.assertTrue(closeOrderResult.getData().getCloseSuccess());
    }


}
