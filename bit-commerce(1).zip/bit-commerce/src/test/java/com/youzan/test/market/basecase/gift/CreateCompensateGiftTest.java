package com.youzan.test.market.basecase.gift;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.mapper.market.gift.GfAssetGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfAssetMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateGoodsMapper;
import com.youzan.commerce.test.mapper.market.gift.GfTemplateMapper;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.gift.api.GiftAssetRemoteService;
import com.youzan.ycm.gift.dto.YcmIdDTO;
import com.youzan.ycm.gift.request.CreateMakeUpAssetRequest;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.CreateMakeUpGiftAssetResponse;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author tianning
 * @date 2020/8/9 8:19 下午
 */
public class CreateCompensateGiftTest extends TnBaseTest {

    @Dubbo
    private GiftAssetRemoteService giftAssetRemoteService;

    @Autowired(required = false)
    public GfTemplateGoodsMapper gfTemplateGoodsMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gAssetGoodsMapper;

    @JSONData(value = "dataResource/basecase.gift/CreateCompensateGiftRequestData.json", key = "createMakeUpGiftTemplateRequest")
    private SaveGiftTemplateRequest createMakeUpGiftTemplateRequest;

    /**
     * 创建补偿礼包  发放补偿礼包   领取补偿礼包   回收补偿礼包
     */
    @Test
    public void createCompensateGiftTest() {
        try {
            //1.创建一个补偿礼包模板
            PlainResult<SaveGiftTemplateResponse> createMakeUpTempleteResult = createMakeUpTemplete(createMakeUpGiftTemplateRequest);
            Assert.assertEquals(createMakeUpTempleteResult.getCode(), 200);
            Assert.assertEquals(createMakeUpTempleteResult.getData().getGiftTemplateDTO().getType(), "MAKE_UP_GIFT");

            //2、发放补偿礼包
            CreateMakeUpAssetRequest createMakeUpAssetRequest = new CreateMakeUpAssetRequest();
            createMakeUpAssetRequest.setDays(120);

            List<Long> giftTemplateIds = new ArrayList<>();
            Long giftTemplateId = createMakeUpTempleteResult.getData().getGiftTemplateDTO().getTemplateId();
            giftTemplateIds.add(giftTemplateId);
            createMakeUpAssetRequest.setGiftTemplateIds(giftTemplateIds);

            List<String> giftTemplateIdsStr = new ArrayList<>();
            giftTemplateIdsStr.add(giftTemplateId.toString());
            createMakeUpAssetRequest.setGiftTemplateIdsStr(giftTemplateIdsStr);

            createMakeUpAssetRequest.setOperator("tianning");
            createMakeUpAssetRequest.setReason("");
            createMakeUpAssetRequest.setReceiveGiftType("Auto");

            List<YcmIdDTO> ycmIds = new ArrayList<>();
            YcmIdDTO ycmIdDTO = new YcmIdDTO();
            ycmIdDTO.setYcmId("58711819");
            ycmIdDTO.setYcmIdType("KDT_ID");
            ycmIds.add(ycmIdDTO);
            createMakeUpAssetRequest.setYcmIds(ycmIds);

            PlainResult<CreateMakeUpGiftAssetResponse> createMakeUpGiftAssetResult = giftAssetRemoteService.createMakeUpGiftAsset(createMakeUpAssetRequest);
            Assert.assertEquals(createMakeUpGiftAssetResult.getCode(), 200);

            List<GiftAsset> giftAssetList =
                    gfAssetMapper.selectList(
                            new QueryWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, giftTemplateId).orderByDesc(GiftAsset::getCreatedAt));

            Assert.assertTrue(CollectionUtils.isNotEmpty(giftAssetList));
            giftAssetList.forEach(item -> {
                Assert.assertEquals(item.getState(), "RECEIVED");
                Assert.assertEquals(item.getType(), "MAKE_UP_GIFT");
            });
        } finally {
            deleteTemplateData();
        }
    }

    /**
     * 创建一个补偿礼包模板
     */
    public PlainResult<SaveGiftTemplateResponse> createMakeUpTemplete(SaveGiftTemplateRequest createGiftTemplateRequest) {

        PlainResult<SaveGiftTemplateResponse> createGiftTemplatePlainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<SaveGiftTemplateResponse>>() {

                    @Override
                    public PlainResult<SaveGiftTemplateResponse> doExecute() {
                        return giftTemplateRemoteService.saveCommonGiftTemplate(createGiftTemplateRequest);
                    }

                    @Override
                    public boolean handleResult(PlainResult<SaveGiftTemplateResponse> createGiftTemplatePlainResult) {
                        return createGiftTemplatePlainResult.getCode() == 200;
                    }
                }, 5, 100);
        return createGiftTemplatePlainResult;
    }
}

