/*
package com.youzan.test.apicase.yop.promotionRemoteService;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.form.PromotionForm;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

*/
/**
 * @program: bit-commerce
 * @description  批量创建活动
 * @author: tianning
 * @create: 2021-03-23 13:02
 **//*

public class BatchCreatePromotionTest extends TnBaseTest {

    @JSONData(value = "dataResource/apicase/yop/BatchCreatePromotionRequestData.json", key = "batchCreatePromotion")
    private PromotionForm batchCreatePromotion;

    @BeforeMethod
    public void beforeMethod() {
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        deletePresentActivityData();
    }

    */
/**
     * 正常用例
     *//*

    @Test
    public void createPromotionNormalTest() {
        try {
            List<PromotionForm> formList = new ArrayList<>();
            formList.add(batchCreatePromotion);
            PlainResult<List<Long>>  batchCreatePromotionResult = promotionRemoteService.batchCreatePromotion(formList);

            try {
                sleep(3000);
            } catch (Throwable e) {
                e.getMessage();
            }

            Assert.assertEquals(batchCreatePromotionResult.getCode(), 200);

            Assert.assertNotNull(batchCreatePromotionResult.getData());
        } finally {
            deletePresentActivityData();
            deleteTemplateDataActivity();
        }
    }

    */
/**
     * 异常用例--入参为null
     *//*

}
*/
