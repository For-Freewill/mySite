package com.youzan.test.yop.onlineOrder;

import com.youzan.api.common.response.PlainResult;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.yop.ConstructionParam;
import com.youzan.test.yop.YopBaseTest;
import com.youzan.yop.api.OrderRemoteService;
import com.youzan.yop.api.entity.order.OrderCreateApi;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.enums.AppStatusState;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * created by leifeiyun on 2020/1/2
 **/
public class buyOrderWithWscTest extends YopBaseTest {
    @Dubbo
    OrderRemoteService orderRemoteService;

    @Test(enabled = false)
    //因为2020的商品，在新系统还不支持，所以暂时不调试这个用例
    public void createOrderForWsc() {
        //创建微商城基础版
        OrderItemForm orderItemForm = ConstructionParam.getOrderItemForm(ItemInfo.WSC_JC_6800.getItemId(), 1);
        List<OrderItemForm> orderItemFormList = new ArrayList<>();
        orderItemFormList.add(orderItemForm);
        CreateOrderForm createOrderForm = ConstructionParam.getCreateOrderWithParam(wscKdtId, wscKdtName, orderItemFormList, 0L);
        PlainResult<OrderCreateApi> orderCreateApiPlainResult = orderRemoteService.createOrderV2(createOrderForm);
        Assert.assertEquals(orderCreateApiPlainResult.getCode(), 200);
        Assert.assertEquals(orderCreateApiPlainResult.getMessage(), "successful");
        if (orderCreateApiPlainResult.getCode() == 200) {
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(orderCreateApiPlainResult.getData().getPayOrderId(), (byte) 4);
            cashierPay(preparePayApiPlainResult, account, wscKdtId);
        }
        checkAppStatus(wscKdtId, AppStatusState.EFFECT, Calendar.YEAR, 1);

    }
}
