package com.youzan.test.apicase.bizConsole;

import com.alibaba.fastjson.JSONObject;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Http;
import com.youzan.test.quickstart.utils.HttpUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by baoyan on 5/27/21.
 */
public class PriceTest extends YunBaseTest {
    @Http("bizConsole")
    HttpUtil httpUtil;

    @Test
    public void PriceNormalTest(){
        Map<String,Object> offlineOrderPriceForm = new HashMap<>();
        offlineOrderPriceForm.put("kdtId","59929777");
        offlineOrderPriceForm.put("kdtName","库存型提单15711-1");
        offlineOrderPriceForm.put("userId",3046l);
        Map<String,Object> batchOrderItemFormV2 = new HashMap<>();
        batchOrderItemFormV2.put("itemId",4);
        batchOrderItemFormV2.put("quantity",1);
        batchOrderItemFormV2.put("buyType",1);
        batchOrderItemFormV2.put("applyKdtIdList",Arrays.asList(59929777l));
        batchOrderItemFormV2.put("appId",2);
        batchOrderItemFormV2.put("isBatchOrder",false);
        offlineOrderPriceForm.put("items", Arrays.asList(batchOrderItemFormV2));
        offlineOrderPriceForm.put("type",0);
        offlineOrderPriceForm.put("needAdminSign",(byte)0);
        offlineOrderPriceForm.put("needInvoice",true);
        String result = httpUtil.doPostReturnResponse("/order/price",offlineOrderPriceForm);
        JSONObject resultAfterParse = JSONObject.parseObject(result);
        Assert.assertEquals(resultAfterParse.getString("msg"),"操作成功");
        Assert.assertEquals(resultAfterParse.getString("code"),"0");

        Map dataValue = getMap(resultAfterParse.getString("data"));
        Assert.assertEquals(dataValue.get("totalPrice").toString(),"128800");
        Assert.assertEquals(dataValue.get("totalRealPrice").toString(),"128800");
    }
/*
    @Test
    public void PriceWithoutUserIdTest(){
        Map<String,Object> offlineOrderPriceForm = new HashMap<>();
        offlineOrderPriceForm.put("kdtId","59929777");
        offlineOrderPriceForm.put("kdtName","库存型提单15711-1");
        offlineOrderPriceForm.put("userId",3046l);
        Map<String,Object> batchOrderItemFormV2 = new HashMap<>();
        batchOrderItemFormV2.put("itemId",4);
        batchOrderItemFormV2.put("quantity",1);
        batchOrderItemFormV2.put("buyType",1);
        batchOrderItemFormV2.put("applyKdtIdList",Arrays.asList(59929777l));
        batchOrderItemFormV2.put("appId",2);
        batchOrderItemFormV2.put("isBatchOrder",false);
        offlineOrderPriceForm.put("items", null);
        offlineOrderPriceForm.put("type",0);
        offlineOrderPriceForm.put("needAdminSign",(byte)0);
        offlineOrderPriceForm.put("needInvoice",true);
        String result = httpUtil.doPostReturnResponse("/order/price",offlineOrderPriceForm);
*//*        JSONObject resultAfterParse = JSONObject.parseObject(result);
        Assert.assertEquals(resultAfterParse.getString("msg"),"操作成功");
        Assert.assertEquals(resultAfterParse.getString("code"),"0");

        Map dataValue = getMap(resultAfterParse.getString("data"));
        Assert.assertEquals(dataValue.get("totalPrice").toString(),"128800");
        Assert.assertEquals(dataValue.get("totalRealPrice").toString(),"128800");*//*
    }*/

    public  Map<String, Object> getMap(String json) {
        JSONObject jsonObject = JSONObject.parseObject(json);
        Map<String, Object> valueMap = new HashMap<String, Object>();
        valueMap.putAll(jsonObject);
        return valueMap;
    }
}
