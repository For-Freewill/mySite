package com.youzan.test.apicase.yop.promotionRemoteService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.request.InvalidPromotionV2Request;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @program: bit-commerce
 * @description 使营销失效
 * @author: tianning
 * @create: 2021-03-24 10:51
 **/
public class InvalidPromotionV2Test extends TnBaseTest {

    @Dubbo
    private PromotionRemoteService promotionRemoteService;

    /**
     * 正常用例
     */
    @Test
    public void invalidPromotionV2Test() {
        PlainResult<Long> createPromotionResult = null;
        try {
            InvalidPromotionV2Request invalidPromotionV2Request = new InvalidPromotionV2Request();
            invalidPromotionV2Request.setOperator("tianning");
            invalidPromotionV2Request.setPromotionType("ACTIVITY");

            createPromotionResult = createPromotion();

            invalidPromotionV2Request.setPromotionId(createPromotionResult.getData());

            PlainResult<Boolean> invalidPromotionV2Result = promotionRemoteService.invalidPromotionV2(invalidPromotionV2Request);

            Assert.assertEquals(invalidPromotionV2Result.getCode(), 200);
            Assert.assertTrue(invalidPromotionV2Result.getData());

            //查一下数据库
            List<MkActivity> mkActivityList =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, createPromotionResult.getData()));
            Assert.assertEquals(mkActivityList.get(0).getState(), "CANCELED");
        } finally {
            deletePresentCouponData();
        }
    }

    /**
     * 异常用例
     */
    @Test
    public void invalidPromotionV2PromotionIdNullTest() {
        InvalidPromotionV2Request invalidPromotionV2Request = new InvalidPromotionV2Request();
        invalidPromotionV2Request.setOperator("tianning");
        invalidPromotionV2Request.setPromotionType("ACTIVITY");
        invalidPromotionV2Request.setPromotionId(null);
        PlainResult<Boolean> invalidPromotionV2Result = promotionRemoteService.invalidPromotionV2(invalidPromotionV2Request);
        Assert.assertEquals(invalidPromotionV2Result.getCode(), 130102);
    }

    /**
     * 异常用例
     * 失效的不可编辑逻辑在前端控制的
     */
    @Test
    public void invalidPromotionV2PromotionTypeNullStringTest() {
        PlainResult<Long> createPromotionResult = null;
        try {
            InvalidPromotionV2Request invalidPromotionV2Request = new InvalidPromotionV2Request();
            invalidPromotionV2Request.setOperator("tianning");
            invalidPromotionV2Request.setPromotionType("");

            createPromotionResult = createPromotion();

            invalidPromotionV2Request.setPromotionId(createPromotionResult.getData());

            PlainResult<Boolean> invalidPromotionV2Result = promotionRemoteService.invalidPromotionV2(invalidPromotionV2Request);

            Assert.assertEquals(invalidPromotionV2Result.getCode(), 200);
            Assert.assertTrue(invalidPromotionV2Result.getData());

            //查一下数据库
            List<MkActivity> mkActivityList =
                    activityMapper.selectList(
                            new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, createPromotionResult.getData()));
            Assert.assertEquals(mkActivityList.get(0).getState(), "CANCELED");
        } finally {
            deletePresentCouponData();
        }
    }
}
