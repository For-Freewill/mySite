package com.youzan.test.offlineTrade.basecase.createOfflineOrderV2;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfScheme;
import com.youzan.commerce.test.mapper.perform.PfSchemeMapper;
import com.youzan.platform.push.api.stock.MsgSmsStockService;
import com.youzan.platform.push.api.stock.dto.StockInfoDTO;
import com.youzan.platform.push.api.stock.dto.StockQueryDTO;
import com.youzan.test.basecase.SimpleToolBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.MarketRemoteService;
import com.youzan.yop.api.entity.OfflineOrderFormV2;
import com.youzan.yop.api.form.order.OrderItemFormV2;
import com.youzan.yop.api.response.CreateOfflineOrderResponse;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.*;

/**
 * @author leifeiyun
 * @date 2021/3/24
 **/
public class CreateOfflineOrderV2Test extends SimpleToolBaseTest {
    @Dubbo
    MarketRemoteService marketRemoteService;

    @Dubbo
    MsgSmsStockService msgSmsStockService;

    @Autowired(required = false)
    PfSchemeMapper pfSchemeMapper;



    @JSONData("dataResource/basecase.createOrder/createOfflineOrderV2.json")
    OfflineOrderFormV2 offlineOrderFormV2;

    @JSONData("dataResource/basecase.createOrder/createOfflineOrderV2.json")
    OfflineOrderFormV2 offlineOrderFormV2Temp;

    Long wscKdtId = 58113442L;
    Long retailKdtId = 58819925L;
    Long beautyKdtId = 59434475L;
    Long eduKdtId = 54610673L;
    Long retailChainUnionKdtIdL=59510256L;
    Long retailChainUnionKdtIdD=59523536L;
    Long msgWscKdtId=59527310L;

    /**
     * 线下落单，微商城
     */
    @Test
    public void CreateOfflineOrderV2ForWsc() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(wscKdtId, Long.valueOf(ItemInfo.WSC_BD_680000_2021.getAppId()), "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(wscKdtId));

        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());

        checkAppStatusWithAppIs(wscKdtId, 1, 1, Collections.singletonList(ItemInfo.WSC_BD_680000_2021.getAppId()));

        refundOrderBatch(wscKdtId, Long.valueOf(ItemInfo.WSC_BD_680000_2021.getAppId()), "", "BY_VALUE", new Date());

    }


    /**
     * 线下落单，零售
     */
    @Test
    public void CreateOfflineOrderV2ForRetail() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(retailKdtId, Long.valueOf(ItemInfo.LS_ZFB_6800_2021.getAppId()), "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(retailKdtId));
        offlineOrderFormV2Temp.setKdtId(String.valueOf(retailKdtId));

        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.LS_ZFB_6800_2021.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setApplyKdtId(String.valueOf(retailKdtId));


        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);


        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());

        checkAppStatusWithAppIs(retailKdtId, 1, 1, Collections.singletonList(ItemInfo.LS_ZFB_6800_2021.getAppId()));

        refundOrderBatch(retailKdtId, Long.valueOf(ItemInfo.LS_ZFB_6800_2021.getAppId()), "", "BY_VALUE", new Date());

    }

    /**
     * 线下落单，美业
     */
    @Test
    public void CreateOfflineOrderV2ForBeauty() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(beautyKdtId, Long.valueOf(ItemInfo.BEAUTY_JC_6800.getAppId()), "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(beautyKdtId));
        offlineOrderFormV2Temp.setKdtId(String.valueOf(beautyKdtId));


        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.BEAUTY_JC_6800.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setApplyKdtId(String.valueOf(beautyKdtId));

        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);


        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());

        checkAppStatusWithAppIs(beautyKdtId, 1, 1, Collections.singletonList(ItemInfo.BEAUTY_JC_6800.getAppId()));

        refundOrderBatch(beautyKdtId, Long.valueOf(ItemInfo.BEAUTY_JC_6800.getAppId()), "", "BY_VALUE", new Date());

    }


    /**
     * 线下落单，教育
     */
    @Test
    public void CreateOfflineOrderV2ForEdu() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(eduKdtId, Long.valueOf(ItemInfo.EDU_BASE_ONLINE.getAppId()), "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(eduKdtId));
        offlineOrderFormV2Temp.setKdtId(String.valueOf(eduKdtId));
        offlineOrderFormV2Temp.setKdtName("edu-自动化-2-白200327");
        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.EDU_BASE_ONLINE.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setDuration(1);
//        orderItemFormV2.setApplyKdtIdList(Arrays.asList(eduKdtId));
        orderItemFormV2.setApplyKdtId(String.valueOf(eduKdtId));

        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);


        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());

        checkAppStatusWithAppIs(eduKdtId, 1, 1, Collections.singletonList(ItemInfo.EDU_BASE_ONLINE.getAppId()));

        refundOrderBatch(eduKdtId, Long.valueOf(ItemInfo.EDU_BASE_ONLINE.getAppId()), "", "BY_VALUE", new Date());

    }


    /**
     * 线下落单，零售连锁4.0L
     */
    @Test
    public void CreateOfflineOrderV2ForRetailChainUnionL() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(retailChainUnionKdtIdL, null, "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(retailChainUnionKdtIdL));
        offlineOrderFormV2Temp.setKdtId(String.valueOf(retailChainUnionKdtIdL));
        offlineOrderFormV2Temp.setKdtName("retailChain-自动化-1");
        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.RETAIL_CHAIN_L_4_UNION.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setDuration(1);
//        orderItemFormV2.setApplyKdtIdList(Arrays.asList(eduKdtId));
        orderItemFormV2.setApplyKdtId(String.valueOf(retailChainUnionKdtIdL));

        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);


        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());
        //yop:50566 ycm：atom_spu_retail_chain_4.0_ultimate 履约name：零售连锁（旗舰版）总部
        checkAppStatusWithAppIs(retailChainUnionKdtIdL, 1, 1, Collections.singletonList(50566));
        //验证生成两个合伙人方案
        List<PfScheme> schemes = pfSchemeMapper.selectList(new QueryWrapper<PfScheme>().eq("state","wait_perform")
        .eq("app_id","combine_spu_retail_chain_partner_meal")
        .eq("owner_id",retailChainUnionKdtIdL));

        Assert.assertEquals(schemes.size(),2);

        refundOrderBatch(retailChainUnionKdtIdL, null, "", "BY_VALUE", new Date());

    }

    /**
     * 线下落单，零售连锁4.0D
     */
    @Test
    public void CreateOfflineOrderV2ForRetailChainUnionD() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(retailChainUnionKdtIdD, null, "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(retailChainUnionKdtIdD));
        offlineOrderFormV2Temp.setKdtId(String.valueOf(retailChainUnionKdtIdD));
        offlineOrderFormV2Temp.setKdtName("wscChain-自动化-1");
        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.RETAIL_CHAIN_D_4_UNION.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setDuration(1);
//        orderItemFormV2.setApplyKdtIdList(Arrays.asList(eduKdtId));
        orderItemFormV2.setApplyKdtId(String.valueOf(retailChainUnionKdtIdD));

        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);


        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());
        //yop:50229 ycm：atom_spu_wsc_chain_mu_for_retail 履约name：零售连锁（旗舰版）总部
        checkAppStatusWithAppIs(retailChainUnionKdtIdD, 1, 1, Collections.singletonList(50229));
        //验证生成两个合伙人方案
        List<PfScheme> schemes = pfSchemeMapper.selectList(new QueryWrapper<PfScheme>().eq("state","wait_perform")
                .eq("app_id","combine_spu_wsc_chain_partner_meal")
                .eq("owner_id",retailChainUnionKdtIdD));

        Assert.assertEquals(schemes.size(),2);

        refundOrderBatch(retailChainUnionKdtIdD, null, "", "BY_VALUE", new Date());

    }

    /**
     * 线下落单，周期型插件
     */
    @Test
    public void CreateOfflineOrderV2ForRetailChainUnionDForCyclePlugin() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(retailChainUnionKdtIdD, null, "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(retailChainUnionKdtIdD));
        offlineOrderFormV2Temp.setKdtId(String.valueOf(retailChainUnionKdtIdD));
        offlineOrderFormV2Temp.setKdtName("wscChain-自动化-1");
        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.KANJIA_0_BUY.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setDuration(1);
//        orderItemFormV2.setApplyKdtIdList(Arrays.asList(eduKdtId));
        orderItemFormV2.setApplyKdtId(String.valueOf(retailChainUnionKdtIdD));

        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);


        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());
        checkAppStatusWithAppIs(retailChainUnionKdtIdD, 1, 1, Collections.singletonList(ItemInfo.KANJIA_0_BUY.getAppId()));


        refundOrderBatch(retailChainUnionKdtIdD, null, "", "BY_VALUE", new Date());

    }

    /**
     * 线下落单，库存型插件
     */
    @Test
    public void CreateOfflineOrderV2ForMsg() {

        long msgWscKdtId = newWscKdtId();

        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(msgWscKdtId));


        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.SMS_1000.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setApplyKdtId(String.valueOf(msgWscKdtId));


        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);



        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());

        try {
            //时间设置这么长是根据debug时间调试出来的，确实挺长了，不然退款不行
            Thread.sleep(60000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        StockQueryDTO stockQueryDTO = new StockQueryDTO();
        stockQueryDTO.setKdtId(msgWscKdtId);
        PlainResult<StockInfoDTO> result = msgSmsStockService.getStock(stockQueryDTO);
        Assert.assertEquals((long) result.getData().getTotalStock(), 1000, "短信库存不对");
        Assert.assertEquals((long) result.getData().getValidStock(), 1000, "短信库存不对");

        //充值库存后记得退款
        refundOrderBatch(msgWscKdtId, Long.valueOf(ItemInfo.SMS_1000.getAppId()),"","BY_VALUE",new Date());
    }


    /**
     * 线下落单，周期库存型插件
     */
    @Test
    public void CreateOfflineOrderV2ForPeriodCountPlugin() {
        PlainResult<CreateOfflineOrderResponse> orderCreateResult = new PlainResult<>();

        refundOrderBatch(wscKdtId, Long.valueOf(ItemInfo.STAFF_YEARS.getAppId()), "", "BY_VALUE", new Date());

        offlineOrderFormV2Temp = SerializationUtils.clone(this.offlineOrderFormV2);
        offlineOrderFormV2Temp.setKdtIdList(Arrays.asList(wscKdtId));

        //items设置
        OrderItemFormV2 orderItemFormV2 = new OrderItemFormV2();
        orderItemFormV2.setItemId(ItemInfo.STAFF_YEARS.getItemId());
        orderItemFormV2.setBuyType((byte) 1);
        orderItemFormV2.setQuantity(1);
        orderItemFormV2.setApplyKdtId(String.valueOf(wscKdtId));


        List<OrderItemFormV2> itemForms = new ArrayList<>();
        itemForms.add(orderItemFormV2);
        offlineOrderFormV2Temp.setItems(itemForms);


        orderCreateResult = marketRemoteService.createOfflineOrderV2(offlineOrderFormV2Temp);

        Assert.assertEquals(orderCreateResult.getCode(), 200, "创建订单失败：" + orderCreateResult.getMessage());
        Assert.assertEquals(orderCreateResult.getMessage(), "successful");
        Assert.assertNotNull(orderCreateResult.getData(), orderCreateResult.getMessage());

        try {
            //时间设置这么长是根据debug时间调试出来的，确实挺长了，不然退款不行
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        checkAppStatusWithAppIs(wscKdtId, 1, 1, Collections.singletonList(ItemInfo.STAFF_YEARS.getAppId()));

        //充值库存后记得退款
        refundOrderBatch(wscKdtId, Long.valueOf(ItemInfo.STAFF_YEARS.getAppId()),"","BY_VALUE",new Date());
    }






    @BeforeMethod
    public void beforeMethod(){
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

