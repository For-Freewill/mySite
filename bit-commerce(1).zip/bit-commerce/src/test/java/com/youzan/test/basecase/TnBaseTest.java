package com.youzan.test.basecase;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.dataprepare.driver.SimpleDriverService;
import com.youzan.commerce.test.dataprepare.util.DataUtil;
import com.youzan.commerce.test.entity.dataobject.market.MkJoinRecord;
import com.youzan.commerce.test.entity.dataobject.market.MkPresent;
import com.youzan.commerce.test.entity.dataobject.market.MkPresentGift;
import com.youzan.commerce.test.entity.dataobject.market.collocation.Collocation;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivity;
import com.youzan.commerce.test.entity.dataobject.market.collocation.MkActivityRule;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCoupon;
import com.youzan.commerce.test.entity.dataobject.market.coupon.MkCouponRule;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAsset;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftAssetGoods;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplate;
import com.youzan.commerce.test.entity.dataobject.market.gift.GiftTemplateGoods;
import com.youzan.commerce.test.entity.dataobject.market.plugin.MKRecommendPlugin;
import com.youzan.commerce.test.entity.dataobject.market.plugin.MKRecommendRule;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.mapper.market.*;
import com.youzan.commerce.test.mapper.market.collocation.ActivityMapper;
import com.youzan.commerce.test.mapper.market.collocation.ActivityRuleMapper;
import com.youzan.commerce.test.mapper.market.collocation.CollocationMapper;
import com.youzan.commerce.test.mapper.market.coupon.CouponAssetMapper;
import com.youzan.commerce.test.mapper.market.coupon.CouponMapper;
import com.youzan.commerce.test.mapper.market.coupon.CouponRuleMapper;
import com.youzan.commerce.test.mapper.market.gift.*;
import com.youzan.commerce.test.mapper.market.plugin.MKReconnendPluginMapper;
import com.youzan.commerce.test.mapper.market.plugin.MKReconnendRuleMapper;
import com.youzan.commerce.test.mapper.perform.*;
import com.youzan.commerce.test.mapper.trade.*;
import com.youzan.commerce.test.mapper.ycmJob.JbcJobMapper;
import com.youzan.commerce.test.mapper.ycmJob.JbcTaskMapper;
import com.youzan.commerce.test.mapper.yop.OpenApplicationItemPreferentionMapper;
import com.youzan.commerce.test.mapper.yop.OpenApplicationPromotionMapper;
import com.youzan.commerce.test.mapper.yop.PromotionActivityMappingMapper;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.BaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.ycm.gift.api.GiftAssetRemoteService;
import com.youzan.ycm.gift.api.GiftTemplateRemoteService;
import com.youzan.ycm.gift.request.SaveGiftTemplateRequest;
import com.youzan.ycm.gift.response.SaveGiftTemplateResponse;
import com.youzan.ycm.market.api.CollocationActivityRemoteService;
import com.youzan.ycm.market.api.GoodsDicountActivityuRemoteService;
import com.youzan.ycm.market.api.OrderFullReduceActivityRemoteService;
import com.youzan.ycm.market.api.RecommendRemoteService;
import com.youzan.ycm.market.dto.activity.CollocationActivityDTO;
import com.youzan.ycm.market.dto.rule.ItemFixedUnitPriceRuleDTO;
import com.youzan.ycm.market.request.activity.SaveCollocationActivityRequest;
import com.youzan.ycm.market.request.activity.SaveGoodsDiscountActivityRequest;
import com.youzan.ycm.market.request.activity.SaveOrderFullReduceActivityRequest;
import com.youzan.ycm.market.request.recommend.SaveRecommendPluginRequest;
import com.youzan.ycm.market.response.activity.SaveCollocationActivityResponse;
import com.youzan.ycm.market.response.activity.SaveGoodsDiscountActivityResponse;
import com.youzan.ycm.market.response.activity.SaveOrderFullReduceActivityResponse;
import com.youzan.yop.api.PromotionRemoteService;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.PromotionForm;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.request.SendPresentGiftRequest;
import org.junit.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static java.lang.Thread.sleep;

/**
 * 田宁专用的测试基类
 *
 * @author tianning
 * @date 2020/8/28 5:21 下午
 */
public class TnBaseTest extends BaseTest {
    @Rule
    public SimpleDriverService driverService = new SimpleDriverService();

    @Dubbo
    public GiftTemplateRemoteService giftTemplateRemoteService;
    @Dubbo
    public GiftAssetRemoteService giftAssetRemoteService;
    @Dubbo
    public PromotionRemoteService promotionRemoteService;
    @Dubbo
    public CollocationActivityRemoteService collocationActivityRemoteService;
    @Dubbo
    public RecommendRemoteService recommendRemoteService;
    @Dubbo
    public OrderFullReduceActivityRemoteService orderFullReduceActivityRemoteService;
    @Dubbo
    public GoodsDicountActivityuRemoteService goodsDicountActivityuRemoteService;

    @Autowired(required = false)
    public GfTemplateGoodsMapper gfTemplateGoodsMapper;
    @Autowired(required = false)
    public GfAssetMapper gfAssetMapper;
    @Autowired(required = false)
    public GfTemplateMapper gfTemplateMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gAssetGoodsMapper;
    @Autowired(required = false)
    public CollocationMapper collocationMapper;
    @Autowired(required = false)
    public ActivityMapper activityMapper;
    @Autowired(required = false)
    public ActivityRuleMapper activityRuleMapper;
    @Autowired(required = false)
    public TdOrderItemMapper tdOrderItemMapper;
    @Autowired(required = false)
    public TdPayOrderMapper tdPayOrderMapper;
    @Autowired(required = false)
    public PfOrderDetailActiveRecordMapper pfOrderDetailActiveRecordMapper;
    @Autowired(required = false)
    public TdSettleOrderMapper tdSettleOrderMapper;
    @Autowired(required = false)
    public PayRefundOrderMapper payRefundOrderMapper;
    @Autowired(required = false)
    public OrderItemRefundOrderMapper orderItemRefundOrderMapper;
    @Autowired(required = false)
    public PromotionResultDetailMapper promotionResultDetailMapper;
    @Autowired(required = false)
    public PresentRecordMapper presentRecordMapper;
    @Autowired(required = false)
    public DeductionResultCompositionMapper deductionResultCompositionMapper;
    @Autowired(required = false)
    public DeductionResultDetailMapper deductionResultDetailMapper;
    @Autowired(required = false)
    public GfAssetGoodsMapper gfAssetGoodsMapper;
    @Autowired(required = false)
    public JoinRecordMapper joinRecordMapper;
    @Autowired(required = false)
    public PfAssetDeductionMapper pfAssetDeductionMapper;
    @Autowired(required = false)
    public PfStockMapper pfStockMapper;
    @Autowired(required = false)
    public PfOrderStockMapper pfOrderStockMapper;
    @Autowired(required = false)
    public PfSchemeMapper pfSchemeMapper;
    @Autowired(required = false)
    public TdOrderMapper tdOrderMapper;
    @Autowired(required = false)
    public PfSchemeOrderRelationMapper pfSchemeOrderRelationMapper;
    @Autowired(required = false)
    public PfRechargeConfigMapper pfRechargeConfigMapper;
    @Autowired(required = false)
    public PfOrderMapper pfOrderMapper;
    @Autowired(required = false)
    public PfOrderDetailMapper pfOrderDetailMapper;
    @Autowired(required = false)
    public PfOrderStatusMapper pfOrderStatusMapper;
    @Autowired(required = false)
    public PfAssetMapper pfAssetMapper;
    @Autowired(required = false)
    public PromotionActivityMappingMapper promotionActivityMappingMapper;
    @Autowired(required = false)
    public CouponMapper couponMapper;
    @Autowired(required = false)
    public CouponRuleMapper couponRuleMapper;
    @Autowired(required = false)
    public CouponAssetMapper couponAssetMapper;
    @Autowired(required = false)
    public OpenApplicationPromotionMapper openApplicationPromotionMapper;
    @Autowired(required = false)
    public OpenApplicationItemPreferentionMapper openApplicationItemPreferentionMapper;

    @Autowired(required = false)
    public MkPresentMapper mkPresentMapper;
    @Autowired(required = false)
    public MkPresentGiftMapper mkPresentGiftMapper;

    @Autowired(required = false)
    public MKReconnendPluginMapper mkReconnendPluginMapper;
    @Autowired(required = false)
    public MKReconnendRuleMapper mkReconnendRuleMapper;

    @Autowired(required = false)
    public JbcJobMapper jbcJobMapper;
    @Autowired(required = false)
    public JbcTaskMapper jbcTaskMapper;

    @JSONData(value = "dataResource/apicase/yop/CreateOrderRequestData.json", key = "createOrderForm")
    private CreateOrderForm createOrderForm;

    @JSONData(value = "dataResource/apicase/yop/CreateGiftTempleteRequestData.json", key = "saveGiftTemplateRequest")
    private SaveGiftTemplateRequest saveGiftTemplateRequest;

    @JSONData(value = "dataResource/apicase/yop/SendPresentGiftRequestData.json", key = "ACTIVITYRequest")
    private SendPresentGiftRequest ACTIVITYRequest;

    @JSONData(value = "dataResource/apicase/yop/CreatePromotionRequestData.json", key = "createPromotion")
    private PromotionForm createPromotion;

    @JSONData(value = "dataResource/apicase/yop/CreatePromotionRequestData.json", key = "createPresentCoupon")
    private PromotionForm createPresentCoupon;

    @JSONData(value = "dataResource/basecase.collocation/SaveCollocationRequestData.json", key = "saveCollocationActivityRequest")
    private SaveCollocationActivityRequest saveCollocationActivityRequest;

    //通用的新建规则的入参，其实和normalRequest是一个接口，但是单独出来一个供其他异常场景调用
    @JSONData(value = "dataResource/apicase.market/recommendRemoteServiceData/saveRecommendPluginRequestDate.json", key = "commonRequest")
    private SaveRecommendPluginRequest commonRequest;

    @JSONData(value = "dataResource/basecase.gift/CreatePresentGiftRequestData.json", key = "createPresentGiftRequest")
    private SaveGiftTemplateRequest createPresentGiftRequest;

    //创建满减
    @JSONData(value = "dataResource/apicase.market/FullReductionRequestData.json", key = "fullReductionWithDiffLadderWithDiffAmountRequest")
    public SaveOrderFullReduceActivityRequest fullReductionWithDiffLadderWithDiffAmountRequest;

    //创建打折 配置2个商品 wsc+积分商城
    @JSONData(value = "dataResource/apicase.market/DiscountActivityRequestData.json", key = "createDiscountActivityRequest")
    public SaveGoodsDiscountActivityRequest createDiscountActivityRequest;

    //创建打折  一个商品多个打折规则
    @JSONData(value = "dataResource/apicase.market/DiscountActivityRequestData.json", key = "createDiscountActivityWithMoreRuleRequest")
    public SaveGoodsDiscountActivityRequest createDiscountActivityWithMoreRuleRequest;


    //持续集成使用的WSC店铺--接口用例查询专用
    public static Long WSCKQUERY = 58711819L;
    public static String WSCKQUERYS = "58711819";
    public static String WSCKQUERYNAME = "CI查询专用店铺";

    //礼包使用的店铺 做了数据清理
    public static Long GIFTKDTID = 58521537L;
    public static String GIFTKDT = "58521537";
    public static String GIFTKDTNAME = "回收礼包CI专用";

    //这个店铺不做数据清理，用来礼包相关的查询
    public static Long GIFTKDTID1 = 58821418L;
    public static String GIFTKDT1 = "58821418";
    public static String GIFTKDTNAME1 = "礼包CI田宁专用";

    //持续集成使用的WSC店铺--接口用例写接口专用
    public static Long WSCKDTIDCIWRITE = 58110324L;
    public static String WSCKDTCIWRITE = "58110324";
    public static String WSCKDTCIWRITENAME = "WSC单店CI专用--写接口";

    //教育单店店铺  基础版
    public static Long EDUKDTID = 59337178L;
    public static String EDUKDT = "59337178";
    public static String EDUKDTIDNAME = "CI测试";

    public static String account = "15558185304";

    public static String SPUID = "atom_spu_plugin_2020122312382544";
    public static String tipComment = "新建规则CI测试";
    public static String updateTipComment = "更新规则CI测试";


    //用来做礼包创建，发放，领取，回收专用的店铺。需要有一笔履约成功的数据一直存在，所以不做订单的数据清理，现在仅保存一笔订单数据
    public static Long PRESENTKDTID = 58820924L;
    public static String PRESENTKDTIDNAME = "买赠店铺-tn";

    public static String fullReductionName = "营销阶梯满减2000-20CI田宁专用-勿动";
    public static String fullReductionRuleName = "营销阶梯满减2000-20CI田宁专用-勿动规则";

    public static String discountName = "打折活动CI田宁专用-勿动";
    public static String discountRuleName = "打折活动CI田宁专用-勿动规则";

    @BeforeMethod
    public void beforeMethod(Method method) {
        List<Map<String, Object>> allCaseData = DataUtil.loadDataSource(method);
        if (com.alibaba.dubbo.common.utils.CollectionUtils.isNotEmpty(allCaseData)) {
            SimpleDriverService.param = allCaseData.get(0);
        }
    }

    /**
     * 根据店铺ID和订单状态查询td_order表数据
     */
    public List<TdOrder> queryTdOrderByKdtIdAndState(Long kdtid) {

        List<TdOrder> tdOrderRecords =
                tdOrderMapper.selectList(
                        new QueryWrapper<TdOrder>().lambda().eq(TdOrder::getBuyerId, kdtid).eq(TdOrder::getState, "PAID").orderByDesc(TdOrder::getCreatedAt));
        return tdOrderRecords;
    }

    /**
     * 根据td_no & AppCategory & performState 查询pf_order表数据
     */
    public List<PfOrder> queryPfOrder(Long kdtid) {

        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        List<TdOrder> tdOrderList = queryTdOrderByKdtIdAndState(kdtid);

        String td_no = tdOrderList.get(0).getTdNo();
        List<PfOrder> pfOrdferRecords =
                pfOrderMapper.selectList(
                        new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBizOrderId, td_no).eq(PfOrder::getAppCategory, "software_meal").eq(PfOrder::getPerformState, "performed").orderByDesc(PfOrder::getCreatedAt));
        return pfOrdferRecords;
    }

    /**
     * 创建一个礼包模板
     */
    public PlainResult<SaveGiftTemplateResponse> createGiftTemplete(SaveGiftTemplateRequest createGiftTemplateRequest) {

        PlainResult<SaveGiftTemplateResponse> createGiftTemplatePlainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<SaveGiftTemplateResponse>>() {

                    @Override
                    public PlainResult<SaveGiftTemplateResponse> doExecute() {
                        return giftTemplateRemoteService.saveCommonGiftTemplate(createGiftTemplateRequest);
                    }

                    @Override
                    public boolean handleResult(PlainResult<SaveGiftTemplateResponse> createGiftTemplatePlainResult) {
                        return createGiftTemplatePlainResult.getCode() == 200;
                    }
                }, 5, 100);
        return createGiftTemplatePlainResult;
    }

    /**
     * 批量删除产生的买赠活动
     */
    public void batchDeleteActivityByName() {
        String activityName = "买赠活动田宁专用-勿动";
        String activityRuleName = "买赠活动田宁专用-勿动规则";

        activityMapper.delete(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, activityName));
        activityRuleMapper.delete(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getRuleName, activityRuleName));
    }

    /**
     * 删除创建一笔买赠活动有关的所有数据
     */
    public void deletePresentActivityData() {
        String activityName = "买赠活动田宁专用-勿动";

        List<MkActivity> mkActivityList =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, activityName));
        if(mkActivityList.size()>0){
            mkActivityList.forEach(item -> {
                List<MkActivityRule> mkActivityRulesList =
                        activityRuleMapper.selectList(
                                new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, item.getId()));

                if(mkActivityRulesList.size()>0) {
                    //获取mk_present表数据，其中id是 mk_present表的actions大字段里的 presentId
                    String presentId = "";
                    JSONArray jsonArray = JSONArray.parseArray(mkActivityRulesList.get(0).getActions());
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    presentId = jsonObject.getString("presentId");
                    List<MkPresent> mkPresentsList =
                            mkPresentMapper.selectList(
                                    new QueryWrapper<MkPresent>().lambda().eq(MkPresent::getId, presentId));

                    Assert.assertNotNull(mkPresentsList);

                    //删除买赠类数据
                    mkPresentMapper.delete(new QueryWrapper<MkPresent>().lambda().eq(MkPresent::getId, presentId));
                    mkPresentGiftMapper.delete(new QueryWrapper<MkPresentGift>().lambda().eq(MkPresentGift::getPresentId, presentId));

                    //删除活动类数据
                    activityRuleMapper.delete(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, item.getId()));
                    joinRecordMapper.delete(new QueryWrapper<MkJoinRecord>().lambda().eq(MkJoinRecord::getMkId, item.getId()));
                }
                }
                );
            activityMapper.delete(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, activityName));
        }


    }

    /**
     * 创建一个买赠活动
     */
    public PlainResult<Long> createPromotion() {
        PlainResult<Long> createPromotionResult = promotionRemoteService.createPromotion(createPromotion);
        Assert.assertEquals(createPromotionResult.getMessage(), "successful");
        Assert.assertEquals(createPromotionResult.getCode(), 200);
        return createPromotionResult;
    }

    /**
     * 创建一个买赠券 不涉及双写，正常保留
     */
    public PlainResult<Long> createPresentCoupon() {
        PlainResult<Long> createPromotionResult = promotionRemoteService.createPresentCoupon(createPresentCoupon);
        Assert.assertEquals(createPromotionResult.getCode(), 200);
        return createPromotionResult;
    }

    /**
     * 删除创建一笔买赠券有关的所有数据
     */
    public void deletePresentCouponData() {
        String couponName = "买赠券田宁专用-勿动";
        List<MkCoupon> mkCouponList = couponMapper.selectList(
                new QueryWrapper<MkCoupon>().eq("name", couponName));

        if (mkCouponList.size() > 0) {
            mkCouponList.forEach(item -> {
                List<MkCouponRule> mkCouponRuleList = couponRuleMapper.selectList(
                        new QueryWrapper<MkCouponRule>().lambda().eq(MkCouponRule::getCouponId, item.getId()));
                //获取mk_present表数据，其中id是mk_present表的actions大字段里的 presentId
                mkCouponRuleList.forEach(itemRule -> {
                    String presentId = "";
                    JSONArray jsonArray = JSONArray.parseArray(itemRule.getActions());
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    presentId = jsonObject.getString("presentId");

                    List<MkPresent> mkPresentsList =
                            mkPresentMapper.selectList(
                                    new QueryWrapper<MkPresent>().lambda().eq(MkPresent::getId, presentId));

                    Assert.assertNotNull(mkPresentsList);

                    //删除买赠类数据
                    mkPresentMapper.delete(new QueryWrapper<MkPresent>().lambda().eq(MkPresent::getId, presentId));
                    mkPresentGiftMapper.delete(new QueryWrapper<MkPresentGift>().lambda().eq(MkPresentGift::getPresentId, presentId));

                    //删除券类数据
                    couponMapper.delete(new QueryWrapper<MkCoupon>().eq("id", item.getId()));
                    couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().eq("coupon_id", item.getId()));
                });
            });
        }
    }

    /**
     * 删除创建一笔满减或者打折活动有关的所有数据
     */
    public void deleteFullDeduceActivityData() {
        String activityName = "满减活动田宁CI失效活动专用-勿动";

        List<MkActivity> mkActivityList =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, activityName));
        if (mkActivityList.size() > 0) {
            mkActivityList.forEach(item -> {
                activityRuleMapper.delete(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, item.getId()));
            });
        }
        activityMapper.delete(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, activityName));
    }

    /**
     * 把生成的买赠活动数据置为失效状态
     */
    public void invalidPresentActivity(Long activityId) {
        activityMapper.update(null, new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId).set(MkActivity::getState, "CANCELED"));

        List<MkActivity> mkActivityLists =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId).orderByDesc(MkActivity::getCreated_at));
        mkActivityLists.forEach(item -> {
            Assert.assertEquals(item.getState(), "CANCELED");
        });
    }

    /**
     * 把生成的买赠券数据置为失效状态
     */
    public void couponInvalid(Long couponId) {
        couponMapper.update(null, new UpdateWrapper<MkCoupon>().lambda().eq(MkCoupon::getId, couponId).set(MkCoupon::getState, "CANCELED"));

        List<MkCoupon> mkCouponLists =
                couponMapper.selectList(
                        new QueryWrapper<MkCoupon>().lambda().eq(MkCoupon::getId, couponId).orderByDesc(MkCoupon::getCreatedAt));
        mkCouponLists.forEach(item -> {
            Assert.assertEquals(item.getState(), "CANCELED");
        });
    }

    /**
     * 把生成的满减活动数据置为失效状态
     */
    public void fullDeduceActivityInvalid(Long activityId) {
        List<MkActivity> mkActivityLists =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId).orderByDesc(MkActivity::getCreated_at));
        mkActivityLists.forEach(item -> {
            activityMapper.update(null, new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId).set(MkActivity::getState, "CANCELED"));
            Assert.assertEquals(item.getState(), "CANCELED");
        });
    }

    /**
     * 创建订单且支付成功，但是只是为了创建一笔完整的订单，目前是为了查询做入参使用
     */
    public PlainResult<String> createNormalOrder(CreateOrderForm createOrderForm, Long kdtidId) {
        rechargeShopBalance(kdtidId.toString(), 99999999);

        //1.如果有未关闭订单，先关闭
        closeWaitPayOrder(kdtidId);

        refundOrderByKdtId(kdtidId);

        createOrderForm.setKdtId(kdtidId);

        //2. 创建订单
        PlainResult<String> plainResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<String>>() {

                    @Override
                    public PlainResult<String> doExecute() {
                        return orderRemoteService.createNormalOrder(createOrderForm);
                    }

                    @Override
                    public boolean handleResult(PlainResult<String> plainResult) {
                        return plainResult.getCode() == 200;
                    }
                }, 5, 100);
        try {
            sleep(3000);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        Assert.assertEquals(plainResult.getCode(), 200);

        if (plainResult.getCode() == 200) {

            //3.预支付
            PlainResult<PreparePayApi> preparePayApiPlainResult = preparePay(Long.valueOf(plainResult.getData()), (byte) 4);
            Assert.assertEquals(preparePayApiPlainResult.getCode(), 200);

            //4.余额支付
            cashierPay(preparePayApiPlainResult, account, kdtidId);
        }
        return plainResult;
    }

    /**
     * 创建搭配购活动
     */
    public PlainResult<SaveCollocationActivityResponse> createCollocation() {
        PlainResult<SaveCollocationActivityResponse> saveCollocationResult = collocationActivityRemoteService.saveCollocation(saveCollocationActivityRequest);
        Assert.assertEquals(saveCollocationResult.getCode(), 200);
        return saveCollocationResult;
    }

    /**
     * 根据生成的活动ID删除搭配购
     */
    public void deleteCollocationByActivityId(String activityId) {
        collocationMapper.delete(new UpdateWrapper<Collocation>().lambda().eq(Collocation::getActivity_id, activityId));

        List<MkActivity> mkActivityList =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId));

        mkActivityList.forEach(item -> {
            List<MkActivityRule> mkActivityRulesList =
                    activityRuleMapper.selectList(
                            new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, item.getId()));
            mkActivityRulesList.forEach(itemRule -> {
                activityRuleMapper.delete(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getActivityId, item.getId()));
            });
            activityMapper.delete(new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId));
        });
    }

    /**
     * 把生成的搭配购置为失效状态
     */
    public void collocationInvalid(String activityId) {
        collocationMapper.update(null, new UpdateWrapper<Collocation>().lambda().eq(Collocation::getActivity_id, activityId).set(Collocation::getState, "CANCELED"));
        List<Collocation> collocationsLists =
                collocationMapper.selectList(
                        new QueryWrapper<Collocation>().lambda().eq(Collocation::getActivity_id, activityId));

        collocationsLists.forEach(item -> {
            Assert.assertEquals(collocationsLists.get(0).getState(), "CANCELED");
        });

        activityMapper.update(null, new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId).set(MkActivity::getState, "CANCELED"));

        List<MkActivity> mkActivityLists =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getId, activityId));
        mkActivityLists.forEach(item -> {
            Assert.assertEquals(item.getState(), "CANCELED");
        });
    }

    /**
     * 构建搭配购DTO
     */
    public CollocationActivityDTO buildCollocationDTO(String activity_id, String id) {
        CollocationActivityDTO collocationActivityDTO = new CollocationActivityDTO();
        collocationActivityDTO.setActivityId(activity_id);
        collocationActivityDTO.setCollocationID(id);
        collocationActivityDTO.setEffectTime("2020-09-01 00:00:00");
        collocationActivityDTO.setExpireTime("2040-09-01 00:00:00");
        collocationActivityDTO.setName("积分商城CI--勿动");
        collocationActivityDTO.setActivityDesc("积分商城CI--勿动");
        collocationActivityDTO.setChannel("YOUZAN");
        collocationActivityDTO.setJoinLimitType("WITH_ALL_APPS");


        List<String> userTags = new ArrayList<>();
        userTags.add("RENEW");
        collocationActivityDTO.setUserTags(userTags);
        collocationActivityDTO.setMainAppId(saveCollocationActivityRequest.getCollocationActivityDTOs().get(0).getMainAppId());
        collocationActivityDTO.setActivityState("EFFECTING");
        List<String> productChannels = new ArrayList<>();
        productChannels.add("WSC");
        collocationActivityDTO.setProductChannels(productChannels);

        List<ItemFixedUnitPriceRuleDTO> itemFixedUnitPriceRuleDTOList = new ArrayList<>();
        ItemFixedUnitPriceRuleDTO itemFixedUnitPriceRuleDTO = new ItemFixedUnitPriceRuleDTO();
        itemFixedUnitPriceRuleDTO.setAppId("atom_spu_point_store");
        itemFixedUnitPriceRuleDTO.setItemId("atom_sku_point_store_year");
        itemFixedUnitPriceRuleDTO.setQuantity(1L);
        itemFixedUnitPriceRuleDTO.setFixedUnitPrice(100L);

        itemFixedUnitPriceRuleDTOList.add(itemFixedUnitPriceRuleDTO);
        collocationActivityDTO.setItemFixedUnitPriceRuleDTOList(itemFixedUnitPriceRuleDTOList);

        return collocationActivityDTO;
    }

    /**
     * 批量删除产生的搭配购活动
     * 删除所有田宁生成的搭配购活动
     */
    public void batchDeleteCollocationByName() {
        String collocationName = "哈士奇搭配购微商城新增测试";
        String activityName = "哈士奇搭配购微商城新增测试";
        String activityRuleName = "哈士奇搭配购微商城新增测试 规则";

        activityMapper.delete(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, activityName));
        activityRuleMapper.delete(new QueryWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getRuleName, activityRuleName));
        collocationMapper.delete(new QueryWrapper<Collocation>().lambda().eq(Collocation::getCollocation_name, collocationName));
    }

    /**
     * 新建一个规则
     * 默认新建微商城扩展包
     */
    public PlainResult<Long> saveRule() {
        deleteRule(tipComment, SPUID);
        PlainResult<Long> saveResult = recommendRemoteService.save(commonRequest);
        Assert.assertEquals(saveResult.getMessage(), "successful");
        Assert.assertEquals(saveResult.getCode(), 200);
        return saveResult;
    }

    /**
     * 查询规则ID
     */
    public MKRecommendRule queryRuleId(String tipComment) {
        MKRecommendRule mkRecommendRule =
                mkReconnendRuleMapper.selectOne(new QueryWrapper<MKRecommendRule>().lambda()
                        .eq(MKRecommendRule::getTipComment, tipComment));
        return mkRecommendRule;
    }

    /**
     * 失效规则
     */
    public void invalidRuleId(String tipComment) {
        MKRecommendRule mkRecommendRule =
                mkReconnendRuleMapper.selectOne(new QueryWrapper<MKRecommendRule>().lambda()
                        .eq(MKRecommendRule::getTipComment, tipComment));
        mkReconnendRuleMapper.update(null, new UpdateWrapper<MKRecommendRule>().lambda().eq(MKRecommendRule::getTipComment, tipComment).set(MKRecommendRule::getState, "invalid"));
    }

    /**
     * 删除田宁CI新建的规则
     */
    public void deleteRule(String tipComment, String SPUID) {
        mkReconnendRuleMapper.delete(new QueryWrapper<MKRecommendRule>().lambda().eq(MKRecommendRule::getTipComment, tipComment));
        mkReconnendPluginMapper.delete(new QueryWrapper<MKRecommendPlugin>().lambda().eq(MKRecommendPlugin::getSpuId, SPUID));
    }

    /**
     * 删除买赠礼包模板
     */
    public void deleteTemplateData() {
        String name = "创建买赠礼包模板";
        String makeUpName = "创建买赠礼包模板";
        List<GiftTemplate> giftTemplateList =
                gfTemplateMapper.selectList(
                        new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, name).orderByDesc(GiftTemplate::getCreated_at));

        List<GiftTemplate> giftTemplateMakeUpList =
                gfTemplateMapper.selectList(
                        new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, makeUpName).orderByDesc(GiftTemplate::getCreated_at));

        if (giftTemplateList.size() > 0) {
            giftTemplateList.forEach(item -> {
                Long templateId = item.getId();
                gfAssetMapper.delete(new UpdateWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, templateId));
                gAssetGoodsMapper.delete(new UpdateWrapper<GiftAssetGoods>().lambda().eq(GiftAssetGoods::getAssetId, templateId));
                gfTemplateGoodsMapper.delete(new UpdateWrapper<GiftTemplateGoods>().lambda().eq(GiftTemplateGoods::getTemplate_id, templateId));
                gfTemplateMapper.delete(new UpdateWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getId, templateId));
            });
        }

        if (giftTemplateMakeUpList.size() > 0) {
            giftTemplateMakeUpList.forEach(itemUpMake -> {
                Long templateId = itemUpMake.getId();
                gfAssetMapper.delete(new UpdateWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, templateId));
                gAssetGoodsMapper.delete(new UpdateWrapper<GiftAssetGoods>().lambda().eq(GiftAssetGoods::getAssetId, templateId));
                gfTemplateGoodsMapper.delete(new UpdateWrapper<GiftTemplateGoods>().lambda().eq(GiftTemplateGoods::getTemplate_id, templateId));
                gfTemplateMapper.delete(new UpdateWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getId, templateId));
            });
        }
    }

    /**
     * 删除买赠礼包模板--名称为：买赠活动田宁专用-勿动
     */
    public void deleteTemplateDataActivity() {
        String name = "买赠活动田宁专用-勿动";
        List<GiftTemplate> giftTemplateList =
                gfTemplateMapper.selectList(
                        new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, name).orderByDesc(GiftTemplate::getCreated_at));


        if (giftTemplateList.size() > 0) {
            giftTemplateList.forEach(item -> {
                Long templateId = item.getId();
                gfAssetMapper.delete(new UpdateWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, templateId));
                gAssetGoodsMapper.delete(new UpdateWrapper<GiftAssetGoods>().lambda().eq(GiftAssetGoods::getAssetId, templateId));
                gfTemplateGoodsMapper.delete(new UpdateWrapper<GiftTemplateGoods>().lambda().eq(GiftTemplateGoods::getTemplate_id, templateId));
                gfTemplateMapper.delete(new UpdateWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getId, templateId));
            });
        }
    }

    /**
     * 删除买赠礼包模板--名称为：买赠券田宁专用-勿动
     */
    public void deleteTemplateDataCoupon() {
        String name = "买赠券田宁专用-勿动";
        List<GiftTemplate> giftTemplateList =
                gfTemplateMapper.selectList(
                        new QueryWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getName, name).orderByDesc(GiftTemplate::getCreated_at));


        if (giftTemplateList.size() > 0) {
            giftTemplateList.forEach(item -> {
                Long templateId = item.getId();
                gfAssetMapper.delete(new UpdateWrapper<GiftAsset>().lambda().eq(GiftAsset::getTemplateId, templateId));
                gAssetGoodsMapper.delete(new UpdateWrapper<GiftAssetGoods>().lambda().eq(GiftAssetGoods::getAssetId, templateId));
                gfTemplateGoodsMapper.delete(new UpdateWrapper<GiftTemplateGoods>().lambda().eq(GiftTemplateGoods::getTemplate_id, templateId));
                gfTemplateMapper.delete(new UpdateWrapper<GiftTemplate>().lambda().eq(GiftTemplate::getId, templateId));
            });
        }
    }

    /**
     * 创建满减活动，活动名称：营销满减CI田宁专用-勿动
     */
    public PlainResult<SaveOrderFullReduceActivityResponse> createFullReductionActivity() {
        PlainResult<SaveOrderFullReduceActivityResponse> saveOrderFullReduceActivityResult = orderFullReduceActivityRemoteService.saveActivity(fullReductionWithDiffLadderWithDiffAmountRequest);
        Assert.assertEquals(saveOrderFullReduceActivityResult.getCode(), 200);

        Assert.assertNotNull(saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId());

        List<MkActivity> mkActivityLists =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, fullReductionName).eq(MkActivity::getState, "AUDITED_PASS").orderByDesc(MkActivity::getCreated_at));
        Assert.assertEquals(mkActivityLists.get(0).getId().toString(), saveOrderFullReduceActivityResult.getData().getFullReduceActivityDTO().getActivityId());
        Assert.assertEquals(mkActivityLists.get(0).getState(), "AUDITED_PASS");
        return saveOrderFullReduceActivityResult;
    }

    /**
     * 失效满减活动
     */
    public void invalidFullReductionActivity() {

        List<MkActivity> mkActivityList = activityMapper.selectList(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, fullReductionName));
        if (mkActivityList.size() > 0) {
            mkActivityList.forEach(item -> {
                activityMapper.update(null, new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getName, fullReductionName).set(MkActivity::getState, "CANCELED"));
            });
        }

        List<MkActivity> mkActivityCanceledList = activityMapper.selectList(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, fullReductionName));
        mkActivityCanceledList.forEach(itemCancled -> {
            activityMapper.update(null, new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getName, fullReductionName).set(MkActivity::getState, "CANCELED"));
        });
    }

    /**
     * 删除满减活动
     */
    public void deleteFullReductionActivity() {
        activityMapper.delete(new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getName, fullReductionName));
        activityRuleMapper.delete(new UpdateWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getRuleName, fullReductionRuleName));
    }

    /**
     * 创建打折活动，活动名称：打折活动CI田宁专用-勿动
     * 配置：参与方式：WITH_ANY_APPS  次数：
     * 配置了两个商品  WSC+积分商城
     */
    public PlainResult<SaveGoodsDiscountActivityResponse> createDiscountActivity() {
        PlainResult<SaveGoodsDiscountActivityResponse> createDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(createDiscountActivityRequest);
        Assert.assertEquals(createDiscountActivityResult.getCode(), 200);

        Assert.assertNotNull(createDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId());

        List<MkActivity> mkActivityLists =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, discountName).eq(MkActivity::getState, "AUDITED_PASS").orderByDesc(MkActivity::getCreated_at));
        Assert.assertEquals(mkActivityLists.get(0).getId().toString(), createDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId());
        Assert.assertEquals(mkActivityLists.get(0).getState(), "AUDITED_PASS");
        return createDiscountActivityResult;
    }

    /**
     * 创建打折活动，活动名称：打折活动CI田宁专用-勿动
     * 配置：参与方式：WITH_ANY_APPS  次数：不限制
     * 一个商品多个打折规则
     */
    public PlainResult<SaveGoodsDiscountActivityResponse> createDiscountActivityWithMoreDiscountRule() {
        PlainResult<SaveGoodsDiscountActivityResponse> createDiscountActivityResult = goodsDicountActivityuRemoteService.saveActivity(createDiscountActivityWithMoreRuleRequest);
        Assert.assertEquals(createDiscountActivityResult.getCode(), 200);

        Assert.assertNotNull(createDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId());

        List<MkActivity> mkActivityLists =
                activityMapper.selectList(
                        new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, discountName).eq(MkActivity::getState, "AUDITED_PASS").orderByDesc(MkActivity::getCreated_at));
        Assert.assertEquals(mkActivityLists.get(0).getId().toString(), createDiscountActivityResult.getData().getGoodsDiscountActivityDTO().getActivityId());
        Assert.assertEquals(mkActivityLists.get(0).getState(), "AUDITED_PASS");
        return createDiscountActivityResult;
    }

    /**
     * 失效打折活动
     */
    public void invalidDiscountActivity() {

        List<MkActivity> mkActivityList = activityMapper.selectList(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, discountName));
        if (mkActivityList.size() > 0) {
            mkActivityList.forEach(item -> {
                activityMapper.update(null, new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getName, discountName).set(MkActivity::getState, "CANCELED"));
            });
        }

        List<MkActivity> mkActivityCanceledList = activityMapper.selectList(new QueryWrapper<MkActivity>().lambda().eq(MkActivity::getName, discountName));
        mkActivityCanceledList.forEach(itemCancled -> {
            activityMapper.update(null, new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getName, discountName).set(MkActivity::getState, "CANCELED"));
        });
    }

    /**
     * 删除打折活动
     */
    public void deleteDiscountActivity() {
        activityMapper.delete(new UpdateWrapper<MkActivity>().lambda().eq(MkActivity::getName, discountName));
        activityRuleMapper.delete(new UpdateWrapper<MkActivityRule>().lambda().eq(MkActivityRule::getRuleName, discountRuleName));
    }

    /**
     * 刷缓存
     */
/*    @Test
    public void main() {
        clearCache("58814450");
    }*/
}
