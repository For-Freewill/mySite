package com.youzan.test.market.basecase.coupon;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.market.coupon.*;
import com.youzan.commerce.test.mapper.market.coupon.*;
import com.youzan.commerce.test.utils.JsonCovertUntil;
import com.youzan.test.BaseTest;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.ycm.market.api.CouponRemoteService;
import com.youzan.ycm.market.dto.coupon.AllCouponDTO;
import com.youzan.ycm.market.dto.coupon.CouponAdmittanceExtDTO;
import com.youzan.ycm.market.dto.rule.GoodsDiscountRuleDTO;
import com.youzan.ycm.market.request.coupon.QueryCouponRequest;
import com.youzan.ycm.market.request.coupon.SaveCouponRequest;
import com.youzan.ycm.market.request.coupon.UpdateCouponBasicInfoRequest;
import com.youzan.ycm.market.request.coupon.UpdateCouponStateRequest;
import com.youzan.ycm.market.response.coupon.SaveCouponResponse;
import com.youzan.ycm.market.response.coupon.UpdateCouponBasicInfoResponse;
import com.youzan.ycm.market.response.coupon.UpdateCouponStateResponse;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;


/**
 * author:luohongshuo
 * create:2021/09/07
 */
public class UpdateCouponTest extends YunBaseTest {
    private static final Logger logger = LoggerFactory.getLogger(BaseTest.class);
    @Dubbo
    public CouponRemoteService couponRemoteService;

    @Autowired(required = false)
    private CouponRuleMapper couponRuleMapper;

    @Autowired(required = false)
    private CouponMapper couponMapper;

    @Autowired(required = false)
    private CouponSendRecordMapper couponSendRecordMapper;

    @Autowired(required = false)
    private CouponAssetMapper couponAssetMapper;

    @Autowired(required = false)
    private CouponSnapshotMapper couponSnapshotMapper;

    private String saveCouponRequestJsonPath = "src/test/resources/data/market/coupon/discountCouponRequest.json";
    private String couponNamePrefix = "sx编辑上架测试";
    private String couponName = couponNamePrefix + new Random().nextInt(10000);
    private String couponAppId = "atom_spu_plugin_2021011212044116";
    private String couponItemId = "atom_sku_2021011212044172_year";



    @BeforeMethod
    public void beforeMethod() {
        logger.info("before method 清理数据");
        deleteCouponByCouponNamePrefix(couponNamePrefix);
    }

    @Test
    public void UpdateCouponModifyTest() {

        //创建优惠券
        SaveCouponRequest saveCouponRequest = JsonCovertUntil.getObjectFromjson(saveCouponRequestJsonPath, SaveCouponRequest.class);
        AllCouponDTO allCouponDTO = saveCouponRequest.getAllCouponDTO();
        allCouponDTO.setName(couponName);
        List<GoodsDiscountRuleDTO> discountRuleList = new ArrayList<>();
        GoodsDiscountRuleDTO goodsDiscountRuleDTO = new GoodsDiscountRuleDTO();
        goodsDiscountRuleDTO.setAppId(couponAppId);
        goodsDiscountRuleDTO.setItemId(couponItemId);
        goodsDiscountRuleDTO.setDiscount(9000l);
        goodsDiscountRuleDTO.setMeetQuantity(1l);
        discountRuleList.add(goodsDiscountRuleDTO);
        allCouponDTO.getGoodsDiscountCouponExtDTO().setDiscountRuleList(discountRuleList);
        CouponAdmittanceExtDTO couponAdmittanceExtDTO = new CouponAdmittanceExtDTO();
        couponAdmittanceExtDTO.setBuyerTags(Arrays.asList("FIRST"));
        List<String> productChannel = new ArrayList<>();
        productChannel.add("WSC");
        productChannel.add("RETAIL");
        couponAdmittanceExtDTO.setProductChannels(productChannel);
        allCouponDTO.setCouponAdmittanceExtDTO(couponAdmittanceExtDTO);

        PlainResult<SaveCouponResponse> result1 = couponRemoteService.saveCoupon(saveCouponRequest);
        String couponId = result1.getData().getAllCouponDTO().getCouponId();
        Assert.assertTrue(result1.isSuccess(), "创建权益券失败！");
        logger.info("saveCoupon：{}" + JSONObject.toJSONString(result1));

        if (result1.getCode() == 200) {
            try {
                Thread.sleep(10000);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        //编辑优惠券
        UpdateCouponBasicInfoRequest updateCouponBasicInfoRequest = new UpdateCouponBasicInfoRequest();
        updateCouponBasicInfoRequest.setCouponId(couponId);
        updateCouponBasicInfoRequest.setName("sx编辑上架测试");
        updateCouponBasicInfoRequest.setCouponDesc("先编辑再上架");
        PlainResult<UpdateCouponBasicInfoResponse> result2 = couponRemoteService.updateCouponBasicInfo(updateCouponBasicInfoRequest);
        logger.info(JSON.toJSONString(result2));
        Assert.assertEquals(result2.getCode(), 200);

        //查询优惠券信息
        QueryCouponRequest queryCouponRequest = new QueryCouponRequest();
        queryCouponRequest.setCouponId(couponId);
        PlainResult<AllCouponDTO> result3 = couponRemoteService.queryCouponById(queryCouponRequest);
        logger.info(JSON.toJSONString(result3));
        Assert.assertEquals(result3.getCode(), 200);


        //优惠券状态变更
        UpdateCouponStateRequest updateCouponStateRequest = new UpdateCouponStateRequest();
        updateCouponStateRequest.setCouponId(couponId);
        //判断优惠券状态
        if (result3.getData().getCouponState() != "ONLINE") {
            updateCouponStateRequest.setCouponState("ONLINE");
        }
        PlainResult<UpdateCouponStateResponse> result4 = couponRemoteService.updateCouponState(updateCouponStateRequest);
        logger.info(JSON.toJSONString(result4));
        Assert.assertEquals(result4.getCode(), 200);


    }
    public void deleteCouponByCouponNamePrefix(String couponNamePrefixPrefix) {
        if (StringUtils.isEmpty(couponNamePrefixPrefix)) {
            return;
        }
        List<Long> couponIdList = couponMapper.selectList(new QueryWrapper<MkCoupon>().lambda()
                .likeRight(MkCoupon::getName, couponNamePrefixPrefix)).stream().map(MkCoupon::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(couponIdList)) {
            couponMapper.deleteBatchIds(couponIdList);
            couponRuleMapper.delete(new QueryWrapper<MkCouponRule>().lambda().in(MkCouponRule::getCouponId, couponIdList));
            couponSnapshotMapper.delete(new QueryWrapper<MkCouponSnapshot>().lambda().in(MkCouponSnapshot::getCouponId, couponIdList));
            couponSendRecordMapper.delete(new QueryWrapper<MkCouponSendRecord>().lambda().in(MkCouponSendRecord::getCouponId, couponIdList));
            couponAssetMapper.delete(new QueryWrapper<MkCouponAsset>().lambda().in(MkCouponAsset::getCouponId, couponIdList));
        }
    }


}
