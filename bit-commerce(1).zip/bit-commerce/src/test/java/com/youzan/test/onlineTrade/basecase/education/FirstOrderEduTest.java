package com.youzan.test.onlineTrade.basecase.education;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.youzan.api.common.response.PlainResult;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrder;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderDetail;
import com.youzan.commerce.test.entity.dataobject.perform.PfOrderStatus;
import com.youzan.commerce.test.entity.dataobject.trade.TdOrder;
import com.youzan.commerce.test.utils.AsynUtil;
import com.youzan.test.basecase.TnBaseTest;
import com.youzan.test.quickstart.annotation.JSONData;
import com.youzan.yop.api.entity.pay.PreparePayApi;
import com.youzan.yop.api.form.order.CreateOrderForm;
import com.youzan.yop.api.form.order.OrderItemForm;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.lang.Thread.sleep;

/**
 * @author tianning
 * @date 2020/8/27 2:19 下午
 * 教育单店订购基础版，且升级到专业版
 */
public class FirstOrderEduTest extends TnBaseTest {

    @JSONData(value = "dataResource/basecase.education/FirstOrderEduRequestData.json", key = "createOrderForm")
    private CreateOrderForm createOrderForm;
 /*   public static Long EDUKDTID = 60021386L;
    public static String EDUKDT = "60021386";*/
    public static String EDUKDTIDNAME = "JYCI使用店铺";

    public static String accountJY = "15558185323";


    /**
     * 购买基础版（有赞教育（2020）基础版 1年），然后升级到专业版
     * 校验点：教育单店服务期 专业版生效时间在基础版生效时间之后
     */

    @Test
    public void createOrderTest() {
     long  EDUKDTID = newEduKdtId();
     String EDUKDT = JSON.toJSONString(EDUKDTID);
     rechargeShopBalance(EDUKDT, 99999999);
     createOrderForm.setKdtId(EDUKDTID);


     /*   rechargeShopBalance(EDUKDT, 99999999);
        //如果有未付款订单，那么关闭
        closeWaitPayOrder(EDUKDTID);
        refundOrderByKdtId(EDUKDTID);
*/
        //订购基础版想
        PlainResult<Long> createOrderResult = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                new AsynUtil.HandleResultExecutor<PlainResult<Long>>() {

                    @Override
                    public PlainResult<Long> doExecute() {
                        return orderRemoteService.createOrder(createOrderForm);
                    }

                    @Override
                    public boolean handleResult(PlainResult<Long> plainResult) {
                        return plainResult.getCode() == 200;
                    }
                }, 5, 100);

        Assert.assertEquals(createOrderResult.getCode(), 200);

        if (createOrderResult.getCode() == 200) {

            PlainResult<PreparePayApi> orderResult = preparePay(createOrderResult.getData(), (byte) 4);

            cashierPay(orderResult, accountJY, EDUKDTID);

            try {
                sleep(4000);
            } catch (Throwable e) {
                e.printStackTrace();
            }

            //查一下第一次订购的礼包的表和履约的表，确认数据确实生成
            List<TdOrder> tdOrderList = queryTdOrderByKdtIdAndState(EDUKDTID);
            if (!(tdOrderList.size() > 0)) {
                tdOrderList = queryTdOrderByKdtIdAndState(EDUKDTID);
            }
            Assert.assertTrue(tdOrderList.size() > 0);
            String td_no = tdOrderList.get(0).getTdNo();

            if (td_no != null) {
                List<PfOrder> pfOrderRecords =
                        pfOrderMapper.selectList(
                                new QueryWrapper<PfOrder>().lambda().eq(PfOrder::getBizOrderId, td_no));
                List<PfOrderDetail> pfOrderDetailsListAll = new ArrayList();
                pfOrderRecords.forEach(item -> {
                    Long id = item.getId();
                    List<PfOrderDetail> pfOrderDetails =
                            pfOrderDetailMapper.selectList(
                                    new QueryWrapper<PfOrderDetail>().lambda().eq(PfOrderDetail::getPfOrderId, id));
                    pfOrderDetailsListAll.addAll(pfOrderDetails);
                });

                List<PfOrderStatus> pfOrderStatusListAll = new ArrayList();
                pfOrderRecords.forEach(itemStatus -> {
                    Long d = itemStatus.getId();
                    List<PfOrderStatus> pfOrderStatuses =
                            pfOrderStatusMapper.selectList(
                                    new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getPfOrderId, d));
                    pfOrderStatusListAll.addAll(pfOrderStatuses);
                });

                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.printStackTrace();
                }

                List<PfOrderStatus> orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", EDUKDTID).eq("level", "new_basic").eq("item_id", "atom_sku_edu_single_year").eq("group_type", "product_with_paid"));

                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.printStackTrace();
                }

                if (!(orderStatusListBasic.size() > 0)) {
                    orderStatusListBasic = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().eq("buy_kdt_id", EDUKDTID).eq("level", "new_basic").eq("item_id", "atom_sku_edu_single_year").eq("group_type", "product_with_paid").orderByDesc("expire_time"));
                }
                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
                Assert.assertTrue(orderStatusListBasic.size() > 0);

                //二次创建订单，进行升级
                CreateOrderForm continueOrderForm = new CreateOrderForm();
                List<OrderItemForm> orderItemForms = new ArrayList<>();
                OrderItemForm orderItemForm = new OrderItemForm();
                orderItemForm.setQuantity(1);
                orderItemForm.setBuyType((byte) 1);
                orderItemForm.setItemId(ItemInfo.EDU_PROFESSION_ONLINE.getItemId());
                orderItemForms.add(orderItemForm);

                continueOrderForm.setItems(orderItemForms);

                continueOrderForm.setKdtId(EDUKDTID);
                continueOrderForm.setUserId(8107334721L);
                continueOrderForm.setKdtName(EDUKDTIDNAME);

                PlainResult<Long> result2 = AsynUtil.getInstance().submitWithRetryWithHandleResult(
                        new AsynUtil.HandleResultExecutor<PlainResult<Long>>() {

                            @Override
                            public PlainResult<Long> doExecute() {
                                return orderRemoteService.createOrder(continueOrderForm);
                            }

                            @Override
                            public boolean handleResult(PlainResult<Long> result2) {
                                return result2.getCode() == 200;
                            }
                        }, 5, 100);

                Assert.assertEquals(result2.getCode(), 200);

                PlainResult<PreparePayApi> updateResult = preparePay(result2.getData(), (byte) 4);
                Assert.assertEquals(updateResult.getCode(), 200);

                cashierPay(updateResult, accountJY, EDUKDTID);

                try {
                    sleep(3000);
                } catch (Throwable e) {
                    e.printStackTrace();
                }

                // 取专业版软件的生效时间 升序排序，取第一个
                List<PfOrderStatus> orderStatusListProfession = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, EDUKDTID).eq(PfOrderStatus::getLevel, "profession").eq(PfOrderStatus::getItemId, "atom_sku_edu_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid"));
                if (!(orderStatusListProfession.size() > 0)) {
                    orderStatusListProfession = pfOrderStatusMapper.selectList(new QueryWrapper<PfOrderStatus>().lambda().eq(PfOrderStatus::getBuyKdtId, EDUKDTID).eq(PfOrderStatus::getLevel, "profession").eq(PfOrderStatus::getItemId, "atom_sku_edu_single_year").eq(PfOrderStatus::getGroupType, "product_with_paid").orderByDesc(PfOrderStatus::getEffectTime));
                }
                Assert.assertTrue(orderStatusListProfession.size() > 0);

                Date professionDate = orderStatusListProfession.get(0).getEffectTime();
                Date basicDate = orderStatusListBasic.get(0).getExpireTime();

                //比较两个版本软件的订单创建时间
//                Assert.assertTrue(professionDate.compareTo(basicDate) >= 0);
            }
        }
    }
}