package com.youzan.test.cloudService.apicase.yop;

import com.youzan.api.common.response.ListResult;
import com.youzan.test.basecase.yunServiceFee.YunBaseTest;
import com.youzan.test.quickstart.annotation.Dubbo;
import com.youzan.yop.api.AppStatusRemoteService;
import com.youzan.yop.api.request.ListAppStatusDetailRequest;
import com.youzan.yop.api.response.AppStatusDetailInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by wulei on 2021-01-04.
 * @大爷
 */
public class ListYcmAppStatusDetailTest extends YunBaseTest {
    @Dubbo
    public AppStatusRemoteService appStatusRemoteService;

    @Test
    public void listYcmAppStatusDetailNormalTest(){
        ListAppStatusDetailRequest listAppStatusDetailRequest = new ListAppStatusDetailRequest();
        listAppStatusDetailRequest.setAppId("atom_spu_retail_single");
        listAppStatusDetailRequest.setApplyKdtId(kdtIdForQuery.toString());
        ListResult<AppStatusDetailInfo> result =  appStatusRemoteService.listYcmAppStatusDetail(listAppStatusDetailRequest);
        logger.info(result.toString());
        Assert.assertEquals(result.getData().get(0).getAppId(),"combine_spu_retail_single");
        Assert.assertEquals(result.getData().get(0).getExpireTime(),getMaxExpiredTime(kdtIdForQuery,"atom_spu_retail_single"));
    }
}
