import json
import re
import os

if os.environ.has_key("runMethod"):
    path = os.environ["WORKSPACE"]+"/src/test/resources/testng/commerce-runMethod.xml"
    failedCasesStr = os.environ["runMethod"]
    failedCases = json.loads(failedCasesStr)
    failedCases.sort()
    newFailedCaseStr=""
    oldClazz=""
    oldMethods=""
    failedCaseStr = ""
    for failedCase in failedCases:
        clazz = failedCase[0:failedCase.rfind(".")]
        method = failedCase[failedCase.rfind(".")+1:len(failedCase)]
        if method == "*":
            failedCaseStr = "\n            <class name=\"" + clazz + "\"></class>"
            newFailedCaseStr = newFailedCaseStr + failedCaseStr
        else:
            method = "\n                    <include name=\"" + method + "\"></include>"
            if clazz !=oldClazz:
                failedCaseStr = ""
                oldMethods=""
                oldMethods = oldMethods+method
                failedCaseStr = "\n            <class name=\"" + clazz + "\">\n                <methods>"+oldMethods+"\n                </methods>\n            </class>"
                newFailedCaseStr = newFailedCaseStr + failedCaseStr
            else:
                if method in oldMethods:
                    continue
                newFailedCaseStr = newFailedCaseStr.replace(failedCaseStr,failedCaseStr.replace(oldMethods,oldMethods+method))
                failedCaseStr = failedCaseStr.replace(oldMethods,oldMethods+method);
                oldMethods = oldMethods+method
        oldClazz=clazz
    newFailedCaseStr = "        <classes>" + newFailedCaseStr + "\n        </classes>"
    print(newFailedCaseStr)
    def replace(filePath, failedCaseStr2 ):
        f=open(filePath,'r')
        alllines=f.readlines()
        f.close()
        f=open(filePath,'w+')
        for eachline in alllines:
            a=re.sub("<classes></classes>",failedCaseStr2,eachline)
            f.writelines(a)
        f.close()
    replace(path, newFailedCaseStr)
