import hudson.model.*
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


//全局变量
def jobUrl=params.jobUrl.trim();
def sc = params.sc.trim();
def line = params.line.trim();

stage 'retry'
node('master')  {
    if(jobUrl == ""){
        error("jobUrl不能为空!")
    }
    if(jobUrl.contains("shangyehua-jenkins")){
        jobUrl = jobUrl.replace("https","http")
    }
    println(jobUrl+"api/json")
    def jsonSlurper = new JsonSlurper()
    if(sc==""){
        def jobInfoStr = new URL(jobUrl+"api/json")
                .getText(connectTimeout: 5000,
                readTimeout: 10000,
                requestProperties: ['Content-Type': "application/json",
                                    'Connection': 'close'])
        //json格式化
        def jobInfo = jsonSlurper.parseText(jobInfoStr)
        for(action in jobInfo.actions){
            if(action.parameters!=null){
                for(parameter in action.parameters){
                    if(parameter.name=="sc"){
                        sc = parameter.value
                        break
                    }
                }
            }

        }
    }
    println(sc)
    if(sc == ""){
        error("无法获取sc!")
    }
    //获取job结果
    def jobResultStr = new URL(jobUrl+"/testReport/api/json")
            .getText(connectTimeout: 5000,
            readTimeout: 10000,
            requestProperties: ['Content-Type': "application/json",
                                'Connection': 'close'])

    def jobResult = jsonSlurper.parseText(jobResultStr)
    //  println(jobResult.suites.get(0).cases)
    List<String> methodList = new ArrayList<>();
    for(casez in jobResult.suites.get(0).cases){
        if(casez.status=="FAILED"||casez.status=="REGRESSION"){
            methodsStr = casez.className + "." + casez.name
            methodList.add(methodsStr)
        }
    }
    def failedCases = JsonOutput.toJson(methodList)
    println(failedCases)
    try {
        if (line=="ycm"){
            build job: 'bit-commerce', parameters:
            [string(name: 'runMethod', value: failedCases),
             string(name: 'TestFile', value: 'runMethod'),
             string(name: 'sc', value: sc)]
        }else if(line=="crm"){
            build job: 'crm-sales-web-base', parameters:
            [string(name: 'runMethod', value: failedCases),
            string(name: 'testfile', value: 'runMethod'),
            string(name: 'type', value: '失败重试用例'),
            string(name: 'sc', value: sc)]
        }
    }catch (Exception err) {
        currentBuild.result = 'SUCCESS'
    }
}
